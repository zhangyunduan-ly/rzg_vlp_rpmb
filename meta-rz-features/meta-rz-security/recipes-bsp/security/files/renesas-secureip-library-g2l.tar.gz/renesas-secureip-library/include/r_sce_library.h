
/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name    : r_sce_library.h
 * Description  : header for RZG2L SCE
***********************************************************************************************************************/
#include <stdint.h>
#include <stddef.h>

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#ifndef R_SCE_LIBRARY_H
#define R_SCE_LIBRARY_H

#define R_SCE_CFG_BASE        (0x11850000)
#define R_SCE_CFG_SIZE        (0x10000)
#define R_SCE_CFG_SRAM_SIZE   (80)
#define R_SCE_CFG_SHEAP_SIZE  (5984)
#define R_SCE_CFG_SINST2_SIZE (64)

/**********************************************************************************************************************
 Global Typedef definitions
 *********************************************************************************************************************/
/* Return error codes fsp */
typedef enum e_fsp_err
{
    FSP_SUCCESS = 0,

    /* Start of Crypto specific (0x10000) @note Refer to sf_cryoto_err.h for Crypto error code. */
    FSP_ERR_CRYPTO_CONTINUE              = 0x10000,  ///< Continue executing function
    FSP_ERR_CRYPTO_SCE_RESOURCE_CONFLICT = 0x10001,  ///< Hardware resource busy
    FSP_ERR_CRYPTO_SCE_FAIL              = 0x10002,  ///< Internal I/O buffer is not empty
    FSP_ERR_CRYPTO_SCE_HRK_INVALID_INDEX = 0x10003,  ///< Invalid index
    FSP_ERR_CRYPTO_SCE_RETRY             = 0x10004,  ///< Retry
    FSP_ERR_CRYPTO_SCE_VERIFY_FAIL       = 0x10005,  ///< Verify is failed
    FSP_ERR_CRYPTO_SCE_ALREADY_OPEN      = 0x10006,  ///< HW SCE module is already opened
    FSP_ERR_CRYPTO_NOT_OPEN              = 0x10007,  ///< Hardware module is not initialized
    FSP_ERR_CRYPTO_UNKNOWN               = 0x10008,  ///< Some unknown error occurred
    FSP_ERR_CRYPTO_NULL_POINTER          = 0x10009,  ///< Null pointer input as a parameter
    FSP_ERR_CRYPTO_NOT_IMPLEMENTED       = 0x1000a,  ///< Algorithm/size not implemented
    FSP_ERR_CRYPTO_RNG_INVALID_PARAM     = 0x1000b,  ///< An invalid parameter is specified
    FSP_ERR_CRYPTO_RNG_FATAL_ERROR       = 0x1000c,  ///< A fatal error occurred
    FSP_ERR_CRYPTO_INVALID_SIZE          = 0x1000d,  ///< Size specified is invalid
    FSP_ERR_CRYPTO_INVALID_STATE         = 0x1000e,  ///< Function used in an valid state
    FSP_ERR_CRYPTO_ALREADY_OPEN          = 0x1000f,  ///< control block is already opened
    FSP_ERR_CRYPTO_INSTALL_KEY_FAILED    = 0x10010,  ///< Specified input key is invalid.
    FSP_ERR_CRYPTO_AUTHENTICATION_FAILED = 0x10011,  ///< Authentication failed
    FSP_ERR_CRYPTO_SCE_KEY_SET_FAIL      = 0x10012,  ///< Failure to Init Cipher
    FSP_ERR_CRYPTO_SCE_AUTHENTICATION    = 0x10013,  ///< Authentication failed
    FSP_ERR_CRYPTO_SCE_PARAMETER         = 0x10014,  ///< Input date is illegal.
    FSP_ERR_CRYPTO_SCE_PROHIBIT_FUNCTION = 0x10015,  ///< An invalid function call occurred.

    /* Start of SF_CRYPTO specific */
    FSP_ERR_CRYPTO_COMMON_NOT_OPENED      = 0x20000, ///< Crypto Framework Common is not opened
    FSP_ERR_CRYPTO_HAL_ERROR              = 0x20001, ///< Cryoto HAL module returned an error
    FSP_ERR_CRYPTO_KEY_BUF_NOT_ENOUGH     = 0x20002, ///< Key buffer size is not enough to generate a key
    FSP_ERR_CRYPTO_BUF_OVERFLOW           = 0x20003, ///< Attempt to write data larger than what the buffer can hold
    FSP_ERR_CRYPTO_INVALID_OPERATION_MODE = 0x20004, ///< Invalid operation mode.
    FSP_ERR_MESSAGE_TOO_LONG              = 0x20005, ///< Message for RSA encryption is too long.
    FSP_ERR_RSA_DECRYPTION_ERROR          = 0x20006, ///< RSA Decryption error.
} fsp_err_t;


/**********************************************************************************************************************
 External global variables
 *********************************************************************************************************************/
/* memory area for SCE procedure */
extern volatile uint32_t * gp_sce;
extern uint32_t S_RAM[];
extern uint32_t S_HEAP[];
extern uint32_t S_INST2[];

/**********************************************************************************************************************
 Exported global functions
 *********************************************************************************************************************/
/*  procedure I/F */
/*  INIT */
extern void R_SCE_SoftwareResetSub (void);                                              /* software reset   ROM */
extern fsp_err_t R_SCE_SelfCheck2Sub (void);
extern fsp_err_t R_SCE_SetSecurityIdSub (void);
extern fsp_err_t R_SCE_CreateExpJtagPassSub (uint32_t *InData_SharedKeyIndex, uint32_t *InData_SessionKey,
        uint32_t *InData_IV, uint32_t *InData_EncAuthData, uint32_t *OutData_Hash);
extern fsp_err_t R_SCE_StateCheckSub(uint32_t *fsm2_number);

/*  Key Update Key Install */
extern fsp_err_t R_SCE_InstallKeyringUpdateKeySub(uint32_t *InData_SharedKeyIndex, uint32_t *InData_SessionKey, uint32_t *InData_IV, uint32_t *InData_InstData, uint32_t *OutData_InstData);

/*  Random */
extern fsp_err_t R_SCE_GenerateRandomNumberSub (uint32_t* OutData_Text);                /* 128bit Random Number Generation */

/*  Key (AES) */
extern fsp_err_t R_SCE_InstallAes128UserKeySub (uint32_t *InData_SharedKeyIndex, uint32_t *InData_SessionKey, uint32_t *InData_IV, uint32_t *InData_InstData, uint32_t *OutData_KeyIndex);  /* Install 128bit AES Key */
extern fsp_err_t R_SCE_GenerateAes128RandomKeyIndexSub (uint32_t *OutData_KeyIndex);    /* Create 128bit AES Key */
extern fsp_err_t R_SCE_GenerateAes256RandomKeyIndexSub (uint32_t *OutData_KeyIndex);    /* Create 256bit AES Key */
extern fsp_err_t R_SCE_AES128_EncryptedKeyWrapSub(uint32_t *InData_IV, uint32_t *InData_InstData, uint32_t *OutData_KeyIndex); /* Update 128bit AES Key */
extern fsp_err_t R_SCE_AES256_EncryptedKeyWrapSub(uint32_t *InData_IV, uint32_t *InData_InstData, uint32_t *OutData_KeyIndex); /* Update 256bit AES Key */

/*  AES-128 ECB/CBC/CTR */
extern fsp_err_t R_SCE_Aes128EncryptDecryptInitSub (uint32_t *InData_Cmd, uint32_t *InData_KeyIndex, uint32_t *InData_IV);  /* AES-128 Encryption/Decryption with ECB/CBC Mode Init ROM */
extern void R_SCE_Aes128EncryptDecryptUpdateSub (uint32_t *InData_Text, uint32_t *OutData_Text, uint32_t MAX_CNT);          /* AES-128 Encryption/Decryption with ECB/CBC Mode Update ROM */
extern fsp_err_t R_SCE_Aes128EncryptDecryptFinalSub (void);                                                                 /* AES-128 Encryption/Decryption with ECB/CBC Mode Final ROM */

/*  AES-256 ECB/CBC/CTR */
extern fsp_err_t R_SCE_Aes256EncryptDecryptInitSub (const uint32_t * InData_Cmd, const uint32_t * InData_KeyIndex, const uint32_t * InData_IV); /* AES-256 Encryption/Decryption with ECB/CBC/CTR Mode Init */
extern void R_SCE_Aes256EncryptDecryptUpdateSub (const uint32_t * InData_Text, uint32_t * OutData_Text, const uint32_t MAX_CNT);                /* AES-256 Encryption/Decryption with ECB/CBC/CTR Mode Update */
extern fsp_err_t R_SCE_Aes256EncryptDecryptFinalSub (void);                                                                                     /* AES-256 Encryption/Decryption with ECB/CBC/CTR Mode Final */

/*  AES-128 CMAC */
extern fsp_err_t R_SCE_Aes128CmacInitSub (uint32_t *InData_KeyIndex);                                           /* AES-128 CMAC generation/verification Init */
extern void R_SCE_Aes128CmacUpdateSub (uint32_t *InData_Text, uint32_t MAX_CNT);                                /* AES-128 CMAC generation/verification Update */
extern fsp_err_t R_SCE_Aes128CmacFinalSub (uint32_t *InData_Cmd, uint32_t *InData_Text, uint32_t *InData_DataT, uint32_t *InData_DataTLen, uint32_t *OutData_DataT);    /* AES-128 CMAC generation/verification Final */

/*  AES-256 CMAC */
extern fsp_err_t R_SCE_Aes256CmacInitSub (uint32_t *InData_KeyIndex);                                               /* AES-256 CMAC generation/verification Init */
extern void R_SCE_Aes256CmacUpdateSub (uint32_t *InData_Text, uint32_t MAX_CNT);                                    /* AES-256 CMAC generation/verification Update */
extern fsp_err_t R_SCE_Aes256CmacFinalSub (uint32_t *InData_Cmd, uint32_t *InData_Text, uint32_t *InData_DataT, uint32_t *InData_DataTLen, uint32_t *OutData_DataT);    /* AES-256 CMAC generation/verification Final */

/*  Key (RSA) */
extern fsp_err_t R_SCE_GenerateRsa1024RandomKeyIndexSub (uint32_t MAX_CNT, uint32_t *OutData_PubKeyIndex, uint32_t *OutData_PrivKeyIndex);  /* RSA-1024 Key Pair Generation */
extern fsp_err_t R_SCE_GenerateRsa2048RandomKeyIndexSub (uint32_t MAX_CNT, uint32_t *OutData_PubKeyIndex, uint32_t *OutData_PrivKeyIndex);  /* RSA-2048 Key Pair Generation */
extern fsp_err_t R_SCE_RSA1024_EncryptedPublicKeyWrapSub (uint32_t *InData_IV, uint32_t *InData_InstData, uint32_t *OutData_KeyIndex);      /* Update 1024bit RSA Public Key */
extern fsp_err_t R_SCE_RSA1024_EncryptedPrivateKeyWrapSub (uint32_t *InData_IV, uint32_t *InData_InstData, uint32_t *OutData_KeyIndex);     /* Update 1024bit RSA Private Key */
extern fsp_err_t R_SCE_RSA2048_EncryptedPublicKeyWrapSub (uint32_t *InData_IV, uint32_t *InData_InstData, uint32_t *OutData_KeyIndex);      /* Update 2048bit RSA Public Key */
extern fsp_err_t R_SCE_RSA2048_EncryptedPrivateKeyWrapSub (uint32_t *InData_IV, uint32_t *InData_InstData, uint32_t *OutData_KeyIndex);     /* Update 2048bit RSA Private Key */
extern fsp_err_t R_SCE_RSA4096_EncryptedPublicKeyWrapSub (uint32_t *InData_IV, uint32_t *InData_InstData, uint32_t *OutData_KeyIndex);      /* Update 4096bit RSA Public Key */

/*  RSA (1024/2048/4096) */
extern fsp_err_t R_SCE_Rsa1024ModularExponentEncryptSub (const uint32_t *InData_KeyIndex, const uint32_t *InData_Text, uint32_t *OutData_Text); /* RSA1024 Encryption with Public Key */
extern fsp_err_t R_SCE_Rsa1024ModularExponentDecryptSub (uint32_t *InData_KeyIndex, const uint32_t *InData_Text, uint32_t *OutData_Text);       /* RSA1024 Decryption with Private Key */
extern fsp_err_t R_SCE_Rsa2048ModularExponentEncryptSub (const uint32_t *InData_KeyIndex, const uint32_t *InData_Text, uint32_t *OutData_Text); /* RSA2048 Encryption with Public Key */
extern fsp_err_t R_SCE_Rsa2048ModularExponentDecryptSub (uint32_t *InData_KeyIndex, const uint32_t *InData_Text, uint32_t *OutData_Text);       /* RSA2048 Decryption with Private Key */
extern fsp_err_t R_SCE_Rsa4096ModularExponentEncryptSub (const uint32_t *InData_KeyIndex, uint32_t *InData_Text, uint32_t *OutData_Text);       /* RSA2048 Decryption with Private Key */

/*  Message Digest */
extern fsp_err_t R_SCE_Sha224256GenerateMessageDigestSub (const uint32_t *InData_SHA_InitVal, const uint32_t *InData_PaddedMsg, const uint32_t MAX_CNT, uint32_t *OutData_MsgDigest);   /* SHA-256 Message Digest Generation ROM */

/*  Key (ECC) */
extern fsp_err_t R_SCE_GenerateEccRandomKeyIndexSub (uint32_t *InData_CurveType, uint32_t *InData_Cmd, uint32_t *OutData_PubKeyIndex, uint32_t *OutData_PrivKeyIndex);  /* 192/224/256bit ECC Key Pair Generation */
extern fsp_err_t R_SCE_ECC192224256_EncryptedPublicKeyWrapSub (uint32_t *InData_CurveType, uint32_t *InData_Cmd, uint32_t *InData_IV, uint32_t *InData_InstData, uint32_t *OutData_KeyIndex);                             /* Update P-192/224/256 ECC Public key */
extern fsp_err_t R_SCE_ECC192224256_EncryptedPrivateKeyWrapSub (uint32_t *InData_CurveType, uint32_t *InData_Cmd, uint32_t *InData_IV, uint32_t *InData_InstData, uint32_t *OutData_KeyIndex);                            /* Update P-192/224/256 ECC Private key */
extern fsp_err_t R_SCE_GenerateEccP512RandomKeyIndexSub (uint32_t *OutData_PubKeyIndex, uint32_t *OutData_PrivKeyIndex);                                                /* 512bit ECC Key Pair Generation */
extern fsp_err_t R_SCE_ECC_BrainpoolP512r1_EncryptedPublicKeyWrapSub (uint32_t *InData_IV, uint32_t *InData_InstData, uint32_t *OutData_KeyIndex);                      /* Update P-512 ECC Public key */
extern fsp_err_t R_SCE_ECC_BrainpoolP512r1_EncryptedPrivateKeyWrapSub (uint32_t *InData_IV, uint32_t *InData_InstData, uint32_t *OutData_KeyIndex);                     /* Update P-512 ECC Private key */

/*  ECDSA/ECC (192/224/256) */
extern fsp_err_t R_SCE_EcdsaSignatureGenerateSub (uint32_t *InData_CurveType, uint32_t *InData_Cmd, uint32_t *InData_KeyIndex, uint32_t *InData_MsgDgst, uint32_t *OutData_Signature);      /* 192/224/256bit ECDSA Signature Generation */
extern fsp_err_t R_SCE_EcdsaSignatureVerificationSub (uint32_t *InData_CurveType, uint32_t *InData_Cmd, uint32_t *InData_KeyIndex, uint32_t *InData_MsgDgst, uint32_t *InData_Signature);   /* 192/224/256bit ECDSA Signature Verification */
extern fsp_err_t R_SCE_EcdsaP512SignatureGenerateSub (uint32_t *InData_KeyIndex, uint32_t *InData_MsgDgst, uint32_t *OutData_Signature);                                                    /* 512bit ECDSA Signature Generation */
extern fsp_err_t R_SCE_EcdsaP512SignatureVerificationSub (uint32_t *InData_KeyIndex, uint32_t *InData_MsgDgst, uint32_t *InData_Signature);                                                 /* 512bit ECDSA Signature Verification */

extern uint32_t change_endian_long (volatile uint32_t value);


#endif /* R_SCE_LIBRARY_H */
