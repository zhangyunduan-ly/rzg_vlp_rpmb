#
# Copyright (c) 2025 Renesas Electronics Corporation. All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause
#

import argparse
from Crypto.PublicKey import ECC
from Crypto.Signature import DSS, pss
from Crypto.Hash import SHA256, SHA3_256, SHA3_384, SHA384
from Crypto.PublicKey import RSA
from Crypto.Cipher import AES


# ======================================================================================================================
# Private constant valiables
# ======================================================================================================================
# Error message print
ERRMSG = print
ERRMSG_OPENFAIL = 'verify_certificate.py : error: File open failed : %s'

# Certificate distinction
DISTINCTION_KCERT = "Key"
DISTINCTION_CCERT = "Code"
KCERT_MAGIC_BIG = '6b657963'
KCERT_MAGIC_LITTLE = '6379656b'
CCERT_MAGIC_BIG = '636f6463'
CCERT_MAGIC_LITTLE = '63646f63'

TLV_MAGIC_START = 0
TLV_MAGIC_END = 4

# Hash algorithm
HASH_START_BIT =8
HASH_END_BIT =18
SIGNATURE_HASH_START_BIT = 18
SIGNATURE_HASH_END_BIT = 22
HASH_TYPE_START_BIT = 4
HASH_TYPE_END_BIT = 8
SHA_2_256_STR = "SHA2-256"
SHA_2_384_STR = "SHA2-384"
SHA_3_256_STR = "SHA3-256"
SHA_3_384_STR = "SHA3-384"
SIGNATURE_SHA_2_256_FILED = 1
SIGNATURE_SHA_2_384_FILED = 2
SIGNATURE_SHA_3_256_FILED = 5
SIGNATURE_SHA_3_384_FILED = 6
SHA_2_256_FILED = 81
SHA_2_384_FILED = 82
SHA_3_256_FILED = 85
SHA_3_384_FILED = 86

# Hash Type
HASH_IMG_PUBKEY = 0
HASH_IMG = 1
HASH_ENCRYPTIONIMG = 2

# Signature algorithm
ECDSA_P256 = 'P-256'
ECDSA_P384 = 'P-384'
RSA_2048 = 'RSA'
RSA_PSS = 'RSA-PSS'
ECDSA_P256_ALGORITHM_FIELD = 34
ECDSA_P384_ALGORITHM_FIELD = 35
RSA2048_ALGORITHM_FIELD = 17
RSA_PSS_SCHEME_FIELD = 1
ALGORITHM_START_BIT = 8
ALGORITHM_END_BIT = 18
RSA_SCHEME_START_BIT = 22
RSA_SCHEME_END_BIT = 24
SIGNATURE_TYPE_START_BIT = 4
SIGNATURE_TYPE_END_BIT = 8
ECDSA_P256_STR = "ECDSA-P256"
ECDSA_P384_STR = "ECDSA-P384"
AES_128_STR = 'AES'
CBC_STR ='-CBC'

# Signature Type
CERTIFICATE_ONLY = 0
CERTIFICATE_AND_IMAGE = 5
CERTIFICATE_AND_ENCRYPTIMAGE = 6
CERTIFICATE_ONLY_STR = "Certificate only"
CERTIFICATE_AND_IMAGE_STR = "Code certificate and image"
CERTIFICATE_AND_ENCRYPTIMAGE_STR = "Code certiticate and encryption image"

# Decryption Command
AES_ECB_FILED = 0
AES_CBC_FILED = 1
AES_CFB_FILED = 2
AES_OFB_FILED = 3
AES_CTR_FILED = 4
AES128_ALGORITHM_FIELD = 0
CIPHER_MODE_START_BIT = 18
CIPHER_MODE_END_BIT = 22

# TLV Type
TLV_TYPE_HEADER = 'Header'
TLV_TYPE_LENGTH = 'Length'
TLV_TYPE_KEY = '0'
TLV_TYPE_SIG = '2'
TLV_TYPE_HASH = '1'
TLV_TYPE_IV = '5'
TLV_TYPE_IMAGE_CIPHER_INFO = 'e'
TLV_TYPE_ENDIAN = 'ENDIAN'
TLV_TYPE = 0
TLV_BINARY_DATA = 1

# Endian string
BIG_ENDIAN_BYTEORDER = 'big'
LITTLE_ENDIAN_BYTEORDER = 'little'
BIG_ENDIAN = 1
LITTLE_ENDIAN = -1

# Decryption FLAGS
CCRET_FLAGS_ENC = "1"
CCRET_BINARY_FLAGS = 7
CCRET_BINARY_FLAGS_START = 8
CCRET_BINARY_FLAGS_END =12

# Using extract TLV data
TLV_HEADER_END = 32
TLV_LENGTH_START = 32
TLV_LENGTH_END = 36
TLV_FIELD_START = 36
TLV_TYPE_AND_LENGTH_START = 0
TLV_TYPE_AND_LENGTH_END = 4
TLV_TYPE_AND_LENGTH_SIZE = 1
HEADER_AND_TLV_LENGTH_END = 36
CHANGE_WORD_TO_BYTE = 4
EXTRACT_TLV_SIZE = 3
EXTRACT_TLV_TYPE_BYTE = 0
CHANGE_HEX = 16
TLV_VALUE_START = 4

# Decryption image path
DECRYPTION_IMAGE_PATH = 'decryption_image.bin'

# Hash Target
MS_PK_STR = "Root of Trust PK"
IMG_PK_STR = "Image Signing PK"
IMG_STR = "Image"
ENCIMG_STR = "Encryption Image"

# Mapping
endian_map ={
    BIG_ENDIAN: BIG_ENDIAN_BYTEORDER,
    LITTLE_ENDIAN: LITTLE_ENDIAN_BYTEORDER
}

key_sizes = {
    ECDSA_P256: 32,
    ECDSA_P384: 48,
    RSA_PSS: 256
}

hash_map = {
    SHA_2_256_FILED: SHA256,
    SHA_2_384_FILED: SHA384,
    SHA_3_256_FILED: SHA3_256,
    SHA_3_384_FILED: SHA3_384,
}

signature_hash_map = {
    SIGNATURE_SHA_2_256_FILED: SHA256,
    SIGNATURE_SHA_2_384_FILED: SHA384,
    SIGNATURE_SHA_3_256_FILED: SHA3_256,
    SIGNATURE_SHA_3_384_FILED: SHA3_384,
}

signature_algorithm_map = {
    ECDSA_P256_ALGORITHM_FIELD: ECDSA_P256,
    ECDSA_P384_ALGORITHM_FIELD: ECDSA_P384,
    RSA2048_ALGORITHM_FIELD: RSA_2048
}

RSA_algorithm_map ={
    RSA_PSS_SCHEME_FIELD: RSA_PSS
}

decryption_mode_map = {
    AES_ECB_FILED: AES.MODE_ECB,
    AES_CBC_FILED: AES.MODE_CBC,
    AES_CFB_FILED: AES.MODE_CFB,
    AES_OFB_FILED: AES.MODE_OFB,
    AES_CTR_FILED: AES.MODE_CTR
}

decryption_algorithm_map ={
    AES128_ALGORITHM_FIELD: AES
}

print_name_map ={
    ECDSA_P256: ECDSA_P256_STR,
    ECDSA_P384: ECDSA_P384_STR,
    RSA_PSS: RSA_PSS,
    CERTIFICATE_ONLY: CERTIFICATE_ONLY_STR,
    CERTIFICATE_AND_IMAGE: CERTIFICATE_AND_IMAGE_STR,
    CERTIFICATE_AND_ENCRYPTIMAGE: CERTIFICATE_AND_ENCRYPTIMAGE_STR,
    SHA256: SHA_2_256_STR,
    SHA384: SHA_2_384_STR,
    SHA3_256: SHA_3_256_STR,
    SHA3_384: SHA_3_384_STR,
    AES: AES_128_STR,
    AES.MODE_CBC: CBC_STR
}

ECC_algorithm = {ECDSA_P256, ECDSA_P384}
RSA_algorithm = {RSA_PSS}

hash_type_img = {HASH_IMG, HASH_ENCRYPTIONIMG}
hash_type_ispk = {HASH_IMG_PUBKEY}


class verify_certificate_class:
    def get_cert_info(self, kcert_list, ccert_list, img_bin, decryption_key, ms_pk_hash):
        #Prepare rule required for decryption image and signature verification
        self.kcert_endian = extract_tlvdata(kcert_list, TLV_TYPE_ENDIAN)
        self.ccert_endian = extract_tlvdata(ccert_list, TLV_TYPE_ENDIAN)
        self.decryption_flag = get_decryption_flag(extract_tlvdata(ccert_list, TLV_TYPE_HEADER), self.ccert_endian)
        self.ccert_signature_type = get_signature_type(extract_tlv_type_and_length(ccert_list, TLV_TYPE_SIG), self.ccert_endian)

        # Prepare binary required for hash check and signature verification
        self.img_bin = img_bin
        self.decryption_key = decryption_key
        self.ms_pk_hash = ms_pk_hash.hex()
        # Key Certificate binary
        self.kcert_img_pk_hash = extract_tlvdata_value(kcert_list,TLV_TYPE_HASH).hex()
        self.kcert_pk = extract_tlvdata_value(kcert_list, TLV_TYPE_KEY)
        self.kcert_signature_binary = extract_tlvdata_value(kcert_list, TLV_TYPE_SIG)
        self.kcert_signature_target = get_signature_target(kcert_list, None, None, self.kcert_endian)
        #Code Certificate binary
        self.ccert_pk = extract_tlvdata_value(ccert_list, TLV_TYPE_KEY)
        self.ccert_signature_binary = extract_tlvdata_value(ccert_list, TLV_TYPE_SIG)
        self.ccert_signature_target = get_signature_target(ccert_list, img_bin, decryption_key, self.ccert_endian)

        # Prepare algorithm required for hash check and signature verification
        # Key Certificate algorithm
        self.kcert_hash_algorithm = get_hash_algorithm_from_signature(extract_tlv_type_and_length(kcert_list, TLV_TYPE_SIG), self.kcert_endian)
        self.kcert_sign_algorithm = get_signature_algorithm(extract_tlv_type_and_length(kcert_list, TLV_TYPE_SIG), self.kcert_endian)
        # Code Certificate algorithm
        self.ccert_hash_algorithm = get_hash_algorithm_from_signature(extract_tlv_type_and_length(ccert_list, TLV_TYPE_SIG), self.ccert_endian)
        self.ccert_sign_algorithm = get_signature_algorithm(extract_tlv_type_and_length(ccert_list, TLV_TYPE_SIG), self.ccert_endian)

        # Prepare binary required for Image hash check
        if self.ccert_signature_type == CERTIFICATE_ONLY:
            self.ccert_img_hash_value = extract_tlvdata_value(ccert_list,TLV_TYPE_HASH).hex()
            self.img_hash_info = extract_tlv_type_and_length(ccert_list,TLV_TYPE_HASH)
            self.hash_type = get_hash_type(self.img_hash_info, self.ccert_endian)

        # Prepare Decryption Image
        if self.decryption_flag == CCRET_FLAGS_ENC:
            self.ccert_ciper_info = extract_tlv_type_and_length(ccert_list, TLV_TYPE_IMAGE_CIPHER_INFO)
            self.decryption_algorithm, self.decryption_mode = get_decryption_algorithm(self.ccert_ciper_info, self.ccert_endian)
            self.ccert_IV = extract_tlvdata_value(ccert_list, TLV_TYPE_IV)
            self.decryption_img = decryption_image(self.ccert_ciper_info, self.ccert_IV, self.img_bin, self.decryption_key, self.ccert_endian)

    def kcert_print(self):
        print("\nHash of Root of Trust PK :", self.ms_pk_hash)
        print("\nKey Certificate")
        print("Signature algorithm :", print_name_map.get(self.kcert_sign_algorithm))
        print("Hash algorithm :", print_name_map.get(self.kcert_hash_algorithm))
        print("Hash of Image Signing PK :", self.kcert_img_pk_hash)


    def ccert_print(self):
        print("\nCode Certificate")
        print("Signature algorithm :", print_name_map.get(self.ccert_sign_algorithm))
        print("Hash algorithm :", print_name_map.get(self.ccert_hash_algorithm))
        if self.decryption_flag == CCRET_FLAGS_ENC:
            print("Decryption algorithm :", print_name_map.get(self.decryption_algorithm) + print_name_map.get(self.decryption_mode))
        print("Signature type :", print_name_map.get(self.ccert_signature_type))
        if self.ccert_signature_type == CERTIFICATE_ONLY:
            if self.hash_type == HASH_IMG:
                print("Hash of image :", self.ccert_img_hash_value)
            elif self.hash_type == HASH_ENCRYPTIONIMG:
                print("Hash of encryption image :", self.ccert_img_hash_value)
        print()


    def kcert_check_hash(self):
        # Check MS PK hash
        check_hash(self.ms_pk_hash, self.kcert_pk, self.kcert_hash_algorithm, MS_PK_STR)

    def ccert_check_hash(self):
        # Check IMG PK hash
        check_hash(self.kcert_img_pk_hash, self.ccert_pk, self.kcert_hash_algorithm, IMG_PK_STR)

    def kcert_verify_signature(self):
        #Key Certificate verify signature
        cert_verify_signature(
            self.kcert_pk,
            self.kcert_sign_algorithm,
            self.kcert_hash_algorithm,
            self.kcert_signature_target,
            self.kcert_signature_binary,
            DISTINCTION_KCERT
            )

    def ccert_verify_signature(self):
        #Code Certificate verify signature
        cert_verify_signature(
            self.ccert_pk,
            self.ccert_sign_algorithm,
            self.ccert_hash_algorithm,
            self.ccert_signature_target,
            self.ccert_signature_binary,
            DISTINCTION_CCERT
            )

    def check_ccert_hash_image(self):
        if self.ccert_signature_type == CERTIFICATE_ONLY:
            if self.hash_type == HASH_IMG:
                if self.decryption_flag == CCRET_FLAGS_ENC:
                    check_hash(self.ccert_img_hash_value, self.decryption_img, self.ccert_hash_algorithm, IMG_STR)
                else :
                    check_hash(self.ccert_img_hash_value, self.img_bin, self.ccert_hash_algorithm, IMG_STR)

            elif self.hash_type == HASH_ENCRYPTIONIMG:
                check_hash(self.ccert_img_hash_value, self.img_bin, self.ccert_hash_algorithm, ENCIMG_STR)

            else:
                print("Error : This is Hash of image public key")
                exit(1)

    def save_decryption_image(self):
        if  self.decryption_flag == CCRET_FLAGS_ENC:
            write_binary_file(self.decryption_img, DECRYPTION_IMAGE_PATH)
            print("Decryption Image :", DECRYPTION_IMAGE_PATH)


# ======================================================================================================================
# Functions
# ======================================================================================================================
# **********************************************************************************************************************
# Function Name : main
# **********************************************************************************************************************
def main():
    # Command line argument perse
    parser = set_cmdline_argparser()
    args = parser.parse_args()

    # Read kcert file
    kcert_bin = read_bin_file(args.kcert)
    if kcert_bin is None:
        exit(1)

    # Read ccert file
    ccert_bin = read_bin_file(args.ccert)
    if ccert_bin is None:
        exit(1)

    # Read root of PK hash file
    ms_pk_hash = read_bin_file(args.pkhash)
    if ms_pk_hash is None:
        exit(1)

    # Read Image file
    img_bin = read_bin_file(args.img)
    if img_bin is None:
        exit(1)

    # Read Decryption key
    if args.iekey is not None:
        decryption_key = bytes.fromhex(read_text_file(args.iekey))
    else:
        decryption_key = None

    # Distinction certificate file
    kcert_endian = certificate_distinction(kcert_bin, DISTINCTION_KCERT)
    ccert_endian = certificate_distinction(ccert_bin, DISTINCTION_CCERT)

    #Distinction certificate length
    certificate_length_distinction(kcert_bin, DISTINCTION_KCERT, kcert_endian)
    certificate_length_distinction(ccert_bin, DISTINCTION_CCERT, ccert_endian)

    # Making certificate list
    kcert_list = make_TLV_list(kcert_bin, kcert_endian)
    ccert_list = make_TLV_list(ccert_bin, ccert_endian)

    # Making certificate class
    cert_class = verify_certificate_class()
    cert_class.get_cert_info(kcert_list, ccert_list, img_bin, decryption_key, ms_pk_hash)
    cert_class.kcert_print()
    cert_class.ccert_print()

    # Check MS PK hash
    cert_class.kcert_check_hash()

    # Verify Key Certificate signature
    cert_class.kcert_verify_signature()

    # Check IMG PK hash
    cert_class.ccert_check_hash()

    # Verify Code Certificate signature
    cert_class.ccert_verify_signature()

    #Check IMG hash
    cert_class.check_ccert_hash_image()

    # If the image was successfully decrypted, save it to a file and print the file path
    cert_class.save_decryption_image()


# **********************************************************************************************************************
# Function Name : certificate_distinction
# **********************************************************************************************************************
def certificate_distinction(certificate, distinction_certificate):
    # Validate the key certificate
    if distinction_certificate == DISTINCTION_KCERT:
        if certificate[TLV_MAGIC_START:TLV_MAGIC_END].hex() == KCERT_MAGIC_BIG:
            return BIG_ENDIAN
        elif certificate[TLV_MAGIC_START:TLV_MAGIC_END].hex() == KCERT_MAGIC_LITTLE:
            return LITTLE_ENDIAN
        else:
            print("Error : Invalid Key Certificate specified")
            exit(1)

    # Validate the code certificate
    if distinction_certificate == DISTINCTION_CCERT:
        if certificate[TLV_MAGIC_START:TLV_MAGIC_END].hex() == CCERT_MAGIC_BIG:
            return BIG_ENDIAN
        elif certificate[TLV_MAGIC_START:TLV_MAGIC_END].hex() == CCERT_MAGIC_LITTLE:
            return LITTLE_ENDIAN
        else:
            print("Error : Invalid Code Certificate specified")
            exit(1)


# **********************************************************************************************************************
# Function Name : certificate_distinction
# **********************************************************************************************************************
def certificate_length_distinction(certificate, distinction_certificate ,endian):
    # Extract TLV length
    get_byteorder = endian_map.get(endian)
    Length = int.from_bytes(certificate[TLV_LENGTH_START:TLV_LENGTH_END], byteorder = get_byteorder)
    tlv_filed_length = len(certificate[TLV_FIELD_START:])
    
    if Length == tlv_filed_length:
        pass
    else:
        print("Error : Invalid", distinction_certificate, "Certificate length specified")
        exit(1)



# **********************************************************************************************************************
# Function Name : check_hash_public_key
# **********************************************************************************************************************
def check_hash(hash, data, hash_algorithm, hash_target):
    calculate_hash = hash_algorithm.new(data).hexdigest()
    print("Calculate hash of", hash_target, ":", calculate_hash)
    if hash == calculate_hash:
        print(hash_target, "Hash check OK")
    else:
        print(hash_target, "Hash check Failed")
        exit(1)


# **********************************************************************************************************************
# Function Name : make_TLV_list
# **********************************************************************************************************************
def make_TLV_list(bin, endian):
    TLV_list = []

    # Header and length fields from binary data into the TLV list
    TLV_list.append([TLV_TYPE_HEADER, bin[:TLV_HEADER_END]])
    TLV_list.append([TLV_TYPE_LENGTH, bin[TLV_LENGTH_START:TLV_LENGTH_END]])

    # Extract TLV length
    get_byteorder = endian_map.get(endian)
    Length = int.from_bytes(bin[TLV_LENGTH_START:TLV_LENGTH_END], byteorder = get_byteorder)

    # Extract TLV field
    _tlv_fld_text = bin[TLV_FIELD_START:]

    # Append extracted TLV and TLV type to the list
    while Length > 0:
        _tlv_fld_ = _tlv_fld_text[TLV_TYPE_AND_LENGTH_START:TLV_TYPE_AND_LENGTH_END]
        _tlv_type = _tlv_fld_[::endian].hex()[EXTRACT_TLV_TYPE_BYTE]
        _tlv_size_word = (_tlv_fld_[::endian][EXTRACT_TLV_SIZE] + TLV_TYPE_AND_LENGTH_SIZE)
        _tlv_size_byte = CHANGE_WORD_TO_BYTE*_tlv_size_word
        _tlv_data = _tlv_fld_text[:_tlv_size_byte]
        TLV_list.append([_tlv_type, _tlv_data])
        Length = Length - _tlv_size_byte
        _tlv_fld_text = _tlv_fld_text[_tlv_size_byte:]

    #Append endian 
    TLV_list.append([TLV_TYPE_ENDIAN, endian])


    return TLV_list


# **********************************************************************************************************************
# Function Name : extract_tlvdata_value
# **********************************************************************************************************************
def extract_tlvdata_value(cert_list, EXTRACT_TLV_TYPE):
    return extract_tlvdata(cert_list, EXTRACT_TLV_TYPE)[TLV_VALUE_START:]


# **********************************************************************************************************************
# Function Name : extract_tlv_type_and_length
# **********************************************************************************************************************
def extract_tlv_type_and_length(cert_list, EXTRACT_TLV_TYPE):
    return extract_tlvdata(cert_list, EXTRACT_TLV_TYPE)[TLV_TYPE_AND_LENGTH_START:TLV_TYPE_AND_LENGTH_END]


# **********************************************************************************************************************
# Function Name : extract_tlvdata
# **********************************************************************************************************************
def extract_tlvdata(cert_list, EXTRACT_TLV_TYPE):
    extract_tlv = [TLV[TLV_BINARY_DATA] for TLV in cert_list if TLV[TLV_TYPE] == EXTRACT_TLV_TYPE]

    if len(extract_tlv) == 0:
        print("Error : Could not find TLV field")
        exit(1)
    elif len(extract_tlv) == 1:
        return extract_tlv[0]
    else :
        print("Error : Multiple TLVs of the same type are present")
        exit(1)


# **********************************************************************************************************************
# Function Name : extract_except_sig
# **********************************************************************************************************************
def extract_except_sig(cert_list):
    expect_sig_tlv = [TLV[TLV_BINARY_DATA] for TLV in cert_list if TLV[TLV_TYPE] != TLV_TYPE_SIG and TLV[TLV_TYPE] != TLV_TYPE_ENDIAN]
    return b''.join(expect_sig_tlv)


# **********************************************************************************************************************
# Function Name : get_hash_algorithm_from_signature
# **********************************************************************************************************************
def get_hash_algorithm_from_signature(signature_tlv, endian):
    # Change each byte in the signature TLV to a list of bits
    signature_bit = [int(bit) for byte in signature_tlv[::endian] for bit in format(byte, '08b')]

    # Extract hash algorithm
    bit_str = ''.join(str(bit) for bit in signature_bit[SIGNATURE_HASH_START_BIT:SIGNATURE_HASH_END_BIT])
    hash = int(bit_str, 2)

    get_hash = signature_hash_map.get(hash)
    if get_hash is None:
        print("Error : This hash algorithm is not found")
        exit(1)

    return get_hash


# **********************************************************************************************************************
# Function Name : get_signature_algorithm
# **********************************************************************************************************************
def get_signature_algorithm(signature_tlv, endian):
    # Change each byte in the signature TLV to a list of bits
    signature_bit = [int(bit) for byte in signature_tlv[::endian] for bit in format(byte, '08b')]

    # Extract signature algorithm
    bit_str = ''.join(str(bit) for bit in signature_bit[ALGORITHM_START_BIT:ALGORITHM_END_BIT])
    algorithm = int(bit_str, 2)

    bit_str = ''.join(str(bit) for bit in signature_bit[RSA_SCHEME_START_BIT:RSA_SCHEME_END_BIT])
    rsa_scheme = int(bit_str, 2)

    get_algorithm = signature_algorithm_map.get(algorithm)

    if get_algorithm == RSA_2048:
        get_algorithm = RSA_algorithm_map.get(rsa_scheme)

    if get_algorithm is None:
        print("Error :This signature algorithm is not supported")
        exit(1)

    return get_algorithm


# **********************************************************************************************************************
# Function Name : get_decryption_algorithm
# **********************************************************************************************************************
def get_decryption_algorithm(cipher_info_tlv, endian):
    # Change each byte in the cipher info TLV to a list of bits
    cipher_info_bit = [int(bit) for byte in cipher_info_tlv[::endian] for bit in format(byte, '08b')]

    # Extract decryption algorithm and decryption mode
    bit_str1 = ''.join(str(bit) for bit in cipher_info_bit[ALGORITHM_START_BIT:ALGORITHM_END_BIT])
    bit_str2 = ''.join(str(bit) for bit in cipher_info_bit[CIPHER_MODE_START_BIT:CIPHER_MODE_END_BIT])
    decryption_algorithm = int(bit_str1, 2)
    decryption_mode = int(bit_str2, 2)

    get_decryption_algorithm = decryption_algorithm_map.get(decryption_algorithm)
    get_decryption_mode = decryption_mode_map.get(decryption_mode)
    if get_decryption_algorithm is None:
        print("Error : This decryption algorithm is not supported")
        exit(1)

    return get_decryption_algorithm, get_decryption_mode


# **********************************************************************************************************************
# Function Name : get_decryption_flag
# **********************************************************************************************************************
def get_decryption_flag(header_bin, endian):
    flag = header_bin[CCRET_BINARY_FLAGS_START:CCRET_BINARY_FLAGS_END][::endian].hex()
    return  flag[CCRET_BINARY_FLAGS]


# **********************************************************************************************************************
# Function Name : get_signature_type
# **********************************************************************************************************************
def get_signature_type(signature_tlv, endian):
    # Change each byte in the signature TLV to a list of bits
    signature_bit = [int(bit) for byte in signature_tlv[::endian] for bit in format(byte, '08b')]

    # Extract signature type
    bit_str = ''.join(str(bit) for bit in signature_bit[SIGNATURE_TYPE_START_BIT:SIGNATURE_TYPE_END_BIT])
    signature_type = int(bit_str, 2)

    return signature_type


# **********************************************************************************************************************
# Function Name : get_hash_type
# **********************************************************************************************************************
def get_hash_type(hash_info, endian):
    hash_bit = [int(bit) for byte in hash_info[::endian] for bit in format(byte, '08b')]

    # Extract signature type
    bit_str = ''.join(str(bit) for bit in hash_bit[SIGNATURE_TYPE_START_BIT:SIGNATURE_TYPE_END_BIT])
    hash_type = int(bit_str, 2)

    return hash_type

# **********************************************************************************************************************
# Function Name : get_signature_target
# **********************************************************************************************************************
def get_signature_target(cert_list, img_bin, decryption_key, endian):
    # Get the signature type
    cert_signature_type = get_signature_type(extract_tlv_type_and_length(cert_list, TLV_TYPE_SIG), endian)

    # Extract signature target in certificate
    cert_expect_sig = extract_except_sig(cert_list)
    # Extract header in certificate
    cert_header_bin = extract_tlvdata(cert_list, TLV_TYPE_HEADER)

    # Signature target of certificate
    if cert_signature_type == CERTIFICATE_ONLY:
        cert_signature_target = cert_expect_sig

    # Signature target of certificate and image
    elif cert_signature_type == CERTIFICATE_AND_IMAGE:
        # Reading image is ecryption
        if get_decryption_flag(cert_header_bin, endian) == CCRET_FLAGS_ENC:
            cert_ciper_info = extract_tlv_type_and_length(cert_list, TLV_TYPE_IMAGE_CIPHER_INFO)
            ccert_IV = extract_tlvdata_value(cert_list, TLV_TYPE_IV)
            decryption_img = decryption_image(cert_ciper_info, ccert_IV, img_bin, decryption_key, endian)
            cert_signature_target = cert_expect_sig + decryption_img
        # Reading image is not encryption
        else:
            cert_signature_target = cert_expect_sig + img_bin

    # Signature target of certificate and encryption image
    elif cert_signature_type == CERTIFICATE_AND_ENCRYPTIMAGE:
        cert_signature_target = cert_expect_sig + img_bin

    else:
        print("Error : Invalid Signature Target")
        exit(1)

    return cert_signature_target


# **********************************************************************************************************************
# Function Name : make_public_key
# **********************************************************************************************************************
def make_public_key(pk, signature_algorithm):
    # Getting DER key size
    key_size = key_sizes[signature_algorithm]

    # ECDSA-P256 or ECDSA-P384
    if signature_algorithm in ECC_algorithm:
        # Split the public key into x and y coordinates
        x = int.from_bytes(pk[:key_size], 'big')
        y = int.from_bytes(pk[key_size:], 'big')
        # Generate ECC key in DER format
        public_key = ECC.construct(curve=signature_algorithm, point_x=x, point_y=y)

    # RSA-PSS
    elif signature_algorithm in RSA_algorithm:
        # Split the public key into modulus and exponent coordinates
        modulus = int.from_bytes(pk[:key_size], 'big')
        exponent = int.from_bytes(pk[key_size:], 'big')
        # Generate RSA key in DER format
        public_key = RSA.construct((modulus, exponent))

    return public_key

# **********************************************************************************************************************
# Function Name : cert_verify_signature
# **********************************************************************************************************************
def cert_verify_signature(pk, sign_algorithm, hash_algorithm, signature_target, signature_binary, distinction_cert):
    # Generate a public key encoded in DER format
    cert_public_key = make_public_key(pk, sign_algorithm)
    h = hash_algorithm.new(signature_target)

    # Configure the signature verifier depending on ECC or RSA algorithm
    if sign_algorithm in ECC_algorithm:
        verifier_kcert = DSS.new(cert_public_key, 'fips-186-3')
    elif sign_algorithm in RSA_algorithm:
        verifier_kcert = pss.new(cert_public_key, salt_bytes=h.digest_size*2)

    # Verify Signature
    try:
        verifier_kcert.verify(h, signature_binary)
        print(distinction_cert, "Certificate Verify OK")
    except ValueError:
        print(distinction_cert, "Certificate Verify Failed")
        exit(1)

# **********************************************************************************************************************
# Function Name : decryption_image
# **********************************************************************************************************************
def decryption_image(cert_ciper_info, ccert_IV, img_bin, decryption_key, endian):
    if decryption_key is None:
        print("Error : Decryption Key not found")
        exit(1)
    # Prepare the cipher object using algorithm, mode, IV, and the decryption key
    decryption_algorithm, decryption_mode = get_decryption_algorithm(cert_ciper_info, endian)
    if decryption_mode == AES.MODE_CBC:
        cipher = decryption_algorithm.new(decryption_key, decryption_mode, ccert_IV)
    else:
        print("Error : This AES mode is not supported")
        exit(1)

    # Image decryption
    decryption_data = cipher.decrypt(img_bin)
    return decryption_data


# **********************************************************************************************************************
# Function Name : set_cmdline_argparser
# **********************************************************************************************************************
def set_cmdline_argparser():
    # Local constant value
    DESC_TOOL = 'Generate manifest tool for Renesas-SB-Library'

    METAVER_KCERT = '<Key Certificate File>'
    METAVER_CCERT = '<Code Certificate File>'
    METAVER_PKHASH = '<Hash of Manifest Signer PK File>'
    METAVER_IMGIN = '<Image File>'
    METAVER_ECRYPTION_KEY = '<Encryption Key File>'

    HELP_KCERT = 'Specify the path of the Key Certificate file'
    HELP_CCERT = 'Specify the path of the Code Certificate file'
    HELP_PKHASH = 'Specify the path of Hash of Manifest Signer PK file'
    HELP_IMGIN = 'Specify the path of the input Image file'
    HELP_ENCRYPTION_KEY = 'Specify the path of the Encryption Key file'

    # Set command line parser
    parser = argparse.ArgumentParser(description=DESC_TOOL)

    # Set arguments for Verify
    parser.add_argument('-kcert', metavar=METAVER_KCERT, required=True, help=HELP_KCERT)
    parser.add_argument('-ccert', metavar=METAVER_CCERT, required=True, help=HELP_CCERT)
    parser.add_argument('-pkhash', metavar=METAVER_PKHASH, required=True, help=HELP_PKHASH)
    parser.add_argument('-img', metavar=METAVER_IMGIN, required=True, help=HELP_IMGIN)
    parser.add_argument('-iekey', metavar=METAVER_ECRYPTION_KEY, required=False, help=HELP_ENCRYPTION_KEY)
    return parser


# **********************************************************************************************************************
# Function Name : read_text_file
# **********************************************************************************************************************
def read_text_file(file_path):
    try:
        with open(file_path, 'r') as infile:
            text = infile.read()
    except:
        ERRMSG(str.format(ERRMSG_OPENFAIL % (file_path)))
        text = None
    return text


# **********************************************************************************************************************
# Function Name : read_bin_file
# **********************************************************************************************************************
def read_bin_file(file_path):
    try:
        with open(file_path, 'rb') as infile:
            bin = infile.read()
    except:
        ERRMSG(str.format(ERRMSG_OPENFAIL % (file_path)))
        bin = None
    return bin


# **********************************************************************************************************************
# Function Name : write_text_file
# **********************************************************************************************************************
def write_text_file(data, file_path):
    ret = 0
    try:
        with open(file_path, 'w') as outfile:
            outfile.write(data)
    except:
        ERRMSG(str.format(ERRMSG_OPENFAIL % (file_path)))
        ret = -1
    return ret


# **********************************************************************************************************************
# Function Name : write_binary_file
# **********************************************************************************************************************
def write_binary_file(data, file_path):
    ret = 0
    try:
        with open(file_path, 'wb') as outfile:
            outfile.write(data)
    except:
        ERRMSG(str.format(ERRMSG_OPENFAIL % (file_path)))
        ret = -1
    return ret


# ======================================================================================================================
# Script start
# ======================================================================================================================
if __name__ == '__main__':
    main()
