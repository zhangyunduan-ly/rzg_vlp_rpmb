#
# Copyright (c) 2019-2025 Renesas Electronics Corporation. All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause
#
from Crypto import Random
from Crypto.Cipher import AES
from Crypto.Hash import SHA256
from Crypto.Hash import SHA384
from Crypto.Hash import SHA3_256
from Crypto.Hash import SHA3_384
from Crypto.Signature import pss
from Crypto.Signature import DSS
from Crypto.PublicKey import ECC
from Crypto.PublicKey import RSA
from Crypto.Random import get_random_bytes

# ======================================================================================================================
# Private global valiables
# ======================================================================================================================
# ECC signature algorighm list
ecc_salgos  = ['ECDSA-P256', 'ECDSA-P384']

# RSA signature algorighm list
rsa_salgos  = ['RSA-PSS']

# Hash object list
halgo_objs  = {'SHA2-256': SHA256, 'SHA2-384': SHA384, 'SHA3-256': SHA3_256, 'SHA3-384': SHA3_384}

# Encryption mode list
ealgo_modes = {'AES-CBC': AES.MODE_CBC}


# ======================================================================================================================
# Functions
# ======================================================================================================================
# **********************************************************************************************************************
# Function Name : get_pubkey_bytes
# **********************************************************************************************************************
def get_pubkey_bytes(salgo, key_pem):
    try:
        if salgo in ecc_salgos:
            key = ECC.import_key(key_pem)
            pubkey = key.pointQ.x.to_bytes(key.pointQ.size_in_bytes())
            pubkey += key.pointQ.y.to_bytes(key.pointQ.size_in_bytes())
        elif salgo in rsa_salgos:
            key = RSA.import_key(key_pem)
            pubkey = key.n.to_bytes(key.size_in_bytes(), 'big')
            pubkey += key.e.to_bytes(4, 'big')
        else:
            pubkey = None
    except:
            pubkey = None
    return pubkey


# **********************************************************************************************************************
# Function Name : get_rand
# **********************************************************************************************************************
def get_rand(len):
    return get_random_bytes(len)


# **********************************************************************************************************************
# Function Name : calc_hash
# **********************************************************************************************************************
def calc_hash(halgo, msgs):
    try:
        hobj = halgo_objs[halgo].new()
        for msg in msgs:
            hobj.update(msg)
        digest = hobj.digest()
    except:
        digest = None
    return digest


# **********************************************************************************************************************
# Function Name : calc_sign
# **********************************************************************************************************************
def calc_sign(salgo, halgo, key_pem, msgs):
    try:
        if salgo in ecc_salgos:
            key = ECC.import_key(key_pem)
            hobj = halgo_objs[halgo].new()
            for msg in msgs:
                hobj.update(msg)
            sobj = DSS.new(key, 'fips-186-3')
            sign = sobj.sign(hobj)
        elif salgo in rsa_salgos:
            key = RSA.import_key(key_pem)
            hobj = halgo_objs[halgo].new()
            for msg in msgs:
                hobj.update(msg)
            sobj = pss.new(key, salt_bytes=(hobj.digest_size * 2))
            sign = sobj.sign(hobj)
        else:
            sign = None
    except:
        sign = None

    return sign


# **********************************************************************************************************************
# Function Name : encrypt
# **********************************************************************************************************************
def encrypt(ealgo, key, iv, plain):
    try:
        aes = AES.new(key, ealgo_modes[ealgo], iv)
        cipher = aes.encrypt(plain)
    except:
        cipher = None
    return cipher
