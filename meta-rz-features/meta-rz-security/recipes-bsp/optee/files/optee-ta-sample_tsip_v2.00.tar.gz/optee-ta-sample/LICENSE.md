The client applications (`*/host/*`) are provided under the
[GPL-2.0](http://opensource.org/licenses/GPL-2.0) license.

The user TAs (`*/ta/*`) are provided under the
[BSD 3-Clause](https://opensource.org/license/bsd-3-clause) license.