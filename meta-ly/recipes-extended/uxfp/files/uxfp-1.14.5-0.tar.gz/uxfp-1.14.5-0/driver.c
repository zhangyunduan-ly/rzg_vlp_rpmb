#include <string.h>
#include <inttypes.h>
#include <assert.h>
#include "devices.h"
#include "driver.h"

const static char *channel_name [] = {
    [CHANNEL_SERIAL_PHY] = "serial-physical",
    [CHANNEL_SERIAL_USB] = "serial-usb",
    [CHANNEL_SERIAL_PCI] = "serial-pci",
    [CHANNEL_FASTBOOT] = "fastboot",
    [CHANNEL_SERIAL_USB_NO_DISCOVERY] = "serial-usb-no-disc",
};

static int32_t generic_flush(const struct _driver *driver);
static int32_t generic_open(const dev_info_t *dev_info, struct _driver *driver);
static int32_t generic_send(const struct _driver *driver, const uint8_t *buffer, const int32_t to_write,
        uint32_t *written);
static int32_t generic_wait_reply(const struct _driver *driver, const uint32_t ms_timeout);
static int32_t generic_read(const struct _driver *driver, uint8_t *buffer, const int32_t to_read,
        uint32_t *read);
static int32_t generic_config(const struct _driver *driver, const bool enable_hw_flow_control);
static int32_t generic_set_baud_rate(const struct _driver *driver, const uint32_t rate);
static int32_t generic_close(struct _driver *driver);

static int32_t open_physical_device(const dev_info_t *dev_info, struct _driver *driver, const int8_t path_id);

static int32_t uart_open(const dev_info_t *dev_info, struct _driver *driver);

static int32_t fastboot_open(const dev_info_t *dev_info, struct _driver *driver);
static int32_t fastboot_send(const struct _driver *driver, const uint8_t *buffer, const int32_t to_write,
        uint32_t *written);
static int32_t fastboot_wait_reply(const struct _driver *driver, const uint32_t ms_timeout);
static int32_t fastboot_read(const struct _driver *driver, uint8_t *buffer, const int32_t to_read,
        uint32_t *read);
static int32_t fastboot_close(struct _driver *driver);

static int32_t uart_wait_reply(const struct _driver *driver, const uint32_t ms_timeout);

/* NULL functions, used by fastboot driver to avoid the caller
 * to implement checks on function pointers */
static int32_t pass_config(const struct _driver *driver, const bool enable_hw_flow_control);
static int32_t pass_set_baud_rate(const struct _driver *driver, const uint32_t rate);
static int32_t pass_flush(const struct _driver *driver);

driver_t usb = {
    .open = generic_open,
    .send = generic_send,
    .read = generic_read,
    .wait_reply = generic_wait_reply,
    .configure = generic_config,
    .set_baud_rate = generic_set_baud_rate,
    .close = generic_close,
    .flush = generic_flush,
};

driver_t usb_no_discovery = {
    .open = uart_open,
    .send = generic_send,
    .read = generic_read,
    .wait_reply = generic_wait_reply,
    .configure = generic_config,
    .set_baud_rate = generic_set_baud_rate,
    .close = generic_close,
    .flush = generic_flush,
};

driver_t pci = {
    .open = generic_open,
    .send = generic_send,
    .read = generic_read,
    .wait_reply = generic_wait_reply,
    .configure = pass_config,
    .set_baud_rate = pass_set_baud_rate,
    .close = generic_close,
    .flush = pass_flush,
};

driver_t uart = {
    .open = uart_open,
    .send = generic_send,
    .read = generic_read,
    .wait_reply = uart_wait_reply,
    .configure = generic_config,
    .set_baud_rate = generic_set_baud_rate,
    .close = generic_close,
    .flush = pass_flush,
};

driver_t fastboot = {
    .open = fastboot_open,
    .send = fastboot_send,
    .read = fastboot_read,
    .wait_reply = fastboot_wait_reply,
    .configure = pass_config,
    .set_baud_rate = pass_set_baud_rate,
    .close = fastboot_close,
    .flush = pass_flush,
};

int32_t get_driver(const channel_t channel, chipset_t chipset, driver_t *driver)
{
    int32_t ret = 0;

    switch (channel) {
        case CHANNEL_SERIAL_PHY:
            *driver = uart;
            break;
        case CHANNEL_SERIAL_USB:
            *driver = usb;
            break;
        case CHANNEL_SERIAL_PCI:
            *driver = pci;
            break;
        case CHANNEL_FASTBOOT:
            *driver = fastboot;
            break;
        case CHANNEL_SERIAL_USB_NO_DISCOVERY:
            *driver = usb_no_discovery;
            break;
        default:
            ALOGE("unknown channel type %u\n", channel);
            ret = CORE_ERROR_OPERATION_NOT_PERMITTED;
            goto end;
    }

    driver->device.handle = INVALID_DEVICE_HANDLE;

    /* TODO: consider to remove this (and chipset from argument list, then) */
    if (chipset >= CHIPSET_UNKNOWN || chipset < CHIPSET_6160) {
        ALOGE("could not set diagnostic interface number: unknown chipset %u\n",
                chipset);
        ret = CORE_ERROR_OPERATION_NOT_PERMITTED;
        goto end;
    }

    assert(channel < CHANNEL_UNKNOWN);
    ALOGD("selected driver for %s channel\n", channel_name[channel]);
end:
    return ret;
}

/* return the first device path without an interface number,
 * or CORE_ERROR_NO_SUCH_DEVICE in case of error */
static int32_t get_fallback_device_pos(const dev_info_t *dev_info)
{
    for (int8_t i = 0; i < dev_info->comm_ports_number; i++) {
        if (strlen(dev_info->ifaces[i]) == 0)
            return i;
    }

    ALOGE("could not find any fallback port\n");
    return CORE_ERROR_NO_SUCH_DEVICE;
}

/* returns the dev_info->comm_port index of the path with the expected
 * interface number, or the fallback device. If none is available returns CORE_ERROR_NO_SUCH_DEVICE */
int32_t get_flashing_device_or_fallback_position(const dev_info_t *dev_info)
{
    int32_t pos = get_flashing_device_pos(dev_info);

    /* check all the error returned values, which are < 0; in case of successful call, an
     * index >= 0 is returned */
    if (pos < 0)
        return get_fallback_device_pos(dev_info);

    return pos;
}

/* returns the dev_info->comm_port index (>= 0) of the path with
 * the expected interface number, or CORE_ERROR_NO_SUCH_DEVICE (< 0) otherwise */
int32_t get_flashing_device_pos(const dev_info_t *dev_info)
{
    int32_t err = CORE_ERROR_NO_SUCH_DEVICE;
    usb_id_t usb_id = {0};
    const char *diag_interface_number;

    if (!core_usb_id_from_str(&usb_id, dev_info->vendor_id, dev_info->product_id)) {
        /* we return an error code, but this would be an error only in devices with discovery available */
        ALOGW("cannot parsing USB id info (%s:%s)\n", dev_info->vendor_id, dev_info->product_id);
        return CORE_ERROR_OPERATION_NOT_PERMITTED;
    }
    diag_interface_number = get_diag_interface_number(usb_id.pid);

    for (int8_t i = 0; i < dev_info->comm_ports_number; i++) {
        ALOGD("searching diag interface in {iface:path} {%s:%s}\n",
                dev_info->ifaces[i],
                dev_info->comm_ports[i]);

        if (strcmp(dev_info->ifaces[i], diag_interface_number) == 0)
            return i;
    }

    return err;
}

static int32_t
generic_flush(const struct _driver *driver)
{
    return core_device_flush(driver->device.handle);
}

static int32_t
generic_open(const dev_info_t *dev_info, struct _driver *driver)
{
    int32_t ret = 0;
    int32_t path_id;

    path_id = get_flashing_device_or_fallback_position(dev_info);
    if (path_id < 0) {
        ret = path_id;
        goto end;
    }

    ALOGD("opening '%s'\n", dev_info->comm_ports[path_id]);

    ret = open_physical_device(dev_info, driver, path_id);

end:
    return ret;
}

static int32_t
generic_send(const struct _driver *driver, const uint8_t *buffer, const int32_t to_write, uint32_t *written)
{
    core_res_t err;

    err = core_device_write(driver->device.handle, buffer, to_write, written);
    if (err)
        ALOGE("write error %d\n", err);

    return err;
}

static int32_t
generic_read(const struct _driver *driver, uint8_t *buffer, const int32_t to_read, uint32_t *read)
{
    core_res_t err = 0;

    err = core_device_read(driver->device.handle, buffer, to_read, read);
    if (err && err != CORE_ERROR_TRY_AGAIN)
        ALOGE("read error %d\n", err);

    return err;
}

static int32_t
generic_config(const struct _driver *driver, const bool enable_hw_flow_control)
{
    core_res_t ret;

    ret = core_device_config(driver->device.handle);
    if (ret)
        ALOGE("device configure error %d\n", ret);

    ALOGD("%s hw flow control\n", enable_hw_flow_control ? "enabling" : "disabling");
    ret = core_set_hw_flow_control(driver->device.handle, enable_hw_flow_control);
    if (ret)
        ALOGE("device configure error %d\n", ret);

    return ret;
}

static int32_t
generic_set_baud_rate(const struct _driver *driver, const uint32_t rate)
{
    core_res_t err;

    err = core_device_set_baud_rate(driver->device.handle, rate);
    if (err)
        ALOGE("set baud rate error %d\n", err);

    return err;
}

static int32_t
generic_close(struct _driver *driver)
{
    int32_t err = CORE_SUCCESS;
    if (driver->device.handle != INVALID_DEVICE_HANDLE)
        err = core_device_close(driver->device.handle);
    return err;
}

static int32_t
open_physical_device(const dev_info_t *dev_info, struct _driver *driver, const int8_t path_id)
{
    int32_t ret;

    ret = core_wait_for_serial(dev_info->comm_ports[path_id]);
    if (ret) {
        ALOGE("error waiting for device '%s'\n",
                dev_info->comm_ports[path_id]);
        goto end;
    }

    ret = core_device_open(dev_info->comm_ports[path_id], &(driver->device.handle));
    if (driver->device.handle == INVALID_DEVICE_HANDLE)
        ALOGE("could not open device '%s'\n",
                dev_info->comm_ports[path_id]);
end:
    return ret;
}

static int32_t
uart_open(const dev_info_t *dev_info, struct _driver *driver)
{
    ALOGD("opening '%s'\n", dev_info->comm_ports[DEFAULT_UART_CHANNEL_ID]);
    return open_physical_device(dev_info, driver, DEFAULT_UART_CHANNEL_ID);
}

static int32_t
fastboot_open(const dev_info_t *dev_info, struct _driver *driver)
{
    return core_endpoint_open(dev_info, &(driver->device));
}

static int32_t
fastboot_send(const struct _driver *driver, const uint8_t *buffer, const int32_t to_write, uint32_t *written)
{
    return core_endpoint_write(&(driver->device), buffer, to_write, written);
}

static int32_t
fastboot_wait_reply(const struct _driver *driver, const uint32_t ms_timeout)
{
    /* fastboot does not need to wait for bytes availability, so we can return SUCCESS */

    return 0;
}

static int32_t
fastboot_read(const struct _driver *driver, uint8_t *buffer, const int32_t to_read, uint32_t *read)
{
    return core_endpoint_read(&(driver->device), buffer, to_read, read);
}

static int32_t
fastboot_close(struct _driver *driver)
{
    return core_endpoint_close(&driver->device);
}

static int32_t
generic_wait_reply(const struct _driver *driver, const uint32_t ms_timeout)
{
    core_res_t ret;

    ret = core_device_poll(driver->device.handle, ms_timeout);
    switch (ret) {
        case CORE_SUCCESS:
            break;
        case CORE_ERROR_TIMEOUT:
            ALOGD("wait for ack timed out\n");
            break;
        default:
            ALOGE("wait for ack error %d\n", ret);
            break;
    }

    return ret;
}

static int32_t
uart_wait_reply(const struct _driver *driver, const uint32_t ms_timeout)
{
    core_res_t ret;
    /* The number of retries is proportional to the max wait timeout.
     * While for the boot mode phase a short number of retries is
     * necessary to permit re-sending the boot char, for the upload
     * phase no re-send is expected and the number of retries shall
     * be much higher because the modem might reply with an ACK
     * only after writing the chunks in memory. */
    const int32_t max_retries = (ms_timeout > 200) ? 2000 : 2;
    const int8_t retry_delay_ms = 3;
    int32_t retries = max_retries;

    do {
        ret = core_device_poll(driver->device.handle, ms_timeout);
        switch (ret) {
            case CORE_SUCCESS:
                break;
            case CORE_ERROR_NO_SUCH_DEVICE:
                /* Modem is physically connected, retry poll in case
                 * it is just unresponsive */
                if (--retries > 0) {
                    if (retries == max_retries - 1) {
                        /* print this only once, avoid flooding the log */
                        ALOGD("UART device: ignoring NO SUCH DEVICE errors\n");
                    }
                    if (retries == 1) {
                        ALOGD("last of %" PRIi32 " attempts to get the modem's reply\n", max_retries);
                        break;
                    }
                    core_sleep(retry_delay_ms);
                }
                break;
            case CORE_ERROR_TIMEOUT:
                ALOGD("wait for ack timed out\n");
                break;
            default:
                ALOGE("wait for ack error %d\n", ret);
                break;
        }
    } while (ret == CORE_ERROR_NO_SUCH_DEVICE && retries > 0);

    if (ret == CORE_ERROR_NO_SUCH_DEVICE) {
        /* modem does not reply after extended retry */
        ret = CORE_ERROR_TIMEOUT;
    }

    return ret;
}

const char *get_channel_name(const channel_t channel)
{
    if (channel > CHANNEL_FASTBOOT)
        return NULL;

    return channel_name[channel];
}

static int32_t pass_config(const struct _driver *driver, const bool enable_hw_flow_control)
{
    return CORE_SUCCESS;
}

static int32_t pass_set_baud_rate(const struct _driver *driver, const uint32_t rate)
{
    return CORE_SUCCESS;
}

static int32_t pass_flush(const struct _driver *driver)
{
    return CORE_SUCCESS;
}
