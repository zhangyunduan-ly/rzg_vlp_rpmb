/**
 * @file boot.h
 * @brief Handling of modem boot mode phase
 *
 * Copyright (C) 2018  Telit Communication spa
 */

#ifndef _BOOT_H_
#define _BOOT_H_
#include <telit-os-abs.h>

#include "driver.h"
#include "stream.h"

#define MAX_ACK_LEN 24
#define MAX_STR_LEN 4
#define MAX_USB_IDS 10
#define MAX_USB_IDS_STR_LEN 5
#define VERSION_NAME_MAX 16
#define DIAG_EXT_BUILD_ID_F 124

#pragma pack( push, 1 )
typedef struct {
    uint8_t command;
    uint8_t msm_hw_version_format;
    uint8_t reserved[2];  /* for alignment / future use */
    uint32_t msm_hw_version;
    uint32_t mobile_model_id;
    /* The following character array contains 2 NULL terminated strings:
     * 'build_id' string, followed by 'model_string' */
    char ver_strings[VERSION_NAME_MAX];
} diag_build_id_rsp;
#pragma pack( pop )

/**
 * @brief context data exchanged during boot mode steps according to selected boot protocol
 */
typedef struct {
    protocol_t *protocol;
    bool recovery;                     /**< true if the modem is supposed to be in recovery mode, false otherwise. */
    usb_id_list_t *usb_ids;            /**< telit_os_abstraction_layer::usb_id_list_t of modems supported by the firmware stream */
    dev_info_t dev_info;               /**< telit_os_abstraction_layer::dev_info_t of the connected USB modem target of the firmware update */
    uint16_t exp_ack_boot_str_len;     /**< length of the modem's expected ack boot string */
    uint8_t *exp_ack_boot_str;         /**< modem's expected ack boot string */
    data_small_block_t rec_ack;        /**< #data_small_block_t with ack sent by the modem */
    uint8_t boot_char_len;             /**< length of boot character buffer */
    uint8_t *boot_char;                /**< content of boot character buffer */
    uint32_t boot_char_send_interval;  /**< inter boot character interval in milliseconds */
    int8_t max_nacks;                  /**< Max number of NACK received before stopping boot phase */
    uint16_t bytes_left;               /**< boot characters left to be sent (this supports send retries) */
    int32_t retries;                   /**< max number of boot mode procedure retries */
    uint32_t timeout;                  /**< maximum waiting time in milliseconds for USB connection */
    uint32_t baud_rate;                /**< requested baud rate for firmware upload phase */
    json_t *report_entries;
    bool no_fastboot_driver;           /**< true if the flashing device (i.e. fastboot ) is NOT handled by a the system (e.g. option driver on Linux). */
    bool modem_discovery;              /**< true if the modem discovery is available, false otherwise */
    uint32_t delay_after_speed_change; /**< delay between the speed change module's ACK and the first data
                                            chunk sent by the host with the new speed (0 if not required) */
} boot_context_t;


/**
 * @brief Set the device in boot mode, ready for download the FW
 *
 * @param[in] driver a driver_t instance to interact with the modem
 * @param[in] stream FW binary stream
 * @param[out] ctx a boot_context_t instance
 * @param[in] stop_after_restart a boolean to request to stop right after the restart of the module is
 *                               requested, used for the boot_mode option
 *
 * @return 0 in case of success, a negative value otherwise
 */
int32_t enter_boot_mode(driver_t *driver, boot_context_t *ctx, bool stop_after_restart, stream_t *stream);

/**
 * @brief configure #boot_context_t structure according to #boot_type_t
 *
 * @param[in] protocol the #protocol_t
 * @param[in] is_recovery TRUE if recovery context is required, FALSE otherwise
 * @param[out] ctx the #boot_context_t
 *
 * @return 0 in case of success, a negative value otherwise
 */
int32_t get_boot_context(protocol_t *protocol, bool is_recovery, boot_context_t *ctx);

#endif  /* _BOOT_H_ */
