#ifndef _HELPERS_
#define _HELPERS_

extern "C" {
#include <telit-os-abs.h>
}

int32_t mock_open(const dev_info_t *dev_info, struct _driver *driver);
int32_t mock_send(const struct _driver *driver, const uint8_t *buffer, const int32_t to_write,
        uint32_t *written);
int32_t mock_wait_reply(const struct _driver *driver, const uint32_t ms_timeout);
int32_t mock_read(const struct _driver *driver, uint8_t *buffer, const int32_t to_read, uint32_t *read);
int32_t mock_config(const struct _driver *driver, const bool enable_hw_flow_control);
int32_t mock_set_baud_rate(const struct _driver *driver, const uint32_t rate);
int32_t mock_flush(const struct _driver *driver);
int32_t mock_close(struct _driver *driver);
#endif /* !_HELPERS_ */
