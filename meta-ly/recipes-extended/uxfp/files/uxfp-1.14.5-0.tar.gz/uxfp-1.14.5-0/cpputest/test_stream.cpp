#include <CppUTest/CommandLineTestRunner.h>
#include <CppUTestExt/MockSupport.h>
#include <cstring>

extern "C" {
#include <telit-os-abs.h>
#include "../stream.h"
}

#define EXPECTED_ACK_BOOT_OFFSET_POSITION 0xBE
#define EXPECTED_HW_FLOW_CTRL_POSITION    0xE2
#define EXPECTED_STREAM_OFFSET_POSITION   0x102

enum {
    STREAM_HEADER_BASE,
    STREAM_HEADER_FLEX,
    STREAM_HEADER_FLEX_OEMPRI,
    STREAM_HEADER_VER5,
    STREAM_HEADER_VER6,
    STREAM_HEADER_VER8,
};

enum {
    EXP_HEADER_SIZE_VER4 = 190 /* 0xBE */,
    EXP_HEADER_SIZE_VER5 = 194 /* 0xC2 */,
    EXP_HEADER_SIZE_VER6 = 226 /* 0xE2 */,
    EXP_HEADER_SIZE_VER8 = 262 /* 0x106 */,
};

/* internal representation of stream header used in stream.c */
typedef struct {
    uint16_t header_size;
    char sw_version[32];
    char product_name[32];
    uint16_t memory_type;
    uint16_t stream_version;
    uint32_t speed_offset;
} stream_header_t;

typedef struct {
    char fake_hw_flow_ctrl_string[32];
    bool exp_hw_flow_ctrl_status;
} hw_flow_ctrl_params_t;

stream_header_t fake_stream_header = {
    .header_size = EXP_HEADER_SIZE_VER4,
    /* can't initialize with string due to GCC bug: https://gcc.gnu.org/bugzilla/show_bug.cgi?id=55227 */
    .sw_version = {'3', '2', '.', '1', '2', '3', '.', '4', '5', '6', 0},
};

stream_header_t fake_flex_stream_header = {
    .header_size = EXP_HEADER_SIZE_VER4,
    /* can't initialize with string due to GCC bug: https://gcc.gnu.org/bugzilla/show_bug.cgi?id=55227 */
    .sw_version = {'F', 'L', 'E', 'X', 0},
};

stream_header_t fake_flex_oempri_stream_header = {
    .header_size = EXP_HEADER_SIZE_VER4,
    /* can't initialize with string due to GCC bug: https://gcc.gnu.org/bugzilla/show_bug.cgi?id=55227 */
    .sw_version = {'F', 'L', 'E', 'X', '_', '1', '2', '3', 0},
};

/* Stream header version 5 with ACK BOOT OFFSET */
static uint32_t fake_ack_boot_offset = 0xABCD;
stream_header_t fake_stream_header_ver5 = {
    .header_size = EXP_HEADER_SIZE_VER5,
    /* can't initialize with string due to GCC bug: https://gcc.gnu.org/bugzilla/show_bug.cgi?id=55227 */
    .sw_version = {'3', '2', '.', '1', '2', '3', '.', '4', '5', '6', 0},
    .stream_version = 5,
};

stream_header_t fake_stream_header_ver6 = {
    .header_size = EXP_HEADER_SIZE_VER6,
    /* can't initialize with string due to GCC bug: https://gcc.gnu.org/bugzilla/show_bug.cgi?id=55227 */
    .sw_version = {'3', '2', '.', '1', '2', '3', '.', '4', '5', '6', 0},
    .stream_version = 6,
};

static uint32_t fake_stream_offset = 0xEFFE;
stream_header_t fake_stream_header_ver8 = {
    .header_size = EXP_HEADER_SIZE_VER8,
    /* can't initialize with string due to GCC bug: https://gcc.gnu.org/bugzilla/show_bug.cgi?id=55227 */
    .sw_version = {'3', '2', '.', '1', '2', '3', '.', '4', '5', '6', 0},
    .stream_version = 8,
};


hw_flow_ctrl_params_t hw_flow_ctrl_disabled = {
    .fake_hw_flow_ctrl_string =
    {'N', 'O', ' ', 'H', 'W', ' ', 'F', 'L', 'O', 'W', ' ', 'C', 'O', 'N', 'T', 'R', 'O', 'L', 0},
    .exp_hw_flow_ctrl_status = false,
};

hw_flow_ctrl_params_t hw_flow_ctrl_enabled = {
    .fake_hw_flow_ctrl_string = {0},
    .exp_hw_flow_ctrl_status = true,
};

/* Use this variable inside TEST to select which stream_header_t instance the
 * mock-ed core_file_read shall return */
static int sw_version_type_selector;

/* Use this variable to select which setup should be used between hw flow control necessary or not */
static hw_flow_ctrl_params_t *hw_flow_ctrl_selector;

static uint8_t call_no = 0;
core_res_t core_file_read(const file_handle_t handle, void *buffer, uint32_t bytes_to_read,
        uint32_t *bytes_read)
{
    mock().actualCall(__func__);

    void *stream_header = NULL;
    size_t stream_header_size;

    switch (sw_version_type_selector) {
        case STREAM_HEADER_BASE:
            memcpy(buffer, &fake_stream_header, sizeof(fake_stream_header));
            break;
        case STREAM_HEADER_FLEX:
            memcpy(buffer, &fake_flex_stream_header, sizeof(fake_flex_stream_header));
            break;
        case STREAM_HEADER_FLEX_OEMPRI:
            memcpy(buffer, &fake_flex_oempri_stream_header, sizeof(fake_flex_oempri_stream_header));
            break;
        case STREAM_HEADER_VER5:
            stream_header = &fake_stream_header_ver5;
            stream_header_size = sizeof(fake_stream_header_ver5);
        case STREAM_HEADER_VER6:
            if (stream_header == NULL) {
                stream_header = &fake_stream_header_ver6;
                stream_header_size = sizeof(fake_stream_header_ver6);
            }
        case STREAM_HEADER_VER8:
            if (stream_header == NULL) {
                stream_header = &fake_stream_header_ver8;
                stream_header_size = sizeof(fake_stream_header_ver8);
            }
            /* dirty trick to handle 4 different calls
             * - first call to read stream_header_t
             * - second call to read ack_boot_offset
             * - third call to read stream_offset
             * - forth call to read hw_flow_ctrl */
            switch (++call_no) {
                case 1:
                    memcpy(buffer, stream_header, stream_header_size);
                    break;
                case 2:
                    memcpy(buffer, &fake_ack_boot_offset, sizeof(fake_ack_boot_offset));
                    *bytes_read = sizeof(fake_ack_boot_offset);
                    break;
                case 3:
                    memcpy(buffer, &fake_stream_offset, sizeof(fake_stream_offset));
                    *bytes_read = sizeof(fake_stream_offset);
                    break;
                case 4:
                    memcpy(buffer, hw_flow_ctrl_selector->fake_hw_flow_ctrl_string,
                            strlen(hw_flow_ctrl_selector->fake_hw_flow_ctrl_string));
                    *bytes_read = strlen(hw_flow_ctrl_selector->fake_hw_flow_ctrl_string);
                    break;
            }
    }

    if (mock().hasReturnValue())
        return (core_res_t)mock().intReturnValue();
    return CORE_ERROR_UNKNOWN;
}

core_res_t core_file_get_size(const file_handle_t handle, uint64_t *size)
{
    mock()
    .actualCall(__func__);
    if (mock().hasReturnValue())
        return (core_res_t)mock().intReturnValue();
    return CORE_ERROR_UNKNOWN;
}

core_res_t core_file_lseek_set(file_handle_t handle, int64_t offset)
{
    mock()
    .actualCall(__func__)
    .withParameter("offset", offset);

    if (mock().hasReturnValue())
        return (core_res_t)mock().intReturnValue();
    return CORE_ERROR_UNKNOWN;
}

TEST_GROUP(stream)
{
    void setup()
    {
        /* reset "first_call" global variable to true at the beginning of each
         * test */
        call_no = 0;
        core_log_set_level(LOG_LEVEL_INFO);
    }

    void teardown()
    {
        mock().checkExpectations();
        mock().clear();
    }
};

TEST(stream, get_stream_from_file)
{
    mock()
    .expectOneCall("core_file_read")
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_file_get_size")
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_file_lseek_set")
    .ignoreOtherParameters()
    .andReturnValue(CORE_SUCCESS);

    sw_version_type_selector = STREAM_HEADER_BASE;

    stream_t stream = {};
    int32_t got = stream_get_from_file(99, CHANNEL_SERIAL_USB, &stream);

    CHECK_EQUAL(0, got);
    CHECK_EQUAL(fake_stream_header.header_size, stream.header_size);
    CHECK_TRUE(strcmp("32.123", stream.base_sw_version) == 0);

}

TEST(stream, get_flex_stream_from_file)
{
    mock()
    .expectOneCall("core_file_read")
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_file_get_size")
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_file_lseek_set")
    .ignoreOtherParameters()
    .andReturnValue(CORE_SUCCESS);

    sw_version_type_selector = STREAM_HEADER_FLEX;

    stream_t stream = {};
    int32_t got = stream_get_from_file(99, CHANNEL_SERIAL_USB, &stream);

    CHECK_EQUAL(0, got);
    CHECK_EQUAL(fake_flex_stream_header.header_size, stream.header_size);
    CHECK_TRUE(strcmp("FLEX", stream.base_sw_version) == 0);
}

TEST(stream, get_flex_oempri_stream_from_file)
{
    mock()
    .expectOneCall("core_file_read")
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_file_get_size")
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_file_lseek_set")
    .ignoreOtherParameters()
    .andReturnValue(CORE_SUCCESS);

    sw_version_type_selector = STREAM_HEADER_FLEX_OEMPRI;

    stream_t stream = {};
    int32_t got = stream_get_from_file(99, CHANNEL_SERIAL_USB, &stream);

    CHECK_EQUAL(0, got);
    CHECK_EQUAL(fake_flex_oempri_stream_header.header_size, stream.header_size);
    CHECK_TRUE(strcmp("FLEX_123", stream.base_sw_version) == 0);
}

TEST(stream, get_ack_boot_offset_stream_version_5)
{
    mock()
    .expectNCalls(2, "core_file_read")
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_file_get_size")
    .andReturnValue(CORE_SUCCESS);
    /* core_file_lseek_set is called first to point where the
     * ack_boot_offset is located */
    mock()
    .expectOneCall("core_file_lseek_set")
    .withLongIntParameter("offset", EXPECTED_ACK_BOOT_OFFSET_POSITION)
    .andReturnValue(CORE_SUCCESS);
    /* core_file_lseek_set is then called to point where the payload is located,
     * which for this version of stream header is right after the header. */
    mock()
    .expectOneCall("core_file_lseek_set")
    .withLongIntParameter("offset", fake_stream_header_ver5.header_size)
    .andReturnValue(CORE_SUCCESS);

    sw_version_type_selector = STREAM_HEADER_VER5;
    stream_t stream = {};
    int32_t got = stream_get_from_file(99, CHANNEL_SERIAL_USB, &stream);

    CHECK_EQUAL(0, got);
    CHECK_EQUAL(fake_stream_header_ver5.header_size, stream.header_size);
    CHECK_TRUE(strcmp("32.123", stream.base_sw_version) == 0);
    CHECK_EQUAL(fake_ack_boot_offset, stream.ack_boot_offset);
}

TEST(stream, get_ack_boot_offset_stream_version_6_and_superior)
{
    mock()
    .expectNCalls(2, "core_file_read")
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_file_get_size")
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_file_lseek_set")
    .withLongIntParameter("offset", EXPECTED_ACK_BOOT_OFFSET_POSITION)
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_file_lseek_set")
    .withLongIntParameter("offset", fake_stream_header_ver6.header_size)
    .andReturnValue(CORE_SUCCESS);

    sw_version_type_selector = STREAM_HEADER_VER6;
    stream_t stream = {};
    int32_t got = stream_get_from_file(99, CHANNEL_SERIAL_USB, &stream);

    CHECK_EQUAL(0, got);
    CHECK_EQUAL(fake_stream_header_ver6.header_size, stream.header_size);
    CHECK_TRUE(strcmp("32.123", stream.base_sw_version) == 0);
    CHECK_EQUAL(fake_ack_boot_offset, stream.ack_boot_offset);
}

TEST(stream, stream_version_8_on_serial_shall_point_to_payload)
{
    /* select a mock pattern where hardware flow control is explicitly disabled in the stream */
    hw_flow_ctrl_selector = &hw_flow_ctrl_disabled;

    /* reading header, ack boot offset and stream offset */
    mock()
    .expectNCalls(4, "core_file_read")
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_file_get_size")
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_file_lseek_set")
    .withLongIntParameter("offset", EXPECTED_ACK_BOOT_OFFSET_POSITION)
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_file_lseek_set")
    .withLongIntParameter("offset", EXPECTED_STREAM_OFFSET_POSITION)
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_file_lseek_set")
    .withLongIntParameter("offset", EXPECTED_HW_FLOW_CTRL_POSITION)
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_file_lseek_set")
    .withLongIntParameter("offset", fake_stream_header_ver8.header_size)
    .andReturnValue(CORE_SUCCESS);

    stream_t stream = {};
    int32_t got;

    sw_version_type_selector = STREAM_HEADER_VER8;
    got = stream_get_from_file(99, CHANNEL_SERIAL_PHY, &stream);
    CHECK_EQUAL(CORE_SUCCESS, got);

    CHECK_EQUAL(fake_stream_header_ver8.header_size, stream.header_size);
    CHECK_TRUE(strcmp("32.123", stream.base_sw_version) == 0);
    CHECK_EQUAL(fake_ack_boot_offset, stream.ack_boot_offset);
    CHECK_EQUAL(hw_flow_ctrl_selector->exp_hw_flow_ctrl_status, stream.hw_flow_ctrl);
    /* stream.stream_offset always point to where the payload is, which
     * for serial channel is after the header */
    CHECK_EQUAL(EXP_HEADER_SIZE_VER8, stream.stream_offset);
}

TEST(stream, stream_version_8_on_usb_shall_point_to_payload)
{
    /* select a mock pattern where hardware flow control is not present in the stream (hardware flow control
     * is enabled in this case) */
    hw_flow_ctrl_selector = &hw_flow_ctrl_enabled;

    /* reading header, ack boot offset and stream offset */
    mock()
    .expectNCalls(4, "core_file_read")
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_file_get_size")
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_file_lseek_set")
    .withLongIntParameter("offset", EXPECTED_ACK_BOOT_OFFSET_POSITION)
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_file_lseek_set")
    .withLongIntParameter("offset", EXPECTED_STREAM_OFFSET_POSITION)
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_file_lseek_set")
    .withLongIntParameter("offset", EXPECTED_HW_FLOW_CTRL_POSITION)
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_file_lseek_set")
    .withLongIntParameter("offset", fake_stream_offset)
    .andReturnValue(CORE_SUCCESS);

    stream_t stream = {};
    int32_t got;

    sw_version_type_selector = STREAM_HEADER_VER8;
    got = stream_get_from_file(99, CHANNEL_SERIAL_USB, &stream);
    CHECK_EQUAL(0, got);

    CHECK_EQUAL(fake_stream_header_ver8.header_size, stream.header_size);
    CHECK_TRUE(strcmp("32.123", stream.base_sw_version) == 0);
    CHECK_EQUAL(fake_ack_boot_offset, stream.ack_boot_offset);
    CHECK_EQUAL(fake_stream_offset, stream.stream_offset);
    CHECK_EQUAL(hw_flow_ctrl_selector->exp_hw_flow_ctrl_status, stream.hw_flow_ctrl);
}

int main(int ac, char **av)
{
    return CommandLineTestRunner::RunAllTests(ac, av);
}
