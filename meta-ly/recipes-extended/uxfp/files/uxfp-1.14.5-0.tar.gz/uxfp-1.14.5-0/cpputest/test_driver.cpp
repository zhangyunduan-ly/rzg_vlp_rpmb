#include <CppUTest/CommandLineTestRunner.h>
#include <CppUTestExt/MockSupport.h>

extern "C" {
#include <telit-os-abs.h>
#include "../driver.h"
}

static const dev_info_t modem_with_no_ports = {
    "mock location path",
    "mock serial",
    "1bc7",
    "1040",
    {},
    {""},
    {},
    0,
    "mock devpath"
};
static const dev_info_t modem_with_no_diag = {
    "mock location path",
    "mock serial",
    "1bc7",
    "1040",
    {"/dev/ttyUSB0"},
    {""},
    {"mock driver"},
    1,
    "mock devpath"
};
static const dev_info_t modem_with_empty_vid_pid = {
    "mock location path",
    "mock serial",
    "",
    "",
    {"/dev/ttyUSB0"},
    {""},
    {"mock driver"},
    1,
    "mock devpath"
};
static const dev_info_t modem_with_invalid_vid = {
    "mock location path",
    "mock serial",
    "gggg",
    "1040",
    {"/dev/ttyUSB0"},
    {""},
    {"mock driver"},
    1,
    "mock devpath"
};
static const dev_info_t modem_with_invalid_pid = {
    "mock location path",
    "mock serial",
    "1bc7",
    "hhhh",
    {"/dev/ttyUSB0"},
    {""},
    {"mock driver"},
    1,
    "mock devpath"
};
/* PID 1040 (LM9x0) has the Diag interface number 00 */
static const dev_info_t modem_with_diag_in_iface_number00 = {
    "mock location path",
    "mock serial",
    "1bc7",
    "1040",
    {"/dev/ttyUSB0"},
    {"00"},
    {"mock driver"},
    1,
    "mock devpath"
};
/* PID 0041 (INFINEON) has the Diag interface number 01 */
static const dev_info_t modem_with_diag_in_iface_number01 = {
    "mock location path",
    "mock serial",
    "1bc7",
    "0041",
    {"/dev/ttyUSB0", "/dev/ttyUSB1"},
    {"00", "01"},
    {"mock driver"},
    2,
    "mock devpath"
};
/* PID 1203 (MDM9x15) has the Diag interface number 02 */
static const dev_info_t modem_with_diag_in_iface_number02 = {
    "mock location path",
    "mock serial",
    "1bc7",
    "1203",
    {"/dev/ttyUSB0", "/dev/ttyUSB1"},
    {"00", "02"},
    {"mock driver"},
    2,
    "mock devpath"
};
/* PID 7010 (ASR1601) has the Diag interface number 03 */
static const dev_info_t modem_with_diag_in_iface_number03 = {
    "mock location path",
    "mock serial",
    "1bc7",
    "7010",
    {"/dev/ttyUSB0", "/dev/ttyUSB1"},
    {"00", "03"},
    {"mock driver"},
    2,
    "mock devpath"
};


TEST_GROUP(driver)
{
    void setup()
    {
        core_log_set_level(LOG_LEVEL_ALERT);
        core_log_set_pprint(CORE_LOG_PPRINT_AUTONEWLINE);
    }

};

TEST(driver, modem_with_no_diag_returns_error_no_such_device)
{
    int32_t want = CORE_ERROR_NO_SUCH_DEVICE;
    int32_t got = get_flashing_device_pos(&modem_with_no_diag);
    CHECK_EQUAL(want, got);
};

TEST(driver, modem_with_diag_returns_its_position_or_error)
{
    struct {
        const std::string name;
        const dev_info_t *device;
        const int32_t want;
    } tt [] = {
        {"device with iface number 00", &modem_with_diag_in_iface_number00, 0},
        {"device with iface number 01", &modem_with_diag_in_iface_number01, 1},
        {"device with iface number 02", &modem_with_diag_in_iface_number02, 1},
        {"device with iface number 03", &modem_with_diag_in_iface_number03, 1},
        {"device with no diag returns NO SUCH DEVICE", &modem_with_no_diag, CORE_ERROR_NO_SUCH_DEVICE},
        {"device with invalid VID", &modem_with_invalid_vid, CORE_ERROR_OPERATION_NOT_PERMITTED},
        {"device with invalid PID", &modem_with_invalid_pid, CORE_ERROR_OPERATION_NOT_PERMITTED},
        {"device with empty VID/PID", &modem_with_empty_vid_pid, CORE_ERROR_OPERATION_NOT_PERMITTED},
    };

    for (auto tc: tt) {
        int32_t got = get_flashing_device_pos(tc.device);
        CHECK_EQUAL_TEXT(tc.want, got, tc.name.c_str());
    }
}

TEST(driver, modem_with_no_diag_returns_the_fallback_device)
{
    int32_t want = 0;
    int32_t got = get_flashing_device_or_fallback_position(&modem_with_no_diag);
    CHECK_EQUAL(want, got);
}

TEST(driver, modem_with_no_ports)
{
    int32_t want = CORE_ERROR_NO_SUCH_DEVICE;
    int32_t got = get_flashing_device_or_fallback_position(&modem_with_no_ports);
    CHECK_EQUAL(want, got);
}

TEST(driver, get_driver)
{
    struct {
        channel_t channel;
        chipset_t chipset;
        int32_t want;
    } test_table [] {
        /* the value of chipset_t is not important here */
        {CHANNEL_SERIAL_USB, CHIPSET_MDM9205, CORE_SUCCESS},
        {CHANNEL_SERIAL_PHY, CHIPSET_MDM9205, CORE_SUCCESS},
        {CHANNEL_SERIAL_PCI, CHIPSET_MDM9205, CORE_SUCCESS},
        {CHANNEL_FASTBOOT, CHIPSET_MDM9205, CORE_SUCCESS},
        {CHANNEL_SERIAL_USB_NO_DISCOVERY, CHIPSET_MDM9205, CORE_SUCCESS},
        {CHANNEL_UNKNOWN, CHIPSET_MDM9205, CORE_ERROR_OPERATION_NOT_PERMITTED},
        {CHANNEL_SERIAL_USB, CHIPSET_UNKNOWN, CORE_ERROR_OPERATION_NOT_PERMITTED},
    };

    for (auto tc: test_table) {
        driver_t driver;
        int32_t got = get_driver(tc.channel, tc.chipset, &driver);
        CHECK_EQUAL (tc.want, got);
    }
}


core_res_t core_device_open(const char *device_path, dev_handle_t *handle)
{
    mock()
    .actualCall(__func__);
    return (core_res_t) mock().returnIntValueOrDefault(CORE_SUCCESS);
}

core_res_t core_wait_for_serial(const char *port)
{
    mock()
    .actualCall(__func__);
    return (core_res_t) mock().returnIntValueOrDefault(CORE_SUCCESS);
}

core_res_t core_device_poll(const dev_handle_t handle, const int64_t msec)
{
    mock()
    .actualCall(__func__);
    return (core_res_t) mock().returnIntValueOrDefault(CORE_SUCCESS);
}

TEST_GROUP(low_level)
{
    void setup()
    {
        core_log_set_level(LOG_LEVEL_ALERT);
        core_log_set_pprint(CORE_LOG_PPRINT_AUTONEWLINE);
    }

    void teardown()
    {
        mock().clear();
    }
};

/* Currently, driver_t::generic_open does not distinguish
 * between different core_device_<function> errors, so
 * a generic CORE_ERROR_UNKNOWN is enough for testing */
TEST(low_level, generic_open_error_timeout)
{
    driver_t driver;
    int32_t ret;

    get_driver(CHANNEL_SERIAL_USB, CHIPSET_MDM9205, &driver);

    mock()
    .expectOneCall("core_wait_for_serial")
    .andReturnValue(CORE_ERROR_TIMEOUT);
    mock()
    .expectNoCall("core_device_open");

    ret = driver.open(&modem_with_diag_in_iface_number00, &driver);
    CHECK_EQUAL(CORE_ERROR_TIMEOUT, ret);
    mock().checkExpectations();
}

TEST(low_level, generic_open_error)
{
    driver_t driver;
    int32_t ret;

    get_driver(CHANNEL_SERIAL_USB, CHIPSET_MDM9205, &driver);

    mock()
    .expectOneCall("core_wait_for_serial")
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_device_open")
    .andReturnValue(CORE_ERROR_UNKNOWN);

    ret = driver.open(&modem_with_diag_in_iface_number00, &driver);
    CHECK_EQUAL(CORE_ERROR_UNKNOWN, ret);
    mock().checkExpectations();
}

TEST(low_level, generic_open_device_without_ports)
{
    driver_t driver;
    int32_t ret;

    get_driver(CHANNEL_SERIAL_USB, CHIPSET_MDM9205, &driver);

    mock()
    .expectNoCall("core_wait_for_serial");
    mock()
    .expectNoCall("core_device_open");

    ret = driver.open(&modem_with_no_ports, &driver);
    CHECK_EQUAL(CORE_ERROR_NO_SUCH_DEVICE, ret);
    mock().checkExpectations();
}

TEST(low_level, uart_wait_reply)
{
    driver_t driver;
    int32_t ret;
    struct {
        core_res_t poll_ret;
        int32_t want;
    } test_table [] {
        {CORE_SUCCESS, CORE_SUCCESS},
        {CORE_ERROR_TIMEOUT, CORE_ERROR_TIMEOUT},
        {CORE_ERROR_UNKNOWN, CORE_ERROR_UNKNOWN},
    };

    get_driver(CHANNEL_SERIAL_PHY, CHIPSET_MDM9205, &driver);

    for (auto tc: test_table) {
        mock()
        .expectOneCall("core_device_poll")
        .andReturnValue(tc.poll_ret);

        ret = driver.wait_reply(&driver, 0);
        CHECK_EQUAL(tc.want, ret);
        mock().checkExpectations();
        mock().clear();
    }

    mock()
    .expectNCalls(2, "core_device_poll")
    .andReturnValue(CORE_ERROR_NO_SUCH_DEVICE);
    ret = driver.wait_reply(&driver, 0);
    CHECK_EQUAL(CORE_ERROR_TIMEOUT, ret);
    mock().checkExpectations();
}


int main(int ac, char **av)
{
    return CommandLineTestRunner::RunAllTests(ac, av);
}
