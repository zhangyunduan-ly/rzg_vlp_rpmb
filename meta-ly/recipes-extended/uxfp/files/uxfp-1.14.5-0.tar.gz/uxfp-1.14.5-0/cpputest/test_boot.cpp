#include "CppUTest/CommandLineTestRunner.h"
#include <CppUTestExt/MockSupport.h>
#include <chrono>
#include <cstring>
#include <vector>

#include "helpers.h"

extern "C" {
#include <telit-os-abs.h>
#include "../boot.h"
#include "../protocol.h"
}


#define IS_NOT_RECOVERY false
#define IS_RECOVERY true

static uint8_t ack_buffer_a0[] = {0xA0};
static uint8_t ack_buffer_a1[] = {0xA1};
static uint8_t ack_buffer_92[] = {0x92};
static uint8_t ack_buffer_6260[] = {
    0xF0, 0x16, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0xFF, 0xFF
};
static uint8_t ack_buffer_asr[2] = { 0x4F, 0x4B };
static uint8_t build_id_rsp_fn990_8GB[] = {
    0x7C, 0x01, 0x00, 0x00, 0x11, 0x16, 0x00, 0x00, 0x4E, 0x01,
    0x00, 0x00, 0x34, 0x35, 0x2E, 0x35, 0x30, 0x2E, 0x30, 0x31,
    0x32, 0x2D, 0x42, 0x38, 0x31, 0x31, 0x00, 0x00, 0x88, 0x88,
    0x7E
};
static uint8_t build_id_rsp_fn990_4GB_model_1[] = {  /* "45.00.013" */
    0x7C, 0x01, 0x00, 0x00, 0x11, 0x16, 0x00, 0x00, 0x4E, 0x01,
    0x00, 0x00, 0x34, 0x35, 0x2E, 0x30, 0x30, 0x2E, 0x30, 0x31,
    0x33, 0x00, 0x00, 0xA1, 0x1F, 0x7E
};
static uint8_t build_id_rsp_fn990_4GB_model_4[] = {  /* "45.00.043" */
    0x7C, 0x01, 0x00, 0x00, 0x11, 0x16, 0x00, 0x00, 0x4E, 0x01,
    0x00, 0x00, 0x34, 0x35, 0x2E, 0x30, 0x30, 0x2E, 0x30, 0x34,
    0x33, 0x00, 0x00, 0xA1, 0x1F, 0x7E
};
static uint8_t mock_fn990_chunk_1[] = {
    0x4E, 0x00, 0x34, 0x35, 0x2E, 0x30, 0x30, 0x2E, 0x31, 0x58,
    0x30, 0x2D, 0x42, 0x30, 0x30, 0x35, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x46, 0x4E, 0x39, 0x39, 0x30, 0x41,
    0x32, 0x38, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x02, 0x00,
    0x05, 0x00, 0x00, 0x00, 0x25, 0x05, 0x11, 0x00
};
static uint8_t mock_fn990_chunk_2[] = {
    0x00, 0x1B, 0x01, 0x6D, 0x6F, 0x64, 0x65, 0x6D, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0xAC, 0x04, 0xAD, 0x04, 0x00, 0x00, 0x01, 0x01, 0x00,
    0x4D, 0x30, 0x52, 0x2E, 0x31, 0x30, 0x30, 0x30, 0x30, 0x30,
    0x2D, 0x42, 0x30, 0x30, 0x35, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00
};

static int32_t mock_open_fail(const dev_info_t *dev_info, struct _driver *driver)
{
    return CORE_ERROR_UNKNOWN;
}

static int32_t mock_send_fail(const struct _driver *driver, const uint8_t *buffer, const int32_t to_write,
        uint32_t *written)
{
    mock()
    .actualCall(__func__)
    .withOutputParameter("written", written);
    return (core_res_t)mock().returnIntValueOrDefault(CORE_SUCCESS);
}

static int32_t mock_read_fail(const struct _driver *driver, uint8_t *buffer, const int32_t to_read,
        uint32_t *read)
{
    mock()
    .actualCall(__func__)
    .withOutputParameter("read", read);
    return (core_res_t)mock().returnIntValueOrDefault(CORE_ERROR_UNKNOWN);
}

static int32_t mock_read_nack(const struct _driver *driver, uint8_t *buffer, const int32_t to_read,
        uint32_t *read)
{
    *read = to_read;
    buffer[0] = 0x0;
    return CORE_SUCCESS;
}

static int32_t mock_config_fail(const struct _driver *driver, const bool enable_hw_flow_control)
{
    return CORE_ERROR_UNKNOWN;
}


static dev_info_t mock_zero_modem_connected[] = { {} };

/* The usb_id_t values and device path are not important for the
 * tests using this structure. */
static dev_info_t mock_one_modem_connected[1] = {
    {"mock location path", "mock serial", "1bc7", "1040", {"/dev/ttyUSB0"}, {"00"}, {"modem driver"}, 1,
     "mock devpath"}
};

core_res_t core_device_enumerate(const usb_id_t *usbid_list,
        const uint8_t usbid_list_size,
        dev_info_t *dev_list,
        int8_t *dev_list_size)
{
    mock()
    .actualCall(__func__)
    .withOutputParameter("dev_list", dev_list)
    .withOutputParameter("dev_list_size", dev_list_size);
    return (core_res_t)mock().returnIntValueOrDefault(CORE_SUCCESS);
}

int32_t read_chunk_from_stream(const file_handle_t file,
        data_big_block_t *chunk,
        uint32_t *bytes)
{
    mock()
    .actualCall(__func__)
    .withOutputParameter("chunk", chunk)
    .withOutputParameter("bytes", bytes);
    return (core_res_t)mock().returnIntValueOrDefault(CORE_SUCCESS);
}

core_res_t core_device_usb_id_event_listener(bool (*condition)(dev_info_t *info, void *data),
        void *data,
        uint32_t timeout_ms,
        usb_id_t *event)
{
    mock()
    .actualCall(__func__)
    .withOutputParameter("event", event);
    return (core_res_t)mock().intReturnValue();
}

core_res_t core_wait_for_serial(const char *port)
{
    mock()
    .actualCall(__func__);
    return (core_res_t) mock().returnIntValueOrDefault(CORE_SUCCESS);
}

core_res_t core_endpoint_open(const dev_info_t *info, dev_ctx_t *endpoint)
{
    mock()
    .actualCall(__func__);
    return (core_res_t)mock().returnIntValueOrDefault(CORE_ERROR_UNKNOWN);
}

/* Testing USB MODE B + FASTBOOT */
protocol_t protocol = {};
boot_context_t ctx = {};
driver_t driver = {};

static void
reset_driver(driver_t *driver)
{
    driver->open = mock_open;
    driver->send = mock_send;
    driver->read = mock_read;
    driver->wait_reply = mock_wait_reply;
    driver->configure = mock_config;
    driver->set_baud_rate = mock_set_baud_rate;
    driver->close = mock_close;
}

TEST_GROUP(generic) {
    void setup()
    {
        /* disable logging; to enable a more verbose logging, please use some other options,
         * such as LOG_LEVEL_DBG */
        core_log_set_level(LOG_LEVEL_ALERT);
        core_log_set_pprint(CORE_LOG_PPRINT_AUTONEWLINE);

        memset(&ctx, 0, sizeof(ctx));
        memset(&protocol, 0, sizeof(protocol));
        reset_driver(&driver);

        get_protocol_from_chipset(CHIPSET_GEN_QC_1, CHANNEL_SERIAL_USB, &protocol);
        get_boot_context(&protocol, IS_NOT_RECOVERY, &ctx);
        ctx.retries = 10;
        ctx.timeout = 0;
    }

    void teardown()
    {
        mock().clear();
    }
};

TEST(generic, no_devices_connected)
{
    /* GIVEN */
    int8_t exp_dev_list_size = 0;
    /* we are forced to set a usb_id_t value for core_device_usb_id_event_listener.
     * In this test we expect a timeout error, so the event usb_id_t is empty */
    usb_id_t no_event = {};

    mock()
    .expectNCalls(4, "core_device_enumerate")
    .withOutputParameterReturning("dev_list", &mock_zero_modem_connected, sizeof(mock_zero_modem_connected))
    .withOutputParameterReturning("dev_list_size", &exp_dev_list_size, sizeof(exp_dev_list_size))
    .andReturnValue(CORE_ERROR_NO_SUCH_DEVICE);
    mock()
    .expectNCalls(2, "core_device_usb_id_event_listener")
    .withOutputParameterReturning("event", &no_event, sizeof(no_event))
    .andReturnValue(CORE_ERROR_TIMEOUT);
    mock().ignoreOtherCalls();

    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);
    /* THEN */
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
    mock().checkExpectations();
}

TEST(generic, too_many_devices)
{
    /* GIVEN */
    dev_info_t mock_two_modem_connected[2] = {
        {"mock location path 1", "mock serial 1", "1bc7", "1040", {"/dev/ttyUSB0"}, {"00"}, {"modem driver"},
         1, "mock devpath 1"},
        {"mock location path 2", "mock serial 2", "1bc7", "1041", {"/dev/ttyUSB4"}, {"00"}, {"modem driver"},
         1, "mock devpath 2"}
    };
    int8_t exp_dev_list_size = 2;

    mock()
    .expectNCalls(2, "core_device_enumerate")
    .withOutputParameterReturning("dev_list", &mock_two_modem_connected, sizeof(mock_two_modem_connected))
    .withOutputParameterReturning("dev_list_size", &exp_dev_list_size, sizeof(exp_dev_list_size))
    .andReturnValue(CORE_SUCCESS);
    mock().ignoreOtherCalls();

    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
    mock().checkExpectations();
}

TEST(generic, two_devices_but_port_given)
{
    /* GIVEN */
    dev_info_t mock_two_modem_connected[2] = {
        {"mock location path 1", "mock serial 1", "1bc7", "1040", {"/dev/ttyUSB0"}, {"00"}, {"modem driver"},
         1, "mock devpath 1"},
        {"mock location path 2", "mock serial 2", "1bc7", "1041", {"/dev/ttyUSB4"}, {"00"}, {"modem driver"},
         1, "mock devpath 2"}
    };
    int8_t exp_dev_list_size = 2;
    const char *devpath = "/dev/ttyUSB0";

    ctx.dev_info.comm_ports_number = 1;
    strlcpy(ctx.dev_info.comm_ports[0], devpath, sizeof(ctx.dev_info.comm_ports[0]));

    mock()
    .expectOneCall("core_device_enumerate")
    .withOutputParameterReturning("dev_list", &mock_two_modem_connected, sizeof(mock_two_modem_connected))
    .withOutputParameterReturning("dev_list_size", &exp_dev_list_size, sizeof(exp_dev_list_size))
    .andReturnValue(CORE_SUCCESS);
    mock().ignoreOtherCalls();
    mock()
    .expectOneCall("mock_read")
    .withOutputParameterReturning("buffer", ack_buffer_a0, sizeof(ack_buffer_a0));

    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_SUCCESS, ret);
    mock().checkExpectations();

}

TEST(generic, enter_boot_mode_open_fail)
{
    /* GIVEN */
    int8_t exp_dev_list_size = 1;
    driver.open = mock_open_fail;

    mock()
    .expectNCalls(2, "core_device_enumerate")
    .withOutputParameterReturning("dev_list", &mock_one_modem_connected, sizeof(mock_one_modem_connected))
    .withOutputParameterReturning("dev_list_size", &exp_dev_list_size, sizeof(exp_dev_list_size))
    .andReturnValue(CORE_SUCCESS);

    mock().ignoreOtherCalls();

    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
    mock().checkExpectations();
}

TEST(generic, enter_boot_mode_configure_fail)
{
    /* GIVEN */
    int8_t exp_dev_list_size = 1;

    driver.configure = mock_config_fail;

    mock()
    .expectNCalls(2, "core_device_enumerate")
    .withOutputParameterReturning("dev_list", &mock_one_modem_connected, sizeof(mock_one_modem_connected))
    .withOutputParameterReturning("dev_list_size", &exp_dev_list_size, sizeof(exp_dev_list_size))
    .andReturnValue(CORE_SUCCESS);

    mock().ignoreOtherCalls();

    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
    mock().checkExpectations();
}

TEST(generic, enter_boot_mode_send_fail)
{
    /* GIVEN */
    int8_t exp_dev_list_size = 1;
    uint32_t zero = 0;
    mock()
    .expectNCalls(2, "core_device_enumerate")
    .withOutputParameterReturning("dev_list", &mock_one_modem_connected, sizeof(mock_one_modem_connected))
    .withOutputParameterReturning("dev_list_size", &exp_dev_list_size, sizeof(exp_dev_list_size))
    .andReturnValue(CORE_SUCCESS);

    driver.send = mock_send_fail;
    mock()
    .expectNCalls(2, "mock_send_fail")
    .withOutputParameterReturning("written", &zero, sizeof(zero))
    .andReturnValue(CORE_ERROR_UNKNOWN);

    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
    mock().checkExpectations();
}

/* Fixing this test resulted in a very long execution time: ~11 seconds
 * so setting it as to be ignored. Remove the "IGNORE_" prefix to work on it */
TEST(generic, enter_boot_mode_send_incomplete)
{
    /* GIVEN */
    int8_t exp_dev_list_size = 1;
    uint32_t zero = 0;
    mock()
    .expectOneCall("core_device_enumerate")
    .withOutputParameterReturning("dev_list", &mock_one_modem_connected, sizeof(mock_one_modem_connected))
    .withOutputParameterReturning("dev_list_size", &exp_dev_list_size, sizeof(exp_dev_list_size))
    .andReturnValue(CORE_SUCCESS);

    driver.send = mock_send_fail;
    /* Simulate a zero write into the modem, but with no error code returned by
     * driver->send. This results in 7 retries to send the boot char */
    mock()
    .expectNCalls(7, "mock_send_fail")
    .withOutputParameterReturning("written", &zero, sizeof(zero))
    .andReturnValue(CORE_SUCCESS);

    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
    mock().checkExpectations();
}

TEST(generic, enter_boot_mode_read_fail)
{
    /* GIVEN */
    int8_t exp_dev_list_size = 1;
    const char *devpath = "/dev/ttyUSB0";
    ctx.dev_info.comm_ports_number = 1;
    strlcpy(ctx.dev_info.comm_ports[0], devpath, sizeof(ctx.dev_info.comm_ports[0]));

    driver.read = mock_read_fail;

    mock()
    .expectOneCall("core_device_enumerate")
    .withOutputParameterReturning("dev_list",
            &mock_one_modem_connected,
            sizeof(mock_one_modem_connected))
    .withOutputParameterReturning("dev_list_size",
            &exp_dev_list_size,
            sizeof(exp_dev_list_size))
    .andReturnValue(CORE_SUCCESS);

    /* Simulate a read from the modem, but with an error code returned by
     * driver->read. This results in 7 retries to read a valid boot char */
    mock()
    .expectNCalls(7, "mock_read_fail")
    .withOutputParameterReturning("read", ack_buffer_a0, sizeof(ack_buffer_a0))
    .andReturnValue(CORE_ERROR_IO_ERROR);

    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
    mock().checkExpectations();

}

TEST(generic, enter_boot_mode_read_incomplete)
{
    /* GIVEN */
    int8_t exp_dev_list_size = 1;

    driver.read = mock_read_fail;
    mock().setData("read", 0);

    const char *devpath = "/dev/ttyUSB0";
    ctx.dev_info.comm_ports_number = 1;
    strlcpy(ctx.dev_info.comm_ports[0], devpath, sizeof(ctx.dev_info.comm_ports[0]));

    mock()
    .expectOneCall("core_device_enumerate")
    .withOutputParameterReturning("dev_list",
            &mock_one_modem_connected,
            sizeof(mock_one_modem_connected))
    .withOutputParameterReturning("dev_list_size",
            &exp_dev_list_size,
            sizeof(exp_dev_list_size))
    .andReturnValue(CORE_SUCCESS);

    /* Simulate a read from the modem, but with an error code returned by
     * driver->read. This results in 7 retries to read a valid boot char */
    mock()
    .expectNCalls(7, "mock_read_fail")
    .withOutputParameterReturning("read", ack_buffer_a0, sizeof(ack_buffer_a0))
    .andReturnValue(CORE_ERROR_UNKNOWN);

    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
    mock().checkExpectations();
}

TEST(generic, enter_boot_mode_stop_after_restart)
{
    /* GIVEN */
    dev_info_t mock_modem_connected[] = {
        {"mock location path 1", "mock serial 1", "1bc7", "1040", {"/dev/ttyUSB0"}, {"00"}, {"modem driver"},
         1, "mock devpath 1"},
    };
    int8_t exp_dev_list_size = 1;
    const char *devpath = "/dev/ttyUSB0";

    ctx.dev_info.comm_ports_number = 1;
    strlcpy(ctx.dev_info.comm_ports[0], devpath, sizeof(ctx.dev_info.comm_ports[0]));

    mock()
    .expectOneCall("core_device_enumerate")
    .withOutputParameterReturning("dev_list", &mock_modem_connected, sizeof(mock_modem_connected))
    .withOutputParameterReturning("dev_list_size", &exp_dev_list_size, sizeof(exp_dev_list_size))
    .andReturnValue(CORE_SUCCESS);
    mock().ignoreOtherCalls();
    mock()
    .expectOneCall("mock_read")
    .withOutputParameterReturning("buffer", ack_buffer_a0, sizeof(ack_buffer_a0));

    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, true, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_SUCCESS, ret);
    mock().checkExpectations();

}

TEST_GROUP(chipset_sdx20) {
    void setup()
    {
        /* disable logging; to enable a more verbose logging, please use some other options,
         * such as LOG_LEVEL_DBG */
        core_log_set_level(LOG_LEVEL_ALERT);
        core_log_set_pprint(CORE_LOG_PPRINT_AUTONEWLINE);

        memset(&ctx, 0, sizeof(ctx));
        memset(&protocol, 0, sizeof(protocol));
        reset_driver(&driver);

        get_protocol_from_chipset(CHIPSET_SDX20, CHANNEL_SERIAL_USB, &protocol);
        get_boot_context(&protocol, IS_NOT_RECOVERY, &ctx);
        ctx.retries = 10;
        ctx.timeout = 0;

        /* This calls are just to mock the actual modem connected and rebooted into fastboot */
        int8_t exp_dev_list_size = 1;
        usb_id_t recovery = {0x18d1, 0xd00d};
        mock()
        .expectNCalls(2, "core_device_enumerate")
        .withOutputParameterReturning("dev_list", &mock_one_modem_connected, sizeof(mock_one_modem_connected))
        .withOutputParameterReturning("dev_list_size", &exp_dev_list_size, sizeof(exp_dev_list_size))
        .andReturnValue(CORE_SUCCESS);
        mock()
        .expectOneCall("core_device_usb_id_event_listener")
        .withOutputParameterReturning("event", &recovery, sizeof(recovery))
        .andReturnValue(CORE_SUCCESS);
    }

    void teardown()
    {
        mock().clear();
        mock().checkExpectations();
    }
};

TEST(chipset_sdx20, enter_boot_mode_usb_success) {
    /* GIVEN */
    usb_id_t recovery = {0x05c6, 0x9008};

    mock()
    .expectOneCall("mock_read")
    .withOutputParameterReturning("buffer", ack_buffer_a0, sizeof(ack_buffer_a0));
    mock()
    .expectOneCall("core_device_usb_id_event_listener")
    .withOutputParameterReturning("event", &recovery, sizeof(recovery))
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_device_enumerate");

    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_SUCCESS, ret);
};

TEST(chipset_sdx20, enter_boot_mode_usb_nack) {
    /* GIVEN */
    usb_id_t recovery = {0x05c6, 0x9008};

    driver.read = mock_read_nack;

    mock()
    .expectNCalls(2, "core_device_usb_id_event_listener")
    .withOutputParameterReturning("event", &recovery, sizeof(recovery))
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectNCalls(2, "core_device_enumerate");

    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
};

TEST_GROUP(chipset_sdx20_recovery) {
    void setup()
    {
        /* disable logging; to enable a more verbose logging, please use some other options,
         * such as LOG_LEVEL_DBG */
        core_log_set_level(LOG_LEVEL_ALERT);
        core_log_set_pprint(CORE_LOG_PPRINT_AUTONEWLINE);

        memset(&ctx, 0, sizeof(ctx));
        memset(&protocol, 0, sizeof(protocol));
        reset_driver(&driver);

        get_protocol_from_chipset(CHIPSET_SDX20, CHANNEL_SERIAL_USB, &protocol);
        get_boot_context(&protocol, IS_RECOVERY, &ctx);
        ctx.retries = 10;
        ctx.timeout = 0;

        /* This calls are just to mock the actual modem connected and rebooted into fastboot */
        int8_t exp_dev_list_size = 1;
        mock()
        .expectOneCall("core_device_enumerate")
        .withOutputParameterReturning("dev_list", &mock_one_modem_connected, sizeof(mock_one_modem_connected))
        .withOutputParameterReturning("dev_list_size", &exp_dev_list_size, sizeof(exp_dev_list_size))
        .andReturnValue(CORE_SUCCESS);
    }

    void teardown()
    {
        mock().clear();
        mock().checkExpectations();
    }
};

TEST(chipset_sdx20_recovery, enter_boot_mode_usb_success) {
    /* GIVEN */
    mock()
    .expectOneCall("mock_read")
    .withOutputParameterReturning("buffer", ack_buffer_a0, sizeof(ack_buffer_a0));
    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_SUCCESS, ret);
};

TEST(chipset_sdx20_recovery, enter_boot_mode_usb_nack) {
    /* GIVEN */
    driver.read = mock_read_nack;

    /* WHEN */
    /* it is worth noting that in case of nack, it is used the boot context field "retries". In this case,
     * that value is slighlty different from the 'TEST(chipset_sdx20, enter_boot_mode_usb_nack); this is due
     * to the mocks functions failures that are different in those tests, without any reset of its original
     * value; so this part of algorithm may need further investigations */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
};

TEST_GROUP(chipset_asr1601) {
    void setup()
    {
        /* disable logging; to enable a more verbose logging, please use some other options,
         * such as LOG_LEVEL_DBG */
        core_log_set_level(LOG_LEVEL_ALERT);
        core_log_set_pprint(CORE_LOG_PPRINT_AUTONEWLINE);

        memset(&ctx, 0, sizeof(ctx));
        memset(&protocol, 0, sizeof(protocol));
        reset_driver(&driver);

        get_protocol_from_chipset(CHIPSET_ASR1601, CHANNEL_SERIAL_USB, &protocol);
        get_boot_context(&protocol, IS_NOT_RECOVERY, &ctx);
        ctx.retries = 10;
        ctx.timeout = 0;

        /* This calls are just to mock the actual modem connected and rebooted into fastboot */
        int8_t exp_dev_list_size = 1;
        usb_id_t recovery = {0x1bc7, 0x9200};
        mock()
        .expectNCalls(2, "core_device_enumerate")
        .withOutputParameterReturning("dev_list", &mock_one_modem_connected, sizeof(mock_one_modem_connected))
        .withOutputParameterReturning("dev_list_size", &exp_dev_list_size, sizeof(exp_dev_list_size))
        .andReturnValue(CORE_SUCCESS);
        mock()
        .expectOneCall("core_device_usb_id_event_listener")
        .withOutputParameterReturning("event", &recovery, sizeof(recovery))
        .andReturnValue(CORE_SUCCESS);
    }

    void teardown()
    {
        mock().clear();
        mock().checkExpectations();
    }
};

TEST(chipset_asr1601, enter_boot_mode_usb_success) {
    /* GIVEN */
    usb_id_t recovery = {0x05c6, 0x9008};

    mock()
    .expectOneCall("mock_read")
    .withOutputParameterReturning("buffer", ack_buffer_a0, sizeof(ack_buffer_a0));
    mock()
    .expectOneCall("core_device_usb_id_event_listener")
    .withOutputParameterReturning("event", &recovery, sizeof(recovery))
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_device_enumerate");

    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_SUCCESS, ret);
};

TEST(chipset_asr1601, enter_boot_mode_usb_nack) {
    /* GIVEN */
    usb_id_t recovery = {0x05c6, 0x9008};

    driver.read = mock_read_nack;

    mock()
    .expectOneCall("core_device_usb_id_event_listener")
    .withOutputParameterReturning("event", &recovery, sizeof(recovery))
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_device_enumerate");

    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
};

TEST_GROUP(chipset_mdm9205_serial_phy)
{
    void setup()
    {
        /* disable logging; to enable a more verbose logging, please use some other options,
         * such as LOG_LEVEL_DBG */
        core_log_set_level(LOG_LEVEL_ALERT);
        core_log_set_pprint(CORE_LOG_PPRINT_AUTONEWLINE);

        memset(&ctx, 0, sizeof(ctx));
        memset(&protocol, 0, sizeof(protocol));
        reset_driver(&driver);

        get_protocol_from_chipset(CHIPSET_MDM9205, CHANNEL_SERIAL_PHY, &protocol);
        get_boot_context(&protocol, IS_NOT_RECOVERY, &ctx);
        ctx.retries = 10;
        ctx.timeout = 0;
    }

    void teardown()
    {
        mock().clear();
    }
};

TEST(chipset_mdm9205_serial_phy, enter_boot_mode_serial_success)
{
    /* GIVEN */
    mock()
    .expectOneCall("mock_read")
    .withOutputParameterReturning("buffer", ack_buffer_a0, sizeof(ack_buffer_a0));

    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_SUCCESS, ret);
    mock().checkExpectations();
};

TEST(chipset_mdm9205_serial_phy, enter_boot_mode_serial_nack)
{
    /* GIVEN */
    driver.read = mock_read_nack;

    /* WHEN */
    /* it is worth noting that the max retries number, set to 10 in the TEST_GROUP function, is using 10
     * units from retries; this way, the retries are decreased and may not be available for other retries.
     * Since the 'retries' field in boot context has no reset, and taking into account that the
     * 'generic_ack_compare' may return only BOOT_MODE_STEP_SEND and BOOT_MODE_STEP_ERROR (which eventually
     * results in the same operation of the BOOT_MODE_STEP_SEND), it seems that this part of algorithm should
     * be investigated further */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
};

TEST_GROUP(chipset_mdm9205_usb)
{
    dev_info_t mock_one_mdm9205_connected[1] = {
        {"mock location path", "mock serial", "1bc7", "110A", {"/dev/ttyUSB0"}, {"00"}, {"modem driver"}, 1,
         "mock devpath"}
    };

    dev_info_t mock_one_mdm9205_recovery_connected[1] = {
        {"mock location path", "mock serial", "05c6", "9008", {"/dev/ttyUSB0"}, {"00"}, {"modem driver"}, 1,
         "mock devpath"}
    };

    void setup()
    {
        /* disable logging; to enable a more verbose logging, please use some other options,
         * such as LOG_LEVEL_DBG */
        core_log_set_level(LOG_LEVEL_ALERT);
        core_log_set_pprint(CORE_LOG_PPRINT_AUTONEWLINE);

        memset(&ctx, 0, sizeof(ctx));
        memset(&protocol, 0, sizeof(protocol));
        reset_driver(&driver);

        get_protocol_from_chipset(CHIPSET_MDM9205, CHANNEL_SERIAL_USB, &protocol);
        get_boot_context(&protocol, IS_NOT_RECOVERY, &ctx);
        ctx.retries = 10;
        ctx.timeout = 0;

        usb_id_t recovery = {0x05c6, 0x9008};
        mock()
        .expectOneCall("core_device_usb_id_event_listener")
        .withOutputParameterReturning("event", &recovery, sizeof(recovery))
        .andReturnValue(CORE_SUCCESS);
    }

    void teardown()
    {
        mock().clear();
        mock().checkExpectations();
    }
};

TEST(chipset_mdm9205_usb, enter_boot_mode_usb_success)
{
    /* GIVEN */
    /* This calls are just to mock the actual modem connected and rebooted into fastboot */
    int8_t exp_dev_list_size = 1;
    mock()
    .expectOneCall("core_device_enumerate")
    .withOutputParameterReturning("dev_list_size", &exp_dev_list_size, sizeof(exp_dev_list_size))
    .withOutputParameterReturning("dev_list",
            &mock_one_mdm9205_connected,
            sizeof(mock_one_mdm9205_connected))
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("core_device_enumerate")
    .withOutputParameterReturning("dev_list_size", &exp_dev_list_size, sizeof(exp_dev_list_size))
    .withOutputParameterReturning("dev_list",
            &mock_one_mdm9205_recovery_connected,
            sizeof(mock_one_mdm9205_recovery_connected))
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("mock_read")
    .withOutputParameterReturning("buffer", ack_buffer_a1, sizeof(ack_buffer_a1));

    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_SUCCESS, ret);
}

TEST_GROUP(chipset_xg110) {
    void setup()
    {
        /* disable logging; to enable a more verbose logging, please use some other options,
         * such as LOG_LEVEL_DBG */
        core_log_set_level(LOG_LEVEL_ALERT);
        core_log_set_pprint(CORE_LOG_PPRINT_AUTONEWLINE);

        memset(&ctx, 0, sizeof(ctx));
        memset(&protocol, 0, sizeof(protocol));
        reset_driver(&driver);

        get_protocol_from_chipset(CHIPSET_XG110, CHANNEL_SERIAL_PHY, &protocol);
        get_boot_context(&protocol, IS_NOT_RECOVERY, &ctx);
        ctx.retries = 10;
        ctx.timeout = 0;
    }

    void teardown()
    {
        mock().clear();
    }
};

TEST(chipset_xg110, enter_boot_mode_serial_success) {
    /* GIVEN */
    mock()
    .expectOneCall("mock_read")
    .withOutputParameterReturning("buffer", ack_buffer_92, sizeof(ack_buffer_92));

    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_SUCCESS, ret);
    mock().checkExpectations();
};

TEST(chipset_xg110, enter_boot_mode_serial_nack) {
    /* GIVEN */
    driver.read = mock_read_nack;

    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
};

TEST_GROUP(chipset_6260) {
    void setup()
    {
        /* disable logging; to enable a more verbose logging, please use some other options,
         * such as LOG_LEVEL_DBG */
        core_log_set_level(LOG_LEVEL_ALERT);
        core_log_set_pprint(CORE_LOG_PPRINT_AUTONEWLINE);

        memset(&ctx, 0, sizeof(ctx));
        memset(&protocol, 0, sizeof(protocol));
        reset_driver(&driver);

        get_protocol_from_chipset(CHIPSET_6260, CHANNEL_SERIAL_USB, &protocol);
        get_boot_context(&protocol, IS_NOT_RECOVERY, &ctx);
        ctx.retries = 10;
        ctx.timeout = 0;

        /* This calls are just to mock the actual modem connected and rebooted into fastboot */
        int8_t exp_dev_list_size = 1;
        mock()
        .expectOneCall("core_device_enumerate")
        .withOutputParameterReturning("dev_list_size", &exp_dev_list_size, sizeof(exp_dev_list_size))
        .withOutputParameterReturning("dev_list", &mock_one_modem_connected, sizeof(mock_one_modem_connected))
        .andReturnValue(CORE_SUCCESS);
    }

    void teardown()
    {
        mock().clear();
        mock().checkExpectations();
    }
};

TEST(chipset_6260, enter_boot_mode_usb_success) {
    /* GIVEN */
    mock()
    .expectOneCall("mock_read")
    .withOutputParameterReturning("buffer",
            ack_buffer_6260,
            sizeof(ack_buffer_6260));

    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_SUCCESS, ret);
};

TEST(chipset_6260, enter_boot_mode_usb_nack) {
    /* GIVEN */
    driver.read = mock_read_nack;

    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
};

TEST_GROUP(chipset_6260_serial) {
    void setup()
    {
        /* disable logging; to enable a more verbose logging, please use some other options,
         * such as LOG_LEVEL_DBG */
        core_log_set_level(LOG_LEVEL_ALERT);
        core_log_set_pprint(CORE_LOG_PPRINT_AUTONEWLINE);

        memset(&ctx, 0, sizeof(ctx));
        memset(&protocol, 0, sizeof(protocol));
        reset_driver(&driver);

        get_protocol_from_chipset(CHIPSET_6260, CHANNEL_SERIAL_PHY, &protocol);
        get_boot_context(&protocol, IS_NOT_RECOVERY, &ctx);
        ctx.retries = 10;
        ctx.timeout = 0;
    }

    void teardown()
    {
        mock().clear();
    }
};

TEST(chipset_6260_serial, enter_boot_mode_serial_success) {
    /* GIVEN */
    mock()
    .expectOneCall("mock_read")
    .withOutputParameterReturning("buffer",
            ack_buffer_6260,
            sizeof(ack_buffer_6260));

    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_SUCCESS, ret);
    mock().checkExpectations();
}

TEST(chipset_6260_serial, enter_boot_mode_serial_nack) {
    /* GIVEN */
    driver.read = mock_read_nack;

    /* WHEN */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* THEN */
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
    mock().checkExpectations();
};

TEST_GROUP(bootloader_quirks)
{
    void setup()
    {
        /* disable logging; to enable a more verbose logging, please use some other options,
         * such as LOG_LEVEL_DBG */
        core_log_set_level(LOG_LEVEL_ALERT);
        core_log_set_pprint(CORE_LOG_PPRINT_AUTONEWLINE);

        memset(&ctx, 0, sizeof(ctx));
        memset(&protocol, 0, sizeof(protocol));
        reset_driver(&driver);
    }

    void teardown()
    {
        mock().clear();
    }
};

TEST(bootloader_quirks, enable_zlp)
{
    int8_t exp_dev_list_size = 1;
    dev_info_t mock_modem_with_no_comm_port[1] = {
        {"mock location path", "mock serial", "1bc7", "9010", {""}, {"00"}, {"mock driver"}, 1,
         "mock devpath"}
    };

    get_protocol_from_chipset(CHIPSET_SDX55, CHANNEL_SERIAL_USB, &protocol);
    get_boot_context(&protocol, IS_RECOVERY, &ctx);
    ctx.retries = 10;
    ctx.timeout = 0;

    mock()
    .expectNCalls(2, "core_device_enumerate")
    .withOutputParameterReturning("dev_list", &mock_modem_with_no_comm_port,
            sizeof(mock_modem_with_no_comm_port))
    .withOutputParameterReturning("dev_list_size", &exp_dev_list_size, sizeof(exp_dev_list_size))
    .andReturnValue(CORE_SUCCESS);
    mock().ignoreOtherCalls();
    mock()
    .expectNCalls(2, "core_endpoint_open")
    .andReturnValue(CORE_ERROR_UNKNOWN);

    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* ZLP is enabled on the fastboot driver, which uses the endpoint directly.
     * So, when the bootloader device is recognized, the boot module reloads
     * the appropriate driver calling "get_driver" and the real fastboot driver
     * will fail opening the false device path stored in the mock dev_info_t
     * used by this test. This failure's nature depends on the libusb in use.
     * We mock the endpoint open to report the failure, just to verify the code
     * path up to this point and taking into account that the test is related
     * to the quirks software path, but mocking also the endpoint functions for
     * exchanging data will result in a deeper test.
     * If not for this limitation, this is a valid use case
     * and the real UXFP shall return CORE_SUCCESS. */
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
    CHECK_TRUE(driver.device.enable_zlp);
    mock().checkExpectations();
}

/* If modem discovery is not enabled (e.g. built without Udev support), UXFP
 * returns with CORE_ERROR_OPERATION_NOT_PERMITTED, unless:
 * A) --port is given, or
 * B) the modem is in recovery and not using a system driver.
 *
 * See boot.c:BOOT_MODE_ENUMERATE section */
TEST(bootloader_quirks, no_modem_discovery)
{
    int8_t exp_dev_list_size = 0;

    get_protocol_from_chipset(CHIPSET_SDX55, CHANNEL_SERIAL_USB, &protocol);
    get_boot_context(&protocol, IS_NOT_RECOVERY, &ctx);

    mock()
    .expectNCalls(2, "core_device_enumerate")
    .withOutputParameterReturning("dev_list", &mock_zero_modem_connected, sizeof(mock_zero_modem_connected))
    .withOutputParameterReturning("dev_list_size", &exp_dev_list_size, sizeof(exp_dev_list_size))
    .andReturnValue(CORE_ERROR_NOT_IMPLEMENTED);

    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
    mock().checkExpectations();
}

TEST(bootloader_quirks, no_modem_discovery_but_port_given)
{
    const char *devpath = "/dev/serialport";
    int8_t exp_dev_list_size = 0;

    get_protocol_from_chipset(CHIPSET_SDX55, CHANNEL_SERIAL_USB, &protocol);
    get_boot_context(&protocol, IS_NOT_RECOVERY, &ctx);
    ctx.dev_info.comm_ports_number = 1;
    strlcpy(ctx.dev_info.comm_ports[0], devpath, sizeof(ctx.dev_info.comm_ports[0]));

    mock()
    .expectNCalls(2, "core_device_enumerate")
    .withOutputParameterReturning("dev_list",
            &mock_zero_modem_connected,
            sizeof(mock_zero_modem_connected))
    .withOutputParameterReturning("dev_list_size",
            &exp_dev_list_size,
            sizeof(exp_dev_list_size))
    .andReturnValue(CORE_ERROR_NOT_IMPLEMENTED);
    mock().ignoreOtherCalls();

    /* This test case will re-load the driver_t, replacing the mock-ed one with
     * a real device which we cannot control, resulting in an open error, since
     * the device path is mock-ed as well. For this reason the returned value
     * from enter_boot_mode is operation not permitted, but in a real usage
     * UXFP will return CORE_SUCCESS */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
    mock().checkExpectations();
}

TEST(bootloader_quirks, no_modem_discovery_but_driverless_modem_in_recovery)
{
    int8_t exp_dev_list_size = 0;

    get_protocol_from_chipset(CHIPSET_SDX55, CHANNEL_SERIAL_USB, &protocol);
    get_boot_context(&protocol, IS_RECOVERY, &ctx);
    ctx.no_fastboot_driver = true;

    mock()
    .expectNCalls(2, "core_device_enumerate")
    .withOutputParameterReturning("dev_list",
            &mock_zero_modem_connected,
            sizeof(mock_zero_modem_connected))
    .withOutputParameterReturning("dev_list_size",
            &exp_dev_list_size,
            sizeof(exp_dev_list_size))
    .andReturnValue(CORE_ERROR_NOT_IMPLEMENTED);
    mock()
    .expectNCalls(2, "core_endpoint_open")
    .andReturnValue(CORE_ERROR_UNKNOWN);

    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);
    /* This test case will load the real fastboot driver, which will fail opening the endpoints;
     * this failure's nature depends on the libusb in use. Obviously, in a real usage UXFP will
     * return CORE_SUCCESS; we mock the endpoint open to report the failure,
     * just to verify the code path up to this point and taking into account that the test is
     * related to the quirks software path, but mocking also the endpoint functions for
     * exchanging data will result in a deeper test */
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
    mock().checkExpectations();
}

/* On USB channel, ASR1601 and ASR1603 will wait the modem to show the serial
 * device for 1 second more */
TEST(bootloader_quirks, asr1601_bootloader_usb_quirk)
{
    int8_t exp_dev_list_size = 1;
    dev_info_t mock_asr_bootloader[1] = {
        {"mock location path 1", "mock serial 1", "1bc7", "9200",
         {"/dev/ttyUSB0"}, {"00"}, {"modem driver"}, 1, "mock devpath 1"},
    };
    get_protocol_from_chipset(CHIPSET_ASR1601, CHANNEL_SERIAL_USB, &protocol);
    get_boot_context(&protocol, IS_RECOVERY, &ctx);

    mock()
    .expectOneCall("core_device_enumerate")
    .withOutputParameterReturning("dev_list",
            &mock_asr_bootloader,
            sizeof(mock_asr_bootloader))
    .withOutputParameterReturning("dev_list_size",
            &exp_dev_list_size,
            sizeof(exp_dev_list_size))
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectOneCall("mock_read")
    .withOutputParameterReturning("buffer", ack_buffer_a0, sizeof(ack_buffer_a0));

    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);
    CHECK_EQUAL(CORE_SUCCESS, ret);
    mock().checkExpectations();
}

/* On Serial channel, ASR1603 will wait the modem to reboot for 10 seconds */
TEST(bootloader_quirks, asr1603_quirks)
{
    auto start = std::chrono::high_resolution_clock::now();
    get_protocol_from_chipset(CHIPSET_ASR1603, CHANNEL_SERIAL_PHY, &protocol);
    get_boot_context(&protocol, IS_NOT_RECOVERY, &ctx);

    mock()
    .expectOneCall("mock_read")
    .withOutputParameterReturning("buffer", ack_buffer_asr, sizeof(ack_buffer_asr));
    mock()
    .expectOneCall("mock_read")
    .withOutputParameterReturning("buffer", ack_buffer_a0, sizeof(ack_buffer_a0));

    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);
    auto stop = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::seconds>(stop - start);

    CHECK_EQUAL(CORE_SUCCESS, ret);
    CHECK_EQUAL(10, duration.count());

    mock().checkExpectations();
}

TEST(bootloader_quirks, if_device_is_pci_the_channel_is_auto_changed_from_usb_to_pci)
{
    int8_t exp_dev_list_size = 1;
    dev_info_t mock_pci_modem[1] = {
        {"mock location path", "mock serial", "17cb", "0306", {"qcdm-device"}, {"00"}, {""}, 1,
         "mock devpath"}
    };

    /* Note: here we set the USB channel, as main.c does */
    get_protocol_from_chipset(CHIPSET_SDX55, CHANNEL_SERIAL_USB, &protocol);
    get_boot_context(&protocol, IS_NOT_RECOVERY, &ctx);
    ctx.retries = 10;
    ctx.timeout = 0;

    mock()
    .expectNCalls(2, "core_device_enumerate")
    .withOutputParameterReturning("dev_list", &mock_pci_modem, sizeof(mock_pci_modem))
    .withOutputParameterReturning("dev_list_size", &exp_dev_list_size, sizeof(exp_dev_list_size))
    .andReturnValue(CORE_SUCCESS);
    mock().ignoreOtherCalls();

    /* Note: enter_boot_mode is expected to detect the PCI device and change
     * the channel to PCI. */
    auto ret = enter_boot_mode(&driver, &ctx, false, NULL);

    /* This test case will re-load the driver_t, replacing the mock-ed one with
     * a real device which we cannot control, resulting in an open error, since
     * the device path is mock-ed as well. For this reason the returned value
     * from enter_boot_mode is operation not permitted, but in a real usage
     * UXFP will return CORE_SUCCESS */
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
    CHECK_EQUAL(CHANNEL_SERIAL_PCI, ctx.protocol->channel);
    mock().checkExpectations();
}

/* This test creates a fake FN990 dual slot device wich answers with a mock version buffer containing string
   "45.50.012-T813". This version is compared with FN990 single slot chipset and boot mode is expected to fail
   because fn990_quirk function will return CORE_ERROR_OPERATION_NOT_PERMITTED since installed fw version is
   not compatible with FN990 single slot.
 */
TEST(bootloader_quirks, fn990_quirk_fail_for_chipset)
{
    int8_t exp_dev_list_size = 1;
    dev_info_t mock_fn990_bootloader[1] = {
        {"mock location path 1", "mock serial 1", "1bc7", "1070",
         {"/dev/ttyUSB0", "/dev/ttyUSB1"}, {"00", "01"}, {"modem driver"}, 2, "mock devpath 1"},
    };
    stream_t stream = {0};

    reset_driver(&driver);
    get_protocol_from_chipset(CHIPSET_SDX65, CHANNEL_SERIAL_USB, &protocol);
    get_boot_context(&protocol, false, &ctx);

    mock()
    .expectNCalls(2, "core_device_enumerate")
    .withOutputParameterReturning("dev_list", &mock_fn990_bootloader, sizeof(mock_fn990_bootloader))
    .withOutputParameterReturning("dev_list_size", &exp_dev_list_size, sizeof(exp_dev_list_size))
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectNCalls(2, "mock_read")
    .withOutputParameterReturning("buffer", build_id_rsp_fn990_8GB, sizeof(build_id_rsp_fn990_8GB));

    mock().ignoreOtherCalls();

    auto ret = enter_boot_mode(&driver, &ctx, false, &stream);
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
    mock().checkExpectations();
}

/* This test passes a NULL stream to the fn990 quirk and it is expected to fail.
 */
TEST(bootloader_quirks, fn990_quirk_fail_for_null_stream)
{
    int8_t exp_dev_list_size = 1;
    dev_info_t mock_fn990_bootloader[1] = {
        {"mock location path 1", "mock serial 1", "1bc7", "1070",
         {"/dev/ttyUSB0", "/dev/ttyUSB1"}, {"00", "01"}, {"modem driver"}, 2, "mock devpath 1"},
    };
    stream_t *stream = NULL;

    reset_driver(&driver);
    get_protocol_from_chipset(CHIPSET_SDX65_8GB, CHANNEL_SERIAL_USB, &protocol);
    get_boot_context(&protocol, false, &ctx);

    mock()
    .expectNCalls(2, "core_device_enumerate")
    .withOutputParameterReturning("dev_list", &mock_fn990_bootloader, sizeof(mock_fn990_bootloader))
    .withOutputParameterReturning("dev_list_size", &exp_dev_list_size, sizeof(exp_dev_list_size))
    .andReturnValue(CORE_SUCCESS);

    mock().ignoreOtherCalls();

    auto ret = enter_boot_mode(&driver, &ctx, false, stream);
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
    mock().checkExpectations();
}

/* This test creates some fake stream chunks in order to get a fake modem image and compare it with a fake
 * version string from the modem which has model 4. The test is expected to fail because stream image have
 * model 1.
 */
TEST(bootloader_quirks, fn990_quirk_fail_for_model)
{
    int8_t exp_dev_list_size = 1;
    dev_info_t mock_fn990_bootloader[1] = {
        {"mock location path 1", "mock serial 1", "1bc7", "1070",
         {"/dev/ttyUSB0", "/dev/ttyUSB1"}, {"00", "01"}, {"modem driver"}, 2, "mock devpath 1"},
    };
    data_big_block_t chunk1 = {0};
    data_big_block_t chunk2 = {0};
    stream_t stream = {0};

    stream.handle = 1;
    stream.header_size = 78;
    stream.read_chunk = read_chunk_from_stream;
    memcpy(chunk1.data, mock_fn990_chunk_1, sizeof(mock_fn990_chunk_1));
    chunk1.len = sizeof(mock_fn990_chunk_1);
    memcpy(chunk2.data, mock_fn990_chunk_2, sizeof(mock_fn990_chunk_2));
    chunk2.len = sizeof(mock_fn990_chunk_2);

    reset_driver(&driver);
    get_protocol_from_chipset(CHIPSET_SDX65, CHANNEL_SERIAL_USB, &protocol);
    get_boot_context(&protocol, false, &ctx);

    mock()
    .expectNCalls(2, "core_device_enumerate")
    .withOutputParameterReturning("dev_list", &mock_fn990_bootloader, sizeof(mock_fn990_bootloader))
    .withOutputParameterReturning("dev_list_size", &exp_dev_list_size, sizeof(exp_dev_list_size))
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectNCalls(2, "mock_read")
    .withOutputParameterReturning("buffer", build_id_rsp_fn990_4GB_model_4,
            sizeof(build_id_rsp_fn990_4GB_model_4));
    mock()
    .expectNCalls(2, "read_chunk_from_stream")
    .withOutputParameterReturning("chunk", &chunk1, sizeof(chunk1))
    .withOutputParameterReturning("bytes", &chunk1.len, sizeof(chunk1.len));
    mock()
    .expectNCalls(2, "read_chunk_from_stream")
    .withOutputParameterReturning("chunk", &chunk2, sizeof(chunk2))
    .withOutputParameterReturning("bytes", &chunk2.len, sizeof(chunk2.len));

    mock().ignoreOtherCalls();

    auto ret = enter_boot_mode(&driver, &ctx, false, &stream);
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
    mock().checkExpectations();
}

/* This test creates some fake stream chunks in order to get a fake modem image and compare it with a fake
 * version string from the modem which has model 4. The test is expected to pass because stream image have
 * model 0 and modem has model 1. Final value will be CORE_ERROR_OPERATION_NOT_PERMITTED because send boot
 * char function will fail afterwards.
 */
TEST(bootloader_quirks, fn990_quirk_pass)
{
    int8_t exp_dev_list_size = 1;
    dev_info_t mock_fn990_bootloader[1] = {
        {"mock location path 1", "mock serial 1", "1bc7", "1070",
         {"/dev/ttyUSB0", "/dev/ttyUSB1"}, {"00", "01"}, {"modem driver"}, 2, "mock devpath 1"},
    };
    data_big_block_t chunk1 = {0};
    data_big_block_t chunk2 = {0};
    data_big_block_t chunk3 = {0};
    stream_t stream = {0};

    stream.handle = 1;
    stream.header_size = 78;
    stream.read_chunk = read_chunk_from_stream;
    memcpy(chunk1.data, mock_fn990_chunk_1, sizeof(mock_fn990_chunk_1));
    chunk1.len = sizeof(mock_fn990_chunk_1);
    memcpy(chunk2.data, mock_fn990_chunk_2, sizeof(mock_fn990_chunk_2));
    chunk2.len = sizeof(mock_fn990_chunk_2);

    reset_driver(&driver);
    get_protocol_from_chipset(CHIPSET_SDX65, CHANNEL_SERIAL_USB, &protocol);
    get_boot_context(&protocol, false, &ctx);

    mock()
    .expectNCalls(2, "core_device_enumerate")
    .withOutputParameterReturning("dev_list", &mock_fn990_bootloader, sizeof(mock_fn990_bootloader))
    .withOutputParameterReturning("dev_list_size", &exp_dev_list_size, sizeof(exp_dev_list_size))
    .andReturnValue(CORE_SUCCESS);
    mock()
    .expectNCalls(2, "mock_read")
    .withOutputParameterReturning("buffer", build_id_rsp_fn990_4GB_model_1,
            sizeof(build_id_rsp_fn990_4GB_model_1));
    mock()
    .expectNCalls(2, "read_chunk_from_stream")
    .withOutputParameterReturning("chunk", &chunk1, sizeof(chunk1))
    .withOutputParameterReturning("bytes", &chunk1.len, sizeof(chunk1.len));
    mock()
    .expectNCalls(2, "read_chunk_from_stream")
    .withOutputParameterReturning("chunk", &chunk2, sizeof(chunk2))
    .withOutputParameterReturning("bytes", &chunk2.len, sizeof(chunk2.len));
    mock()
    .expectNCalls(2, "read_chunk_from_stream")
    .withOutputParameterReturning("chunk", &chunk3, sizeof(chunk3))
    .withOutputParameterReturning("bytes", &chunk3.len, sizeof(chunk3.len));

    mock().ignoreOtherCalls();

    auto ret = enter_boot_mode(&driver, &ctx, false, &stream);
    CHECK_EQUAL(CORE_ERROR_OPERATION_NOT_PERMITTED, ret);
    mock().checkExpectations();
}

int main(int ac, char **av)
{
    return CommandLineTestRunner::RunAllTests(ac, av);
}
