#include <CppUTest/CommandLineTestRunner.h>
#include <CppUTestExt/MockSupport.h>

#include "helpers.h"

extern "C" {
#include <telit-os-abs.h>
#include "../driver.h"
#include "../upload.h"
}

static driver_t driver = {};

static void reset_driver(driver_t *driver)
{
    driver->send = mock_send;
    driver->read = mock_read;
    driver->wait_reply = mock_wait_reply;
    driver->configure = mock_config;
    driver->set_baud_rate = mock_set_baud_rate;
    driver->flush = mock_flush;
}
/* Mock stream with no header and random bytes
 * as payload.
 * Upload does not need to read the header,
 * so we can create a mock-ed stream without it.
 * Moreover, only Serial channel tests actually read
 * the stream to find the stream_byte. */
static data_big_block_t mock_stream_base[5] = {
    {4, {0x4, 0x2, 0x3, 0x4}},
    /* The following chunk is the speed chunk:
     * Setting a custom stream_t::speed_offset at 10 bytes will make
     * the last byte of the following chunk the speed_byte (because
     * it is the 10th byte). So we set this byte, and this byte only,
     * to 0x1 corresponding to 115200. */
    {4, {0x4, 0x2, 0x3, 0x1 /* speed byte */}},
    {4, {0x4, 0x2, 0x3, 0x4}},
    {4, {0x4, 0x2, 0x3, 0x4}},
    {0, {}}
};

static data_big_block_t mock_stream_le910c1_eux[5] = {
    {4, {0x4, 0x2, 0x3, 0x4}},
    /* Speed chunk for LE910Cx.
     * data[0] needs to be CHUNK_CMD_TYPE_SPEED (0x01), while the speed_byte is
     * scaled down respect the other modems, for example 115200 is 0x0 in place
     * of 0x01 */
    {4, {0x1, 0x2, 0x3, 0x0}},
    {4, {0x4, 0x2, 0x3, 0x4}},
    {4, {0x4, 0x2, 0x3, 0x4}},
    {0, {}}
};


static data_big_block_t *mock_stream = NULL;
static size_t mock_read_stream_idx = 0;
static int32_t mock_read_chunk(const file_handle_t file, data_big_block_t *chunk, uint32_t *bytes)
{
    if (mock_stream_base[mock_read_stream_idx].len > 0) {
        *bytes = mock_stream[mock_read_stream_idx].len;
        *chunk = mock_stream[mock_read_stream_idx];
        mock_read_stream_idx++;
    } else {
        *bytes = 0;  /* end of stream */
    }
    return CORE_SUCCESS;
}

static int32_t mock_set_baud_rate_test_value(const struct _driver *driver, const uint32_t rate)
{
    mock()
    .actualCall(__func__)
    .withIntParameter("rate", rate);
    return CORE_SUCCESS;
}

int main(int ac, char **av)
{
    return CommandLineTestRunner::RunAllTests(ac, av);
}

TEST_GROUP(upload)
{
    void setup()
    {
        core_log_set_level(LOG_LEVEL_ALERT);
        core_log_set_pprint (CORE_LOG_PPRINT_AUTONEWLINE);
        reset_driver(&driver);
        /* reset pointer to the beginning of the stream */
        mock_read_stream_idx = 0;
        mock_stream = mock_stream_base;
    }
};

TEST(upload, test_several_ack_values)
{
    boot_context_t boot_ctx = {
        .delay_after_speed_change = false
    };
    upload_context_t ctx = {
        .stream = {
            .header_size = 0,
            .ack_boot_offset = 0,
            .filesize = sizeof(*mock_stream),
            .read_chunk = mock_read_chunk,
        }
    };
    uint8_t expected_ack_len1[] = {0xA0};
    uint8_t expected_ack_len3[] = {0x1, 0x1, 0xA5};

    struct {
        chipset_t chipset;
        uint8_t *expected_ack;
    } test_table [] {
        {CHIPSET_GEN_QC_1, expected_ack_len1},
        {CHIPSET_SDX20, expected_ack_len1},
        {CHIPSET_6160, expected_ack_len3},
        {CHIPSET_XG118, expected_ack_len3},
        {CHIPSET_7160, expected_ack_len3},
    };

    for (auto tc: test_table) {
        protocol_t protocol = {};
        reset_driver(&driver);
        /* reset pointer to the beginning of the stream */
        mock_read_stream_idx = 0;
        mock_stream = mock_stream_base;

        mock()
        .expectNCalls(4, "mock_read")
        .withOutputParameterReturning("buffer", tc.expected_ack, sizeof(tc.expected_ack));

        get_protocol_from_chipset(tc.chipset, CHANNEL_SERIAL_USB, &protocol);
        get_upload_context(&protocol, &ctx);

        int32_t got = upload_firmware(&driver, &ctx, &boot_ctx);

        CHECK_EQUAL_TEXT(CORE_SUCCESS, got, get_chipset_name(tc.chipset));
        mock().checkExpectations();
    }
    mock().clear();
};

TEST(upload, do_not_wait_for_ack_if_ack_boot_offset_is_non_zero)
{
    int32_t err;
    protocol_t protocol = {};
    uint8_t ignored_ack[] = {0x1, 0x2, 0x3, 0x4};
    uint8_t expected_ack[] = {0xA0};
    boot_context_t boot_ctx = {
        .delay_after_speed_change = false
    };
    upload_context_t ctx = {
        .stream = {
            .header_size = 0,
            /* set the ack_boot_offset in the middle of the stream of 4 chunks,
             * so that only starting from the second chunk an ACK is expected. */
            .ack_boot_offset = sizeof(*mock_stream) / 2,
            .filesize = sizeof(*mock_stream),
            .read_chunk = mock_read_chunk,
        }
    };

    err = get_protocol_from_chipset(CHIPSET_MDM9205, CHANNEL_SERIAL_USB, &protocol);
    CHECK_EQUAL(CORE_SUCCESS, err);

    err = get_upload_context(&protocol, &ctx);
    CHECK_EQUAL(CORE_SUCCESS, err);

    /* mock_read is called to read the ack from the modem: 4 chunks, 4 ACKs.
     * However since ACK boot offset is set in the middle of the stream,
     * the first chunk is not expected to be ACK-ed, and we expect an ACK only
     * from the next 3 chunks.
     * To test this, we provide a wrong ACK to the first chunk, which shall not
     * cause any error, since it shouldn't be checked.
     * */
    mock()
    .expectOneCall("mock_read")
    .withOutputParameterReturning("buffer", ignored_ack, sizeof(ignored_ack));
    mock()
    .expectNCalls(3, "mock_read")
    .withOutputParameterReturning("buffer", expected_ack, sizeof(expected_ack));
    int32_t got = upload_firmware(&driver, &ctx, &boot_ctx);
    CHECK_EQUAL(CORE_SUCCESS, got);

    mock().checkExpectations();
    mock().clear();
}

TEST(upload, no_speed_change_required_shall_not_call_set_baud_rate)
{
    uint8_t expected_ack[] = {0xA0};
    protocol_t protocol = {};
    boot_context_t boot_ctx = {
        .delay_after_speed_change = false
    };
    upload_context_t ctx = {
        .stream = {
            .header_size = 0,
            .speed_offset = 10,
            .filesize = sizeof(*mock_stream),
            .read_chunk = mock_read_chunk,
        }
    };

    driver.set_baud_rate = mock_set_baud_rate_test_value;
    mock()
    .expectNCalls(4, "mock_read")
    .withOutputParameterReturning("buffer", expected_ack, sizeof(expected_ack));

    mock()
    .expectNoCall("mock_set_baud_rate_test_value");

    get_protocol_from_chipset(CHIPSET_MDM9205, CHANNEL_SERIAL_PHY, &protocol);
    get_upload_context(&protocol, &ctx);

    int32_t got = upload_firmware(&driver, &ctx, &boot_ctx);

    CHECK_EQUAL(CORE_SUCCESS, got);
    mock().checkExpectations();
    mock().clear();
}

TEST(upload, request_speed_change_shall_call_set_baud_rate)
{
    uint8_t expected_ack[] = {0xA0};
    speed_opt_t expected_rates[] = {
        SPEED_OPT_230400,
        SPEED_OPT_460800,
        SPEED_OPT_921600,
        SPEED_OPT_2000000,
        SPEED_OPT_3000000,
        SPEED_OPT_3200000,
        SPEED_OPT_3750000
    };

    driver.set_baud_rate = mock_set_baud_rate_test_value;

    for (auto expected_rate: expected_rates) {
        protocol_t protocol = {};
        boot_context_t boot_ctx = {
            .delay_after_speed_change = true
        };
        upload_context_t ctx = {
            .stream = {
                .header_size = 0,
                .speed_offset = 10,
                .filesize = sizeof(*mock_stream),
                .read_chunk = mock_read_chunk,
            }
        };
        /* reset pointer to the beginning of the stream */
        mock_read_stream_idx = 0;
        get_protocol_from_chipset(CHIPSET_MDM9205, CHANNEL_SERIAL_PHY, &protocol);
        get_upload_context(&protocol, &ctx);
        ctx.wanted_speed = expected_rate;

        mock()
        .expectNCalls(4, "mock_read")
        .withOutputParameterReturning("buffer", expected_ack, sizeof(expected_ack));

        mock()
        .expectOneCall("mock_set_baud_rate_test_value")
        .withIntParameter("rate", expected_rate);

        int32_t got = upload_firmware(&driver, &ctx, &boot_ctx);

        CHECK_EQUAL(CORE_SUCCESS, got);
        mock().checkExpectations();
    }
    mock().clear();
}

/* LE910Cx uses a custom Speed byte to Baud rate mapping */
TEST(upload, request_speed_change_shall_call_set_baud_rate_LE910Cx)
{
    uint8_t expected_ack[] = {0xA0};
    speed_opt_t expected_rates[] = {
        SPEED_OPT_230400,
        SPEED_OPT_460800,
        SPEED_OPT_921600,
        SPEED_OPT_2000000,
        SPEED_OPT_3000000,
        SPEED_OPT_3200000,
        SPEED_OPT_3750000
    };
    driver.set_baud_rate = mock_set_baud_rate_test_value;
    mock_stream = mock_stream_le910c1_eux;

    for (auto expected_rate: expected_rates) {
        protocol_t protocol = {};
        boot_context_t boot_ctx = {
            .delay_after_speed_change = false
        };
        upload_context_t ctx = {
            .stream = {
                .header_size = 0,
                .speed_offset = 10,
                .filesize = sizeof(*mock_stream),
                .read_chunk = mock_read_chunk,
            }
        };

        /* reset pointer to the beginning of the stream */
        mock_read_stream_idx = 0;

        get_protocol_from_chipset(CHIPSET_LE910C1_EUX, CHANNEL_SERIAL_PHY, &protocol);
        get_upload_context(&protocol, &ctx);
        ctx.wanted_speed = expected_rate;

        mock()
        .expectNCalls(4, "mock_read")
        .withOutputParameterReturning("buffer", expected_ack, sizeof(expected_ack));

        mock()
        .expectOneCall("mock_set_baud_rate_test_value")
        .withIntParameter("rate", expected_rate);

        int32_t got = upload_firmware(&driver, &ctx, &boot_ctx);

        CHECK_EQUAL(CORE_SUCCESS, got);
        mock().checkExpectations();
    }
    mock().clear();
}
