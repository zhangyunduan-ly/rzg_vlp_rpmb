#include <CppUTest/CommandLineTestRunner.h>
#include <CppUTestExt/MockSupport.h>

#include <memory.h>
extern "C" {
#include <telit-os-abs.h>
#include "../diagnostic.h"
}

dev_info_t dev_list_0modems[] = {
};

dev_info_t dev_list_2modems[] = {
    {
        "mock_location_path",
        "mock_serial",
        "1bc7",
        "1040",
        {"/dev/ttyUSB0"},
        {"00"},
        {"mock_driver"},
        1,
        "mock_dev_path"
    },
    {
        "mock_location_path",
        "",
        "1bc7",
        "1041",
        {"/dev/ttyUSB1", "/dev/ttyUSB2"},
        {"01", "00"},
        {"mock_driver"},
        2,
        "mock_dev_path"
    }
};

TEST_GROUP(diagnostic)
{
    void setup()
    {
        /* disable logging */
        core_log_set_level(LOG_LEVEL_ALERT);
    }

    void teardown()
    {
        mock().clear();
    }
};

TEST(diagnostic, no_device_connected)
{
    /* GIVEN */
    core_res_t err;
    driver_t driver = {};
    /* use just random usb ids, no device is connected anyway */
    usb_id_t usb_ids[] = {
        {0x1bc7, 0x0000},
        {0x1bc7, 0x1111},
    };
    int32_t usb_ids_size = ARRAY_SIZE(usb_ids);
    diagnostic_t diagnostic = {};
    int8_t diagnostic_size = 0;
    int8_t expected_dev_list_size = 0;

    mock()
    .expectOneCall("core_device_enumerate")
    .withOutputParameterReturning("dev_list_size", &expected_dev_list_size, sizeof(int8_t))
    .withOutputParameterReturning("dev_list", &dev_list_0modems, sizeof(dev_list_0modems))
    .andReturnValue(CORE_ERROR_NO_SUCH_DEVICE);

    /* WHEN */
    err = show_connected_diag_ports(
            &driver,
            usb_ids,
            usb_ids_size,
            &diagnostic,
            &diagnostic_size);

    /* THEN */
    CHECK_EQUAL(CORE_ERROR_NO_SUCH_DEVICE, err);
    mock().checkExpectations();
};

TEST(diagnostic, device_connected)
{
    /* GIVEN */
    core_res_t err;
    driver_t driver = {};
    usb_id_t usb_ids[] = {
        {0x1bc7, 0x1040},
        {0x1bc7, 0x1041},
    };
    int32_t usb_ids_size = ARRAY_SIZE(usb_ids);
    diagnostic_t diagnostic[2] = {};
    int8_t diagnostic_size = 0;
    int8_t expected_dev_list_size = 2;

    mock()
    .expectOneCall("core_device_enumerate")
    .withOutputParameterReturning("dev_list_size", &expected_dev_list_size, sizeof(int8_t))
    .withOutputParameterReturning("dev_list", &dev_list_2modems, sizeof(dev_list_2modems))
    .andReturnValue(CORE_SUCCESS);


    /* WHEN */
    err = show_connected_diag_ports(
            &driver,
            usb_ids,
            usb_ids_size,
            diagnostic,
            &diagnostic_size);

    /* THEN */
    CHECK_EQUAL(CORE_SUCCESS, err);
    CHECK_EQUAL(2, diagnostic_size);
    mock().checkExpectations();
};


int main(int ac, char **av)
{
    return CommandLineTestRunner::RunAllTests(ac, av);
}

/* Mock-ed core_device_enumerate */
core_res_t core_device_enumerate(const usb_id_t *usbid_list,
        const uint8_t usbid_list_size,
        dev_info_t *dev_list,
        int8_t *dev_list_size)
{
    mock()
    .actualCall("core_device_enumerate")
    .withOutputParameter("dev_list", dev_list)
    .withOutputParameter("dev_list_size", dev_list_size);
    return (core_res_t)mock().intReturnValue();
}
