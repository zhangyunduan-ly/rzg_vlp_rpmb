# README

UXFP is the Telit modems firmware updating tool.

It is composed of

- The libuxfp library: a static library that provides the firmware updater APIs
  (Linux only. Windows build creates only the application binary).
- The uxfp application binary: runnable UXFP updater application that uses
  libuxfp interface.

## Usage

```sh
$ ./uxfp --help
usage:
        uxfp --help
        uxfp --show-diag-ports
        uxfp --file <path/to/stream/file>
        uxfp --file <path/to/stream/file> --port <path/to/device> [--debug]
             [--lossrecovery] [--noprogress]
        uxfp --file <path/to/stream/file> --port <path/to/device> --serial
             [--debug] [--lossrecovery] [--noprogress]
        uxfp --file <path/to/stream/file> --port <path/to/device> --serial
             --speed <baudrate> [--debug] [--lossrecovery] [--noprogress]

options:
   --file     <value>   : path to stream file - required
   --port     <value>   : flashing port path (case sensitive) - optional
   --serial             : the given port is a physical serial one (ignored if
                          --port is not provided) - optional
   --speed    <value>   : serial speed [valid values 115200, 230400, 460800,
                          921600, 2000000, 3000000 ] - optional
   --class    <value>   : modem class - optional
   --debug              : enable debug logging - optional
   --lossrecovery       : device in recovery mode - optional
   --no-fastboot-driver : No system driver takes care of the modem fastboot
                          device (only if NO modem discovery). - optional
   --noprogress         : do not show progress percent (to use inside scripts)
                          - optional
   --show-diag-ports    : only show connected diagnostic ports and exit - optional
   --json               : log in JSON format (automatically enable --report) - optional
   --report             : final JSON report (do not enable --json automatically)
                          - optional
```

## How to Build libuxfp and UXFP

### Linux build

#### Linux dependencies

- Telit OS Abstraction Layer library (tosal)
- libudev
- libusb

#### Linux build commands

```sh
./configure
make
```

or

```sh
meson builddir
cd builddir
meson compile
```

The Make build will produce two objects:

- **.libs/libuxfp.a** static library, with firmware updater APIs.
- **uxfp** the uxfp application binary, statically linked to `libuxfp.a`.

The meson build will produce the same two objects above, but inside directory `builddir`.

### Windows build

#### Windows dependencies

- Telit OS Abstraction Layer library (tosal)

#### Windows build commands

go to directory `uxfp/windows` and modify `LIBS` and `CFLAGS` variables in order
to provide the correct path to `telit_os_abstraction_layer` directory. Then run
the command:

**WARNING** make.bat is deprecated it will be removed! Please use Meson.

```dosbatch
make.bat
```

or

```sh
meson builddir
cd builddir
meson compile
```

The Make build will produce the `uxfp.exe` binary inside windows directory.
The meson build will produce the same binary above, but inside `builddir` directory.

## Test and Coverage

Meson comes with a fully functional unit test system.

Tests are run with the command meson test.

```sh
meson setup builddir -Dtest=true
cd builddir
meson test -t2        # or meson test -C builddir from source directory
```

Meson captures the output of all tests and writes it in the log file meson-logs/testlog.txt.

Enable coverage measurements by giving Meson the command line flag `-Db_coverage=true`

```sh
meson setup builddir -Db_coverage=true -Dtest=true
cd builddir
meson test -t2                             # to generate the necessary data
ninja coverage
```

Meson will autodetect what coverage generator tools you have installed and will
generate the corresponding targets.

In UXFP this was tested using `gcov`, provided by gcc, and `lcov` (On
Ubuntu/Debian `apt install lcov`).
