#!/usr/bin/env bash

set -euo pipefail

cd subprojects/telit_os_abstraction_layer
./bootstrap.sh
cd -

# version
major=$(grep MAJOR version.h | head -1 | cut -d'"' -f2)
minor=$(grep MINOR version.h | head -1 | cut -d'"' -f2)
patch=$(grep PATCH version.h | head -1 | cut -d'"' -f2)
cust=$(grep CUST version.h | head -1 | cut -d'"' -f2)
echo "$major.$minor.$patch-$cust" > .version

mkdir -p m4
autoreconf -i
