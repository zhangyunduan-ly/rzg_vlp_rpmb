#ifndef __DEVICES_H__
#define __DEVICES_H__
#include <stdint.h>
#include <telit-os-abs.h>

#define IFACE_NUMBER_00 "00"
#define IFACE_NUMBER_01 "01"
#define IFACE_NUMBER_02 "02"
#define IFACE_NUMBER_03 "03"

#define USBID_GOOGLE_FASTBOOT {0x18d1, 0xd00d}
#define USBID_FLASHLOADER_ALTAIR {0x216f, 0x0051}
#define USBID_TDLOADER {0x1bc7, 0x9010}
#define USBID_PCIE_FN980 {0x17cb, 0x0306}
#define USBID_PCIE_FN990 {0x17cb, 0x0308}
#define USBID_UDELOADER_FN980 {0x1bc7, 0x8900}
#define USBID_UDELOADER_FN990 {0x1bc7, 0x8905}
#define USBID_ASR1601_LOADER {0x1bc7, 0x9200}
#define USBID_ASR1603_LOADER {0x1bc7, 0x9201}
#define USBID_MDM9205_EDL {0x05C6, 0x9008}
#define USBID_QCX216_LOADER {0x1bc7, 0x920a}

#define USBID_LIST_EMPTY { 0, {{0x0000, 0x0000}} }
#define USBID_LIST_INFINEON { 1, {{0x058b, 0x0041}} }
#define USBID_LIST_FLASHLOADER_INTEL_7160 { 1, {{0x8087, 0x0716}} }
#define USBID_LIST_FLASHLOADER_TYPE_AB { 4, \
                                         {USBID_FLASHLOADER_ALTAIR, {0x1bc7, 0x900e}, USBID_GOOGLE_FASTBOOT, \
                                          USBID_TDLOADER}, }
#define USBID_LIST_FLASHLOADER_MDM9X15 { 3, {{0x1bc7, 0x1201}, {0x1bc7, 0x1203}, {0x1bc7, 0x1204}}}
#define USBID_LIST_FLASHLOADER_LM9X0 { 3, {{0x1bc7, 0x1040}, {0x1bc7, 0x1041}, {0x1bc7, 0x1042}}}
#define USBID_LIST_SDX55 { 10, \
                           {{0x1bc7, 0x8000}, {0x1bc7, 0x1050}, {0x1bc7, 0x1051}, {0x1bc7, 0x1052}, \
                               {0x1bc7, 0x1053}, \
                               {0x1bc7, 0x1055}, {0x1bc7, 0x1056}, USBID_TDLOADER, USBID_PCIE_FN980, \
                               USBID_UDELOADER_FN980}, }
#define USBID_LIST_LE910C1_EUX { 3, {{0x1bc7, 0x1031}, {0x1bc7, 0x1037}, USBID_TDLOADER}, }
#define USBID_LIST_MDM9205 { 2, {{0x1bc7, 0x110A}, {0x1bc7, 0x110B}} }
#define USBID_LIST_SDX12 { 4, {{0x1bc7, 0x1060}, {0x1bc7, 0x1061}, {0x1bc7, 0x1062}, {0x1bc7, 0x1063}, }}
#define USBID_LIST_ASR1601 { 3, {{0x1bc7, 0x7010}, {0x1bc7, 0x7011}, USBID_ASR1601_LOADER, }}
#define USBID_LIST_ASR1603 { 3, {{0x1bc7, 0x701A}, {0x1bc7, 0x701B}, USBID_ASR1603_LOADER, }}
#define USBID_LIST_FN990A28 { 8, \
                              {{0x1bc7, 0x1070}, {0x1bc7, 0x1071}, {0x1bc7, 0x1072}, {0x1bc7, 0x1073}, \
                                  USBID_TDLOADER, \
                                  USBID_PCIE_FN990, {0x1bc7, 0x800A}, USBID_UDELOADER_FN990} }
#define USBID_LIST_QCX216 { 3, {{0x1bc7, 0x7020}, {0x1bc7, 0x7021}, USBID_QCX216_LOADER }}

const char *get_diag_interface_number(const uint32_t pid);
bool is_pci_device(const dev_info_t *device);
#endif  /* __DEVICES_H__ */
