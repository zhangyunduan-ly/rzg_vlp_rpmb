REM To be compiled with a VS Native Tools Command Prompt

cd subprojects\telit_os_abstraction_layer
call make.bat %1
cd ..\..\

cd windows
call make.bat %1
cd ..\

if exist "windows\uxfp.exe" (
	echo uxfp available at windows
)
