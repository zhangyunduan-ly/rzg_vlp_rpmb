#include <telit-os-abs.h>

#include "protocol.h"
#include "devices.h"
#include "ttest.h"

#define USB_ID_EMPTY { 0, {{0x0000, 0x0000}, } }
#define GOOGLE_FASTBOOT_USB_ID {0x18d1, 0xd00d}
#define SDX55_SBL_USB_ID {0x1bc7, 0x9010}
#define FLASHLOADER_ALTAIR {0x216f, 0x0051}


static void
test_is_pci_device(void)
{
    dev_info_t non_pci_device = {
        .vendor_id = "1bc7",
        .product_id = "1050",
    };
    dev_info_t fn980 = {
        .vendor_id = "17cb",
        .product_id = "0306",
    };
    dev_info_t fn990 = {
        .vendor_id = "17cb",
        .product_id = "0308",
    };
    CHECK_TRUE(is_pci_device(&non_pci_device) == false);
    CHECK_TRUE(is_pci_device(&fn980) == true);
    CHECK_TRUE(is_pci_device(&fn990) == true);
}

static void
test_get_usb_ids_from_chipset(void)
{
    usb_id_list_t expected[] = {
        [CHIPSET_6160] = { 1, {{0x058b, 0x0041}} },
        [CHIPSET_6260] = { 1, {{0x058b, 0x0041}} },
        [CHIPSET_7160] = { 1, {{0x8087, 0x0716}} },
        [CHIPSET_ALTAIR] =
        { 4, {FLASHLOADER_ALTAIR, {0x1bc7, 0x900e}, GOOGLE_FASTBOOT_USB_ID, SDX55_SBL_USB_ID}, },
        [CHIPSET_GEN_QC_1] =
        { 4, {FLASHLOADER_ALTAIR, {0x1bc7, 0x900e}, GOOGLE_FASTBOOT_USB_ID, SDX55_SBL_USB_ID}, },
        [CHIPSET_GEN_QC_2] = USB_ID_EMPTY,
        [CHIPSET_GEN_QC_3] =
        { 4, {FLASHLOADER_ALTAIR, {0x1bc7, 0x900e}, GOOGLE_FASTBOOT_USB_ID, SDX55_SBL_USB_ID}, },
        [CHIPSET_GEN_QC_4] =
        { 4, {FLASHLOADER_ALTAIR, {0x1bc7, 0x900e}, GOOGLE_FASTBOOT_USB_ID, SDX55_SBL_USB_ID}, },
        [CHIPSET_GEN_QC_5] =
        { 4, {FLASHLOADER_ALTAIR, {0x1bc7, 0x900e}, GOOGLE_FASTBOOT_USB_ID, SDX55_SBL_USB_ID}, },
        [CHIPSET_MDM6200] =
        { 4, {FLASHLOADER_ALTAIR, {0x1bc7, 0x900e}, GOOGLE_FASTBOOT_USB_ID, SDX55_SBL_USB_ID}, },
        [CHIPSET_MDM9206] = USB_ID_EMPTY,
        [CHIPSET_MDM9207_MDM9628] = { 2, {{0x1bc7, 0x1201}, {0x1bc7, 0x1203}}},
        [CHIPSET_MDM9640] = { 3, {{0x1bc7, 0x1040}, {0x1bc7, 0x1041}, {0x1bc7, 0x1042}}},
        [CHIPSET_MDM9X15] = { 2, {{0x1bc7, 0x1201}, {0x1bc7, 0x1203}}},
        [CHIPSET_SDX20] = { 3, {{0x1bc7, 0x1040}, {0x1bc7, 0x1041}, {0x1bc7, 0x1042}}},
        [CHIPSET_XG110] = USB_ID_EMPTY,
        [CHIPSET_XG118] = { 1, {{0x058b, 0x0041}} },
        [CHIPSET_XGOLD] = USB_ID_EMPTY,
        [CHIPSET_XMM727] = USB_ID_EMPTY,
        [CHIPSET_SDX55] =
        { 10,
          {{0x1bc7, 0x8000}, {0x1bc7, 0x1050}, {0x1bc7, 0x1051}, {0x1bc7, 0x1052}, {0x1bc7, 0x1053},
           {0x1bc7, 0x1055}, {0x1bc7, 0x1056}, {0x1bc7, 0x9010}, {0x17cb, 0x0306},
           {0x1bc7, 0x8900}}, },
        [CHIPSET_LE910C1_EUX] = { 3, {{0x1bc7, 0x1031}, {0x1bc7, 0x1037}, SDX55_SBL_USB_ID} },
        [CHIPSET_MDM9205] = { 2, {{0x1bc7, 0x110A}, {0x1bc7, 0x110B}} },
        [CHIPSET_SDX12] = { 4, {{0x1bc7, 0x1060}, {0x1bc7, 0x1061}, {0x1bc7, 0x1062}, {0x1bc7, 0x1063}, }},
        [CHIPSET_ASR1601] = { 3, {{0x1bc7, 0x7010}, {0x1bc7, 0x7011}, {0x1bc7, 0x9200}, }},
        [CHIPSET_SDX65] =
        { 8,
          {{0x1bc7, 0x1070}, {0x1bc7, 0x1071}, {0x1bc7, 0x1072}, {0x1bc7, 0x1073}, USBID_TDLOADER,
           {0x17cb, 0x0308}, {0x1bc7, 0x800A}, {0x1bc7, 0x8905}}},
        [CHIPSET_ASR1603] = { 3, {{0x1bc7, 0x701A}, {0x1bc7, 0x701B}, {0x1bc7, 0x9201}, }},
        [CHIPSET_SDX65_8GB] =
        { 8,
          {{0x1bc7, 0x1070}, {0x1bc7, 0x1071}, {0x1bc7, 0x1072}, {0x1bc7, 0x1073}, USBID_TDLOADER,
           {0x17cb, 0x0308}, {0x1bc7, 0x800A}, {0x1bc7, 0x8905}}},
        [CHIPSET_UNKNOWN] = USB_ID_EMPTY,
    };
    usb_id_list_t *usbids = NULL;

    for (int i = CHIPSET_6160; i < CHIPSET_UNKNOWN; i++) {
        core_res_t err = get_usb_ids_from_chipset(i, false, &usbids);

        CHECK_NUM_MSG(expected[i].len, ==, usbids->len, "chipset:%d - %s\n", i, get_chipset_name(i));

        if (expected[i].len)
            CHECK_NUM(err, ==, CORE_SUCCESS);
        else
            CHECK_NUM(err, ==, CORE_ERROR_NO_SUCH_DEVICE);

        for (int j = 0; j < usbids->len; j++) {
            /*TLOG("%s (%d, %d): 0x%04x:0x%04x\n", get_chipset_name(i), i, j, usbids->items[j].vid, usbids->items[j].pid);*/
            CHECK_NUM_MSG(expected[i].items[j].vid, ==, usbids->items[j].vid, "[chipset:%d, j:%d]\n", i, j);
            CHECK_NUM_MSG(expected[i].items[j].pid, ==, usbids->items[j].pid, "[chipset:%d, j:%d]\n", i, j);
        }
    }
}

static void
test_get_recovery_usb_ids_from_chipset(void)
{
    usb_id_list_t expected[] = {
        [CHIPSET_6160] = { 1, {{0x058b, 0x0041}} },
        [CHIPSET_6260] = { 1, {{0x058b, 0x0041}} },
        [CHIPSET_7160] = { 1, {{0x8087, 0x0716}} },
        [CHIPSET_ALTAIR] =
        { 4, {FLASHLOADER_ALTAIR, {0x1bc7, 0x900e}, GOOGLE_FASTBOOT_USB_ID, SDX55_SBL_USB_ID}, },
        [CHIPSET_GEN_QC_1] =
        { 4, {FLASHLOADER_ALTAIR, {0x1bc7, 0x900e}, GOOGLE_FASTBOOT_USB_ID, SDX55_SBL_USB_ID}, },
        [CHIPSET_GEN_QC_2] = USB_ID_EMPTY,
        [CHIPSET_GEN_QC_3] = {1, {GOOGLE_FASTBOOT_USB_ID}},
        [CHIPSET_GEN_QC_4] = {1, {GOOGLE_FASTBOOT_USB_ID}},
        [CHIPSET_GEN_QC_5] = {1, {GOOGLE_FASTBOOT_USB_ID}},
        [CHIPSET_MDM6200] = {1, {GOOGLE_FASTBOOT_USB_ID}},
        [CHIPSET_MDM9206] = USB_ID_EMPTY,
        [CHIPSET_MDM9207_MDM9628] = {1, {GOOGLE_FASTBOOT_USB_ID}},
        [CHIPSET_MDM9640] = {1, {GOOGLE_FASTBOOT_USB_ID}},
        [CHIPSET_MDM9X15] = {1, {GOOGLE_FASTBOOT_USB_ID}},
        [CHIPSET_SDX20] = {1, {GOOGLE_FASTBOOT_USB_ID}},
        [CHIPSET_XG110] = USB_ID_EMPTY,
        [CHIPSET_XG118] = { 1, {{0x058b, 0x0041}} },
        [CHIPSET_XGOLD] = USB_ID_EMPTY,
        [CHIPSET_XMM727] = USB_ID_EMPTY,
        [CHIPSET_SDX55] = {3, {{0x1bc7, 0x9010}, {0x17cb, 0x0306}, {0x1bc7, 0x8900}}, },
        [CHIPSET_LE910C1_EUX] = {1, {SDX55_SBL_USB_ID}},
        [CHIPSET_MDM9205] = { 2, {{0x1bc7, 0x110A}, {0x1bc7, 0x110B}} },
        [CHIPSET_SDX12] = { 1, {{0x1bc7, 0x9010}, }},
        [CHIPSET_ASR1601] = { 1, {{0x1bc7, 0x9200}, }},
        [CHIPSET_SDX65] = { 3, {USBID_TDLOADER, {0x17cb, 0x0308}, {0x1bc7, 0x8905}}},
        [CHIPSET_ASR1603] = { 1, {{0x1bc7, 0x9201}, }},
        [CHIPSET_SDX65_8GB] = { 3, {USBID_TDLOADER, {0x17cb, 0x0308}, {0x1bc7, 0x8905}}},
        [CHIPSET_UNKNOWN] = USB_ID_EMPTY,
    };
    usb_id_list_t *usbids = NULL;

    for (int i = CHIPSET_6160; i < CHIPSET_UNKNOWN; i++) {
        core_res_t err = get_usb_ids_from_chipset(i, true, &usbids);

        CHECK_NUM_MSG(expected[i].len, ==, usbids->len, "chipset:%d - %s\n", i, get_chipset_name(i));

        if (expected[i].len)
            CHECK_NUM(err, ==, CORE_SUCCESS);
        else
            CHECK_NUM(err, ==, CORE_ERROR_NO_SUCH_DEVICE);

        for (int j = 0; j < usbids->len; j++) {
            /*TLOG("%s (%d, %d): 0x%04x:0x%04x\n", get_chipset_name(i), i, j, usbids->items[j].vid, usbids->items[j].pid);*/
            CHECK_NUM_MSG(expected[i].items[j].vid, ==, usbids->items[j].vid, "[chipset:%d, j:%d]\n", i, j);
            CHECK_NUM_MSG(expected[i].items[j].pid, ==, usbids->items[j].pid, "[chipset:%d, j:%d]\n", i, j);
        }
    }
}

void test_get_recovery_usb_id_mhi(void)
{
    int i = CHIPSET_SDX55;
    usb_id_list_t expected[] = {
        [CHIPSET_SDX55] = {3, {{0x1bc7, 0x9010}, {0x17cb, 0x0306}, {0x1bc7, 0x8900}}, },
    };
    usb_id_list_t *usbids = NULL;

    core_res_t err = get_usb_ids_from_chipset(CHIPSET_SDX55, true, &usbids);

    CHECK_NUM_MSG(expected[i].len, ==, usbids->len, "chipset:%d - %s\n", i, get_chipset_name(i));

    if (expected[i].len)
        CHECK_NUM(err, ==, CORE_SUCCESS);
    else
        CHECK_NUM(err, ==, CORE_ERROR_NO_SUCH_DEVICE);

    for (int j = 0; j < usbids->len; j++) {
        /*TLOG("%s (%d, %d): 0x%04x:0x%04x\n", get_chipset_name(i), i, j, usbids->items[j].vid, usbids->items[j].pid);*/
        CHECK_NUM_MSG(expected[i].items[j].vid, ==, usbids->items[j].vid, "[chipset:%d, j:%d]\n", i, j);
        CHECK_NUM_MSG(expected[i].items[j].pid, ==, usbids->items[j].pid, "[chipset:%d, j:%d]\n", i, j);
    }

}

int main(int argc, char *argv[])
{
    TTEST_INIT(argc, argv);
    RUN(test_get_usb_ids_from_chipset);
    RUN(test_get_recovery_usb_ids_from_chipset);
    RUN(test_get_recovery_usb_id_mhi);
    RUN(test_is_pci_device);
}

