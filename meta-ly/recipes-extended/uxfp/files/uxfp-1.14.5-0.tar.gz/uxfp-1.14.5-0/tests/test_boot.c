#include <telit-os-abs.h>
#include <assert.h>

#include "boot.h"
#include "ttest.h"


static void test_get_boot_context()
{
    int32_t err;
    boot_context_t ctx = {0};
    struct _tt {
        chipset_t chipset;
        core_res_t expected_error[4];  /* for serial, usb, pci, and fastboot channel */
    } tt [] = {
        {CHIPSET_GEN_QC_1, {CORE_SUCCESS, CORE_SUCCESS, CORE_SUCCESS}},
        /* this chipset does not support USB */
        {CHIPSET_XGOLD,
         {CORE_SUCCESS, CORE_ERROR_OPERATION_NOT_PERMITTED, CORE_ERROR_OPERATION_NOT_PERMITTED,
          CORE_ERROR_OPERATION_NOT_PERMITTED}},
        {CHIPSET_6160, {CORE_SUCCESS, CORE_SUCCESS, CORE_ERROR_OPERATION_NOT_PERMITTED, CORE_SUCCESS}},
        {CHIPSET_6260, {CORE_SUCCESS, CORE_SUCCESS, CORE_ERROR_OPERATION_NOT_PERMITTED, CORE_SUCCESS}},
        {CHIPSET_XG118, {CORE_SUCCESS, CORE_SUCCESS, CORE_ERROR_OPERATION_NOT_PERMITTED, CORE_SUCCESS}},
        {CHIPSET_GEN_QC_3, {CORE_SUCCESS, CORE_SUCCESS, CORE_ERROR_OPERATION_NOT_PERMITTED, CORE_SUCCESS}},
        {CHIPSET_MDM6200, {CORE_SUCCESS, CORE_SUCCESS, CORE_ERROR_OPERATION_NOT_PERMITTED, CORE_SUCCESS}},
        {CHIPSET_GEN_QC_1, {CORE_SUCCESS, CORE_SUCCESS, CORE_ERROR_OPERATION_NOT_PERMITTED, CORE_SUCCESS}},
        /* this chipset does not support USB */
        {CHIPSET_XG110,
         {CORE_SUCCESS, CORE_ERROR_OPERATION_NOT_PERMITTED, CORE_ERROR_OPERATION_NOT_PERMITTED,
          CORE_ERROR_OPERATION_NOT_PERMITTED}},
        {CHIPSET_MDM9X15, {CORE_SUCCESS, CORE_SUCCESS, CORE_ERROR_OPERATION_NOT_PERMITTED, CORE_SUCCESS}},
        {CHIPSET_GEN_QC_4, {CORE_SUCCESS, CORE_SUCCESS, CORE_ERROR_OPERATION_NOT_PERMITTED, CORE_SUCCESS}},
        /* this chipset does not support USB */
        {CHIPSET_GEN_QC_2,
         {CORE_SUCCESS, CORE_ERROR_OPERATION_NOT_PERMITTED, CORE_ERROR_OPERATION_NOT_PERMITTED,
          CORE_ERROR_OPERATION_NOT_PERMITTED}},
        {CHIPSET_GEN_QC_3, {CORE_SUCCESS, CORE_SUCCESS, CORE_ERROR_OPERATION_NOT_PERMITTED, CORE_SUCCESS}},
        {CHIPSET_7160, {CORE_SUCCESS, CORE_SUCCESS, CORE_ERROR_OPERATION_NOT_PERMITTED, CORE_SUCCESS}},
        {CHIPSET_ALTAIR, {CORE_SUCCESS, CORE_SUCCESS, CORE_ERROR_OPERATION_NOT_PERMITTED, CORE_SUCCESS}},
        {CHIPSET_MDM9640,
         {CORE_ERROR_OPERATION_NOT_PERMITTED, CORE_SUCCESS, CORE_ERROR_OPERATION_NOT_PERMITTED,
          CORE_SUCCESS}},
        {CHIPSET_GEN_QC_5, {CORE_SUCCESS, CORE_SUCCESS, CORE_ERROR_OPERATION_NOT_PERMITTED, CORE_SUCCESS}},
        {CHIPSET_MDM9207_MDM9628,
         {CORE_SUCCESS, CORE_SUCCESS, CORE_ERROR_OPERATION_NOT_PERMITTED, CORE_SUCCESS}},
        {CHIPSET_XMM727,
         {CORE_ERROR_OPERATION_NOT_PERMITTED, CORE_SUCCESS, CORE_ERROR_OPERATION_NOT_PERMITTED,
          CORE_SUCCESS}},
        {CHIPSET_MDM9206, {CORE_SUCCESS, CORE_SUCCESS, CORE_ERROR_OPERATION_NOT_PERMITTED, CORE_SUCCESS}},
        /* this chipset does not support serial flashing */
        {CHIPSET_SDX20,
         {CORE_ERROR_OPERATION_NOT_PERMITTED, CORE_SUCCESS, CORE_ERROR_OPERATION_NOT_PERMITTED,
          CORE_SUCCESS}},
        /* this chipset does not support serial flashing */
        {CHIPSET_SDX55, {CORE_ERROR_OPERATION_NOT_PERMITTED, CORE_SUCCESS, CORE_SUCCESS, CORE_SUCCESS}},
        /* this chipset does not support serial flashing (yet) */
        {CHIPSET_LE910C1_EUX, {CORE_SUCCESS, CORE_SUCCESS, CORE_ERROR_OPERATION_NOT_PERMITTED, CORE_SUCCESS}},
        {CHIPSET_UNKNOWN, {CORE_ERROR_UNKNOWN, CORE_ERROR_UNKNOWN, CORE_ERROR_UNKNOWN, CORE_ERROR_UNKNOWN}},
    };

    for (int n = CHIPSET_6160; tt[n].chipset != CHIPSET_UNKNOWN; n++) {

        TLOG("==================================\n");
        protocol_t protocol = {0};
        chipset_t chipset = tt[n].chipset;
        TLOG("boot context for chipset %d (%s)\n", chipset, get_chipset_name(chipset));

        for (int s = CHANNEL_SERIAL_PHY; s < CHANNEL_UNKNOWN; s++) {
            channel_t channel = s;

            TLOG("  channel %s\n", get_channel_name(channel));

            for (int r = 0; r < 2; r++) {
                bool recovery = r;

                err = get_protocol_from_chipset(chipset, channel, &protocol);
                assert(err == 0);

                err = get_boot_context(&protocol, recovery, &ctx);
                CHECK_NUM_MSG(err, ==, tt[n].expected_error[s],
                        "test#%d, chipset:%d (%s), channel:%d (%s), recovery:%d",
                        n, chipset, get_chipset_name(chipset), s, get_channel_name(s), r);

                TLOG("    - recovery: %s\n", ctx.recovery ? "true" : "false");
                TLOG("    - %d usb_ids: ", ctx.usb_ids->len);
                for (int i = 0; i < ctx.usb_ids->len; i++) {
                    TLOG("%04X:%04X, ", ctx.usb_ids->items[i].vid, ctx.usb_ids->items[i].pid);
                }
                TLOG("\n");
            }
        }

    }
}


int main(int argc, char *argv[])
{
    TTEST_INIT(argc, argv);
    RUN(test_get_boot_context);
}

