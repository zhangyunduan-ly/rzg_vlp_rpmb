#include <telit-os-abs.h>

#include "stream.h"

const static char *help = "\n\
usage:\n\
    test_stream <path/to/stream>\n";

static bool
test_open_stream(const char *stream_path)
{
    int32_t err = 0;
    file_handle_t file;
    stream_t stream;

    core_log_set_level(LOG_LEVEL_DBG);

    err = core_init();
    if (err) {
        ALOGE("could not initialize telit OS abstraction layer\n");
        goto end;
    }

    err = core_file_open(stream_path, &file);
    if (file == INVALID_FILE_HANDLE) {
        ALOGE("could not open stream file '%s': error %d\n", stream_path, err);
        err = -1;
        goto end;
    }

    err = stream_get_from_file(file, &stream);
    if (err) {
        ALOGE("could not get stream header from handle\n");
        goto close_file;
    }

    stream_print_content(&stream);

close_file:
    core_file_close(file);

end:
    return (err == 0);
}

int main(int argc, char *argv[])
{
    const char *stream_path;
    if (argc < 2) {
        ALOGI("%s\n", help);
        return -1;
    }

    stream_path = argv[1];

    if (!test_open_stream(stream_path))
        ALOGE("FAILED\n");
}
