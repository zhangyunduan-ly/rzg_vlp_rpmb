#include <telit-os-abs.h>

#include "devices.h"
#include "driver.h"
#include "protocol.h"
#include "ttest.h"


void test_negative_get_driver(void);
void test_diagnostic_interface_number(void);

int main(int argc, char *argv[])
{
    TTEST_INIT(argc, argv);
    RUN(test_negative_get_driver);
    RUN(test_diagnostic_interface_number);
    return 0;
}


void test_negative_get_driver(void)
{
    driver_t driver = {0};
    struct {
        chipset_t chipset;
        channel_t channel;
        core_res_t exp_err;
    } tt [] = {
        {0, CHANNEL_SERIAL_PHY, CORE_ERROR_OPERATION_NOT_PERMITTED},  /* first chipset value is 1 */
        {CHIPSET_UNKNOWN, CHANNEL_SERIAL_PHY, CORE_ERROR_OPERATION_NOT_PERMITTED},
        {CHIPSET_UNKNOWN + 1, CHANNEL_SERIAL_PHY, CORE_ERROR_OPERATION_NOT_PERMITTED},
        {CHIPSET_6160, CHANNEL_UNKNOWN, CORE_ERROR_OPERATION_NOT_PERMITTED},
        {CHIPSET_6160, CHANNEL_UNKNOWN + 1, CORE_ERROR_OPERATION_NOT_PERMITTED},
        {0xFF, 0xFF, 0xFF},
    };

    TLOG("Negative test: Error messages are expected.\n");
    for (int i = 0; tt[i].exp_err != 0xFF; ++i) {
        int err = get_driver(tt[i].channel, tt[i].chipset, &driver);
        CHECK_NUM(err, ==, tt[i].exp_err);
    }
}


void test_diagnostic_interface_number(void)
{
    struct tt {
        usb_id_list_t usbids;
        /* Expected interface number for each PID of the list */
        char *interface_number_expected[11];
    } tests[] = {
        {USBID_LIST_INFINEON, {IFACE_NUMBER_01, NULL}},
        {USBID_LIST_FLASHLOADER_INTEL_7160, {IFACE_NUMBER_00, NULL}},
        {USBID_LIST_FLASHLOADER_TYPE_AB, {IFACE_NUMBER_00,
                                          IFACE_NUMBER_00,
                                          IFACE_NUMBER_00,
                                          IFACE_NUMBER_00,
                                          IFACE_NUMBER_00,
                                          NULL}},
        {USBID_LIST_FLASHLOADER_MDM9X15, {IFACE_NUMBER_00,
                                          IFACE_NUMBER_02,
                                          IFACE_NUMBER_00,
                                          NULL}},
        {USBID_LIST_FLASHLOADER_LM9X0, {IFACE_NUMBER_00,
                                        IFACE_NUMBER_00,
                                        IFACE_NUMBER_02,
                                        NULL}},
        {USBID_LIST_SDX55, {IFACE_NUMBER_00,
                            IFACE_NUMBER_00,
                            IFACE_NUMBER_00,
                            IFACE_NUMBER_02,
                            IFACE_NUMBER_00,
                            IFACE_NUMBER_00,
                            IFACE_NUMBER_02,
                            IFACE_NUMBER_00,
                            IFACE_NUMBER_00,
                            IFACE_NUMBER_00,
                            NULL}},
        {USBID_LIST_LE910C1_EUX, {IFACE_NUMBER_00,
                                  IFACE_NUMBER_00,
                                  IFACE_NUMBER_00,
                                  NULL}},
        {USBID_LIST_MDM9205, {IFACE_NUMBER_00,
                              IFACE_NUMBER_00,
                              NULL}},
        {USBID_LIST_SDX12, {IFACE_NUMBER_00,
                            IFACE_NUMBER_00,
                            IFACE_NUMBER_02,
                            IFACE_NUMBER_00,
                            NULL}},
        {USBID_LIST_EMPTY, {0}}
    };

    for (int i = 0; tests[i].interface_number_expected[0] != NULL; ++i) {
        for (uint8_t j = 0; j < tests[i].usbids.len; ++j) {
            const char *diag_interface_number = get_diag_interface_number(tests[i].usbids.items[j].pid);
            CHECK_STR_MSG(diag_interface_number, ==, tests[i].interface_number_expected[j],
                    "[test#%d/%d] PID 0x%04X expects iface %s, not %s (i:%d, j:%d)\n",
                    i + 1, tests[i].usbids.len + 1,
                    tests[i].usbids.items[j].pid,
                    tests[i].interface_number_expected[j],
                    diag_interface_number,
                    i,
                    j);
        }
    }
}
