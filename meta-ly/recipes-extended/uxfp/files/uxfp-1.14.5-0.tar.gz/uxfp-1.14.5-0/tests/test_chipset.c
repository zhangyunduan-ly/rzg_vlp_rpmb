#include <telit-os-abs.h>

#include "protocol.h"
#include "ttest.h"


static void
test_get_chipset_from_sw_version(void)
{
    const static struct _tests {
        const char *version;
        const chipset_t expected_chipset;
    } tt [] = {
        {"08.01.000", CHIPSET_GEN_QC_1},
        {"10.00.000", CHIPSET_XGOLD},
        {"11.00.001", CHIPSET_6160},
        {"12.00.002", CHIPSET_6260},
        {"13.00.003", CHIPSET_XG118},
        {"14.12.004", CHIPSET_GEN_QC_3},
        {"14.22.004", CHIPSET_MDM6200},
        {"15.00.000", CHIPSET_GEN_QC_1},
        {"16.01.004", CHIPSET_XG110},
        {"17.00.000", CHIPSET_MDM9X15},
        {"18.42.021", CHIPSET_GEN_QC_4},
        {"18.x1.000", CHIPSET_GEN_QC_2},
        {"19.10.000", CHIPSET_GEN_QC_3},
        {"20.00.005", CHIPSET_7160},
        {"23.00.005", CHIPSET_ALTAIR},
        {"24.00.005", CHIPSET_GEN_QC_5},
        {"24.01.500", CHIPSET_MDM9640},
        {"24.01.000", CHIPSET_MDM9640},
        {"25.01.123", CHIPSET_MDM9207_MDM9628},
        {"25.30.123", CHIPSET_LE910C1_EUX},
        {"27.01.123", CHIPSET_XMM727},
        {"30.01.123", CHIPSET_MDM9206},
        {"32.01.123", CHIPSET_SDX20},
        {"37.01.123", CHIPSET_MDM9205},
        {"38.01.123", CHIPSET_SDX55},
        {NULL, CHIPSET_UNKNOWN},
    };

    for (int i = 0; tt[i].version != NULL; i++) {
        chipset_t chipset = get_chipset_from_sw_version(tt[i].version);
        CHECK_NUM(chipset, ==, tt[i].expected_chipset);
    }
}


int main(int argc, char *argv[])
{
    TTEST_INIT(argc, argv);
    RUN(test_get_chipset_from_sw_version);
}
