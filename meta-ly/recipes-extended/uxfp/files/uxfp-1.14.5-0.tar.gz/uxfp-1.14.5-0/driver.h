/**
 * @file driver.h
 * @brief Handling data exchange with the modem
 *
 * Copyright (C) 2018  Telit Communication spa
 */

#ifndef _DRIVER_H_
#define _DRIVER_H_

#include "protocol.h"

#include <telit-os-abs.h>

#define DEFAULT_UART_CHANNEL_ID   0  /**< default channel position for UART */

/**
 * @brief functions and handle for data exchange with the modem
 */
struct _driver {
    dev_ctx_t device;  /**< telit_os_abstraction_layer::dev_ctx_t device instance */
    int32_t (*open)(const dev_info_t *dev_info, struct _driver *driver);
    int32_t (*send)(const struct _driver *driver, const uint8_t *buffer, const int32_t to_write,
            uint32_t *written);
    int32_t (*read)(const struct _driver *driver, uint8_t *buffer, const int32_t to_read, uint32_t *read);
    int32_t (*wait_reply)(const struct _driver *driver, const uint32_t ms_timeout);
    int32_t (*configure)(const struct _driver *driver, const bool enable_hw_flow_control);
    int32_t (*set_baud_rate)(const struct _driver *driver, const uint32_t rate);
    int32_t (*close)(struct _driver *driver);
    int32_t (*flush)(const struct _driver *driver);
};

typedef struct _driver driver_t;

/**
 * @brief configure #driver_t to communicate with a modem over a #channel_t
 *
 * @param[in] channel #channel_t instance
 * @param[in] chipset #chipset_t instance
 * @param[out] driver #driver_t instance
 *
 * @return 0 in case of success, a negative value otherwise
 */
int32_t get_driver(const channel_t channel, chipset_t chipset, driver_t *driver);

/**
 * @brief get the flashing device position in telit_os_abstraction_layer::dev_info_t
 *
 * The flashing device path is the communication port with DIAGNOSTIC interface number, in
 * case none of the paths have the interface number, a fallback path is searched for.
 *
 * @param[in] dev_info the modem telit_os_abstraction_layer::dev_info_t
 * @param[in] driver the #driver_t instance driving the modem
 *
 * @return the position of the device in telit_os_abstraction_layer::dev_info_t.comm_ports or telit_os_abstraction_layer::CORE_ERROR_NO_SUCH_DEVICE in case of error
 */
int32_t get_flashing_device_or_fallback_position(const dev_info_t *dev_info);
/**
 * @brief get the flashing device position in telit_os_abstraction_layer::dev_info_t
 *
 * The flashing device path is the communication port with DIAGNOSTIC interface number
 *
 * @param[in] dev_info the modem telit_os_abstraction_layer::dev_info_t
 * @param[in] driver the #driver_t instance driving the modem
 *
 * @return the position of the device in telit_os_abstraction_layer::dev_info_t.comm_ports or telit_os_abstraction_layer::CORE_ERROR_NO_SUCH_DEVICE in case of error
 */
int32_t get_flashing_device_pos(const dev_info_t *dev_info);
#endif  /* _DRIVER_H_ */
