/*
 * Copyright (C) 2018  Telit Communication spa
 */

/**
 * @file stream.h
 * @brief data types related to firmware stream format
 */
#ifndef _STREAM_H_
#define _STREAM_H_

#include <stdint.h>
#include <stdlib.h>

#include <telit-os-abs.h>

#include "protocol.h"

#define MAX_STREAM_STRING         32
#define DATA_SMALL_BLOCK_MAX_SIZE 256
#define DATA_BIG_BLOCK_MAX_SIZE   65536
#define CHUNK_HEADER_LEN          2

#define IMG_FRAME_VERSION_LEN       256
#define MAX_STREAM_READ_SIZE        4096
#define IMAGE_INFO_FRAME_TYPE_FN990 0x08

#define VERSION_HOST_FN990     0x00
#define VERSION_M0_FN990       0x01
#define VERSION_M1_FN990       0x02
#define VERSION_CNV0_FN990     0x03
#define VERSION_CNV1_FN990     0x04
#define VERSION_OEMAPPS_FN990  0x05
#define VERSION_CUSTAPPS_FN990 0x06

/**
 * @brief encapsulate a small block of data from the modem
 */
typedef struct data_small_block {
    uint16_t len;
    uint8_t data[DATA_SMALL_BLOCK_MAX_SIZE];
} data_small_block_t;

/**
 * @brief encapsulate a big block of data from the modem
 */
typedef struct data_big_block {
    uint16_t len;
    uint8_t data[DATA_BIG_BLOCK_MAX_SIZE];
} data_big_block_t;

/**
 * @brief the types of image info frame
 */
typedef struct {
    uint8_t cmd_type;
    uint16_t cmd_len;
    uint32_t image_size;
    uint32_t frame_number;
    uint8_t version_type;
    int index;
    char version[IMG_FRAME_VERSION_LEN];
    char image_name[16];
} image_info_frame_t;

/**
 * @brief the firmware stream header info
 */
typedef struct {
    file_handle_t handle;                    /**< The file handle of the stream file */
    uint16_t header_size;                    /**< The header size in bytes */
    uint32_t ack_boot_offset;                /**< The stream offset at which the modem start returning acknowledges */
    uint32_t stream_offset;                  /**< The stream offset where the USB payload is located at (only sstream header version >= 8) */
    char product_name[MAX_STREAM_STRING];    /**< Product Name */
    uint32_t speed_offset;                   /**< The stream offset at which the desired speed must be injected */
    bool hw_flow_ctrl;                       /**< The hardware flow control enabling status */
    uint16_t stream_version;                 /**< The stream version code */
    char sw_version[MAX_STREAM_STRING];      /**< The stream version string */
    char base_sw_version[MAX_STREAM_STRING]; /**< The base stream version string */
    uint64_t filesize;                       /**< The file size in bytes */
    int32_t (*read_chunk)(const file_handle_t file,
            data_big_block_t *chunk,
            uint32_t *bytes);                /**< Function to get the next stream chunk */
} stream_t;


/**
 * @brief configure #stream_t from the given firmware file handle
 *
 * @param[in] handle the telit_os_abstraction_layer::file_handle_t of the firmware file
 * @param[in] channel a #channel_t value
 * @param[out] stream the #stream_t
 *
 * @return 0 in case of success, or telit_os_abstraction_layer::core_res_t otherwise
 */
int32_t stream_get_from_file(const file_handle_t handle, const channel_t channel, stream_t *stream);

/**
 * @brief show #stream_t content on the standard output
 *
 * Enabled only if CORE_LOG_DEBUG is set
 *
 * @param[in] stream a #stream_t
 */
void stream_print_content(const stream_t *stream);

/**
 * @brief check whether a #stream_t has a `ack boot offset` value
 *
 * @param[in] stream a #stream_t
 *
 * @return true if #stream_t has a `ack boot offset` value, false otherwise.
 */
bool stream_has_ack_boot_offset(const stream_t *stream);

/**
 * @brief read data from stream
 *
 * @param[in] file the stream handle
 * @param[in] bytes number of bytes read
 * @param[out] chunk the read data
 *
 * @return core_res_t errors
 */
int32_t read_chunk_from_stream(const file_handle_t file, data_big_block_t *chunk, uint32_t *bytes);

/**
 * @brief read image info frame header from chunk
 *
 * @param[in] chunk the stream chunk
 * @param[out] info the extracted info
 *
 * @return core_res_t errors
 */
int32_t get_image_info_frame_fn990(const data_big_block_t *chunk, image_info_frame_t *info);

#endif  /* _STREAM_H_ */
