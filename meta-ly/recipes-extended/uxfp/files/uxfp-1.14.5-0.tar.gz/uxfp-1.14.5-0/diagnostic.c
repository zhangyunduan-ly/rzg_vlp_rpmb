#include <string.h>

#include "devices.h"
#include "diagnostic.h"

core_res_t show_connected_diag_ports(const driver_t *driver, const usb_id_t *usb_ids, int32_t usb_ids_size,
        diagnostic_t *diagnostic, int8_t *diagnostic_size)
{
    static dev_info_t dev_list[MAX_DEVICE_LIST_SIZE] = {0};
    core_res_t err;
    int8_t dev_list_size = MAX_DEVICE_LIST_SIZE;

    memset(dev_list, 0, sizeof(dev_list));
    memset(diagnostic, 0, sizeof(*diagnostic));

    err = core_device_enumerate(usb_ids, usb_ids_size,
            dev_list, &dev_list_size);

    if (!err) {
        int c = 0;

        for (int i = 0; i < dev_list_size; ++i) {
            dev_info_t *cur = &dev_list[i];
            const char *diag_interface_number;

            if (!core_usb_id_from_str(&diagnostic[c].usb_id, cur->vendor_id, cur->product_id)) {
                ALOGE("error parsing USB id info (%s:%s)\n", cur->vendor_id, cur->product_id);
                continue;
            }

            if (strlen(cur->serial))
                strlcpy(diagnostic[c].serial_number, cur->serial, sizeof(diagnostic[0].serial_number));
            else
                strlcpy(diagnostic[c].serial_number, "unknown", sizeof(diagnostic[0].serial_number));

            diag_interface_number = get_diag_interface_number(diagnostic[c].usb_id.pid);
            for (int j = 0; j < cur->comm_ports_number; ++j) {
                if (strcmp(cur->ifaces[j], diag_interface_number) == 0) {
                    strlcpy(diagnostic[c].diagnostic_port_name, cur->comm_ports[j],
                            sizeof(diagnostic[0].diagnostic_port_name));
                    c++;
                }
            }
        }

        *diagnostic_size = c;
    }

    return err;
}
