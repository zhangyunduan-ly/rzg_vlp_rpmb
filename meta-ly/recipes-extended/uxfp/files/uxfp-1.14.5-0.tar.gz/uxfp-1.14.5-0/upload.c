#include <assert.h>
#include <errno.h>
#include <string.h>
#include <inttypes.h>

#include "boot.h"
#include "upload.h"

#define MAX_PACKET_SIZE                     8192
#define MAX_WAIT_READ                       (60 * 1000)

/**************************************/
/* Private functions                  */
/**************************************/
static int32_t upload_mode(driver_t *driver, upload_context_t *c, boot_context_t *boot_ctx);
static int32_t write_chunk_to_device(const driver_t *driver, const data_big_block_t *chunk);
static int32_t read_ack_from_device(const driver_t *driver, buffer_t *ack, const int32_t exp_len,
        const uint32_t ms_timeout);
static bool compare_ack_buffer(const acknowledge_t *expected, const buffer_t *received);
static bool is_ack_in_list(const acknowledge_t *expected, const buffer_t *received);
static bool compare_no_message(const acknowledge_t *expected, const buffer_t *received);
static int32_t handle_host_speed_change(const driver_t *driver, const speed_opt_t speed,
        const bool enable_hw_flow_control);
static int8_t get_speed_byte(const speed_opt_t speed);
static int8_t get_speed_byte_le910cx(const speed_opt_t speed);

static int32_t inject_speed_byte(data_big_block_t *chunk, const int32_t offset, const speed_opt_t speed);
static int32_t inject_speed_byte_and_crc(data_big_block_t *chunk, const int32_t offset,
        const speed_opt_t speed);

static speed_opt_t get_speed_opt_from_speed_byte(const uint8_t speed_byte);

static int32_t get_offset_in_speed_chunk(upload_context_t *ctx, data_big_block_t *chunk,
        uint32_t stream_offset);
static int32_t get_offset_in_speed_chunk_le910cx(upload_context_t *ctx, data_big_block_t *chunk,
        uint32_t stream_offset);

static int32_t flush_channel(const driver_t *driver);
/* end private functions */

const static acknowledge_t ack_first_len2 = {
    .data = {0x1, 0x1},
    .data_len = 2,
    .ack_len = 2,
    .compare = compare_ack_buffer,
};

const static acknowledge_t ack_first_len3 = {
    .data = {0x1, 0x1, 0xA5},
    .data_len = 3,
    .ack_len = 3,
    .compare = compare_ack_buffer,
};

const static acknowledge_t ack_len1 = {
    .data = {0xA0},
    .data_len = 1,
    .ack_len = 1,
    .compare = compare_ack_buffer,
};

const static acknowledge_t ack_len1_with_multiple_values = {
    .data = {0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6, 0xA7, 0xA8, 0xA9, 0x1},
    .data_len = 11,
    .ack_len = 1,
    .compare = is_ack_in_list,
};

/* Special acknowledge_t instance to be used with ack_offset_handling_t value
 * "ACK_READ_AND_IGNORE_UNTIL_OFFSET".
 * With MDM9205 and usb-channel, the upload module shall wait for a
 * variable-length response from the modem before sending the next chunk, but
 * the actual respose content shall be ignored. For this to work we ask to read
 * just 1 byte of the response, then flush the buffers before sending the next
 * chunk. */
const static acknowledge_t ack_ignored = {
    .data = {0x0},
    .data_len = 1,
    .ack_len = 1,
    .compare = compare_no_message,
};

/**************************************/
/* Upload operations                  */
/**************************************/
/**
 * @brief Upload handling functions
 */
struct upload_operations {
    int8_t (*get_speed_byte)(const speed_opt_t speed);
    int32_t (*get_offset_in_speed_chunk)(upload_context_t *ctx, data_big_block_t *chunk,
            uint32_t stream_offset);
    int32_t (*inject_speed_byte)(data_big_block_t *chunk, const int32_t offset, const speed_opt_t speed);
    int32_t (*flush_channel)(const driver_t *driver);
};

static struct upload_operations upload_fops = {
    .get_speed_byte = NULL,
    .get_offset_in_speed_chunk = NULL,
    .inject_speed_byte = NULL,
    .flush_channel = NULL,
};
/* end upload operations */


int32_t get_upload_context(protocol_t *protocol, upload_context_t *ctx)
{
    int32_t err = 0;
    upload_type_t type;

    type = get_upload_type_from_chipset(protocol->chipset, protocol->channel);
    if (type == UPLOAD_TYPE_UNKNOWN) {
        ALOGE("could not get upload type for chipset:'%s' and channel:'%s'\n",
                get_chipset_name(protocol->chipset),
                get_channel_name(protocol->channel));
        return CORE_ERROR_EINVAL;
    }

    ALOGD("getting context for upload type %s\n", get_upload_type_name(type));
    if (protocol->channel == CHANNEL_SERIAL_PHY) {
        ctx->speed_change_state = SPEED_CHANGE_CHANGE_IN_MODEM;
        upload_fops.get_speed_byte = get_speed_byte;
        upload_fops.get_offset_in_speed_chunk = get_offset_in_speed_chunk;
        upload_fops.inject_speed_byte = inject_speed_byte;
    } else {
        ctx->speed_change_state = SPEED_CHANGE_DONE;
        if (protocol->chipset == CHIPSET_MDM9205)
            upload_fops.flush_channel = flush_channel;
    }

    ctx->max_nacks = 0;

    /* Chipset specific configuration */
    switch (protocol->chipset) {
        case CHIPSET_ASR1601:
        case CHIPSET_ASR1603:
        case CHIPSET_ALTAIR:
        case CHIPSET_ALT1255:
        case CHIPSET_ALT1350:
        case CHIPSET_QCX216:
            ctx->ack_timeout_ms = 240 * 1000;
            break;
        default:
            ctx->ack_timeout_ms = MAX_WAIT_READ;
    }
    ALOGD("ack timeout set to %" PRIu32 " ms\n", ctx->ack_timeout_ms);

    /* Upload type specific configuration: this configuration applies to
     * all the chipsets that share the same upload phase behavior. */
    switch (type) {
        case UPLOAD_TYPE_A:
            ctx->ack_expected = ACK_IS_EXPECTED;
            ctx->exp_first_ack = NULL;
            ctx->exp_ack = &ack_len1_with_multiple_values;
            break;
        case UPLOAD_TYPE_B1:
            ctx->ack_expected = ACK_IS_EXPECTED;
            ctx->exp_first_ack = &ack_first_len3;
            ctx->exp_ack = &ack_len1_with_multiple_values;
            break;
        case UPLOAD_TYPE_B2:
            ctx->ack_expected = ACK_IS_EXPECTED;
            ctx->exp_first_ack = &ack_first_len2;
            ctx->exp_ack = &ack_len1_with_multiple_values;
            break;
        case UPLOAD_TYPE_C:
        case UPLOAD_TYPE_D:
        case UPLOAD_TYPE_D_SPEED_QUIRK:
            ctx->ack_expected = ACK_IS_EXPECTED;
            ctx->exp_first_ack = NULL;
            ctx->exp_ack = &ack_len1;
            if (type == UPLOAD_TYPE_D_SPEED_QUIRK) {
                upload_fops.get_speed_byte = get_speed_byte_le910cx;
                upload_fops.get_offset_in_speed_chunk = get_offset_in_speed_chunk_le910cx;
                upload_fops.inject_speed_byte = inject_speed_byte_and_crc;
            }
            break;
        case UPLOAD_TYPE_E:
            ctx->ack_expected = ACK_SKIP_UNTIL_OFFSET;
            ctx->exp_first_ack = &ack_first_len3;
            ctx->exp_ack = &ack_len1_with_multiple_values;
            break;
        case UPLOAD_TYPE_F:
        case UPLOAD_TYPE_F_HW_FLOW_CONTROL:
            ctx->exp_first_ack = NULL;
            ctx->exp_ack = &ack_len1;
            ctx->max_nacks = 2;
            ctx->enable_hw_flow_control_after_speed_change =
                    (type == UPLOAD_TYPE_F_HW_FLOW_CONTROL && ctx->stream.hw_flow_ctrl
                    && ctx->wanted_speed > 115200);
            break;
        case UPLOAD_TYPE_G:
            ctx->ack_expected = ACK_READ_AND_IGNORE_UNTIL_OFFSET;
            ctx->exp_first_ack = NULL;
            ctx->exp_ack = &ack_ignored;
            break;
        default:
            ALOGE("unexpected upload type %u\n", type);
            err = CORE_ERROR_EINVAL;
            break;
    }

    return err;
}

int32_t upload_firmware(driver_t *driver, upload_context_t *ctx, boot_context_t *boot_ctx)
{
    int32_t err;

    ALOGI("[+] uploading firmware\n");
    ALOGI("[+] this may take several minutes, do not disconnect the device\n");
    err = upload_mode(driver, ctx, boot_ctx);
    if (err)
        ALOGE("upload mode error %" PRIi32 "\n", err);

    return err;
}

static bool
compare_ack_buffer(const acknowledge_t *expected, const buffer_t *received)
{
    bool match = true;
    int32_t i;

    for (i = 0; i < expected->data_len; i++) {
        match = (expected->data[i] == received->data[i]);
        if (!match)
            break;
    }

    if (!match) {
        ALOGD("ack check failed!\n");
        ALOGD("expected:\n");
        for (i = 0; i < expected->data_len; i++) {
            ALOGD("0x%02" PRIX8 ",\n", expected->data[i]);
        }

        ALOGD("received:\n");
        for (i = 0; i < received->len; i++) {
            ALOGD("0x%02" PRIX8 ",\n", received->data[i]);
        }
    }

    return match;
}

static bool
is_ack_in_list(const acknowledge_t *expected, const buffer_t *received)
{
    bool match = false;
    int32_t i;

    for (i = 0; i < expected->data_len; i++) {
        match = expected->data[i] == received->data[0];
        if (match)
            break;
    }

    if (!match) {
        ALOGD("ack check failed!\n");
        ALOGD("expected one of:\n");
        for (i = 0; i < expected->data_len; i++) {
            ALOGD("0x%02" PRIX8 ",\n", expected->data[i]);
        }
        ALOGD("received: 0x%02" PRIX8 "\n", received->data[0]);
    }

    return match;
}

static bool
compare_no_message(const acknowledge_t *expected, const buffer_t *received)
{
    return true;
}

static int32_t
write_chunk_to_device(const driver_t *driver, const data_big_block_t *chunk)
{
    int32_t err = 0;
    uint32_t written = 0;
    uint32_t to_write = chunk->len + 1;

    if (upload_fops.flush_channel)
        upload_fops.flush_channel(driver);

    do {
        /* According to 80000NT10058A_r20, the chunk read from stream is LEN + 1*/
        int32_t offset = (chunk->len + 1) - to_write;
        int32_t packet = to_write > MAX_PACKET_SIZE ? MAX_PACKET_SIZE : to_write;  /* Avoid flooding the modem */

        err = driver->send(driver, chunk->data + offset, packet, &written);
        if (err) {
            ALOGE("write chunk error %" PRIi32 "\n", err);
            break;
        }

        to_write -= written;
    } while (to_write > 0);

    /* In case of bytes left to write, but no error, set CORE_ERROR_UNKNOWN */
    if (to_write)
        err = err ? err : CORE_ERROR_UNKNOWN;

    return err;
}


static int32_t read_ack_from_device(const driver_t *driver, buffer_t *ack, const int32_t exp_len,
        const uint32_t ms_timeout)
{
    int32_t err;

    err = driver->wait_reply(driver, ms_timeout);
    if (err) {
        ALOGE("could not get any reply\n");
        goto end;
    }

    do {
        uint32_t read = 0;
        uint32_t offset = ack->len;

        err = driver->read(driver, ack->data + offset, exp_len - ack->len, &read);
        if (err && err != -EAGAIN) {
            ALOGE("cannot read ACK: error %" PRIi32 "\n", err);
            goto end;
        }

        ack->len += read;
        if ((exp_len - ack->len) > 0)
            ALOGD("%" PRIi32 " bytes left (offset %" PRIu32 ")\n", exp_len - ack->len, offset);
    } while ((exp_len - ack->len) > 0);

end:
    return err;
}

static int32_t
upload_mode(driver_t *driver, upload_context_t *c, boot_context_t *boot_ctx)
{
    int32_t err = 0;
    const acknowledge_t *exp_ack = NULL;
    static data_big_block_t chunk = {0};
    int32_t chunks = 0;
    uint32_t stream_offset = c->stream.stream_offset;
    uint32_t cur_chunk_len = 0;
    int32_t percent;
    enum upload_step {
        READ_STREAM,
        HANDLE_SPEED,
        WRITE_CHUNK,
        READ_REPLY
    } step = READ_STREAM;

    memset(&chunk, 0, sizeof(chunk));


    do {
        if (c->progress)
            c->progress(stream_offset, c->stream.filesize);

        switch (step) {
            case READ_STREAM:
                memset(&chunk, 0, sizeof(chunk));
                err = c->stream.read_chunk(c->stream.handle, &chunk, &cur_chunk_len);
                if (err) {
                    ALOGE("read chunk error %" PRIi32 "\n", err);
                    err = UPLOAD_ERR_READ_CHUNK;
                    goto end;
                }

                if (cur_chunk_len == 0) {
                    ALOGD("end of stream reached\n");  /* not an error */
                    goto end;
                }

                chunks++;
                percent = (100 * (uint64_t) stream_offset) / c->stream.filesize;
                ALOGD("read chunk #%" PRIi32 " [stream_off:%" PRIu32 " + %" PRIu32 "] (%" PRIi32 "/100)\n",
                        chunks, stream_offset, cur_chunk_len + CHUNK_HEADER_LEN, percent);

                stream_offset += cur_chunk_len + CHUNK_HEADER_LEN;

                step = (c->speed_change_state == SPEED_CHANGE_DONE) ?  WRITE_CHUNK : HANDLE_SPEED;
                break;
            case HANDLE_SPEED:
                switch (c->speed_change_state) {
                    case SPEED_CHANGE_CHANGE_IN_MODEM: {
                        int32_t chunk_offset;
                        int8_t speed_byte;
                        speed_opt_t stream_speed;

                        chunk_offset = upload_fops.get_offset_in_speed_chunk(c, &chunk, stream_offset);
                        if (chunk_offset < 0) {
                            /* current chunk is not a speed change command */
                            break;
                        }

                        ALOGI("[+] handling speed change in modem\n");
                        stream_speed = get_speed_opt_from_speed_byte(chunk.data[chunk_offset]);
                        if (c->wanted_speed == SPEED_OPT_UNKNOWN && stream_speed == SPEED_OPT_UNKNOWN) {
                            ALOGE("speed change error: unrecognized stream speed byte (%" PRIu8 ")\n",
                                    chunk.data[chunk_offset]);
                            c->speed_change_state = SPEED_CHANGE_DONE;
                            break;
                        }

                        /* if speed is not set from CLI, use the one inside the stream. */
                        if (c->wanted_speed == SPEED_OPT_UNKNOWN) {
                            c->wanted_speed = stream_speed;
                        } else {
                            speed_byte = upload_fops.get_speed_byte(c->wanted_speed);
                            err = upload_fops.inject_speed_byte(&chunk, chunk_offset, speed_byte);
                            if (err)
                                goto end;
                        }

                        if (c->wanted_speed == SPEED_OPT_115200
                                || c->wanted_speed == SPEED_OPT_NOCHANGE) {
                            ALOGD("no modem speed change required.\n");
                            c->speed_change_state = SPEED_CHANGE_DONE;
                            break;
                        }

                        c->speed_change_state = SPEED_CHANGE_CHANGE_IN_HOST;
                        break;
                    }
                    case SPEED_CHANGE_CHANGE_IN_HOST:
                        ALOGD("[+] handling speed change in host\n");
                        err = handle_host_speed_change(
                                driver,
                                c->wanted_speed,
                                c->enable_hw_flow_control_after_speed_change);
                        if (err)
                            goto end;

                        c->speed_change_state = SPEED_CHANGE_DONE;
                        break;
                    case SPEED_CHANGE_DONE:
                    default:
                        /* nothing to do */
                        break;
                }

                if (c->speed_change_state == SPEED_CHANGE_DONE) {
                    ALOGI("[+] handling speed change done\n");
                    if (boot_ctx->delay_after_speed_change) {
                        ALOGD("waiting the phisical modem peripheral to be ready\n");
                        core_sleep(boot_ctx->delay_after_speed_change);
                    }
                }

                step++;
                break;
            case WRITE_CHUNK:
                err = write_chunk_to_device(driver, &chunk);
                if (err) {
                    ALOGE("write chunk error %" PRIi32 "\n", err);
                    goto end;
                }


                if (c->report_entries) {
                    /* update percent to have the final 100% value stored */
                    percent = (100 * (uint64_t) stream_offset) / c->stream.filesize;
                    json_update(c->report_entries, REPORT_KEY_UPLOAD_STREAM_OFF, &stream_offset,
                            VALUE_TYPE_LONG);
                    json_update(c->report_entries, REPORT_KEY_UPLOAD_CHUNK, &chunks, VALUE_TYPE_INT);
                    json_update(c->report_entries, REPORT_KEY_UPLOAD_PERC, &percent, VALUE_TYPE_INT);
                }

                switch (c->ack_expected) {
                    case ACK_IS_EXPECTED:
                        step++;
                        break;
                    case ACK_SKIP_UNTIL_OFFSET:
                        step = (stream_offset <= c->stream.ack_boot_offset) ? READ_STREAM : step + 1;
                        break;
                    case ACK_READ_AND_IGNORE_UNTIL_OFFSET:
                        if (stream_offset > c->stream.ack_boot_offset) {
                            c->ack_expected = ACK_IS_EXPECTED;
                            c->exp_ack = &ack_len1;
                        }
                        step++;
                        break;
                }
                break;
            case READ_REPLY: {
                buffer_t ack = {0};

                exp_ack = (c->exp_first_ack != NULL) ? c->exp_first_ack : c->exp_ack;

                err = read_ack_from_device(driver, &ack, exp_ack->ack_len, c->ack_timeout_ms);
                if (err) {
                    ALOGE("could not read ack from device\n");
                    goto end;
                }

                if (exp_ack->compare(exp_ack, &ack)) {
                    /* Deleting first_ack reference to avoid waiting for it again */
                    c->exp_first_ack = NULL;
                    step = READ_STREAM;
                    break;
                }

                if (c->max_nacks-- > 0) {
                    ALOGD(
                            "got a NACK: this modem might emit spurious bytes during upload, nothing to do (%"
                            PRIu8 " possible NACK left)\n",
                            c->max_nacks);
                    step = READ_REPLY;
                } else {
                    ALOGE("got a NACK!\n");
                    err = UPLOAD_ERR_GOT_NACK;
                }

                break;
            }
            default:
                ALOGE("unexpected upload step %u\n", step);
                err = UPLOAD_ERR_UNKNOWN_STEP;
        }
    } while (!err);

end:
    if (!err) {
        ALOGI("\n");
        ALOGI("[+] firmware uploaded successfully!\n");
    }

    if (c->report_entries)
        json_update(c->report_entries, REPORT_KEY_UPLOAD_RETURN, &err, VALUE_TYPE_INT);
    return err;
}

static int32_t handle_host_speed_change(const driver_t *driver, const speed_opt_t speed,
        const bool enable_hw_flow_control)
{
    int32_t err;

    err = driver->configure(driver, enable_hw_flow_control);
    if (err)
        ALOGE("device config failed\n");

    err = driver->set_baud_rate(driver, speed);
    if (err)
        ALOGE("set speed failed\n");

    return err;
}

static int8_t
get_speed_byte(const speed_opt_t speed)
{
    int8_t speed_byte = SPEED_OPT_UNKNOWN;

    switch (speed) {
        case SPEED_OPT_115200:
            speed_byte = 1;
            break;
        case SPEED_OPT_230400:
            speed_byte = 2;
            break;
        case SPEED_OPT_460800:
            speed_byte = 3;
            break;
        case SPEED_OPT_921600:
            speed_byte = 4;
            break;
        case SPEED_OPT_NOCHANGE:
            speed_byte = 9;
            break;
        case SPEED_OPT_2000000:
            speed_byte = 12;
            break;
        case SPEED_OPT_3000000:
            speed_byte = 10;
            break;
        case SPEED_OPT_UNKNOWN:
        default:
            break;
    }

    return speed_byte;
}

/* LE910Cx requires a special mapping between speed and
 * speed byte, since its values are shifted by one
 * ("normal" le910cx_speed_byte = speed_byte - 1) */
static int8_t
get_speed_byte_le910cx(const speed_opt_t speed)
{
    int8_t speed_byte = -1;

    switch (speed) {
        case SPEED_OPT_115200:
            speed_byte = 0;
            break;
        case SPEED_OPT_230400:
            speed_byte = 1;
            break;
        case SPEED_OPT_460800:
            speed_byte = 2;
            break;
        case SPEED_OPT_921600:
            speed_byte = 3;
            break;
        case SPEED_OPT_3000000:
            speed_byte = 4;
            break;
        case SPEED_OPT_3200000:
            speed_byte = 5;
            break;
        case SPEED_OPT_3750000:
            speed_byte = 6;
            break;
        case SPEED_OPT_2000000:
        case SPEED_OPT_UNKNOWN:
        default:
            speed_byte = SPEED_OPT_UNKNOWN;
            break;
    }

    return speed_byte;
}

static int32_t
get_offset_in_speed_chunk(upload_context_t *ctx, data_big_block_t *chunk, uint32_t stream_offset)
{
    uint32_t speed_offset;
    int32_t chunk_offset;

    speed_offset = ctx->stream.header_size + ctx->stream.speed_offset;
    if (stream_offset <= speed_offset)
        return -1;

    chunk_offset = (chunk->len + 1) - (stream_offset - speed_offset);
    assert(chunk_offset >= 0);

    return chunk_offset;
}

static int32_t get_offset_in_speed_chunk_le910cx(upload_context_t *ctx,
        data_big_block_t *chunk,
        uint32_t stream_offset)
{
#define CHUNK_CMD_TYPE_SPEED 1
#define LE910CX_CHUNK_OFFSET 3

    if (chunk->data[0] != CHUNK_CMD_TYPE_SPEED)
        return -1;

    return LE910CX_CHUNK_OFFSET;
}

static uint16_t
crc16(uint16_t crc_value, unsigned char new_byte)
{
#define POLYNOM 0x1021
    for (unsigned i = 0; i < 8; i++) {
        if (((crc_value & 0x8000) >> 8) ^ (new_byte & 0x80))
            crc_value = 0x0000FFFF & ((crc_value << 1) ^ POLYNOM);
        else
            crc_value = 0x0000FFFF & (crc_value << 1);

        new_byte <<= 1;
    }

#undef POLYNOM
    return crc_value;
}

static uint16_t calculate_crc16(unsigned char *data, unsigned char len)
{
    uint16_t crc;
    unsigned char aux = 0;

    crc = 0xFFFF;
    while (aux < len) {
        crc = crc16(crc, data[aux]);
        aux++;
    }

    return (~crc);
}

static int32_t inject_speed_byte(data_big_block_t *chunk, const int32_t offset, const speed_opt_t speed)
{
    int32_t err = CORE_ERROR_EINVAL;

    if (offset > chunk->len)
        return err;

    err = CORE_SUCCESS;
    chunk->data[offset] = speed;
    ALOGD("injected speed byte:%u at offset:%" PRIi32 "\n", speed, offset);
    return err;
}

static int32_t inject_speed_byte_and_crc(data_big_block_t *chunk, const int32_t offset,
        const speed_opt_t speed)
{
    int32_t err;
    uint16_t crc;

    err = inject_speed_byte(chunk, offset, speed);
    if (err)
        return err;

    crc = htobe16(calculate_crc16(chunk->data, 5));
    memcpy(&chunk->data[offset + 2], &crc, 2);
    ALOGD("injected crc:%" PRIu16 " at offset %" PRIi32 "\n", crc, offset);
    return err;
}

/* Reuse the modem specific function get_speed_byte to get the
 * speed value from the speed byte (the reverse of get_speed_byte).
 * This avoids to write another modem specific function */
static speed_opt_t get_speed_opt_from_speed_byte(const uint8_t speed_byte)
{
    speed_opt_t ss[] = {
        SPEED_OPT_115200,
        SPEED_OPT_230400,
        SPEED_OPT_460800,
        SPEED_OPT_921600,
        SPEED_OPT_2000000,
        SPEED_OPT_3000000,
        SPEED_OPT_3200000,
        SPEED_OPT_3750000,
        SPEED_OPT_NOCHANGE,
        SPEED_OPT_UNKNOWN,
    };

    for (uint8_t i = 0; ss[i] != SPEED_OPT_UNKNOWN; ++i) {
        if (speed_byte == upload_fops.get_speed_byte(ss[i]))
            return ss[i];
    }

    return SPEED_OPT_UNKNOWN;
}

static int32_t flush_channel(const driver_t *driver)
{
    return driver->flush(driver);
}
