#include <assert.h>
#include <string.h>
#include <inttypes.h>
#include <stdio.h>

#include "devices.h"
#include "protocol.h"

chipset_t get_chipset_from_sw_version(const char *sw_version)
{
    uint8_t i = 0;
    chipset_t chipset = CHIPSET_UNKNOWN;
    const static struct _fw_to_chipset_map {
        char *fw_stem;
        uint8_t fw_stem_lenght;
        chipset_t chipset;
    } fw_to_chipset_map [] = {
        {"08.01", 5, CHIPSET_GEN_QC_1},
        {"10.", 3, CHIPSET_XGOLD},
        {"11.", 3, CHIPSET_6160},
        {"12.", 3, CHIPSET_6260},
        {"13.", 3, CHIPSET_XG118},
        {"14.12", 5, CHIPSET_GEN_QC_3},
        {"14.22", 5, CHIPSET_MDM6200},
        {"15.", 3, CHIPSET_GEN_QC_1},
        {"16.01", 5, CHIPSET_XG110},
        {"17.", 3, CHIPSET_MDM9X15},
        {"18.42.021", 9, CHIPSET_GEN_QC_4},
        {"18.x1", 5, CHIPSET_GEN_QC_2},
        {"19.10", 5, CHIPSET_GEN_QC_3},
        {"20.", 3, CHIPSET_7160},
        {"23.", 3, CHIPSET_ALTAIR},
        {"24.01", 5, CHIPSET_MDM9640},
        {"24.", 3, CHIPSET_GEN_QC_5},
        {"25.30", 5, CHIPSET_LE910C1_EUX},
        {"25.", 3, CHIPSET_MDM9207_MDM9628},
        {"27.", 3, CHIPSET_XMM727},
        {"30.", 3, CHIPSET_MDM9206},
        {"32.", 3, CHIPSET_SDX20},
        {"FLEX_32", 7, CHIPSET_SDX20},
        {"37.", 3, CHIPSET_MDM9205},
        {"38.", 3, CHIPSET_SDX55},
        {"40.", 3, CHIPSET_SDX12},
        {"FLEX_24", 7, CHIPSET_MDM9640},
        {"39.", 3, CHIPSET_ASR1601},
        {"45.0", 4, CHIPSET_SDX65},
        {"44.", 3, CHIPSET_ASR1603},
        {"43.", 3, CHIPSET_ALT1255},
        {"48.", 3, CHIPSET_ALT1350},
        {"45.5", 4, CHIPSET_SDX65_8GB},
        {"52.", 3, CHIPSET_QCX216},
        {NULL, 0, CHIPSET_UNKNOWN},
    };

    assert(sw_version);

    while (fw_to_chipset_map[i].fw_stem) {
        char *stem = fw_to_chipset_map[i].fw_stem;
        uint8_t len = fw_to_chipset_map[i].fw_stem_lenght;

        if (memcmp(sw_version, stem, len) == 0) {
            chipset = fw_to_chipset_map[i].chipset;
            break;
        }
        i++;
    }

    return chipset;
}

const char *get_chipset_name(const chipset_t chipset)
{
    const static char *chipset_names[] = {
        [CHIPSET_6160] = "HE863",
        [CHIPSET_6260] = "HE910, UE910, UL865, UE866",
        [CHIPSET_7160] = "LE910-V2",
        [CHIPSET_ALTAIR] = "LE866",
        [CHIPSET_GEN_QC_1] = "UC864, DE910",
        [CHIPSET_GEN_QC_2] = "GC864, CE910",
        [CHIPSET_GEN_QC_3] = "UE910-V2, HE920",
        [CHIPSET_GEN_QC_4] = "CL865",
        [CHIPSET_GEN_QC_5] = "LE922A",
        [CHIPSET_MDM6200] = "HE910-V2",
        [CHIPSET_MDM9206] = "ME910",
        [CHIPSET_MDM9207_MDM9628] = "LE910Cx, LE920A4",
        [CHIPSET_MDM9640] = "LM940",
        [CHIPSET_MDM9X15] = "LE910, LE920",
        [CHIPSET_SDX20] = "LM960",
        [CHIPSET_XG110] = "GE866-QUAD, GL*",
        [CHIPSET_XG118] = "GE910",
        [CHIPSET_XGOLD] = "GC864-DUAL-V2, GC864-QUAD-V2, GC864-GPS",
        [CHIPSET_XMM727] = "LE940B6",
        [CHIPSET_SDX55] = "FN980, FT980-KS",
        [CHIPSET_LE910C1_EUX] = "LE910C1-EUX",
        [CHIPSET_MDM9205] = "ME910G1, ME310G1",
        [CHIPSET_SDX12] = "LN920",
        [CHIPSET_ASR1601] = "LE910S1",
        [CHIPSET_SDX65] = "FN990 single slot",
        [CHIPSET_ASR1603] = "LE910R1",
        [CHIPSET_ALT1255] = "NE310L2-W1, NE310L2-WW",
        [CHIPSET_ALT1350] = "ME310M1",
        [CHIPSET_SDX65_8GB] = "FN990 dual slot",
        [CHIPSET_QCX216] = "ELS63-I, LE910Q1",
        [CHIPSET_UNKNOWN] = "UNKNOWN",
    };

    if (chipset < CHIPSET_6160 || chipset >= CHIPSET_UNKNOWN)
        return NULL;

    return chipset_names[chipset];
}


/* Chipset to protocol mapping for when the modem is connected through serial port */
const static protocol_t chipset_to_serial_protocol [] = {
    [CHIPSET_6160] =
    { CHIPSET_6160, CHANNEL_SERIAL_PHY, BOOT_TYPE_C1_SERIAL, BOOT_TYPE_C1_SERIAL, UPLOAD_TYPE_B1},
    [CHIPSET_6260] =
    { CHIPSET_6260, CHANNEL_SERIAL_PHY, BOOT_TYPE_C1_SERIAL, BOOT_TYPE_C1_SERIAL, UPLOAD_TYPE_B1},
    [CHIPSET_7160] =
    { CHIPSET_7160, CHANNEL_SERIAL_PHY, BOOT_TYPE_C3_SERIAL, BOOT_TYPE_C3_SERIAL, UPLOAD_TYPE_E},
    /* set AT#FFUART=2 */
    [CHIPSET_ALTAIR] =
    { CHIPSET_ALTAIR, CHANNEL_SERIAL_PHY, BOOT_TYPE_A_SERIAL, BOOT_TYPE_A_SERIAL, UPLOAD_TYPE_C},
    [CHIPSET_GEN_QC_1] =
    { CHIPSET_GEN_QC_1, CHANNEL_SERIAL_PHY, BOOT_TYPE_A_SERIAL, BOOT_TYPE_A_SERIAL, UPLOAD_TYPE_A},
    [CHIPSET_GEN_QC_2] =
    { CHIPSET_GEN_QC_2, CHANNEL_SERIAL_PHY, BOOT_TYPE_A_SERIAL, BOOT_TYPE_A_SERIAL, UPLOAD_TYPE_A},
    [CHIPSET_GEN_QC_3] =
    { CHIPSET_GEN_QC_3, CHANNEL_SERIAL_PHY, BOOT_TYPE_A_SERIAL, BOOT_TYPE_A_SERIAL, UPLOAD_TYPE_C},
    [CHIPSET_GEN_QC_4] =
    { CHIPSET_GEN_QC_4, CHANNEL_SERIAL_PHY, BOOT_TYPE_A_SERIAL, BOOT_TYPE_A_SERIAL, UPLOAD_TYPE_A},
    [CHIPSET_GEN_QC_5] =
    { CHIPSET_GEN_QC_5, CHANNEL_SERIAL_PHY, BOOT_TYPE_A_SERIAL, BOOT_TYPE_A_SERIAL, UPLOAD_TYPE_D},
    [CHIPSET_MDM6200] =
    { CHIPSET_MDM6200, CHANNEL_SERIAL_PHY, BOOT_TYPE_A_SERIAL, BOOT_TYPE_A_SERIAL, UPLOAD_TYPE_C},
    [CHIPSET_MDM9206] =
    { CHIPSET_MDM9206, CHANNEL_SERIAL_PHY, BOOT_TYPE_F_SERIAL, BOOT_TYPE_F_SERIAL, UPLOAD_TYPE_F},
    [CHIPSET_MDM9207_MDM9628] =
    { CHIPSET_MDM9207_MDM9628, CHANNEL_SERIAL_PHY, BOOT_TYPE_D_SERIAL, BOOT_TYPE_A_SERIAL,
      UPLOAD_TYPE_D_SPEED_QUIRK},
    /* serial flashing unsupported */
    [CHIPSET_MDM9640] =
    { CHIPSET_MDM9640, CHANNEL_SERIAL_PHY, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_MDM9X15] =
    { CHIPSET_MDM9X15, CHANNEL_SERIAL_PHY, BOOT_TYPE_D_SERIAL, BOOT_TYPE_A_SERIAL, UPLOAD_TYPE_D},
    /* serial flashing unsupported */
    [CHIPSET_SDX20] =
    { CHIPSET_SDX20, CHANNEL_SERIAL_PHY, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_XG110] =
    { CHIPSET_XG110, CHANNEL_SERIAL_PHY, BOOT_TYPE_B_SERIAL, BOOT_TYPE_B_SERIAL, UPLOAD_TYPE_A},
    /* FIXME UPLOAD_TYPE_B2 sw < 13.00.xx2 */
    [CHIPSET_XG118] =
    { CHIPSET_XG118, CHANNEL_SERIAL_PHY, BOOT_TYPE_C2_SERIAL, BOOT_TYPE_C2_SERIAL, UPLOAD_TYPE_B1},
    [CHIPSET_XGOLD] =
    { CHIPSET_XGOLD, CHANNEL_SERIAL_PHY, BOOT_TYPE_B_SERIAL, BOOT_TYPE_B_SERIAL, UPLOAD_TYPE_A},
    /* serial flashing unsupported */
    [CHIPSET_XMM727] =
    { CHIPSET_XMM727, CHANNEL_SERIAL_PHY, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_SDX55] =
    { CHIPSET_SDX55, CHANNEL_SERIAL_PHY, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_LE910C1_EUX] =
    { CHIPSET_LE910C1_EUX, CHANNEL_SERIAL_PHY, BOOT_TYPE_D_SERIAL, BOOT_TYPE_A_SERIAL,
      UPLOAD_TYPE_D_SPEED_QUIRK},
    [CHIPSET_MDM9205] =
    { CHIPSET_MDM9205, CHANNEL_SERIAL_PHY, BOOT_TYPE_E_SERIAL, BOOT_TYPE_E_SERIAL,
      UPLOAD_TYPE_F_HW_FLOW_CONTROL},
    [CHIPSET_SDX12] =
    { CHIPSET_SDX12, CHANNEL_SERIAL_PHY, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    /* AT+TCOMWRT=1 to set it into boot mode, then AT#REBOOT */
    [CHIPSET_ASR1601] =
    { CHIPSET_ASR1601, CHANNEL_SERIAL_PHY, BOOT_TYPE_A2, BOOT_TYPE_A_USB, UPLOAD_TYPE_C},
    [CHIPSET_SDX65] =
    { CHIPSET_SDX65, CHANNEL_SERIAL_PHY, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    /* AT+TCOMWRT=1 to set it into boot mode, then AT#REBOOT */
    [CHIPSET_ASR1603] =
    { CHIPSET_ASR1603, CHANNEL_SERIAL_PHY, BOOT_TYPE_A2, BOOT_TYPE_A_USB, UPLOAD_TYPE_C},
    [CHIPSET_ALT1255] =
    { CHIPSET_ALT1255, CHANNEL_SERIAL_PHY, BOOT_TYPE_G_SERIAL, BOOT_TYPE_G_SERIAL, UPLOAD_TYPE_C},
    [CHIPSET_ALT1350] =
    { CHIPSET_ALT1350, CHANNEL_SERIAL_PHY, BOOT_TYPE_G_SERIAL, BOOT_TYPE_G_SERIAL, UPLOAD_TYPE_C},
    [CHIPSET_SDX65_8GB] =
    { CHIPSET_SDX65_8GB, CHANNEL_SERIAL_PHY, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    /* AT+TCOMWRT=1 to set it into boot mode, then AT#REBOOT */
    [CHIPSET_QCX216] =
    { CHIPSET_QCX216, CHANNEL_SERIAL_PHY, BOOT_TYPE_A2, BOOT_TYPE_A_USB, UPLOAD_TYPE_C},
    [CHIPSET_UNKNOWN] =
    { CHIPSET_UNKNOWN, CHANNEL_UNKNOWN, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
};

/* Chipset to protocol mapping for when the modem is connected through USB port */
const static protocol_t chipset_to_usb_protocol [] = {
    [CHIPSET_6160] = { CHIPSET_6160, CHANNEL_SERIAL_USB, BOOT_TYPE_C1_USB, BOOT_TYPE_C1_USB, UPLOAD_TYPE_B1},
    [CHIPSET_6260] = { CHIPSET_6260, CHANNEL_SERIAL_USB, BOOT_TYPE_C1_USB, BOOT_TYPE_C1_USB, UPLOAD_TYPE_B1},
    [CHIPSET_7160] = { CHIPSET_7160, CHANNEL_SERIAL_USB, BOOT_TYPE_C3_USB, BOOT_TYPE_C3_USB, UPLOAD_TYPE_E},
    [CHIPSET_ALTAIR] = { CHIPSET_ALTAIR, CHANNEL_SERIAL_USB, BOOT_TYPE_A_USB, BOOT_TYPE_A_USB, UPLOAD_TYPE_C},
    [CHIPSET_GEN_QC_1] =
    { CHIPSET_GEN_QC_1, CHANNEL_SERIAL_USB, BOOT_TYPE_A_USB, BOOT_TYPE_A_USB, UPLOAD_TYPE_A},
    /* usb flashing unsupported */
    [CHIPSET_GEN_QC_2] =
    { CHIPSET_GEN_QC_2, CHANNEL_SERIAL_USB, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_A},
    [CHIPSET_GEN_QC_3] =
    { CHIPSET_GEN_QC_3, CHANNEL_SERIAL_USB, BOOT_TYPE_B_USB, BOOT_TYPE_FASTBOOT, UPLOAD_TYPE_C},
    [CHIPSET_GEN_QC_4] =
    { CHIPSET_GEN_QC_4, CHANNEL_SERIAL_USB, BOOT_TYPE_B_USB, BOOT_TYPE_FASTBOOT, UPLOAD_TYPE_A},
    [CHIPSET_GEN_QC_5] =
    { CHIPSET_GEN_QC_5, CHANNEL_SERIAL_USB, BOOT_TYPE_B_USB, BOOT_TYPE_FASTBOOT, UPLOAD_TYPE_D},
    [CHIPSET_MDM6200] =
    { CHIPSET_MDM6200, CHANNEL_SERIAL_USB, BOOT_TYPE_B_USB, BOOT_TYPE_FASTBOOT, UPLOAD_TYPE_C},
    [CHIPSET_MDM9206] =
    { CHIPSET_MDM9206, CHANNEL_SERIAL_USB, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_MDM9207_MDM9628] =
    { CHIPSET_MDM9207_MDM9628, CHANNEL_SERIAL_USB, BOOT_TYPE_B_USB, BOOT_TYPE_FASTBOOT,
      UPLOAD_TYPE_D},
    [CHIPSET_MDM9640] =
    { CHIPSET_MDM9640, CHANNEL_SERIAL_USB, BOOT_TYPE_B_USB, BOOT_TYPE_FASTBOOT, UPLOAD_TYPE_D},
    [CHIPSET_MDM9X15] =
    { CHIPSET_MDM9X15, CHANNEL_SERIAL_USB, BOOT_TYPE_B_USB, BOOT_TYPE_FASTBOOT, UPLOAD_TYPE_D},
    [CHIPSET_SDX20] =
    { CHIPSET_SDX20, CHANNEL_SERIAL_USB, BOOT_TYPE_B_USB, BOOT_TYPE_FASTBOOT, UPLOAD_TYPE_D},
    /* usb flashing unsupported */
    [CHIPSET_XG110] =
    { CHIPSET_XG110, CHANNEL_SERIAL_USB, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    /* FIXME UPLOAD_TYPE_B2 sw < 13.00.xx2 */
    [CHIPSET_XG118] =
    { CHIPSET_XG118, CHANNEL_SERIAL_USB, BOOT_TYPE_C2_USB, BOOT_TYPE_C2_USB, UPLOAD_TYPE_B1},
    /* usb flashing unsupported */
    [CHIPSET_XGOLD] =
    { CHIPSET_XGOLD, CHANNEL_SERIAL_USB, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_XMM727] =
    { CHIPSET_XMM727, CHANNEL_SERIAL_USB, BOOT_TYPE_C4_USB, BOOT_TYPE_C4_USB, UPLOAD_TYPE_E},
    [CHIPSET_SDX55] =
    { CHIPSET_SDX55, CHANNEL_SERIAL_USB, BOOT_TYPE_B_USB, BOOT_TYPE_FASTBOOT, UPLOAD_TYPE_C},
    [CHIPSET_LE910C1_EUX] =
    { CHIPSET_LE910C1_EUX, CHANNEL_SERIAL_USB, BOOT_TYPE_B_USB, BOOT_TYPE_FASTBOOT, UPLOAD_TYPE_C},
    [CHIPSET_MDM9205] =
    { CHIPSET_MDM9205, CHANNEL_SERIAL_USB, BOOT_TYPE_A3_USB, BOOT_TYPE_DO_NOTHING, UPLOAD_TYPE_G},
    [CHIPSET_SDX12] =
    { CHIPSET_SDX12, CHANNEL_SERIAL_USB, BOOT_TYPE_B_USB, BOOT_TYPE_FASTBOOT, UPLOAD_TYPE_C},
    /* AT+TCOMWRT=1 to set it into boot mode, then AT#REBOOT */
    [CHIPSET_ASR1601] =
    { CHIPSET_ASR1601, CHANNEL_SERIAL_USB, BOOT_TYPE_A2, BOOT_TYPE_FASTBOOT, UPLOAD_TYPE_C},
    [CHIPSET_SDX65] =
    { CHIPSET_SDX65, CHANNEL_SERIAL_USB, BOOT_TYPE_B_USB, BOOT_TYPE_FASTBOOT, UPLOAD_TYPE_C},
    /* AT+TCOMWRT=1 to set it into boot mode, then AT#REBOOT */
    [CHIPSET_ASR1603] =
    { CHIPSET_ASR1603, CHANNEL_SERIAL_USB, BOOT_TYPE_A2, BOOT_TYPE_FASTBOOT, UPLOAD_TYPE_C},
    [CHIPSET_ALT1255] =
    { CHIPSET_ALT1255, CHANNEL_SERIAL_USB, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_ALT1350] =
    { CHIPSET_ALT1350, CHANNEL_SERIAL_USB, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_SDX65_8GB] =
    { CHIPSET_SDX65_8GB, CHANNEL_SERIAL_USB, BOOT_TYPE_B_USB, BOOT_TYPE_FASTBOOT, UPLOAD_TYPE_C},
    /* AT+TCOMWRT=1 to set it into boot mode, then AT#REBOOT */
    [CHIPSET_QCX216] =
    { CHIPSET_QCX216, CHANNEL_SERIAL_USB, BOOT_TYPE_A2, BOOT_TYPE_FASTBOOT, UPLOAD_TYPE_C},
    [CHIPSET_UNKNOWN] =
    { CHIPSET_UNKNOWN, CHANNEL_UNKNOWN, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
};

/* Chipset to protocol mapping for when the modem is connected through PCI port */
const static protocol_t chipset_to_pci_protocol [] = {
    [CHIPSET_6160] =
    { CHIPSET_6160, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_6260] =
    { CHIPSET_6260, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_7160] =
    { CHIPSET_7160, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_ALTAIR] =
    { CHIPSET_ALTAIR, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_GEN_QC_1] =
    { CHIPSET_GEN_QC_1, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN,
      UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_GEN_QC_2] =
    { CHIPSET_GEN_QC_2, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN,
      UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_GEN_QC_3] =
    { CHIPSET_GEN_QC_3, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN,
      UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_GEN_QC_4] =
    { CHIPSET_GEN_QC_4, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN,
      UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_GEN_QC_5] =
    { CHIPSET_GEN_QC_5, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN,
      UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_MDM6200] =
    { CHIPSET_MDM6200, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_MDM9206] =
    { CHIPSET_MDM9206, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_MDM9207_MDM9628] =
    { CHIPSET_MDM9207_MDM9628, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN,
      UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_MDM9640] =
    { CHIPSET_MDM9640, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_MDM9X15] =
    { CHIPSET_MDM9X15, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_SDX20] =
    { CHIPSET_SDX20, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_XG110] =
    { CHIPSET_XG110, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_XG118] =
    { CHIPSET_XG118, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_XGOLD] =
    { CHIPSET_XGOLD, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_XMM727] =
    { CHIPSET_XMM727, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_SDX55] =
    { CHIPSET_SDX55, CHANNEL_SERIAL_PCI, BOOT_TYPE_B_USB, BOOT_TYPE_FASTBOOT, UPLOAD_TYPE_C},
    [CHIPSET_LE910C1_EUX] =
    { CHIPSET_LE910C1_EUX, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN,
      UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_MDM9205] =
    { CHIPSET_MDM9205, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_SDX12] =
    { CHIPSET_SDX12, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_ASR1601] =
    { CHIPSET_ASR1601, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_SDX65] =
    { CHIPSET_SDX65, CHANNEL_SERIAL_PCI, BOOT_TYPE_B_USB, BOOT_TYPE_FASTBOOT, UPLOAD_TYPE_C},
    [CHIPSET_ASR1603] =
    { CHIPSET_ASR1603, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_ALT1255] =
    { CHIPSET_ALT1255, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_ALT1350] =
    { CHIPSET_ALT1350, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_SDX65_8GB] =
    { CHIPSET_SDX65_8GB, CHANNEL_SERIAL_PCI, BOOT_TYPE_B_USB, BOOT_TYPE_FASTBOOT, UPLOAD_TYPE_C},
    [CHIPSET_QCX216] =
    { CHIPSET_QCX216, CHANNEL_SERIAL_PCI, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
    [CHIPSET_UNKNOWN] =
    { CHIPSET_UNKNOWN, CHANNEL_UNKNOWN, BOOT_TYPE_UNKNOWN, BOOT_TYPE_UNKNOWN, UPLOAD_TYPE_UNKNOWN},
};

boot_type_t get_boot_type_from_chipset(const chipset_t chipset, const channel_t channel, const bool recovery)
{
    boot_type_t type = BOOT_TYPE_UNKNOWN;

    if (chipset < CHIPSET_6160 || chipset >= CHIPSET_UNKNOWN) {
        ALOGE("unknown chipset %u\n", chipset);
        goto end;
    }

    switch (channel) {
        case CHANNEL_SERIAL_PHY:
            type = recovery ?
                    chipset_to_serial_protocol[chipset].boot_type_recovery :
                    chipset_to_serial_protocol[chipset].boot_type;
            break;
        case CHANNEL_SERIAL_USB:
            type = recovery ?
                    chipset_to_usb_protocol[chipset].boot_type_recovery :
                    chipset_to_usb_protocol[chipset].boot_type;
            break;
        case CHANNEL_FASTBOOT:
            type = BOOT_TYPE_FASTBOOT;
            break;
        case CHANNEL_UNKNOWN:
        default:
            ALOGE("unknown channel %u\n", channel);
            break;
    }

end:
    return type;
}

upload_type_t get_upload_type_from_chipset(const chipset_t chipset, const channel_t channel)
{
    upload_type_t type = UPLOAD_TYPE_UNKNOWN;

    if (chipset < CHIPSET_6160 || chipset >= CHIPSET_UNKNOWN) {
        ALOGE("unknown chipset %u\n", chipset);
        goto end;
    }

    type = (channel == CHANNEL_SERIAL_PHY) ?
            chipset_to_serial_protocol[chipset].upload_type :
            chipset_to_usb_protocol[chipset].upload_type;

end:
    return type;

}

int32_t get_download_usb_id_from_chipset(const chipset_t chipset, usb_id_list_t **usb_ids)
{
    static usb_id_list_t usbid_list_empty = USBID_LIST_EMPTY;
    static usb_id_list_t usbid_list_infineon = USBID_LIST_INFINEON;
    static usb_id_list_t usbid_list_flashloader_intel_7160 = USBID_LIST_FLASHLOADER_INTEL_7160;
    static usb_id_list_t usbid_list_flashloader_type_ab = USBID_LIST_FLASHLOADER_TYPE_AB;
    static usb_id_list_t usbid_list_flashloader_mdm9x15 = USBID_LIST_FLASHLOADER_MDM9X15;
    static usb_id_list_t usbid_list_flashloader_lm9x0 = USBID_LIST_FLASHLOADER_LM9X0;
    static usb_id_list_t usbid_list_sdx55 = USBID_LIST_SDX55;
    static usb_id_list_t usbid_list_le910c1_eux = USBID_LIST_LE910C1_EUX;
    static usb_id_list_t usbid_list_mdm9205 = USBID_LIST_MDM9205;
    static usb_id_list_t usbid_list_sdx12 = USBID_LIST_SDX12;
    static usb_id_list_t usbid_list_asr1601 = USBID_LIST_ASR1601;
    static usb_id_list_t usbid_list_asr1603 = USBID_LIST_ASR1603;
    static usb_id_list_t usbid_list_fn990a28 = USBID_LIST_FN990A28;
    static usb_id_list_t usbid_list_qcx216 = USBID_LIST_QCX216;

    int err = CORE_SUCCESS;
    switch (chipset) {
        case CHIPSET_6160:
        case CHIPSET_6260:
        case CHIPSET_XG118:
            *usb_ids = &usbid_list_infineon;
            break;
        case CHIPSET_7160:
            *usb_ids = &usbid_list_flashloader_intel_7160;
            break;
        case CHIPSET_ALTAIR:
        case CHIPSET_GEN_QC_1:
        case CHIPSET_GEN_QC_3:
        case CHIPSET_GEN_QC_4:
        case CHIPSET_GEN_QC_5:
        case CHIPSET_MDM6200:
            *usb_ids = &usbid_list_flashloader_type_ab;
            break;
        case CHIPSET_MDM9X15:
        case CHIPSET_MDM9207_MDM9628:
            *usb_ids = &usbid_list_flashloader_mdm9x15;
            break;
        case CHIPSET_MDM9640:
        case CHIPSET_SDX20:
            *usb_ids = &usbid_list_flashloader_lm9x0;
            break;
        case CHIPSET_SDX55:
            *usb_ids = &usbid_list_sdx55;
            break;
        case CHIPSET_LE910C1_EUX:
            *usb_ids = &usbid_list_le910c1_eux;
            break;
        case CHIPSET_MDM9205:
            *usb_ids = &usbid_list_mdm9205;
            break;
        case CHIPSET_SDX12:
            *usb_ids = &usbid_list_sdx12;
            break;
        case CHIPSET_GEN_QC_2:
        case CHIPSET_MDM9206:
        case CHIPSET_XG110:
        case CHIPSET_XGOLD:
        case CHIPSET_XMM727:
        case CHIPSET_ALT1255:
        case CHIPSET_ALT1350:
            *usb_ids = &usbid_list_empty;  /* usb flashing unsupported */
            break;
        case CHIPSET_ASR1601:
            *usb_ids = &usbid_list_asr1601;
            break;
        case CHIPSET_ASR1603:
            *usb_ids = &usbid_list_asr1603;
            break;
        case CHIPSET_SDX65:
        case CHIPSET_SDX65_8GB:
            *usb_ids = &usbid_list_fn990a28;
            break;
        case CHIPSET_QCX216:
            *usb_ids = &usbid_list_qcx216;
            break;
        case CHIPSET_UNKNOWN:
        default:
            ALOGE("unsupported or unknown chipset %u\n", chipset);
            *usb_ids = &usbid_list_empty;
            err = CORE_ERROR_EINVAL;
    }
    return err;
}


int32_t get_second_phase_boot_usb_id_from_chipset(const chipset_t chipset, usb_id_list_t **usb_ids)
{
    static usb_id_list_t google_fastboot = { 1, {USBID_GOOGLE_FASTBOOT} };
    static usb_id_list_t tdloader = {1, {USBID_TDLOADER}};
    static usb_id_list_t sdx55loader = {3, {USBID_TDLOADER, USBID_PCIE_FN980, USBID_UDELOADER_FN980}};
    static usb_id_list_t asr1601loader = {1, {USBID_ASR1601_LOADER }};
    static usb_id_list_t asr1603loader = {1, {USBID_ASR1603_LOADER }};
    static usb_id_list_t sdx65loader = {3, {USBID_TDLOADER, USBID_PCIE_FN990, USBID_UDELOADER_FN990}};
    static usb_id_list_t mdm9205_edloader = {1, {USBID_MDM9205_EDL}};
    static usb_id_list_t qcx216loader = {1, {USBID_QCX216_LOADER }};

    if (chipset == CHIPSET_UNKNOWN)
        return CORE_ERROR_EINVAL;

    switch (chipset) {
        case CHIPSET_SDX55:
            *usb_ids = (usb_id_list_t *)&sdx55loader;
            break;
        case CHIPSET_SDX12:
        case CHIPSET_LE910C1_EUX:
            *usb_ids = (usb_id_list_t *)&tdloader;
            break;
        case CHIPSET_ASR1601:
            *usb_ids = (usb_id_list_t *)&asr1601loader;
            break;
        case CHIPSET_ASR1603:
            *usb_ids = (usb_id_list_t *)&asr1603loader;
            break;
        case CHIPSET_SDX65:
        case CHIPSET_SDX65_8GB:
            *usb_ids = (usb_id_list_t *)&sdx65loader;
            break;
        case CHIPSET_MDM9205:
            *usb_ids = (usb_id_list_t *)&mdm9205_edloader;
            break;
        case CHIPSET_MDM9207_MDM9628:
            *usb_ids = (usb_id_list_t *)&google_fastboot;
            break;
        case CHIPSET_QCX216:
            *usb_ids = (usb_id_list_t *)&qcx216loader;
            break;
        /* TODO: manage all the cases and report an error in default case */
        default:
            *usb_ids = (usb_id_list_t *)&google_fastboot;
            break;
    }

    return CORE_SUCCESS;
}

bool has_second_phase_boot(const protocol_t *protocol)
{
    if (protocol->boot_type_recovery == BOOT_TYPE_UNKNOWN)
        return false;
    /* Usually, chipsets that do not have a 2nd boot phase are given the same
     * value for boot_type and boot_type_recovery. */
    if (protocol->boot_type == protocol->boot_type_recovery
            /* chipset CHIPSET_MDM9207_MDM9628 is an exception to what stated
             * above. It uses BOOT_TYPE_B_USB in both 1st ans 2nd boot phase,
             * so it requires a dedicated condition. */
            && protocol->boot_type != BOOT_TYPE_B_USB)
        return false;
    return true;
}

core_res_t get_usb_ids_from_chipset(const chipset_t chipset, const bool is_recovery, usb_id_list_t **usb_ids)
{
    int32_t err = CORE_SUCCESS;

    if (chipset < CHIPSET_6160 || chipset >= CHIPSET_UNKNOWN) {
        ALOGE("unknown chipset %u\n", chipset);
        err = CORE_ERROR_EINVAL;
        goto end;
    }

    if (is_recovery && has_second_phase_boot(&chipset_to_usb_protocol[chipset]))
        err = get_second_phase_boot_usb_id_from_chipset(chipset, usb_ids);
    else
        err = get_download_usb_id_from_chipset(chipset, usb_ids);
    if (err)
        return err;

    /* No USB IDs found or found only the empty element */
    if ((*usb_ids)->len == 0) {
        ALOGD("No USB IDs for chipset %u %s\n", chipset, get_chipset_name(chipset));
        err = CORE_ERROR_NO_SUCH_DEVICE;
    }

    {
        /* this is useful logging in debug mode */
        ALOGD("chipset %u (%s) in %s mode has %" PRIu8 " usb_id(s): \n",
                chipset,
                get_chipset_name(chipset),
                is_recovery ? "recovery" : "mission",
                (*usb_ids)->len);
        for (int i = 0; i < (*usb_ids)->len; i++) {
            ALOGD(" %04" PRIX32 ":%04" PRIX32 "\n", (*usb_ids)->items[i].vid, (*usb_ids)->items[i].pid);
        }
    }

end:
    return err;
}

core_res_t get_protocol_from_chipset(const chipset_t chipset, const channel_t channel, protocol_t *protocol)
{
    core_res_t ret = CORE_SUCCESS;

    if (chipset < CHIPSET_6160 || chipset >= CHIPSET_UNKNOWN) {
        ALOGE("unknown chipset %u\n", chipset);
        ret = CORE_ERROR_EINVAL;
        goto end;
    }

    switch (channel) {
        case CHANNEL_SERIAL_PHY:
            *protocol = chipset_to_serial_protocol[chipset];
            break;
        case CHANNEL_SERIAL_USB:
        case CHANNEL_FASTBOOT:
            *protocol = chipset_to_usb_protocol[chipset];
            break;
        case CHANNEL_SERIAL_PCI:
            *protocol = chipset_to_pci_protocol[chipset];
            break;
        default:
            ALOGE("unexpected channel %u\n", channel);
            ret = CORE_ERROR_EINVAL;
    }

end:
    return ret;
}

const char *get_boot_type_name(boot_type_t type)
{
    static const char *boot_type_names[] = {
        [BOOT_TYPE_A_SERIAL] = "A_SERIAL",
        [BOOT_TYPE_B_SERIAL] = "B_SERIAL",
        [BOOT_TYPE_C1_SERIAL] = "C1_SERIAL",
        [BOOT_TYPE_C2_SERIAL] = "C2_SERIAL",
        [BOOT_TYPE_C3_SERIAL] = "C3_SERIAL",
        [BOOT_TYPE_D_SERIAL] = "D_SERIAL",
        [BOOT_TYPE_A_USB] = "A_USB",
        [BOOT_TYPE_B_USB] = "B_USB",
        [BOOT_TYPE_C1_USB] = "C1_USB",
        [BOOT_TYPE_C2_USB] = "C2_USB",
        [BOOT_TYPE_C3_USB] = "C3_USB",
        [BOOT_TYPE_C4_USB] = "C4_USB",
        [BOOT_TYPE_E] = "E",
        [BOOT_TYPE_FASTBOOT] = "FASTBOOT",
        [BOOT_TYPE_F_SERIAL] = "F_SERIAL",
        [BOOT_TYPE_E_SERIAL] = "E_SERIAL",
        [BOOT_TYPE_A2] = "A2",
        [BOOT_TYPE_A3_USB] = "A3_USB",
        [BOOT_TYPE_DO_NOTHING] = "NO_MESSAGES",
        [BOOT_TYPE_G_SERIAL] = "G_SERIAL",
        [BOOT_TYPE_UNKNOWN] = "UNKNOWN",
    };

    if (type >= BOOT_TYPE_UNKNOWN)
        return boot_type_names[BOOT_TYPE_UNKNOWN];

    return boot_type_names[type];
}

const char *get_upload_type_name(upload_type_t type)
{
    static const char *upload_type_names[] = {
        [UPLOAD_TYPE_A] = "UPLOAD_TYPE_A",                                 /* GC, GE/GL, UC864 DE910 CE910 CL865 */
        [UPLOAD_TYPE_B1] = "UPLOAD_TYPE_B1",                               /* HE910, UE910, UE866, UL865, HE863 GE910 > 13.00.XX.2 */
        [UPLOAD_TYPE_B2] = "UPLOAD_TYPE_B2",                               /* GE910 < 13.00.XX.2 */
        [UPLOAD_TYPE_C] = "UPLOAD_TYPE_C",                                 /* HE910-V2, HE920, UE910-V2 */
        [UPLOAD_TYPE_D] = "UPLOAD_TYPE_D",                                 /* LE910, LE910, LE922A, LM940, LM960 */
        [UPLOAD_TYPE_D_SPEED_QUIRK] = "UPLOAD_TYPE_D_SPEED_QUIRK",         /* LE910Cx, LE920A4 */
        [UPLOAD_TYPE_E] = "UPLOAD_TYPE_E",                                 /* LE910-V2, LE940B6 */
        [UPLOAD_TYPE_F] = "UPLOAD_TYPE_F",                                 /* ME910C1, ME910G1, ME310G1 */
        [UPLOAD_TYPE_F_HW_FLOW_CONTROL] = "UPLOAD_TYPE_F_HW_FLOW_CONTROL", /* ME910G1, ME310G1, enable HW flow control for speed > 115200 */
        [UPLOAD_TYPE_G] = "UPLOAD_TYPE_G",                                 /* ME910G1, ME310G1, USB channel */
        [UPLOAD_TYPE_UNKNOWN] = "UPLOAD_TYPE_UNKNOWN",
    };

    if (type >= UPLOAD_TYPE_UNKNOWN)
        return upload_type_names[UPLOAD_TYPE_UNKNOWN];

    return upload_type_names[type];
}

core_res_t get_fn990_sw_version_info(const char *version, version_info_fn990_t *info)
{
    core_res_t err = CORE_SUCCESS;
    uint8_t exp_args = 6;
    char *fmt = NULL;
    int8_t ret = 0;

    /* The expected format is aa.Hb.SsX
     * aa = platform (= 45)
     * H= Form factor (4Gb: M.2=0, LGA=1, Wi-Fi enable with GEN512=2) (8Gb: M.2_Multi-Image=5, LGA=6,
     *    Terminal=7, M.2_Single-Image=8…)
     * b = Major version
     * S = Solution baseline (0:LE.1.2, 1: LE.1.3.1)
     * s = models (0: FN990A28, 1: FN990A40, 2: FE990A28-EA, 3: FN990A28-HP, 4: FN990A40-HP )
     * X = minor package version
     *
     *  see Fx990_version_naming_convention_r.6.0 document
     */

    fmt = "%2d.%1d%1d.%1d%1d%1d";

    ret = sscanf(version, fmt,
            &info->platform_num,
            &info->form_factor,
            &info->major_version,
            &info->solution_baseline,
            &info->model,
            &info->minor_pkg_version);

    err = !(ret > 0 && (exp_args == ret));

    if (err) {
        ALOGE("could not recognize version string '%s' (recognized %d/%d)\n",
                version, ret, exp_args);
        err = CORE_ERROR_EINVAL;
    }

    return err;
}

core_res_t parse_fn990_modem_version(const char *version, version_info_fn990_t *info)
{
    bool is_alpha_release = strstr(version, "-A") != NULL;
    bool is_beta_release = strstr(version, "-B") != NULL;
    bool is_test_release = strstr(version, "-T") != NULL;
    core_res_t err = CORE_SUCCESS;
    uint8_t exp_args = 0;
    int32_t build_number;
    char *fmt = NULL;
    int8_t ret = 0;

    /* The expected format is M0R.SsHrzz[-Vvvv]:
     * - M0R: modem platform
     * S = Solution baseline (0:LE.1.2, 1: LE.1.3.1)
     * s = models (0: FN990A28, 1: FN990A40, 2: FE990A28-EA, 3: FN990A28-HP, 4: FN990A40-HP)
     * H = Form factor (4Gb: M.2=0, LGA=1, Wi-Fi enable with GEN512=2)
     *                 (8Gb: M.2_Multi-Image=5, LGA=6, Terminal=7, M.2_Single-Image=8…)
     * r = major software version
     * zz = software release version
     *
     * appendixes [-Vvvv]:
     * - V: build type (Beta ,Alpha ,Test)
     * - vvv: build number (000-999)
     *
     *  see Fx990_version_naming_convention_r.6.0 document
     */
    if (!is_beta_release && !is_alpha_release && !is_test_release) {
        exp_args = 6;
        fmt = "%3s.%1d%1d%1d%1d%2d";

        ret = sscanf(version, fmt,
                info->platform,
                &info->solution_baseline,
                &info->model,
                &info->form_factor,
                &info->major_version,
                &info->minor_pkg_version);
    } else {
        exp_args = 7;

        if (is_beta_release) {
            fmt = "%3s.%1d%1d%1d%1d%2d-B%3d";
        } else if (is_alpha_release) {
            fmt = "%3s.%1d%1d%1d%1d%2d-A%3d";
        } else {
            fmt = "%3s.%1d%1d%1d%1d%2d-T%3d";
        }

        ret = sscanf(version, fmt,
                info->platform,
                &info->solution_baseline,
                &info->model,
                &info->form_factor,
                &info->major_version,
                &info->minor_pkg_version,
                &build_number);
    }

    err = !(ret > 0 && (exp_args == ret));

    if (err) {
        ALOGE("could not recognize version string '%s' (recognized %d/%d)\n",
                version, ret, exp_args);
        err = CORE_ERROR_EINVAL;
    }

    return err;
}
