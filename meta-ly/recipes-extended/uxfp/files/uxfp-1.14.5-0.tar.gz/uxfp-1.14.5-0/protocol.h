/**
 * @file protocol.h
 * @brief Mapping between modem models and their flashing protocols
 *
 * Copyright (C) 2018  Telit Communication spa
 */
#ifndef _PROTOCOL_H_
#define _PROTOCOL_H_
#include <stdint.h>
#include <telit-os-abs.h>

/**
 * @brief UXFP to modem communication channel types
 */
typedef enum {
    CHANNEL_SERIAL_PHY,              /**< serial port connection */
    CHANNEL_SERIAL_USB,              /**< USB connection through OS driver */
    CHANNEL_SERIAL_PCI,              /**< PCIe connection through OS driver */
    CHANNEL_FASTBOOT,                /**< USB connection through endpoints */
    CHANNEL_SERIAL_USB_NO_DISCOVERY, /**< USB connection with a fallback to direct serial channel */
    CHANNEL_UNKNOWN,
} channel_t;

/**
 * @brief chipset types
 */
typedef enum {
    CHIPSET_6160            = 1,  /**< HE863 */
    CHIPSET_6260            = 2,  /**< HE910, UE910, UL865, UE866 */
    CHIPSET_7160            = 3,  /**< LE910-V2 */
    CHIPSET_ALTAIR          = 4,  /**< LE866 */
    CHIPSET_GEN_QC_1        = 5,  /**< UC864, DE910 */
    CHIPSET_GEN_QC_2        = 6,  /**< GC864, CE910 */
    CHIPSET_GEN_QC_3        = 7,  /**< UE910-V2, HE920 */
    CHIPSET_GEN_QC_4        = 8,  /**< CL865 */
    CHIPSET_GEN_QC_5        = 9,  /**< LE922A */
    CHIPSET_MDM6200         = 10, /**< HE910-V2 */
    CHIPSET_MDM9206         = 11, /**< ME910 */
    CHIPSET_MDM9207_MDM9628 = 12, /**< LE910Cx, LE920A4 */
    CHIPSET_MDM9640         = 13, /**< LM940 */
    CHIPSET_MDM9X15         = 14, /**< LE910, LE920 */
    CHIPSET_SDX20           = 15, /**< LM960 */
    CHIPSET_XG110           = 16, /**< GE866-QUAD, GL* */
    CHIPSET_XG118           = 17, /**< GE910 */
    CHIPSET_XGOLD           = 18, /**< GC864-DUAL-V2, GC864-QUAD-V2, GC864-GPS */
    CHIPSET_XMM727          = 19, /**< LE940B6 */
    CHIPSET_SDX55           = 20, /**< FN980, FT980-KS */
    CHIPSET_LE910C1_EUX     = 21, /**< LE910C1-EUX */
    CHIPSET_MDM9205         = 22, /**< ME910G1, ME310G1 */
    CHIPSET_SDX12           = 23, /**< LN920 */
    CHIPSET_ASR1601         = 24, /**< LE910S1 */
    CHIPSET_SDX65           = 25, /**< FN990 single slot */
    CHIPSET_ASR1603         = 26, /**< LE910R1 */
    CHIPSET_ALT1255         = 27, /**< NE310L2-W1, NE310L2-WW */
    CHIPSET_ALT1350         = 28, /**< ME310M1 */
    CHIPSET_SDX65_8GB       = 29, /**< FN990 dual slot*/
    CHIPSET_QCX216          = 30, /**< ELS63-I/LE910Q1 */
    CHIPSET_UNKNOWN,
} chipset_t;

/* Temporary naming for boot modes. Ideally this
 * will be linked to chipset or to another modem
 * characteristic */

/**
 * @brief boot types according to 80000NT10058A_r20
 */
typedef enum {
    BOOT_TYPE_A_SERIAL   = 0,  /**< GC864, GE864-QUAD, UC864, DE910, CE910, CL865, HE910-V2, HE920, UE910-V2*/
    BOOT_TYPE_B_SERIAL   = 1,  /**< GC864-QUAD-V2, GC864-DUAL-V2, GE864-DUAL-V2, GE864-GPS, GL*, GE866-QUAD */
    BOOT_TYPE_C1_SERIAL  = 2,  /**< HE910, UE910, UL865, UE866, HE863 */
    BOOT_TYPE_C2_SERIAL  = 3,  /**< GE910 */
    BOOT_TYPE_C3_SERIAL  = 4,  /**< LE910-V2 */
    BOOT_TYPE_D_SERIAL   = 5,  /**< LE920, LE910, LE922A, LE910Cx, LE920A4 */
    BOOT_TYPE_A_USB      = 6,  /**< UC864, DE910, LE922A/LM940/LM960 fastboot*/
    BOOT_TYPE_B_USB      = 7,  /**< CL865, HE910-V2, HE920, UE910-V2, LE920, LE910, LE910Cx, LE920A4, LE922A/LM940/LM960 no fastboot */
    BOOT_TYPE_C1_USB     = 8,  /**< HE910, UE910, UE866, UL865, HE863*/
    BOOT_TYPE_C2_USB     = 9,  /**< GE910 */
    BOOT_TYPE_C3_USB     = 10, /**< LE910-V2 */
    BOOT_TYPE_C4_USB     = 11, /**< LE940B6 */
    BOOT_TYPE_E          = 12, /**< LE866 (actually, not assigned) */
    BOOT_TYPE_FASTBOOT   = 13, /**< Fastboot device */
    BOOT_TYPE_F_SERIAL   = 14, /**< ME910C1 */
    BOOT_TYPE_E_SERIAL   = 15, /**< ME910G1 ME310G1*/
    BOOT_TYPE_A2         = 16, /**< LE910S1 LE910R1 */
    BOOT_TYPE_A3_USB     = 17, /**< ME910G1 ME310G1 */
    BOOT_TYPE_DO_NOTHING = 18, /**< ME910G1 ME310G1 in EDL mode */
    BOOT_TYPE_G_SERIAL   = 19, /**< ME310M1 (ALT1350) */
    BOOT_TYPE_UNKNOWN,
} boot_type_t;

/**
 * @brief The upload types according to 80000NT10058A_r20
 */
typedef enum {
    UPLOAD_TYPE_A,                 /**< GC, GE/GL, UC864 DE910 CE910 CL865 */
    UPLOAD_TYPE_B1,                /**< HE910, UE910, UE866, UL865, HE863 GE910 > 13.00.XX.2 */
    UPLOAD_TYPE_B2,                /**< GE910 < 13.00.XX.2 */
    UPLOAD_TYPE_C,                 /**< HE910-V2, HE920, UE910-V2 */
    UPLOAD_TYPE_D,                 /**< LE910, LE910, LE922A, LM940, LM960 */
    UPLOAD_TYPE_D_SPEED_QUIRK,     /**< LE910Cx, LE920A4 */
    UPLOAD_TYPE_E,                 /**< LE910-V2, LE940B6 */
    UPLOAD_TYPE_F,                 /**< ME910C1, ME910G1, ME310G1 */
    UPLOAD_TYPE_F_HW_FLOW_CONTROL, /**< ME910G1, ME310G1, enable HW flow control for speed > 115200 */
    UPLOAD_TYPE_G,                 /**< ME910G1, ME310G1 USB channel */
    UPLOAD_TYPE_UNKNOWN,
} upload_type_t;

/**
 * @brief mapping between #chipset_t, #boot_type_t, #upload_type_t and #usb_id_t values
 */
typedef struct {
    chipset_t chipset;
    channel_t channel;
    boot_type_t boot_type;
    /* if the chipset does not have a second boot phase, set the same type for
     * boot_type and boot_type_recovery */
    boot_type_t boot_type_recovery;
    upload_type_t upload_type;
} protocol_t;

/**
 * @brief Version info string for FN990
 */
typedef struct {
    char platform[4];
    int32_t platform_num;
    int32_t form_factor;
    int32_t major_version;
    int32_t solution_baseline;
    int32_t model;
    int32_t minor_pkg_version;
} version_info_fn990_t;

/**
 * @brief return the #chipset_t type according to the firmware version string
 *
 * @param[in] sw_version the firmware version string
 *
 * @return a #chipset_t value corresponding to the given version string
 */
chipset_t get_chipset_from_sw_version(const char *sw_version);

/**
 * @brief get a descriptive name for the given #chipset_t
 *
 * @param[in] chipset the #chipset_t
 *
 * @return a string with a the #chipset_t descriptive name, or NULL if #chipset_t does not match
 */
const char *get_chipset_name(const chipset_t chipset);

/**
 * @brief get a descriptive name for the given #channel_t
 *
 * @param[in] channel a #channel_t value
 *
 * @return a string with a the #channel_t descriptive name, or NULL if #channel_t does not match
 */
const char *get_channel_name(const channel_t channel);

/**
 * @brief get the #boot_type_t for the given #chipset_t
 *
 * @param[in] chipset the #chipset_t value
 * @param[in] channel the #channel_t value
 * @param[in] recovery true if the device is in already recovery mode, false otherwise
 *
 * @return the #boot_type_t value corresponding to #chipset_t and #channel_t or BOOT_TYPE_UNKNOWN if the pair does not match.
 */
boot_type_t get_boot_type_from_chipset(const chipset_t chipset, const channel_t channel, const bool recovery);

/**
 * @brief get #protocol_t given chipset and channel
 *
 * @param[in] chipset a #chipset_t
 * @param[in] channel a #channel_t
 * @param[out] protocol a #protocol_t corresponding to the given #chipset_t and #channel_t
 *
 * @return 0 in case of success or -22 in case of invalid #chipset_t
 */
core_res_t get_protocol_from_chipset(const chipset_t chipset, const channel_t channel, protocol_t *protocol);
/**
 * @brief get the #upload_type_t for the given #chipset_t
 *
 * @param[in] chipset the #chipset_t value
 * @param[in] channel the #channel_t value
 *
 * @return the #upload_type_t value corresponding to #chipset_t and #channel_t or UPLOAD_TYPE_UNKNOWN if the pair does not match.
 */
upload_type_t get_upload_type_from_chipset(const chipset_t chipset, const channel_t channel);


/**
 * @brief Return the list of USB ids (vendor id and product id pairs) for a given chipset
 *
 * @param[in] chipset the #chipset_t value
 * @param[in] is_recovery TRUE if the if the list of USB ids for modem in recovery mode is needed, FALSE otherwise
 * @param[out] usb_ids the returned #usb_id_list_t.
 *
 * @return CORE_SUCCESS in case of success, CORE_EINVAL in case of wrong input parameters, CORE_ERROR_NO_SUCH_DEVICE in case no USB id
 * for the chipset is found.
 */
core_res_t get_usb_ids_from_chipset(const chipset_t chipset, const bool is_recovery, usb_id_list_t **usb_ids);

/**
 * @brief get info from FN990 sw version string
 *
 * @param[in] sw_version the firmware version string
 * @param[out] info a #version_info_fn990_t containing the sw version info
 *
 * @return CORE_SUCCESS in case of success or CORE_ERROR_EINVAL in case of invalid sw_version
 */
core_res_t get_fn990_sw_version_info(const char *sw_version, version_info_fn990_t *info);

/**
 * @brief get info from FN990 modem version string
 *
 * @param[in] sw_version the modem version string
 * @param[out] info a #version_info_fn990_t containing the sw version info
 *
 * @return CORE_SUCCESS in case of success or CORE_ERROR_EINVAL in case of invalid sw_version
 */
core_res_t parse_fn990_modem_version(const char *sw_version, version_info_fn990_t *info);

const char *get_boot_type_name(boot_type_t type);
const char *get_upload_type_name(upload_type_t type);

bool has_second_phase_boot(const protocol_t *protocol);
#endif  /* _PROTOCOL_H_ */
