#include <assert.h>
#include <string.h>
#include <telit-os-abs.h>

#include "ttest.h"

#define ASSERT_INT_EQ(a, b) { \
            if (!( a == b )) { \
                TLOG("FAILED: %lu != %lu\n", a, b); \
                assert(( a == b )); \
            } \
} \

static void
test_print_help_empty_message(void)
{
    int i;
    const char *usage = NULL;
    const flag_t *flag = NULL;
    char expected[10][MAX_HELP_MSG_LINE] = {0};
    char help_message[10][MAX_HELP_MSG_LINE] = {0};

    compose_help_message(usage, flag, 0, help_message, 10);
    for (i = 0; i < 10; ++i) {
        CHECK_STR(expected[i], ==, help_message[i]);
    }
}

static void
test_print_help(void)
{
#define USAGE \
        "usage:\n\
        uxfp --help\n\
        uxfp --show-diag-ports\n\
        uxfp --file <path/to/stream/file>\n\
        uxfp --file <path/to/stream/file> --port <path/to/device> [--debug] [--lossrecovery] [--noprogress]\n\
        uxfp --file <path/to/stream/file> --port <path/to/device> --serial [--debug] [--lossrecovery] [--noprogress]\n\
        uxfp --file <path/to/stream/file> --port <path/to/device> --serial --speed <baudrate> [--debug] [--lossrecovery] [--noprogress]\n"

    int i;

    struct {
        char port[MAX_FLAG_VALUE_LEN];
        char file[MAX_FLAG_VALUE_LEN];
        uint32_t class;
        bool serial;
        uint64_t speed;
    } options = {0};

    flag_t flags [] = {
        {"--file", "-f", VALUE_TYPE_STRING, &options.file, REQ, "path to stream file"},
        {"--port", "-p", VALUE_TYPE_STRING, &options.port, OPT, "flashing port path (case sensitive)"},
        {"--serial", NULL, VALUE_TYPE_BOOLEAN, &options.serial, OPT,
         "the given port is a physical serial one (ignored if --port is not provided)"},
        {NULL, NULL, VALUE_TYPE_UNKNOWN, NULL, OPT, NULL},
    };
    char expected[5][MAX_HELP_MSG_LINE] = {
        USAGE,
        "options:",
        " -f or --file     <value> : path to stream file - required",
        " -p or --port     <value> : flashing port path (case sensitive) - optional",
        "       --serial           : the given port is a physical serial one (ignored if --port is not provided) - optional"
    };
    char help_message[5][MAX_HELP_MSG_LINE] = {0};

    compose_help_message(USAGE, flags, 3, help_message, 5);

    for (i = 0; i < 5; ++i) {
        CHECK_STR(expected[i], ==, help_message[i]);
    }
#undef USAGE
}

/* this function aims to test a branch of the get_opts function which is related to the argument '-h'.
 * In case of failure, the returned error by the function in this case is CORE_ERROR_TRY_AGAIN */
static void
test_print_help_argument_check_failure(void)
{
    core_res_t err;
    unsigned long int integer = 0;
    char *cli[] = {"uxfp", "-h"};

    flag_t flags [] = {
        {"--mandatory", NULL, VALUE_TYPE_STRING, &integer, REQ, NULL},
        {NULL, NULL, VALUE_TYPE_UNKNOWN, NULL, OPT, NULL},
    };

    err = get_opts(3, cli, flags);
    /* failure is expected */
    CHECK_TRUE(err == CORE_ERROR_TRY_AGAIN);
}

static void
test_print_truncated_help(void)
{
/* a short help_message array cannot contain the whole help message.
 * This test is the same as test_print_help, but the help_message output
 * is declared with 3 rows instead that the required 5 */
#define USAGE \
        "usage:\n\
        uxfp --help\n\
        uxfp --show-diag-ports\n\
        uxfp --file <path/to/stream/file>\n\
        uxfp --file <path/to/stream/file> --port <path/to/device> [--debug] [--lossrecovery] [--noprogress]\n\
        uxfp --file <path/to/stream/file> --port <path/to/device> --serial [--debug] [--lossrecovery] [--noprogress]\n\
        uxfp --file <path/to/stream/file> --port <path/to/device> --serial --speed <baudrate> [--debug] [--lossrecovery] [--noprogress]\n"

    int i;

    struct {
        char port[MAX_FLAG_VALUE_LEN];
        char file[MAX_FLAG_VALUE_LEN];
        uint32_t class;
        bool serial;
        uint64_t speed;
    } options = {0};

    flag_t flags [] = {
        {"--file", "-f", VALUE_TYPE_STRING, &options.file, REQ, "path to stream file"},
        {"--port", "-p", VALUE_TYPE_STRING, &options.port, OPT, "flashing port path (case sensitive)"},
        {"--serial", NULL, VALUE_TYPE_BOOLEAN, &options.serial, OPT,
         "the given port is a physical serial one (ignored if --port is not provided)"},
        {NULL, NULL, VALUE_TYPE_UNKNOWN, NULL, OPT, NULL},
    };
    char expected[5][MAX_HELP_MSG_LINE] = {
        USAGE,
        "options:",
        " -f or --file     <value> : path to stream file - required",
        {0}  /* expect the rows to be empty after the third one */
    };
    char help_message[5][MAX_HELP_MSG_LINE] = {0};

    /* NOTE: help_message_size == 3 */
    compose_help_message(USAGE, flags, 3, help_message, 3);

    for (i = 0; i < 5; ++i) {
        CHECK_STR(expected[i], ==, help_message[i]);
    }
#undef USAGE
}

static void
test_success_all_mandatory(void)
{
    int32_t err;

    char value_a[MAX_FLAG_VALUE_LEN] = {0};
    char value_b[MAX_FLAG_VALUE_LEN] = {0};

    char *cli[] = {"uxfp", "--mandatory-a", "A", "--mandatory-b", "B"};
    flag_t flags [] = {
        {"--mandatory-a", NULL, VALUE_TYPE_STRING, &value_a, REQ, NULL},
        {"--mandatory-b", NULL, VALUE_TYPE_STRING, &value_b, REQ, NULL},
        {NULL, NULL, VALUE_TYPE_UNKNOWN, NULL, OPT, NULL},
    };

    err = get_opts(5, cli, flags);
    CHECK_TRUE(!err);
}

static void
test_success_missing_non_mandatory(void)
{
    int32_t err;

    char mandatory[MAX_FLAG_VALUE_LEN] = {0};

    char *cli[] = {"uxfp", "--mandatory", "A"};
    flag_t flags [] = {
        {"--mandatory", NULL, VALUE_TYPE_STRING, &mandatory, REQ, NULL},
        {"--non-mandatory", NULL, VALUE_TYPE_STRING, NULL, OPT, NULL},
        {NULL, NULL, VALUE_TYPE_UNKNOWN, NULL, OPT, NULL},
    };

    err = get_opts(3, cli, flags);
    CHECK_TRUE(!err);
}

/* this routine is intended to test the conversion of the integer arguments passed that succeeds */
static void
test_success_integer(void)
{
#define NUM_TESTS 3
    int32_t err;
    unsigned long int integer = 0;

    flag_t flags [] = {
        {"--integer", NULL, VALUE_TYPE_ULONG, &integer, REQ, NULL},
        {NULL, NULL, VALUE_TYPE_UNKNOWN, NULL, OPT, NULL},
    };
    char *cli[NUM_TESTS][3] = {
        {"uxfp", "--integer", "115200"},
        {"uxfp", "--integer", "3000000000"},
        {"uxfp", "--integer", "2000000000"},
    };
    uint64_t exp_out[] = {115200, 3000000000, 2000000000, 0};

    for (int i = 0; i < NUM_TESTS; i++) {
        err = get_opts(3, cli[i], flags);
        CHECK_TRUE(!err);
        CHECK_LONG(integer, ==, exp_out[i]);
        integer = 0;
    }
#undef NUM_TESTS
}

/* this routine is intended to test the conversion of the integer arguments passed that fails */
static void
test_fail_integer_conversion(void)
{
#define NUM_TESTS 3
    int32_t err;
    unsigned long int integer = 0;

    flag_t flags [] = {
        {"--integer", NULL, VALUE_TYPE_ULONG, &integer, REQ, NULL},
        {NULL, NULL, VALUE_TYPE_UNKNOWN, NULL, OPT, NULL},
    };
    char *cli[NUM_TESTS][3] = {
        {"uxfp", "--integer", "abc115200"},
        {"uxfp", "--integer", "3000abc00000"},
        {"uxfp", "--integer", "abc"},  /* expected error -> value == 0 */
    };

    for (int i = 0; i < NUM_TESTS; i++) {
        err = get_opts(3, cli[i], flags);
        CHECK_TRUE(err == CORE_ERROR_EINVAL);
        integer = 0;
    }
#undef NUM_TESTS
}

/* this test is intended to test the code branch where an invalid, unknown type is found.
 * In this case, the expected error is CORE_ERROR_EINVAL */
static void
test_unknown_type_conversion(void)
{
    int32_t err;
    unsigned long int integer = 0;

    flag_t flags [] = {
        {"--unknown", NULL, VALUE_TYPE_UNKNOWN, &integer, REQ, NULL},
        {NULL, NULL, VALUE_TYPE_UNKNOWN, NULL, OPT, NULL},
    };
    char *cli[] = {"uxfp", "--unknown", "abc115200"};

    err = get_opts(3, cli, flags);
    CHECK_TRUE(err == CORE_ERROR_EINVAL);
}

static void
test_success_provided_boolean_is_true(void)
{
    int32_t err;

    char *generic[MAX_FLAG_VALUE_LEN] = {0};
    bool boolean = false;

    char *cli[] = {"uxfp", "--generic", "value", "--boolean"};
    flag_t flags [] = {
        {"--generic", NULL, VALUE_TYPE_STRING, &generic, OPT, NULL},
        {"--boolean", NULL, VALUE_TYPE_BOOLEAN, &boolean, OPT, NULL},
        {NULL, NULL, VALUE_TYPE_UNKNOWN, NULL, OPT, NULL},
    };

    err = get_opts(4, cli, flags);
    CHECK_TRUE(!err);
    CHECK_TRUE(boolean);
}

static void
test_success_not_provided_boolean_has_default_value(void)
{
    int32_t err;

    char *generic[MAX_FLAG_VALUE_LEN] = {0};
    bool boolean = false;

    char *cli[] = {"uxfp", "--generic", "value"};
    flag_t flags [] = {
        {"--generic", NULL, VALUE_TYPE_STRING, &generic, OPT, NULL},
        {"--boolean", NULL, VALUE_TYPE_BOOLEAN, &boolean, OPT, NULL},
        {NULL, NULL, VALUE_TYPE_UNKNOWN, NULL, OPT, NULL},
    };

    err = get_opts(3, cli, flags);
    CHECK_TRUE(!err);
    CHECK_FALSE(boolean);
}

static void
test_fail_missing_mandatory(void)
{
    int32_t err;

    char mandatory[MAX_FLAG_VALUE_LEN] = {0};
    char non_mandatory[MAX_FLAG_VALUE_LEN] = {0};

    char *cli[] = {"uxfp", "--non-mandatory", "B"};
    flag_t flags [] = {
        {"--mandatory", NULL, VALUE_TYPE_STRING, &mandatory, REQ, NULL},
        {"--non-mandatory", NULL, VALUE_TYPE_STRING, &non_mandatory, OPT, NULL},
        {NULL, NULL, VALUE_TYPE_UNKNOWN, NULL, OPT, NULL},
    };

    err = get_opts(3, cli, flags);
    /* failure is expected */
    CHECK_TRUE(err);
}

static void
test_fail_value_flag_followed_by_another_flag(void)
{
    int32_t err;

    char port[MAX_FLAG_VALUE_LEN] = {0};
    char file[MAX_FLAG_VALUE_LEN] = {0};

    char *cli[] = {"uxfp", "--port", "--file", "path-to-file"};
    flag_t flags [] = {
        {"--port", "-p", VALUE_TYPE_STRING, &port, REQ, "flashing port"},
        {"--file", "-f", VALUE_TYPE_STRING, &file, REQ, "path to stream file"},
        {NULL, NULL, VALUE_TYPE_UNKNOWN, NULL, OPT, NULL},
    };

    err = get_opts(3, cli, flags);
    /* failure is expected */
    CHECK_TRUE(err);
}

static void
test_fail_integer_value_expected(void)
{
    int32_t err;

    unsigned long int serial = 0;

    char *cli[] = {"uxfp", "--serial", "abc"};
    flag_t flags [] = {
        {"--integer", "-i", VALUE_TYPE_ULONG, &serial, REQ, "integer value"},
        {NULL, NULL, VALUE_TYPE_UNKNOWN, NULL, OPT, NULL},
    };

    err = get_opts(3, cli, flags);
    /* failure is expected */
    CHECK_TRUE(err);
}

static void
test_fail_value_flag_with_no_value(void)
{
    int32_t err;

    char port[MAX_FLAG_VALUE_LEN] = {0};

    char *cli[] = {"uxfp", "--port"};
    flag_t flags[] = {
        {"--port", "-p", VALUE_TYPE_STRING, &port, REQ, "flashing port"},
        {NULL, NULL, VALUE_TYPE_UNKNOWN, NULL, OPT, NULL},
    };

    err = get_opts(2, cli, flags);
    /* failure is expected */
    CHECK_TRUE(err);
}

static void
test_fail_invalid_flag_double_dash(void)
{
    int32_t err;
    char foo[MAX_FLAG_VALUE_LEN] = {0};
    char *cli[] = {"uxfp", "--", "value"};
    flag_t flags[] = {
        {"--foo", "-f", VALUE_TYPE_STRING, &foo, OPT, "negative test for invalid long name flag"},
        {NULL, NULL, VALUE_TYPE_UNKNOWN, NULL, OPT, NULL},
    };

    err = get_opts(3, cli, flags);
    /* failure is expected */
    CHECK_TRUE(err);
}

static void
test_fail_invalid_flag_long_name(void)
{
    int32_t err;
    char foo[MAX_FLAG_VALUE_LEN] = {0};
    char *cli[] = {"uxfp", "-foo", "value"};
    flag_t flags[] = {
        {"--foo", "-f", VALUE_TYPE_STRING, &foo, OPT, "negative test for invalid long name flag"},
        {NULL, NULL, VALUE_TYPE_UNKNOWN, NULL, OPT, NULL},
    };

    err = get_opts(3, cli, flags);
    /* failure is expected */
    CHECK_TRUE(err);
}

static void
test_fail_unknown_flag_long_name(void)
{
    int32_t err;
    char foo[MAX_FLAG_VALUE_LEN] = {0};
    flag_t flags[] = {
        {"--foo", "-f", VALUE_TYPE_STRING, &foo, OPT, "negative test for invalid long name flag"},
        {NULL, NULL, VALUE_TYPE_UNKNOWN, NULL, OPT, NULL},
    };
    char *cli[] = {"uxfp", "--adifferentflag", "value"};

    err = get_opts(3, cli, flags);
    /* failure is expected */
    CHECK_TRUE(err);
}

static void
test_fail_unknown_flag_short_name(void)
{
    int32_t err;
    char foo[MAX_FLAG_VALUE_LEN] = {0};
    flag_t flags[] = {
        {"--foo", "-f", VALUE_TYPE_STRING, &foo, OPT, "negative test for invalid long name flag"},
        {NULL, NULL, VALUE_TYPE_UNKNOWN, NULL, OPT, NULL},
    };
    char *cli[] = {"uxfp", "-a", "value"};

    err = get_opts(3, cli, flags);
    /* failure is expected */
    CHECK_TRUE(err);
}


int main(int argc, char *argv[])
{
    TTEST_INIT(argc, argv);
    core_log_set_pprint(CORE_LOG_PPRINT_AUTONEWLINE);

    RUN(test_print_help_empty_message);
    RUN(test_print_truncated_help);
    RUN(test_print_help);
    RUN(test_print_help_argument_check_failure);

    RUN(test_success_all_mandatory);
    RUN(test_success_missing_non_mandatory);
    RUN(test_success_integer);
    RUN(test_fail_integer_conversion);
    RUN(test_unknown_type_conversion);
    RUN(test_success_provided_boolean_is_true);
    RUN(test_success_not_provided_boolean_has_default_value);

    RUN(test_fail_missing_mandatory);
    RUN(test_fail_value_flag_with_no_value);
    RUN(test_fail_value_flag_followed_by_another_flag);
    RUN(test_fail_integer_value_expected);

    RUN(test_fail_invalid_flag_double_dash);
    RUN(test_fail_invalid_flag_long_name);

    RUN(test_fail_unknown_flag_long_name);
    RUN(test_fail_unknown_flag_short_name);

    return 0;
}
