#include <assert.h>
#include <string.h>
#include "ttest.h"

#include <telit-os-abs.h>

#define ONE_SECOND 1 * 1000

static usb_id_list_t device_list = {0};

static void test_event_listener(void);
static void test_endless_event_listener(void);

int main(int argc, char *argv[])
{
    core_res_t err = CORE_ERROR_EINVAL;

    if (argc < 3) {
        ALOGI("usage: test_event_listener <vid> <pid>\n");
        return err;
    }

    core_log_set_level(LOG_LEVEL_INFO);

    /* Listen for events from VID and PID passed as inputs */
    core_usb_id_from_str(&device_list.items[0], argv[1], argv[2]);
    device_list.len = 1;

    err = core_init();
    if (err) {
        ALOGE("could not initialize core library\n");
        goto end;
    }

    TTEST_INIT(argc, argv);
    RUN(test_event_listener);
    core_sleep(1 * ONE_SECOND);
    RUN(test_endless_event_listener);

end:
    return err;
}

static void test_event_listener()
{
    core_res_t err;
    int32_t timeout = 30;
    usb_id_t event = {0};

    TLOG("%s: wait %d seconds for a device attach\n", __FUNCTION__, timeout);

    err = core_device_usb_id_event_listener(core_usb_id_find_match,
            &device_list, timeout * 1000, &event); CHECK_FALSE(err);
    if (!err) {
        TLOG("recognized USB attach of device %04X:%04X\n",
                event.vid, event.pid);
        TLOG("SUCCESS\n");
    }
}

static void test_endless_event_listener()
{
    core_res_t err;
    usb_id_t event = {0};

    TLOG("%s: wait endlessy for a device attach (CTRL-C to stop)\n", __FUNCTION__);

    err = core_device_usb_id_event_listener(core_usb_id_find_match,
            &device_list, TIMEOUT_INFINITE, &event);
    CHECK_FALSE(err);
    if (!err) {
        TLOG("recognized USB attach of device %04X:%04X\n",
                event.vid, event.pid);
        TLOG("SUCCESS\n");
    }
}
