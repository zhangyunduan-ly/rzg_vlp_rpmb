#include <telit-os-abs.h>

#include "ttest.h"

void test_usb_id_from_str(void);
void test_usb_id_is_null(void);
void test_usb_id_equals(void);
static void test_usb_id_find_match(void);
static void test_usb_id_wait_for_devices(void);

int main(int argc, char *argv[])
{
    TTEST_INIT(argc, argv);

    RUN(test_usb_id_from_str);
    RUN(test_usb_id_is_null);
    RUN(test_usb_id_equals);
    RUN(test_usb_id_find_match);
    RUN(test_usb_id_wait_for_devices);
    return 0;
}

void test_usb_id_from_str(void)
{
    char test_vid[4][5] = {
        "1BC7", "1bc7", "041c", "42cc"
    };
    char test_pid[4][5] = {
        "1201", "1201", "0032", "1234"
    };
    uint32_t exp_vid[] = {
        0x1bc7, 0x1bc7, 0x041c, 0x42cc
    };
    uint32_t exp_pid[] = {
        0x1201, 0x1201, 0x0032, 0x1234
    };

    for (int i = 0; i < 3; i++) {
        bool res;
        usb_id_t usb_id = {0};
        res = core_usb_id_from_str(&usb_id, test_vid[i], test_pid[i]);
        CHECK_TRUE(res);
        CHECK_NUM(usb_id.vid, ==, exp_vid[i]);
        CHECK_NUM(usb_id.pid, ==, exp_pid[i]);
    }
}

void test_usb_id_is_null(void)
{
    usb_id_t usb_id = {0};

    CHECK_TRUE(core_usb_id_is_null(&usb_id));

    CHECK_TRUE(core_usb_id_from_str(&usb_id, "1bc7", "0032"));
    CHECK_FALSE(core_usb_id_is_null(&usb_id));
}

void test_usb_id_equals(void)
{
    usb_id_t left = {0};
    usb_id_t right = {0};

    /* initially are both null */
    CHECK_TRUE(core_usb_id_equals(&left, &right));

    /* equals when not null */
    CHECK_TRUE(core_usb_id_from_str(&left, "1bc7", "0032"));
    CHECK_TRUE(core_usb_id_from_str(&right, "1bc7", "0032"));
    CHECK_TRUE(core_usb_id_equals(&left, &right));

    /* different vid */
    CHECK_TRUE(core_usb_id_from_str(&right, "1bc6", "0031"));
    CHECK_FALSE(core_usb_id_equals(&left, &right));

    /* different pid */
    CHECK_TRUE(core_usb_id_from_str(&right, "1bc7", "0031"));
    CHECK_FALSE(core_usb_id_equals(&left, &right));

    /* missing vid */
    CHECK_FALSE(core_usb_id_from_str(&right, "", "0031"));

    /* missing pid */
    CHECK_FALSE(core_usb_id_from_str(&right, "1bc7", ""));

    /* invalid vid */
    CHECK_FALSE(core_usb_id_from_str(&right, "1zfg", "0031"));

    /* invalid pid */
    CHECK_FALSE(core_usb_id_from_str(&right, "1bc7", "5k43"));
}

static void test_usb_id_find_match(void)
{
    dev_info_t devinfo = {0};
    usb_id_list_t usb_id_list = {2, {{0x18d1, 0xd00d}, {0x1bc7, 0x8905}}};

    /* testing core_usb_id_find_match successful */
    strlcpy(devinfo.vendor_id, "1bc7", sizeof(devinfo.vendor_id));
    strlcpy(devinfo.product_id, "8905", sizeof(devinfo.product_id));
    CHECK_TRUE(core_usb_id_find_match(&devinfo, &usb_id_list));

    /* testing core_usb_id_find_match failing because invalid */
    strlcpy(devinfo.vendor_id, "1zfg", sizeof(devinfo.vendor_id));
    CHECK_FALSE(core_usb_id_find_match(&devinfo, &usb_id_list));
}

/* this test is aimed to call the core_usb_id_wait_for_devices with a list of invalid vid/pids and to exit
 * for timeout. The list is full of invalid names to avoid failing this test as soon as a valid modem is
 * connected */
static void
test_usb_id_wait_for_devices(void)
{
#define TEN_SECONDS_IN_MS 10000
    /* list of invalid vid/pids */
    usb_id_list_t expected[] = {
        { 1, {{0xf58f, 0xf0f1}} },
        { 1, {{0xf58f, 0xf0f1}} },
        { 1, {{0xf08f, 0xf7f6}} },
        { 2, {{0xfcbf, 0xf2f1}, {0xfcbf, 0xf2f3}}},
        { 3, {{0xfcbf, 0xf0f0}, {0xfcbf, 0xf0f1}, {0xfcbf, 0xf0f2}}},
        { 2, {{0xfcbf, 0xf1fa}, {0xfcbf, 0xf1fb}} },
    };
    usb_id_list_t *usbids = expected;

    dev_info_t dev_info_list[5] = {0};
    core_res_t err;

    err = core_usb_id_wait_for_devices(usbids, dev_info_list, TEN_SECONDS_IN_MS);
    CHECK_TRUE(err == CORE_ERROR_TIMEOUT);
#undef TEN_SECONDS_IN_MS
}
