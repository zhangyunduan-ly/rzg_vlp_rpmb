#ifndef _VERSION_H_
#define _VERSION_H_

#define MAJOR "1"
#define MINOR "15"
#define PATCH "6"
#define CUST  "0"

#endif  /* _VERSION_H_ */
