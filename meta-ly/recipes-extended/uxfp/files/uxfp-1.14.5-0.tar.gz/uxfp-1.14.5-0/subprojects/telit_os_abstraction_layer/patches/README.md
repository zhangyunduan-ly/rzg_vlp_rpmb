- 0001-Replace-timespec_get-with-clock_gettime.patch
  This patch is intended for systems that do not have `timespec_get`, which is replaced by `clock_gettime`.
