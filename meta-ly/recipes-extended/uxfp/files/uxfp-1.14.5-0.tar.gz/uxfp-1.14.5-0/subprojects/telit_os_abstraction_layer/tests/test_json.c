#include <telit-os-abs.h>
#include "ttest.h"

extern int32_t json_compose(json_t *entries, char *json, const int32_t json_len);

void test_json_msg(void);
void test_json_msg_update_message(void);
void test_json_msg_not_enough_space_for_final_string(void);
void test_json_update(void);
void test_json_array(void);
void test_json_nested_arrays(void);

int main(int argc, char *argv[])
{
    TTEST_INIT(argc, argv);
    RUN(test_json_msg);
    RUN(test_json_msg_update_message);
    RUN(test_json_msg_not_enough_space_for_final_string);
    RUN(test_json_update);
    RUN(test_json_array);
    RUN(test_json_nested_arrays);
    return 0;
}

void test_json_array(void)
{
#define NUMBER_OF_ARRAY_ENTRIES 3
    char *expected_msg_json =
            "\"key1\": \"type\", \"key2\": [{\"item00\": \"one\", \"item01\": \"two\"},{\"item10\": \"three\", \"item11\": \"four\"},{\"item20\": \"five\", \"item21\": \"six\"}]";
    int32_t expected_msg_len = strlen(expected_msg_json);
    char *msg_json;
    int32_t len;

    enum { KEY1, KEY2, KEY3, KEY_LAST };

    struct {
        char message1[MAX_JSON_MESSAGE_LEN];
        json_t *message2[NUMBER_OF_ARRAY_ENTRIES];
        uint8_t message3;
    } values = {0};

    json_t entries[] = {
        [KEY1] = {"key1", values.message1, VALUE_TYPE_STRING},
        [KEY2] = {"key2", values.message2, VALUE_TYPE_ARRAY},
        [KEY3] = {"key3", &values.message3, VALUE_TYPE_ARRAY_SIZE},
        [KEY_LAST] = {NULL, NULL, VALUE_TYPE_UNKNOWN},
    };

    struct _array_item {
        char array_element1[10];
        char array_element2[10];
    };

    struct _array_item array_values[NUMBER_OF_ARRAY_ENTRIES] =
    { {"one", "two"}, {"three", "four"}, {"five", "six"} };
    json_t array_entries[NUMBER_OF_ARRAY_ENTRIES][3];

    array_entries[0][0].key = "item00";
    array_entries[0][0].type = VALUE_TYPE_STRING;
    array_entries[0][0].value = array_values[0].array_element1;
    array_entries[0][1].key = "item01";
    array_entries[0][1].type = VALUE_TYPE_STRING;
    array_entries[0][1].value = array_values[0].array_element2;
    array_entries[0][2].key = NULL;
    array_entries[0][2].type = VALUE_TYPE_UNKNOWN;
    array_entries[0][2].value = NULL;
    array_entries[1][0].key = "item10";
    array_entries[1][0].type = VALUE_TYPE_STRING;
    array_entries[1][0].value = array_values[1].array_element1;
    array_entries[1][1].key = "item11";
    array_entries[1][1].type = VALUE_TYPE_STRING;
    array_entries[1][1].value = array_values[1].array_element2;
    array_entries[1][2].key = NULL;
    array_entries[1][2].type = VALUE_TYPE_UNKNOWN;
    array_entries[1][2].value = NULL;
    array_entries[2][0].key = "item20";
    array_entries[2][0].type = VALUE_TYPE_STRING;
    array_entries[2][0].value = array_values[2].array_element1;
    array_entries[2][1].key = "item21";
    array_entries[2][1].type = VALUE_TYPE_STRING;
    array_entries[2][1].value = array_values[2].array_element2;
    array_entries[2][2].key = NULL;
    array_entries[2][2].type = VALUE_TYPE_UNKNOWN;
    array_entries[2][2].value = NULL;

    strcpy(values.message1, "type");
    values.message2[0] = array_entries[0];
    values.message2[1] = array_entries[1];
    values.message2[2] = array_entries[2];
    values.message3 = NUMBER_OF_ARRAY_ENTRIES;

    len = 512;
    msg_json = (char *)alloca(len);
    memset(msg_json, '\0', len);

    len = json_compose(entries, msg_json, len);
    CHECK_NUM(len, ==, expected_msg_len);
    CHECK_STR(msg_json, ==, expected_msg_json);
#undef NUMBER_OF_ARRAY_ENTRIES
}

void test_json_nested_arrays(void)
{
#define NUMBER_OF_ARRAY1_ENTRIES 2
#define NUMBER_OF_ARRAY2_ENTRIES 2
    char *expected_msg_json =
            "\"key1\": \"type\", \"key2\": [{\"key1_arr1\": \"value0\", \"key2_arr1\": [{\"key1_arr2\": \"value00\"},{\"key1_arr2\": \"value01\"}]},{\"key1_arr1\": \"value1\", \"key2_arr1\": [{\"key1_arr2\": \"value10\"},{\"key1_arr2\": \"value11\"}]}]";
    int32_t expected_msg_len = strlen(expected_msg_json);
    char *msg_json;
    int32_t len;
    int i;

    enum { KEY1, KEY2, KEY3, KEY_LAST };

    struct {
        char message1[MAX_JSON_MESSAGE_LEN];
        json_t *message2[NUMBER_OF_ARRAY1_ENTRIES];
        uint8_t message3;
    } values_1 = {0};

    struct _values_2 {
        char message1[MAX_JSON_MESSAGE_LEN];
        json_t *message2[NUMBER_OF_ARRAY2_ENTRIES];
        uint8_t message3;
    };

    struct _values_3 {
        char message1[MAX_JSON_MESSAGE_LEN];
    };

    struct _values_2 values_2[NUMBER_OF_ARRAY1_ENTRIES] = {0};
    struct _values_3 values_3[NUMBER_OF_ARRAY1_ENTRIES][NUMBER_OF_ARRAY2_ENTRIES] = {0};

    json_t arr1_entries[NUMBER_OF_ARRAY1_ENTRIES][4];
    json_t arr2_entries[NUMBER_OF_ARRAY1_ENTRIES][NUMBER_OF_ARRAY2_ENTRIES][2];

    json_t values_1_entries[] = {
        [KEY1] = {"key1", values_1.message1, VALUE_TYPE_STRING },
        [KEY2] = {"key2", values_1.message2, VALUE_TYPE_ARRAY},
        [KEY3] = {"key3", &values_1.message3, VALUE_TYPE_ARRAY_SIZE},
        [KEY_LAST] = {NULL, NULL, VALUE_TYPE_UNKNOWN},
    };

    for (i = 0; i < NUMBER_OF_ARRAY1_ENTRIES; i++) {
        int j;

        arr1_entries[i][KEY1].key = "key1_arr1";
        arr1_entries[i][KEY1].value = values_2[i].message1;
        sprintf(values_2[i].message1, "value%d", i);
        arr1_entries[i][KEY1].type = VALUE_TYPE_STRING;
        arr1_entries[i][KEY2].key = "key2_arr1";
        arr1_entries[i][KEY2].value = values_2[i].message2;
        arr1_entries[i][KEY2].type = VALUE_TYPE_ARRAY;
        arr1_entries[i][KEY3].key = "key3_arr1";
        arr1_entries[i][KEY3].value = &values_2[i].message3;
        values_2[i].message3 = NUMBER_OF_ARRAY2_ENTRIES;
        arr1_entries[i][KEY3].type = VALUE_TYPE_ARRAY_SIZE;
        arr1_entries[i][KEY_LAST].key = NULL;
        arr1_entries[i][KEY_LAST].value = NULL;
        arr1_entries[i][KEY_LAST].type = VALUE_TYPE_UNKNOWN;

        for (j = 0; j < NUMBER_OF_ARRAY2_ENTRIES; j++) {
            arr2_entries[i][j][KEY1].key = "key1_arr2";
            arr2_entries[i][j][KEY1].value = values_3[i][j].message1;
            sprintf(values_3[i][j].message1, "value%d%d", i, j);
            arr2_entries[i][j][KEY1].type = VALUE_TYPE_STRING;
            arr2_entries[i][j][KEY2].key = NULL;
            arr2_entries[i][j][KEY2].value = NULL;
            arr2_entries[i][j][KEY2].type = VALUE_TYPE_UNKNOWN;

            values_2[i].message2[j] = arr2_entries[i][j];
        }

        values_1.message2[i] = arr1_entries[i];
    }

    strcpy(values_1.message1, "type");
    values_1.message3 = NUMBER_OF_ARRAY1_ENTRIES;

    len = 512;
    msg_json = (char *)alloca(len);
    memset(msg_json, '\0', len);

    len = json_compose(values_1_entries, msg_json, len);
    CHECK_NUM(len, ==, expected_msg_len);
    CHECK_STR(msg_json, ==, expected_msg_json);
#undef NUMBER_OF_ARRAY1_ENTRIES
#undef NUMBER_OF_ARRAY2_ENTRIES
}

void test_json_update(void)
{
    enum { KSTR, KBOOL, KINT, KINT64, KUINT64, KEY_LAST };
    struct {
        char string[MAX_JSON_ENTRY_LEN];
        bool boolean;
        int32_t integer;
        int64_t ilong;
        uint64_t ulong;
    } values;

    json_t entries [] = {
        [KSTR] = {"string", (void *)values.string, VALUE_TYPE_STRING},
        [KBOOL] = {"boolean", &values.boolean, VALUE_TYPE_BOOLEAN},
        [KINT] = {"int", &values.integer, VALUE_TYPE_INT},
        [KINT64] = {"long", &values.ilong, VALUE_TYPE_LONG},
        [KUINT64] = {"ulong", &values.ulong, VALUE_TYPE_ULONG},
        [KEY_LAST] = {NULL, NULL, VALUE_TYPE_UNKNOWN},
    };
    bool ok, bvalue = true;
    int32_t i32 = 10;
    int64_t i64 = 65536;
    uint64_t u64 = 65536;
    int32_t len;
    int32_t expected_msg_len = 85;
    char *msg_json;
    char *expected_msg_json =
            "\"string\": \"string message\", \"boolean\": true, \"int\": 10, \"long\": 65536, \"ulong\": 65536";

    len = MAX_JSON_ENTRY_LEN * ARRAY_SIZE(entries);
    msg_json = (char *)alloca(len);

    ok = json_update(entries, KSTR, "string message", VALUE_TYPE_STRING);
    CHECK_TRUE(ok);
    ok = json_update(entries, KBOOL, &bvalue, VALUE_TYPE_BOOLEAN);
    CHECK_TRUE(ok);
    ok = json_update(entries, KINT, &i32, VALUE_TYPE_INT);
    CHECK_TRUE(ok);
    ok = json_update(entries, KINT64, &i64, VALUE_TYPE_LONG);
    CHECK_TRUE(ok);
    ok = json_update(entries, KUINT64, &u64, VALUE_TYPE_ULONG);
    CHECK_TRUE(ok);

    len = json_compose(entries, msg_json, len);
    CHECK_NUM(len, ==, expected_msg_len);
    CHECK_STR(msg_json, ==, expected_msg_json);
}

void test_json_msg_not_enough_space_for_final_string(void)
{
    enum { KEY1, KEY2, KEY3, KEY_LAST };

    struct {
        char message1[MAX_JSON_MESSAGE_LEN];
        char message2[MAX_JSON_MESSAGE_LEN];
        char message3[MAX_JSON_MESSAGE_LEN];
    } values = {0};

    json_t entries[] = {
        [KEY1] = {"key1", values.message1, VALUE_TYPE_STRING},
        [KEY2] = {"key2", values.message2, VALUE_TYPE_STRING},
        [KEY3] = {"key3", values.message3, VALUE_TYPE_STRING},
        [KEY_LAST] = {NULL, NULL, VALUE_TYPE_UNKNOWN},
    };
    bool ok;
    char *expected_msg_json = "\"key1\": \"message for key1\", \"key2\": null, \"key3\": null";
    int32_t expected_msg_len = 54;
    char *msg_json;
    int32_t len;
    int32_t limited_allocation = 10;

    msg_json = (char *)alloca(limited_allocation);

    ok = json_update(entries, KEY1, "message for key1", VALUE_TYPE_STRING);
    CHECK_TRUE(ok);

    len = json_compose(entries, msg_json, limited_allocation);
    /* output len is still correct, because it outputs the required
     * msg_json len, but the message is expected to be truncated */
    CHECK_NUM(len, ==, expected_msg_len);
    CHECK_NUM(len, !=, limited_allocation);
    CHECK_STR(msg_json, !=, expected_msg_json);
}

void test_json_msg(void)
{
    enum { KEY1, KEY2, KEY3, KEY_LAST };

    struct {
        char message1[MAX_JSON_MESSAGE_LEN];
        char message2[MAX_JSON_MESSAGE_LEN];
        char message3[MAX_JSON_MESSAGE_LEN];
    } values = {0};

    json_t entries[] = {
        [KEY1] = {"key1", values.message1, VALUE_TYPE_STRING},
        [KEY2] = {"key2", values.message2, VALUE_TYPE_STRING},
        [KEY3] = {"key3", values.message3, VALUE_TYPE_STRING},
        [KEY_LAST] = {NULL, NULL, VALUE_TYPE_UNKNOWN},
    };
    bool ok;
    char *expected_msg_json = "\"key1\": \"message for key1\", \"key2\": null, \"key3\": null";
    int32_t expected_msg_len = 54;
    char *msg_json;
    int32_t len;

    len = MAX_JSON_ENTRY_LEN * sizeof(entries) / sizeof(json_t);
    msg_json = (char *)alloca(len);

    ok = json_update(entries, KEY1, "message for key1", VALUE_TYPE_STRING);
    CHECK_TRUE(ok);

    len = json_compose(entries, msg_json, len);
    CHECK_NUM(len, ==, expected_msg_len);
    CHECK_STR(msg_json, ==, expected_msg_json);
}

void test_json_msg_update_message(void)
{
    enum { KEY1, KEY2, KEY3, KEY_LAST };

    struct {
        char message1[MAX_JSON_MESSAGE_LEN];
        char message2[MAX_JSON_MESSAGE_LEN];
        char message3[MAX_JSON_MESSAGE_LEN];
    } values = {0};

    json_t entries[] = {
        [KEY1] = {"key1", values.message1, VALUE_TYPE_STRING},
        [KEY2] = {"key2", values.message2, VALUE_TYPE_STRING},
        [KEY3] = {"key3", values.message3, VALUE_TYPE_STRING},
        [KEY_LAST] = {NULL, NULL, VALUE_TYPE_UNKNOWN},
    };
    bool ok;
    char *expected_msg_json_first = "\"key1\": \"message for key1\", \"key2\": null, \"key3\": null";
    int32_t expected_msg_len_first = 54;
    char *expected_msg_json_later = "\"key1\": \"new message for key1\", \"key2\": null, \"key3\": null";
    int32_t expected_msg_len_later = 58;
    char *msg_json;
    int32_t len, req_len1, req_len2;

    len = MAX_JSON_ENTRY_LEN * sizeof(entries) / sizeof(json_t);
    msg_json = (char *)alloca(len);

    ok = json_update(entries, KEY1, "message for key1", VALUE_TYPE_STRING);
    CHECK_TRUE(ok);

    req_len1 = json_compose(entries, msg_json, len);
    CHECK_NUM(req_len1, ==, expected_msg_len_first);
    CHECK_STR(msg_json, ==, expected_msg_json_first);

    /* update KEY1 message */
    ok = json_update(entries, KEY1, "new message for key1", VALUE_TYPE_STRING);
    CHECK_TRUE(ok);

    req_len2 = json_compose(entries, msg_json, len);
    CHECK_NUM(req_len2, ==, expected_msg_len_later);
    CHECK_STR(msg_json, ==, expected_msg_json_later);
}
