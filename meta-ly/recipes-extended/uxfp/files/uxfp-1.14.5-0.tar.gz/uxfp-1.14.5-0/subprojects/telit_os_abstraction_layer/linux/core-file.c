#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>

#include <telit-os-abs.h>


static int32_t core_file_lseek(file_handle_t handle, int64_t offset, int32_t origin);


core_res_t core_file_exists(const char *file_path)
{
    int ret = CORE_ERROR_EINVAL;

    if (!file_path) {
        return ret;
    }

    errno = 0;
    ret = access(file_path, F_OK);
    if (ret) {
        ALOGD("access to '%s' returned %d, errno (%d) %s\n",
                file_path, ret, errno, strerror(errno));
    }

    return (ret == 0) ? CORE_SUCCESS : CORE_ERROR_FILE_NOT_FOUND;
}

core_res_t core_file_open(const char *file_path, file_handle_t *handle)
{
    core_res_t err = CORE_SUCCESS;

    errno = 0;
    *handle = open(file_path, O_RDWR | O_NONBLOCK | O_CREAT, 0644);
    if (errno) {
        int error = errno;
        ALOGE("error %d %s opening file '%s'\n", error, strerror(error), file_path);
        err = map_errno_to_core_err(error);
    }

    return err;
}

core_res_t core_file_close(const file_handle_t handle)
{
    return core_device_close((dev_handle_t)handle);
}

#pragma weak core_file_read
core_res_t core_file_read(const file_handle_t handle, void *buffer, uint32_t bytes_to_read,
        uint32_t *bytes_read)
{
    return core_device_read((dev_handle_t) handle, buffer, bytes_to_read, bytes_read);
}

core_res_t core_file_write(const file_handle_t handle, const void *buffer, uint32_t bytes_to_write,
        uint32_t *bytes_written)
{
    return core_device_write((dev_handle_t) handle, buffer, bytes_to_write, bytes_written);
}

#pragma weak core_file_lseek_set
core_res_t core_file_lseek_set(file_handle_t handle, int64_t offset)
{
    return (core_file_lseek(handle, offset, SEEK_SET) ?
           CORE_ERROR_UNKNOWN : CORE_SUCCESS);
}

#pragma weak core_file_get_size
core_res_t core_file_get_size(const file_handle_t handle, uint64_t *size)
{
    core_res_t ret = CORE_SUCCESS;
    struct stat file;

    if (fstat(handle, &file)) {
        int err = errno;

        ALOGE("could not get file size: error %d %s\n", err, strerror(err));
        ret = map_errno_to_core_err(err);
    } else {
        *size = (uint64_t)file.st_size;
    }

    return ret;
}

static int32_t
core_file_lseek(file_handle_t handle, int64_t offset, int32_t origin)
{
    int32_t err = -1;
    off_t off;

    off = lseek(handle, offset, origin);
    if (off == -1) {
        ALOGE("lseek error: %d\n", errno);
        goto end;
    }

    if (off != offset) {
        ALOGE("lseek returned offset different than expected\n");
        goto end;
    }

    err = 0;

end:
    return err;
}

core_res_t core_create_directory(const char *path)
{
    return mkdir(path, 755);
}

core_res_t core_directory_exists(const char *path)
{
    int ret = CORE_ERROR_EINVAL;

    if (!path) {
        return ret;
    }

    DIR *dir = opendir(path);

    if (dir) {
        ret = CORE_SUCCESS;
        closedir(dir);
    } else if (ENOENT == errno) {
        ret = CORE_ERROR_FILE_NOT_FOUND;
    } else {
        ALOGE("opendir() failed: %d\n", errno);
    }

    return ret;
}

