set libs=..\windows\telit-os-abs.lib

for %%s in (*.c) do (
    echo "--- making test: %%~ns ---"
    cl -I. -I..\ -I..\windows -Fo%%~ns.obj -FS -c %%~ns.c
    link -nologo -out:%%~ns.exe ^
        Winusb.lib setupapi.lib advapi32.lib %libs% ^
        %%~ns.obj
)

del *.obj
