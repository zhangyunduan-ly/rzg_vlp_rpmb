#pragma comment(lib, "Ws2_32.lib")
#include <signal.h>

#include <telit-os-abs.h>

/* 1-millisecond target resolution */
#define TARGET_RESOLUTION 1

static WSADATA wsa_data;
extern bool is_log_native_enabled;
static UINT wTimerRes = 0;

sig_atomic_t sigint_detected = 0;

core_res_t map_get_last_error_to_core_err(DWORD err)
{
    core_res_t ret;

    switch (err) {
        default:
            ret = CORE_ERROR_UNKNOWN;
    }

    return ret;
}

core_res_t map_errno_to_core_err(int err)
{
    core_res_t ret;

    switch (err) {
        case EPERM:
            ret = CORE_ERROR_OPERATION_NOT_PERMITTED;
            break;
        case ENOENT:
            ret = CORE_ERROR_FILE_NOT_FOUND;
            break;
        case EINTR:
            ret = CORE_ERROR_EINTR;
            break;
        case EIO:
            ret = CORE_ERROR_IO_ERROR;
            break;
        case EAGAIN:
            ret = CORE_ERROR_TRY_AGAIN;
            break;
        case EACCES:
            ret = CORE_ERROR_PERMISSION_DENIED;
            break;
        case EBUSY:
            ret = CORE_ERROR_DEVICE_BUSY;
            break;
        case ENODEV:
            ret = CORE_ERROR_NO_SUCH_DEVICE;
            break;
        case EINVAL:
            ret = CORE_ERROR_EINVAL;
            break;
        case ETIMEDOUT:
            ret = CORE_ERROR_TIMEOUT;
            break;
        case ENOSPC:
            ret = CORE_ERROR_ENOSPC;
            break;
        default:
            ret = CORE_ERROR_UNKNOWN;
    }

    return ret;
}

core_res_t core_init(void)
{
    int32_t ret;
    MMRESULT mmr;
    TIMECAPS tc;

    ret = WSAStartup(MAKEWORD(2, 2), &wsa_data);
    if (ret != 0) {
        ALOGE("could not initialize wsa: %d\n", GetLastError());
        ret = -1;
    }

    /* configure timer resolution, not blocking error even though
     * the applications could not behave properly */
    mmr = timeGetDevCaps(&tc, sizeof(tc));
    if (mmr != MMSYSERR_NOERROR) {
        ALOGE("could not get time capabilities: error %d\n", mmr);
    } else {
        wTimerRes = min(max(tc.wPeriodMin, TARGET_RESOLUTION), tc.wPeriodMax);
        ALOGD("Timer resolution %u\n", wTimerRes);
        mmr = timeBeginPeriod(wTimerRes);
        if (mmr != MMSYSERR_NOERROR) {
            ALOGE("could not set time period: error %d\n", mmr);
        }
    }

    return (ret ? CORE_ERROR_UNKNOWN : CORE_SUCCESS);
}

void core_deinit(void)
{
    timeEndPeriod(wTimerRes);
    WSACleanup();
    core_log_deinit();
}

void core_sleep(const uint32_t timeout_ms)
{
    /* more precise, but it uses CPU, so it is used only
     * for short sleep intervals */
    if (timeout_ms < 300) {
        core_timeval_t tv_start;

        core_get_time_of_day(&tv_start);

        do {
            core_timeval_t tv_end;

            core_get_time_of_day(&tv_end);
            if ((tv_end.tv_sec * (int)1e6 + tv_end.tv_usec) -
                    (tv_start.tv_sec * (int)1e6 + tv_start.tv_usec) >= timeout_ms * 1000) {
                break;
            }

            Sleep(0);
        } while (true);

    } else {
        /* less precise, but no CPU usage */
        TIMECAPS tmc;
        MMRESULT mmr;

        /* configure sleep interval time */
        mmr = timeGetDevCaps(&tmc, sizeof(tmc));
        if (mmr != MMSYSERR_NOERROR) {
            ALOGE("could not get time capabilities: error %d\n", mmr);
        } else {
            mmr = timeBeginPeriod(tmc.wPeriodMin);
            if (mmr != MMSYSERR_NOERROR) {
                ALOGE("could not set time period: error %d\n", mmr);
            }
        }

        /* call Sleep even if the timer period has not been set */
        Sleep(timeout_ms);

        if (mmr == MMSYSERR_NOERROR) {
            mmr = timeEndPeriod(tmc.wPeriodMin);
            if (mmr != MMSYSERR_NOERROR) {
                ALOGE("could not reset time period: error %d\n", mmr);
            }
        }
    }
}

void core_signal_notify(const int sig)
{
    switch (sig) {
        case SIGINT:
            sigint_detected = 1;
            break;
    }
}

core_res_t core_get_time_of_day(core_timeval_t *tv)
{
    static const uint64_t EPOCH = ((uint64_t) 116444736000000000ULL);

    SYSTEMTIME system_time;
    FILETIME file_time;
    uint64_t time;

    GetSystemTime( &system_time );
    SystemTimeToFileTime( &system_time, &file_time );
    time =  ((uint64_t)file_time.dwLowDateTime );
    time += ((uint64_t)file_time.dwHighDateTime) << 32;

    tv->tv_sec = (uint32_t) ((time - EPOCH) / 10000000L);
    tv->tv_usec = (uint32_t) (system_time.wMilliseconds * 1000);

    return CORE_SUCCESS;
}

static void _core_xetoh(void *dest, size_t dest_size, void *src, size_t src_size)
{
    /* Windows PCs are always little endian so no conversion needed */
    switch (dest_size) {
        case 8:
            *(uint64_t *)dest = *(uint64_t *)src;
            break;
        case 4:
            *(uint32_t *)dest = *(uint32_t *)src;
            break;
        case 2:
            *(uint16_t *)dest = *(uint16_t *)src;
            break;
        case 1:
            *(uint8_t *)dest = *(uint8_t *)src;
            break;
        default:
            ALOGW("%s: destination size %zu not supported", __FUNCTION__, dest_size);
    }
}

void core_letoh(void *dest, size_t dest_size, void *src, size_t src_size)
{
    _core_xetoh(dest, dest_size, src, src_size);
}

void core_htole(void *dest, size_t dest_size, void *src, size_t src_size)
{
    _core_xetoh(dest, dest_size, src, src_size);
}

core_res_t core_log_set_native(const bool enable)
{
    return CORE_ERROR_NOT_IMPLEMENTED;
}

char *core_str_case_str(const char *haystack, const char *needle)
{
    return StrStrIA(haystack, needle);
}

core_res_t core_get_time(struct timespec *ts)
{
    core_res_t ret = CORE_SUCCESS;

    if (!timespec_get(ts, TIME_UTC)) {
        ret = CORE_ERROR_OPERATION_NOT_PERMITTED;
    }

    return ret;
}
