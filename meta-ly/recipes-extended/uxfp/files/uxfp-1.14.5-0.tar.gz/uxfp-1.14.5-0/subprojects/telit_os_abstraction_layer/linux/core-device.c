#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <libgen.h>
#if LIBUDEV
#include <libudev.h>
#endif
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/inotify.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <unistd.h>
#include <ctype.h>
#include <inttypes.h>

#include <telit-os-abs.h>

#define BUF_LEN 1024

extern sig_atomic_t sigint_detected;

#if LIBUDEV
#define SUBSYSTEMS {"tty", "usb", "mhi_uci", "wwan", "GobiQMI", "cwan_qmi", NULL}
static core_res_t get_device_info(const usb_id_t *usbid, const uint8_t usbid_size, dev_info_t *info,
        int8_t *list_size);
static core_res_t device_event_listener(bool (*condition)(dev_info_t *info,
        void *data), void *data, uint32_t timeout_ms, char *event_vid, char *event_pid, usb_event_t *event_type);
#endif

#pragma weak core_device_open
core_res_t core_device_open(const char *device_path, dev_handle_t *handle)
{
    core_res_t err = CORE_SUCCESS;

    errno = 0;
    *handle = open(device_path, O_RDWR | O_NONBLOCK);
    if (errno) {
        int error = errno;
        ALOGE("could not open device %s: error %d %s\n",
                device_path, error, strerror(error));
        err = map_errno_to_core_err(error);
    }

    return err;
}

#pragma weak core_device_close
core_res_t core_device_close(const dev_handle_t handle)
{
    core_res_t err = CORE_SUCCESS;
    int32_t ret;

    errno = 0;
    ret = close(handle);
    if (ret != 0) {
        int error = errno;
        ALOGD("could not close handle: error %d %s\n", error, strerror(error));
        err = map_errno_to_core_err(error);
    }

    return err;
}

#pragma weak core_device_config
core_res_t core_device_config(const dev_handle_t handle)
{
    return core_set_hw_flow_control(handle, false);
}

core_res_t core_set_hw_flow_control(const dev_handle_t handle, const bool enable)
{
    core_res_t err = CORE_SUCCESS;
    int32_t ret = 0;
    struct termios config = {0};

    errno = 0;
    ret = tcgetattr(handle, &config);
    if (ret) {
        int error = errno;

        if (error == ENOTTY) {
            /* This is not a tty device, no need to set flow control */
            goto end;
        }

        ALOGE("could not get device configuration: error %d %s\n", error, strerror(error));
        err = map_errno_to_core_err(error);
        goto end;
    }

    cfmakeraw(&config);
    if (enable) {
        config.c_cflag |= CRTSCTS;
    } else {
        config.c_cflag &= ~CRTSCTS;
    }

    errno = 0;
    ret = tcsetattr(handle, TCSANOW, &config);
    if (ret) {
        int error = errno;
        ALOGE("could not set device config: error %d %s\n", error, strerror(error));
        err = map_errno_to_core_err(error);
        goto end;
    }

end:
    return err;
}

#pragma weak core_get_serial_state
core_res_t core_get_serial_state(const dev_handle_t handle, serial_state_t *state)
{
    /* This function always returns CORE_SUCCESS, if input is good
     * This because some USB serial port drivers could not support those
     * settings, but they are needed in some specific scenarios */
    int32_t ret = CORE_SUCCESS;
    int settings = 0;

    if (!state) {
        ret = CORE_ERROR_EINVAL;
        goto end;
    }
    memset(state, 0, sizeof(*state));

    if (ioctl(handle, TIOCMGET, &settings) < 0) {
        int err = errno;
        ALOGD("could not get serial setting: error %d %s\n", err, strerror(err));
        goto end;
    }

    state->dsr = settings & TIOCM_DSR;
    if (!state->dsr) {
        state->dsr = settings & TIOCM_LE;
    }
    state->cts = settings & TIOCM_CTS;
    state->dcd = settings & TIOCM_CAR;
    state->ring = settings & TIOCM_RNG;

end:
    return ret;
}

#pragma weak core_set_control_signals
core_res_t core_set_control_signals(const dev_handle_t handle, bool dtr, bool rts)
{
    /* This function always returns CORE_SUCCESS, printing a debug log if fails
     * This because some USB serial port drivers could not support those
     * settings, but they are needed for UART */
    int32_t ret = CORE_SUCCESS;
    int settings = 0;

    if (ioctl(handle, TIOCMGET, &settings) < 0) {
        int err = errno;
        ALOGD("could not get serial setting: error %d %s\n", err, strerror(err));
        goto end;
    }

    if (rts) {
        settings |= TIOCM_RTS;
    } else {
        settings &= ~TIOCM_RTS;
    }

    if (dtr) {
        settings |= TIOCM_DTR;
    } else {
        settings &= ~TIOCM_DTR;
    }

    if (ioctl(handle, TIOCMSET, &settings) < 0) {
        int err = errno;
        ALOGD("could not set serial setting: error %d %s\n", err, strerror(err));
    }

end:
    return ret;
}

#pragma weak core_device_set_baud_rate
core_res_t core_device_set_baud_rate(const dev_handle_t handle, const uint32_t baud_rate)
{
    int32_t ret = CORE_SUCCESS;
    speed_t speed;
    struct termios config = {0};

    ALOGD("setting baudrate %" PRIu32 "\n", baud_rate);

    errno = 0;
    ret = tcgetattr(handle, &config);
    if (ret == -1) {
        int err = errno;
        ALOGE("could not get device configuration: error %d %s\n", err, strerror(err));
        ret = map_errno_to_core_err(err);
        goto end;
    }

    switch (baud_rate) {
        case 115200:
            speed = B115200;
            break;
        case 230400:
            speed = B230400;
            break;
        case 460800:
            speed = B460800;
            break;
        case 921600:
            speed = B921600;
            break;
        case 2000000:
            speed = B2000000;
            break;
        case 3000000:
            speed = B3000000;
            break;
        default:
            ALOGE("invalid baud rate %" PRIu32 "\n", baud_rate);
            ret = CORE_ERROR_EINVAL;
            goto end;
    }

    ret = cfsetispeed(&config, speed);
    if (ret == -1) {
        int err = errno;
        ALOGE("cfsetispeed error %d %s\n", err, strerror(err));
        ret = map_errno_to_core_err(err);
        goto end;
    }

    ret = cfsetospeed(&config, speed);
    if (ret == -1) {
        int err = errno;
        ALOGE("cfsetospeed error %d %s\n", err, strerror(err));
        ret = map_errno_to_core_err(err);
        goto end;
    }

    ret = tcsetattr(handle, TCSANOW, &config);
    if (ret) {
        int err = errno;
        ALOGD("could not set device config: error %d %s\n", err, strerror(err));
        ret = map_errno_to_core_err(err);
        goto end;
    }

    /* check whether the speed has actually changed */
    ret = tcgetattr(handle, &config);
    if (ret == -1) {
        int err = errno;
        ALOGE("could not get device configuration: error %d %s\n", err, strerror(err));
        ret = map_errno_to_core_err(err);
        goto end;
    }

    if (cfgetispeed(&config) != speed || cfgetospeed(&config) != speed) {
        ALOGD("baud rate has not changed\n");
    }

end:
    return ret;
}

core_res_t core_device_read(dev_handle_t handle, void *buffer, const uint32_t bytes_to_read,
        uint32_t *bytes_read)
{
    core_res_t ret = CORE_SUCCESS;
    int32_t bytes;

    *bytes_read = 0;
    errno = 0;

    bytes = (int32_t)read(handle, buffer, bytes_to_read);
    if (bytes == -1) {
        int err = errno;

        if (err != EAGAIN) {
            ALOGE("could not read data from handle: error %d %s\n", err, strerror(err));
        }

        ret = map_errno_to_core_err(err);
    } else {
        *bytes_read = bytes;
    }

    return ret;
}

static core_res_t _core_device_poll(const dev_handle_t handle, const int64_t msec, short events)
{
    core_res_t ret = CORE_SUCCESS;
    int ret_poll;
    struct pollfd event = {0};

    event.fd = handle;
    event.events = events;

    errno = 0;
    ret_poll = poll(&event, 1, msec);
    if (ret_poll == -1) {
        int err = errno;

        if (err != EINTR) {
            ALOGE("Poll error %d, %s", err, strerror(err));
        }

        ret = map_errno_to_core_err(err);
        goto end;
    }

    if (event.revents & POLLHUP) {
        ALOGD("poll hang up\n");
        ret = CORE_ERROR_OP_CANCELLED;
        goto end;
    }

    if (event.revents & POLLERR) {
        ALOGE("poll device error\n");
        ret = CORE_ERROR_UNKNOWN;
        goto end;
    }

    if (!(event.revents & events)) {
        /*ALOGD("poll timeout\n");*/
        ret = CORE_ERROR_TIMEOUT;
        goto end;
    }

end:
    return ret;
}

#pragma weak core_device_poll
core_res_t core_device_poll(const dev_handle_t handle, const int64_t msec)
{
    return _core_device_poll(handle, msec, POLLIN);
}

core_res_t core_device_write(dev_handle_t handle, const void *buffer, uint32_t bytes_to_write,
        uint32_t *bytes_written)
{
    core_res_t ret = CORE_SUCCESS;
    int32_t written;

    errno = 0;
    *bytes_written = 0;

    ret = _core_device_poll(handle, 5000, POLLOUT);
    if (ret == CORE_SUCCESS) {
        written = (int32_t)write(handle, buffer, bytes_to_write);
        if (written == -1) {
            int err = errno;

            ALOGE("could not write data to handle: error %d %s\n", err, strerror(err));
            ret = map_errno_to_core_err(err);
        } else {
            *bytes_written = written;
        }
    }

    return ret;
}

core_res_t core_device_recoursive_write(dev_handle_t handle, const void *buffer, size_t bytes_to_write)
{
    core_res_t ret = CORE_SUCCESS;
    uint32_t total_written = 0;
    int8_t retry = 10;
    uint32_t written;

    ret = _core_device_poll(handle, 5000, POLLOUT);

    if (ret == CORE_SUCCESS) {
        while (total_written < bytes_to_write && retry > 0) {
            written = (int32_t)write(handle, buffer, bytes_to_write);

            if (written == -1) {
                int err = errno;

                ALOGE("could not write data to handle: error %d %s\n", err, strerror(err));
                ret = map_errno_to_core_err(err);
                goto end;
            } else if (written == 0) {
                retry--;
                core_sleep(10);
                continue;
            }

            total_written += written;
            retry = 10;
        }
    }

    if (retry == 0) {
        ALOGE("write returned zero (written %d bytes out of %d)\n", total_written, bytes_to_write);
        ret = CORE_ERROR_IO_ERROR;
    }

end:
    return ret;
}

core_res_t core_device_timed_read(dev_handle_t handle, void *buffer, uint32_t bytes_to_read,
        const uint32_t msec, uint32_t *bytes_read)
{
    core_res_t ret = CORE_SUCCESS;

    *bytes_read = 0;

    ret = core_device_poll(handle, (int64_t)msec);
    if (ret != CORE_SUCCESS) {
        goto end;
    }

    /* TBD: should we check also read for errors ? */
    ret = core_device_read(handle, buffer, bytes_to_read, bytes_read);

end:
    return ret;
}

core_res_t core_device_get_bytes_available(const dev_handle_t handle, uint32_t *bytes)
{
    core_res_t ret = CORE_SUCCESS;

    errno = 0;
    ret = ioctl(handle, FIONREAD, bytes);
    if (ret == -1) {
        int err = errno;
        ALOGE("ioctl FIONREAD returned error %d %s\n", err, strerror(err));

        ret = map_errno_to_core_err(err);
    }

    return ret;
}

bool core_device_has_vid_pid(const dev_info_t *info, const char *vid, const char *pid)
{
    assert(info);
    assert(vid);
    assert(pid);

    return (strncmp(info->vendor_id, vid, 5) == 0) && (strncmp(info->product_id, pid, 5) == 0);
}

#pragma weak core_device_enumerate
core_res_t core_device_enumerate(const usb_id_t *usbid_list,
        const uint8_t usbid_list_size,
        dev_info_t *dev_list,
        int8_t *dev_list_size)
{
#if LIBUDEV
    return get_device_info(usbid_list, usbid_list_size, dev_list, dev_list_size);
#else
    return CORE_ERROR_NOT_IMPLEMENTED;
#endif
}

core_res_t core_device_get_info(const char *vid, const char *pid, dev_info_t *info)
{
#if LIBUDEV
    usb_id_t usbid;
    int8_t list_size = 1;
    if (!core_usb_id_from_str(&usbid, vid, pid)) {
        return CORE_ERROR_EINVAL;
    }
    return get_device_info(&usbid, 1, info, &list_size);
#else
    return CORE_ERROR_NOT_IMPLEMENTED;
#endif
}

core_res_t core_device_get_usb_id_info(const usb_id_t *usbid, dev_info_t *info)
{
#if LIBUDEV
    int8_t list_size = 1;
    return get_device_info(usbid, 1, info, &list_size);
#else
    return CORE_ERROR_NOT_IMPLEMENTED;
#endif
}

core_res_t core_device_get_usb_id_info_list(const usb_id_t *usbid, dev_info_t *info, const int len)
{
#if LIBUDEV
    int8_t list_size = len;
    return get_device_info(usbid, 1, info, &list_size);
#else
    return CORE_ERROR_NOT_IMPLEMENTED;
#endif
}

#pragma weak core_device_usb_id_event_listener
core_res_t core_device_usb_id_event_listener(bool (*condition)(dev_info_t *info, void *data),
        void *data,
        uint32_t timeout_ms,
        usb_id_t *event)
{
#if LIBUDEV
    core_res_t err;
    char event_vid[MAX_USB_ID_LEN + 1] = {0};
    char event_pid[MAX_USB_ID_LEN + 1] = {0};

    err = device_event_listener(condition, data, timeout_ms, event_vid, event_pid, NULL);
    if (err) {
        return err;
    }

    return core_usb_id_from_str(event, event_vid, event_pid) ? CORE_SUCCESS : CORE_ERROR_UNKNOWN;
#else
    return CORE_ERROR_NOT_IMPLEMENTED;
#endif
}

#pragma weak core_device_usb_id_event_type_listener
core_res_t core_device_usb_id_event_type_listener(bool (*condition)(dev_info_t *info,
        void *data), void *data, uint32_t timeout_ms, usb_id_t *event, usb_event_t *event_type)
{
#if LIBUDEV
    core_res_t err;
    char event_vid[MAX_USB_ID_LEN + 1] = {0};
    char event_pid[MAX_USB_ID_LEN + 1] = {0};

    err = device_event_listener(condition, data, timeout_ms, event_vid, event_pid, event_type);
    if (err) {
        return err;
    }

    return core_usb_id_from_str(event, event_vid, event_pid) ? CORE_SUCCESS : CORE_ERROR_UNKNOWN;
#else
    return CORE_ERROR_NOT_IMPLEMENTED;
#endif
}

core_res_t core_device_event_listener(bool (*condition)(dev_info_t *info, void *data),
        void *data,
        uint32_t timeout_ms,
        char *event_vid,
        char *event_pid)
{
#if LIBUDEV
    return device_event_listener(condition, data, timeout_ms, event_vid, event_pid, NULL);
#else
    return CORE_ERROR_NOT_IMPLEMENTED;
#endif
}

#pragma weak core_wait_for_serial
core_res_t core_wait_for_serial(const char *port)
{
    core_res_t ret = CORE_SUCCESS;
    int fd, wd;
    char buf[BUF_LEN] = {0};
    ssize_t len, i = 0;
    char *dir_name = NULL;
    char *base_name = NULL;
    char *tmp_dir_name = NULL;
    char *tmp_file_name = NULL;
    struct pollfd event = {0};

    if (!port) {
        ALOGE("invalid port name\n");
        ret = CORE_ERROR_EINVAL;
        goto end;
    }

    if (access(port, F_OK) != -1 ) {
        /* Successfully found the device */
        goto end;
    }

    fd = inotify_init();
    if (fd == -1) {
        ALOGE("inotify_init\n");
        ret = CORE_ERROR_UNKNOWN;
        goto end;
    }

    errno = 0;
    tmp_dir_name = strdup(port);
    if (!tmp_dir_name) {
        ALOGE("could not copy port '%s' for dirname: error %d %s",
                port, errno, strerror(errno));
        ret = CORE_ERROR_MEM;
        goto close_descriptor;
    }
    dir_name = dirname(tmp_dir_name);

    tmp_file_name = strdup(port);
    if (!tmp_file_name) {
        ALOGE("could not copy port '%s' for basename: error %d %s",
                port, errno, strerror(errno));
        ret = CORE_ERROR_MEM;
        goto close_descriptor;
    }
    base_name = basename(tmp_file_name);

    wd = inotify_add_watch(fd, dir_name, IN_CREATE);
    if (wd == -1) {
        ALOGE("inotify_add_watch\n");
        ret = CORE_ERROR_UNKNOWN;
        goto close_descriptor;
    }

    event.fd = fd;
    event.events = POLLIN;

    while (!sigint_detected) {
        if (access(port, F_OK) != -1 ) {
            /* the device successfully attached in the meanwhile, no need for other checks */
            goto disable_watch;
        }

        if (poll(&event, 1, 1000) == -1) {
            ALOGE("Poll error %d, %s\n", errno, strerror(errno));
            ret = CORE_ERROR_UNKNOWN;
            goto disable_watch;
        }

        if (event.revents & POLLERR) {
            ALOGE("Poll device error\n");
            ret = CORE_ERROR_UNKNOWN;
            goto disable_watch;
        }

        if (!(event.revents & POLLIN)) {
            /*ALOGD("Poll timeout\n");*/
            continue;
        }

        len = read(fd, buf, BUF_LEN);
        if (len == -1) {
            /* Debug print log to display the read operation error (error status may be temporary) */
            ALOGD("Read error %d, %s\n", errno, strerror(errno));
            errno = 0;
            continue;
        }

        while (i < len) {
            struct inotify_event *event = (struct inotify_event *)&buf[i];

            if ((event->mask & IN_CREATE) && (strcmp(event->name, base_name) == 0)) {
                ALOGD("%s is created\n", port);
                goto disable_watch;
            }

            /* update the index to the start of the next event */
            i += sizeof (struct inotify_event) + event->len;
        }
        i = 0;
    }

    ret = (sigint_detected ? CORE_ERROR_NO_SUCH_DEVICE : CORE_SUCCESS);

disable_watch:
    inotify_rm_watch(fd, wd);

close_descriptor:
    close(fd);

end:
    if (tmp_file_name) {
        free(tmp_file_name);
    }
    if (tmp_dir_name) {
        free(tmp_dir_name);
    }

    return ret;
}

#if LIBUDEV
static core_res_t udev_enumerate_devices(struct udev **context,
        struct udev_enumerate **enumerate,
        struct udev_list_entry **devices)
{
    core_res_t err = CORE_ERROR_UNKNOWN;
    char *subsystems[] = SUBSYSTEMS;
    int i;

    *context = udev_new();
    if (*context == NULL) {
        ALOGE("could not allocate udev context\n");
        goto end;
    }

    *enumerate = udev_enumerate_new(*context);
    if (*enumerate == NULL) {
        ALOGE("could not allocate udev enumerate\n");
        goto end;
    }

    for (i = 0; subsystems[i] != NULL; ++i) {
        if (udev_enumerate_add_match_subsystem(*enumerate, subsystems[i]) < 0) {
            ALOGE("could not update udev enumerate filter with subsystem %s\n", subsystems[i]);
            goto end;
        }
    }

    if (udev_enumerate_scan_devices(*enumerate) < 0) {
        ALOGE("could not scan devices\n");
        goto end;
    }

    *devices = udev_enumerate_get_list_entry(*enumerate);
    if (*devices == NULL) {
        ALOGW("devices list is empty\n");
        err = CORE_ERROR_NO_SUCH_DEVICE;
        goto end;
    }
    err = CORE_SUCCESS;

end:
    return err;
}


static core_res_t get_device_id(struct udev_device *dev, usb_id_t *usb_id)
{
    struct udev_device *parent = NULL;
    const char *keys[2] = {0};
    const char *values[2] = {0};

    const char *subsystem = udev_device_get_property_value(dev, "SUBSYSTEM");
    if (subsystem
            && (strcmp(subsystem, "mhi_uci") == 0
            || strcmp(subsystem, "wwan") == 0)) {
        keys[0] = "vendor";
        keys[1] = "device";
        parent = udev_device_get_parent_with_subsystem_devtype(dev, "pci", NULL);
    } else {
        keys[0] = "idVendor";
        keys[1] = "idProduct";
        parent = udev_device_get_parent_with_subsystem_devtype(dev, "usb", "usb_device");
    }
    if (!parent) {
        return CORE_ERROR_NO_SUCH_DEVICE;
    }

    values[0] = udev_device_get_sysattr_value(parent, keys[0]);
    values[1] = udev_device_get_sysattr_value(parent, keys[1]);
    if (!values[0] || !values[1]) {
        ALOGE("could not find vendor and/or product id\n");
        return CORE_ERROR_NO_SUCH_DEVICE;
    }

    if (!core_usb_id_from_str(usb_id, values[0], values[1])) {
        ALOGE("could not parse ids %s:%s\n", values[0], values[1]);
        return CORE_ERROR_UNKNOWN;
    }

    return CORE_SUCCESS;
}


static void get_location_path(struct udev_device *dev, char *location_path)
{
    const char *sysname;
    unsigned int wwan_index;

    sysname = udev_device_get_sysname(dev);

    /* the syspath paired to a sysname in the format "wwan<n>" is a candidate
     * device location for PCIe devices, because it is a common substring with
     * the syspath of the ports wwan<n>at<m>, wwan<n>qcdm<m>, etc. */
    if (sscanf(sysname, "wwan%u", &wwan_index) == 1) {
        snprintf(location_path, MAX_STR_VALUE, "%s", udev_device_get_syspath(dev));
        return;
    }

    /* skip the sysname ending with usb<n>, since it only refers to the usb
    * controller and it is not enough to distinguish the device location */
    if (strstr(sysname, "usb") != NULL) {
        return;
    }

    /* skip sysname in format X-Y.Z:A.B, since it refers to the device port,
     * not to the modem location. */
    if (strstr(sysname, "-") != NULL && strstr(sysname, ":") != NULL) {
        return;
    }

    /* the syspath paired with the sysname at this point is a device location
     * candidate */
    snprintf(location_path, MAX_STR_VALUE, "%s", udev_device_get_syspath(dev));
}

static bool is_valid_serial(const char *serial)
{
    int i;

    for (i = 0; i < strlen(serial); i++) {
        if (!isalnum((unsigned char)serial[i])) {
            return false;
        }
    }

    return true;
}

static bool update_unique_devpath(struct udev_device *device, dev_info_t *info)
{
    char *pos;
    const char *dev_path;

    if (strlen(info->dev_path)) {
        return false;
    }

    dev_path = udev_device_get_property_value(device, "DEVPATH");
    if (!dev_path) {
        return false;
    }

    /* Remove the port-dependent variable part of DEVPATH */
    pos = strstr(dev_path, info->location_path);
    if (!pos) {
        return false;
    }
    pos += strlen(info->location_path);
    *pos = '\0';
    snprintf(info->dev_path, MAX_STR_VALUE, "%s", dev_path);

    return true;
}

static void pci_quirk(const char *comm_port, const int comm_port_number, dev_info_t *info)
{
    if (strcasestr(comm_port, "qcdm") != NULL
            || strcasestr(comm_port, "diag") != NULL) {
        ALOGD("port %d is MHI, setting interface number to 00\n", comm_port_number);
        char iface[3] = "00";
        sprintf(info->ifaces[comm_port_number], "%s", iface);
    }

    if (strcasestr(comm_port, "sahara") != NULL) {
        ALOGD("port %d is SAHARA, setting interface number to 01\n", comm_port_number);
        char iface[3] = "01";
        sprintf(info->ifaces[comm_port_number], "%s", iface);
    }
}

static bool is_new_location_path(const char *current, const char *candidate)
{
    /* the candidate location path is new if different and not a superstring of
     * the current location path */
    return (strcmp(candidate, current) != 0) &&
           (strstr(candidate, current) == NULL);
}

static core_res_t get_device_info(const usb_id_t *usbid_list,
        const uint8_t usbid_list_size,
        dev_info_t *dev_list,
        int8_t *dev_list_size)
{
    core_res_t err = CORE_ERROR_NO_SUCH_DEVICE;
    struct udev *context = NULL;
    struct udev_enumerate *enumerate = NULL;
    struct udev_list_entry *devices = NULL;
    struct udev_list_entry *entry = NULL;
    uint8_t dev_list_max_size = *dev_list_size;
    int8_t dev_list_idx = 0;
    char location_path[MAX_STR_VALUE] = {0};
    char serial_number[MAX_STR_VALUE] = {0};

    err = udev_enumerate_devices(&context, &enumerate, &devices);
    if (err) {
        ALOGE("could not init udev: error %d\n", err);
        goto clean;
    }

    *dev_list_size = 0;

    udev_list_entry_foreach(entry, devices) {
        dev_info_t *info;
        usb_id_t curid = {0};
        const char *value = NULL;
        uint8_t k;
        const char *path;
        struct udev_device *dev;

        path = udev_list_entry_get_name(entry);
        if (!path) {
            /* nothing to clean, just next item */
            continue;
        }
        dev = udev_device_new_from_syspath(context, path);
        if (!dev) {
            goto next;
        }

        get_location_path(dev, location_path);
        if (strlen(location_path) == 0) {
            goto next;
        }

        info = &dev_list[dev_list_idx];

        value = udev_device_get_sysattr_value(dev, "serial");
        if (value && is_valid_serial(value)) {
            strlcpy(serial_number, value, sizeof(serial_number));
        }

        err = get_device_id(dev, &curid);
        if (err) {
            if (err != CORE_ERROR_NO_SUCH_DEVICE) {
                udev_device_unref(dev);
                goto clean;
            }
            goto next;
        }

        for (k = 0; k < usbid_list_size; ++k) {
            if (!core_usb_id_equals(&usbid_list[k], &curid)) {
                continue;
            }
            goto found;
        }
        goto next;
found:

        if (strlen(info->location_path) == 0 ||
                is_new_location_path(info->location_path, location_path)) {
            if ((*dev_list_size) >= dev_list_max_size) {
                ALOGD("device info list full (dev_list_idx %" PRIi8 ", max %" PRIu8 ")\n",
                        dev_list_idx, dev_list_max_size);
                goto next;
            }
            dev_list_idx = *dev_list_size;
            info = &dev_list[dev_list_idx];

            ALOGD("dev[%" PRIi8 "].location_path = %s\n", dev_list_idx, location_path);
            strlcpy(info->location_path, location_path, sizeof(info->location_path));

            ALOGD("dev[%" PRIi8 "].serial = %s\n", dev_list_idx, serial_number);
            strlcpy(info->serial, serial_number, sizeof(info->serial));
        }

        if (update_unique_devpath(dev, info)) {
            ALOGD("dev[%" PRIi8 "].dev_path = '%s'\n", dev_list_idx, info->dev_path);
        }

        if (info->comm_ports_number >= MAX_COMM_PORTS_NUM) {
            ALOGI("communication port list full\n");
            udev_device_unref(dev);
            break;
        }

        if (info->vendor_id[0] == '\0' &&
                info->product_id[0] == '\0') {
            ALOGD("dev[%" PRIi8 "].usb_id = {0x%04" PRIx32 ":0x%04" PRIx32 "}\n",
                    dev_list_idx, curid.vid, curid.pid);
            snprintf(info->vendor_id, 5, "%04x", curid.vid);
            snprintf(info->product_id, 5, "%04x", curid.pid);
            (*dev_list_size)++;
        }

        value = udev_device_get_sysattr_value(dev, "bInterfaceNumber");
        if (value) {
            ALOGD("dev[%" PRIi8 "].iface[%" PRIu32 "] = %s\n", dev_list_idx, info->comm_ports_number, value);
            strlcpy(info->ifaces[info->comm_ports_number], value, sizeof(info->ifaces[0]));
        }

        value = udev_device_get_driver(dev);
        if (value) {
            ALOGD("dev[%" PRIi8 "].driver[%" PRIu32 "] = '%s'\n", dev_list_idx, info->comm_ports_number,
                    value);
            strlcpy(info->drivers[info->comm_ports_number], value, sizeof(info->drivers[0]));
        }

        value = udev_device_get_devnode(dev);
        if (value) {
            pci_quirk(value, info->comm_ports_number, info);
            ALOGD("dev[%" PRIi8 "].path[%" PRIu32 "] = '%s'\n", dev_list_idx, info->comm_ports_number, value);
            strlcpy(info->comm_ports[info->comm_ports_number], value, sizeof(info->comm_ports[0]));
            /* from udev we receive first the interface number, then the driver and
             * finally the comm_port name, then we can update comm_ports_number here */
            info->comm_ports_number++;
        }

next:
        udev_device_unref(dev);
    }

clean:
    udev_enumerate_unref(enumerate);
    udev_unref(context);

    /* "err" here could evaluate to CORE_ERROR_NO_SUCH_DEVICE
     * because the LAST call returned error, not because no
     * device has been found in the whole loop */
    if (err == CORE_ERROR_NO_SUCH_DEVICE &&
            *dev_list_size != 0) {
        err = CORE_SUCCESS;
    }
    return err;
}

static core_res_t device_event_listener(bool (*condition)(dev_info_t *info, void *data),
        void *data,
        uint32_t timeout_ms,
        char *event_vid,
        char *event_pid,
        usb_event_t *usb_event)
{
    core_res_t err;
    struct udev *context = NULL;
    struct udev_monitor *mon = NULL;
    int32_t inner_timeout_ms = 100;
    bool ok = false;
    dev_handle_t handle;
    int i;
    char *subsystems[] = SUBSYSTEMS;

#define timeout_not_expired (timeout_ms == TIMEOUT_INFINITE || timeout_ms > 0)

    if (timeout_ms == TIMEOUT_INFINITE) {
        ALOGD("waiting for USB event without timeout\n");
        inner_timeout_ms = -1;
    }

    context = udev_new();
    assert(context);

    mon = udev_monitor_new_from_netlink(context, "udev");
    assert(mon);

    for (i = 0; subsystems[i] != NULL; ++i) {
        err = udev_monitor_filter_add_match_subsystem_devtype(mon, subsystems[i], NULL);
        if (err) {
            ALOGE("could not update udev listener filter with subsystem %s: err %d\n", subsystems[i], err);
            return err;

        }
    }

    err = udev_monitor_enable_receiving(mon);
    assert(!err);

    handle = udev_monitor_get_fd(mon);
    assert(handle != INVALID_DEVICE_HANDLE);

    while (!ok && timeout_not_expired) {
        const char *devnode = NULL;
        const char *action = NULL;
        const char *dev_path = NULL;
        struct udev_device *dev = NULL;
        static dev_info_t info = {0};
        usb_id_t usbid = {0};

        memset(&info, 0, sizeof(info));

        err = core_device_poll(handle, inner_timeout_ms);
        if (err == CORE_ERROR_TIMEOUT) {
            if (timeout_ms == TIMEOUT_INFINITE) {
                ALOGE("unexpected poll timeout. Endless wait was expected, continuing");
                continue;
            }
            timeout_ms = timeout_ms - inner_timeout_ms;
            if (timeout_ms <= 0) {
                ALOGD("event listening timed out\n");
                err = CORE_ERROR_TIMEOUT;
            }
            continue;
        }

        if (err) {
            if (err != CORE_ERROR_EINTR) {
                ALOGE("event listener error %d\n", err);
            }

            break;
        }

        dev = udev_monitor_receive_device(mon);
        if (!dev) {
            ALOGD("no device found. error occurred\n");
            err = CORE_ERROR_UNKNOWN;
            break;
        }

        action = udev_device_get_action(dev);
        if (usb_event) {
            if (!action ||
                    (strcmp(action, "add") != 0 && strcmp(action, "remove") != 0)) {
                goto clean;
            }
        } else {
            if (!action || (strcmp(action, "add") != 0)) {
                goto clean;
            }
        }
        ALOGD("%s event\n", action);

        err = get_device_id(dev, &usbid);
        if (err) {
            ALOGD("could not get USB ids from device\n");
            continue;
        }
        if (usbid.vid && usbid.pid) {
            int res;
            res = snprintf(info.vendor_id, sizeof(info.vendor_id), "%04x", usbid.vid);
            if (res >= sizeof(info.vendor_id)) {
                err = CORE_ERROR_UNKNOWN;
                goto clean;
            }
            res = snprintf(info.product_id, MAX_USB_ID_LEN + 1, "%04x", usbid.pid);
            if (res >= sizeof(info.product_id)) {
                err = CORE_ERROR_UNKNOWN;
                goto clean;
            }
        }

        devnode = udev_device_get_devnode(dev);
        if (!devnode) {
            ALOGD("no device node found. \n");
        } else {
            strlcpy(info.comm_ports[0], devnode, sizeof(info.comm_ports[0]));
            info.comm_ports_number = 1;
        }

        ALOGD("checking device: {node:%s, vid: %s, pid: %s}\n",
                info.comm_ports[0],
                info.vendor_id,
                info.product_id);

        ok = condition(&info, data);
        if (ok) {
            if (usbid.vid && usbid.pid) {
                int res;
                res = snprintf(event_vid, MAX_USB_ID_LEN + 1, "%04x", usbid.vid);
                if (res > MAX_USB_ID_LEN) {
                    err = CORE_ERROR_UNKNOWN;
                    goto clean;
                }
                res = snprintf(event_pid, MAX_USB_ID_LEN + 1, "%04x", usbid.pid);
                if (res > MAX_USB_ID_LEN) {
                    err = CORE_ERROR_UNKNOWN;
                    goto clean;
                }
                ALOGD("condition met against device %s:%s, exiting...\n", event_vid, event_pid);
            } else {
                ALOGD("condition met, exiting...\n");
            }

            if (usb_event) {
                dev_path = udev_device_get_property_value(dev, "DEVPATH");
                if (dev_path) {
                    strlcpy(usb_event->dev_path, dev_path, sizeof(usb_event->dev_path));
                }
                if (!strcmp(action, "add")) {
                    usb_event->type = CORE_USB_EVENT_ADD;
                } else {
                    usb_event->type = CORE_USB_EVENT_REMOVE;
                }
            }

            err = CORE_SUCCESS;
        }

clean:
        udev_device_unref(dev);
    }

    udev_monitor_unref(mon);
    udev_unref(context);

#undef timeout_not_expired

    return err;
}
#endif

#pragma weak core_device_flush
core_res_t core_device_flush(const dev_handle_t handle)
{
    if (0 == tcflush(handle, TCIOFLUSH)) {
        return CORE_SUCCESS;
    }

    return CORE_ERROR_IO_ERROR;
}

core_res_t core_device_realpath(const char *path, char *real_path)
{
    core_res_t ret = CORE_ERROR_EINVAL;

    if (path && real_path && strlen(path) > 0) {
        errno = 0;

        if (realpath(path, real_path)) {
            ret = CORE_SUCCESS;
        } else {
            ret = map_errno_to_core_err(errno);
        }
    }

    return ret;
}
