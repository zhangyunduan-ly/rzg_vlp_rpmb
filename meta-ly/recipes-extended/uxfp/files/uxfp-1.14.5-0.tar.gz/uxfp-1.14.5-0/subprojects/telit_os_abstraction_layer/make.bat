REM To be compiled with a VS Native Tools Command Prompt

cd windows
call make.bat %1
cd ..

if "%1" == "tests" (
    cd tests
    call make.bat
    cd ..
)

if "%1" == "clean" (
    del tests\*.exe
    goto end
)

:end
