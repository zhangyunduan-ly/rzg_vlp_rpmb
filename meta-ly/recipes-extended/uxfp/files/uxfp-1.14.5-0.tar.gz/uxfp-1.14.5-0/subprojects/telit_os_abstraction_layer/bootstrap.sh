#!/usr/bin/env bash

set -euo pipefail

# version
major=$(grep MAJOR version.h | cut -d'"' -f2)
minor=$(grep MINOR version.h | cut -d'"' -f2)
patch=$(grep PATCH version.h | cut -d'"' -f2)
cust=$(grep CUST version.h | cut -d'"' -f2)
echo "$major.$minor.$patch-$cust" > .version

mkdir -p m4
autoreconf -i
