#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <telit-os-abs.h>

#define MAX_CLI_ARGS 30
#define MAX_SHORT_PREFIX 8  /* Space for short name prefix message */

static bool is_flag(const char *string);
static bool is_valid_flag(const char *string);
static core_res_t get_value(flag_t *flag, const char *string);

core_res_t get_opts(int argc, char **argv, flag_t *flags)
{
    core_res_t err = CORE_ERROR_EINVAL;
    bool unknown_arg[MAX_CLI_ARGS];
    int8_t i, j;

    assert(flags);
    assert(MAX_CLI_ARGS >= argc);

    /* NOTE: It seems that 1-initializing unknown_arg on declaration
     * does not work the same as memset */
    memset(unknown_arg, 1, MAX_CLI_ARGS);

    for (i = 0; flags[i].long_name; i++) {
        flag_t *flag = &flags[i];
        bool found = false;

        /* argv[0] is application name */
        for (j = 1; j < argc; j++) {
            char *string = argv[j];

            if (!string || !is_flag(string)) {
                unknown_arg[j] = false;
                continue;
            }

            if (!is_valid_flag(string)) {
                ALOGE("flag '%s' is invalid\n", string);
                err = CORE_ERROR_EINVAL;
                goto end;
            }

            if (strncmp(string, "-h", 3) == 0 || strncmp(string, "--help", 7) == 0) {
                err = CORE_ERROR_TRY_AGAIN;
                goto end;
            }

            if (!( (flag->long_name  && strcmp(string, flag->long_name) == 0) ||
                    (flag->short_name && strcmp(string, flag->short_name) == 0) ) ) {
                continue;
            }

            unknown_arg[j] = false;

            switch (flag->type) {
                case VALUE_TYPE_BOOLEAN:
                    err = get_value(flag, "true");
                    break;
                default: {
                    bool flag_followed_by_value = (j + 1 < argc) && !is_flag(argv[j + 1]);
                    if (!flag_followed_by_value) {
                        ALOGE("flag %s requires a value\n", flag->long_name);
                        err = CORE_ERROR_EINVAL;
                        goto end;
                    }

                    /* next argv is expected to be the flag value, acquire it and set it "known"
                     * NOTE: any possible error message is printed inside get_value, "err" is set
                     * here only to report it to the caller */
                    err = get_value(flag, argv[j + 1]);
                    unknown_arg[++j] = false;

                    break;
                }
            }

            if (err) {
                ALOGE("and error occurred parsing %s\n", flag->long_name);
                goto end;
            }

            found = true;
        }

        if (flag->required && !found) {
            ALOGE("flag '%s' is required\n", flag->long_name);
            err = CORE_ERROR_EINVAL;
            goto end;
        }
    }

    for (i = 1; i < argc; i++) {
        if (unknown_arg[i]) {
            ALOGE("unknown argument '%s'\n", argv[i]);
            err = CORE_ERROR_EINVAL;
            goto end;
        }
    }

    err = CORE_SUCCESS;

end:
    return err;
}

int compose_help_message(const char *usage,
        const flag_t *flags_arr,
        const uint8_t flags_arr_size,
        char help_message[][MAX_HELP_MSG_LINE],
        const uint8_t help_message_size)
{
    int i, offset = 0;

    if (usage) {
        strlcpy(help_message[offset++], usage, sizeof(help_message[0]));
    }

    if (!flags_arr_size) {
        ALOGD("no flag to show\n");
        return offset;
    }

    strlcpy(help_message[offset++], "options:", sizeof(help_message[0]));
    for (i = 0;
            (i < flags_arr_size) && (i + offset < help_message_size);
            i++) {
        const flag_t *flag = &flags_arr[i];
        char msg[MAX_HELP_MSG_LINE] = {0};
        char prefix[MAX_SHORT_PREFIX] = {0};

        /* prefix the short name if available, or leave a black space otherwise */
        if (flag->short_name) {
            snprintf(prefix, MAX_SHORT_PREFIX, " %2s or ", flag->short_name);
        } else {
            snprintf(prefix, MAX_SHORT_PREFIX, "       ");
        }

        if (flag->type == VALUE_TYPE_BOOLEAN) {
            snprintf(msg, MAX_HELP_MSG_LINE,
                    "%s%-18s : %s - %s",
                    prefix,
                    flag->long_name,
                    flag->description,
                    flag->required ? "required" : "optional");
        } else {
            snprintf(msg, MAX_HELP_MSG_LINE,
                    "%s%-10s <value> : %s - %s",
                    prefix,
                    flag->long_name,
                    flag->description,
                    flag->required ? "required" : "optional");
        }

        strlcpy(help_message[i + offset], msg, sizeof(help_message[0]));
    }
    return offset + i;
}

static core_res_t
get_value(flag_t *flag, const char *string)
{
    core_res_t err = CORE_ERROR_EINVAL;

    if (string) {
        err = CORE_SUCCESS;

        switch (flag->type) {
            case VALUE_TYPE_BOOLEAN:
                *(bool *)flag->value = (strcmp(string, "true") == 0);
                break;
            case VALUE_TYPE_ULONG: {
                unsigned long int v;
                char *end_ptr;

                errno = 0;
                v = strtoul(string, &end_ptr, 10);
                if (*end_ptr != '\0') {
                    ALOGE("Invalid string\n");
                    err = CORE_ERROR_EINVAL;
                    break;
                }
                if (errno) {
                    ALOGE("could not convert %s: error %d %s\n", string, errno, strerror(errno));
                    err = CORE_ERROR_EINVAL;
                    break;
                }
                *(uint64_t *)flag->value = v;
                break;
            }
            case VALUE_TYPE_STRING:
                strlcpy(flag->value, string, MAX_FLAG_VALUE_LEN);
                break;
            case VALUE_TYPE_UNKNOWN:
            default:
                ALOGE("unknown type value %u\n", flag->type);
                err = CORE_ERROR_EINVAL;
                break;
        }
    }

    return err;
}

static bool is_flag(const char *string)
{
    assert(string != NULL);
    return (string[0] == '-');
}

static bool is_valid_flag(const char *string)
{
    int32_t len;

    len = strlen(string);

    if (len == 0 || len == 1) {
        return false;
    }

    if (len == 2 && !(string[0] == '-' && string[1] != '-')) {
        return false;
    }

    if (len > 2 && !(string[0] == '-' && string[1] == '-')) {
        return false;
    }

    return true;
}
