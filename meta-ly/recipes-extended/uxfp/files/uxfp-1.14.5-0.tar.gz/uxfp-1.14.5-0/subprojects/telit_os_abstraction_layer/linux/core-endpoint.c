#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include <telit-os-abs.h>

#define MAX_ENDPOINT_TRANSFER_TIMEOUT_MS (30 * 1000)

#if LIBUSB
static core_res_t endpoint_transfer(const dev_ctx_t *ep, const bool is_write, void *buffer,
        const uint32_t to_transfer, uint32_t *transferred);
static core_res_t endpoint_open(const dev_info_t *info, dev_ctx_t *ep);
static core_res_t endpoint_close(dev_ctx_t *ep);
#endif

#pragma weak core_endpoint_open
core_res_t core_endpoint_open(const dev_info_t *info, dev_ctx_t *ep)
{
#if LIBUSB
    return endpoint_open(info, ep);
#else
    return CORE_ERROR_NOT_IMPLEMENTED;
#endif
}

core_res_t core_endpoint_close(dev_ctx_t *ep)
{
#if LIBUSB
    return endpoint_close(ep);
#else
    return CORE_ERROR_NOT_IMPLEMENTED;
#endif
}

core_res_t core_endpoint_write(const dev_ctx_t *ep, const void *buffer, const uint32_t bytes_to_write,
        uint32_t *bytes_written)
{
#if LIBUSB
    const bool is_write = true;
    return endpoint_transfer(ep, is_write, (char *)buffer, bytes_to_write, bytes_written);
#else
    return CORE_ERROR_NOT_IMPLEMENTED;
#endif
}

core_res_t core_endpoint_read(const dev_ctx_t *ep, void *buffer, const uint32_t bytes_to_read,
        uint32_t *bytes_read)
{
#if LIBUSB
    const bool is_write = false;
    return endpoint_transfer(ep, is_write, buffer, bytes_to_read, bytes_read);
#else
    return CORE_ERROR_NOT_IMPLEMENTED;
#endif
}


#if LIBUSB

/*
 * The documentation of libusb_get_port_numbers() says "As per the USB 3.0
 * specs, the current maximum limit for the depth is 7."
 */
#define USB_MAX_DEPTH 7

static int get_sys_name(char *buf, size_t size, libusb_device *dev)
{
    uint8_t port_numbers[USB_MAX_DEPTH] = {0};
    uint8_t bus_number = 0;
    int valid_elements = 0;
    int inner_ret = 0;
    int ret = 0;
    int i = 0;

    memset(buf, 0, size);
    bus_number = libusb_get_bus_number(dev);
    valid_elements = libusb_get_port_numbers(dev, port_numbers, sizeof(port_numbers));

    if (valid_elements == LIBUSB_ERROR_OVERFLOW) {
        ALOGE("libusb_get_port_numbers error: Array is too small (%u)\n", sizeof(port_numbers));
        goto end;
    }

    if (valid_elements == 0) {  /* Special-case root devices */
        inner_ret = snprintf(buf, size, "usb%d", bus_number);
        ret += inner_ret;
    } else {
        inner_ret = snprintf(buf, size, "%d-", bus_number);
        ret += inner_ret;

        for (i = 0; i < valid_elements && inner_ret >= 0; i++) {
            inner_ret = snprintf(buf + ret, size - ret, i ? ".%d" : "%d", port_numbers[i]);
            ret += inner_ret;
        }
    }

    /* if ret is already a positive value, and snprintf in the loop fails,
     * the loop would be interrupted but ret value would be positive.
     * So, if one snprintf fails, set ret = 0  */
    if (inner_ret <= 0) {
        ret = 0;
    }

end:
    return ret;
}

/* https://stackoverflow.com/questions/58054984/doing-string-startswith-endswith-in-c */
/* return 0 for match, nonzero for no match */
static int string_ends_with(const char *s, const char *t)
{
    size_t slen = strlen(s);
    size_t tlen = strlen(t);
    if (tlen > slen) {
        return 1;
    }
    return strcmp(s + slen - tlen, t);
}

static core_res_t endpoint_open(const dev_info_t *info, dev_ctx_t *ep)
{
    core_res_t err = CORE_ERROR_UNKNOWN;
    uint8_t i, j, k;
    libusb_context *context;
    libusb_device *device;
    libusb_device_handle *handle = NULL;
    struct libusb_config_descriptor *conf_desc;
    usb_id_t usbid = {0};

    if (info->vendor_id[0] == '\0' || info->product_id[0] == '\0') {
        err = CORE_ERROR_EINVAL;
        goto end;
    }

    if (!core_usb_id_from_str(&usbid, info->vendor_id, info->product_id)) {
        ALOGE("could not convert %s:%s\n", info->vendor_id, info->product_id);
        goto end;
    }

    ep->context =  NULL;
    ep->usb_handle =  NULL;
    ep->interface_number =  0;
    ep->read_endpoint_id =  0xFF;
    ep->write_endpoint_id =  0xFF;

    libusb_init(&context);

/* LIBUSB version 1.0.22 deprecated libusb_set_debug */
#if defined(LIBUSB_API_VERSION) && (LIBUSB_API_VERSION >= 0x01000106)
    libusb_set_option(context, LIBUSB_OPTION_LOG_LEVEL, LIBUSB_LOG_LEVEL_INFO);
#else
    libusb_set_debug(context, LIBUSB_LOG_LEVEL_INFO);
#endif

    /* If location path is not populated means device automatic discovery is not available. In this case
     * function string_ends_with() below would never return a match and libusb_open() won't be called in
     * any case resulting in a failure because the handle will be NULL. In this case fallback to the
     * previous way and open the first fastboot device with matching VID/PID */
    if (strlen(info->location_path) == 0) {
        handle = libusb_open_device_with_vid_pid(context, usbid.vid, usbid.pid);
        if (!handle) {
            ALOGE("could not open device 0x%04" PRIX32 ":0x%04" PRIX32 "\n", usbid.vid, usbid.pid);
            err = CORE_ERROR_NO_SUCH_DEVICE;
            goto err;
        }
    } else {
        libusb_device **devs;
        ssize_t dev_num;

        dev_num = libusb_get_device_list(context, &devs);
        if (dev_num < 0) {
            ALOGE("could not find any flashing devices\n");
            err = CORE_ERROR_NO_SUCH_DEVICE;
            goto err;
        }

        for (i = 0; i < dev_num; i++) {
            libusb_device *found = devs[i];
            char sys_name[PATH_MAX];

            if (get_sys_name(sys_name, sizeof(sys_name), found) > 0) {

                if (string_ends_with(info->location_path, sys_name) == 0) {
                    err = libusb_open(found, &handle);
                    if (err) {
                        libusb_free_device_list(devs, dev_num);
                        ALOGE("could not open device 0x%04" PRIX32 ":0x%04" PRIX32 "\n", usbid.vid,
                                usbid.pid);
                        err = CORE_ERROR_NO_SUCH_DEVICE;
                        goto err;
                    }

                    break;
                }
            }
        }

        libusb_free_device_list(devs, dev_num);
    }

    if (!handle) {
        ALOGE("Device not found\n");
        goto clean;
    }

    device = libusb_get_device(handle);
    if (!device) {
        ALOGE("could not get device handle\n");
        goto clean;
    }

    err = libusb_get_active_config_descriptor(device, &conf_desc);
    if (err) {
        ALOGE("could not get active configuration descriptor: error %d\n", err);
        goto clean;
    }

    for (i = 0; i < conf_desc->bNumInterfaces; i++) {                  /* loop through ifaces */
        for (j = 0; j < conf_desc->interface[i].num_altsetting; j++) { /* loop through altsettings */
            const struct libusb_interface_descriptor *alt;

            alt = &conf_desc->interface[i].altsetting[j];

            for (k = 0; k < alt->bNumEndpoints; k++) {  /* loop through endpoints */
                const struct libusb_endpoint_descriptor *endpoint;

                endpoint = &alt->endpoint[k];
                if ((endpoint->bmAttributes & LIBUSB_TRANSFER_TYPE_MASK) &
                        (LIBUSB_TRANSFER_TYPE_BULK | LIBUSB_TRANSFER_TYPE_INTERRUPT)) {

                    if (libusb_kernel_driver_active(handle, i)) {
                        err = libusb_detach_kernel_driver(handle, i);
                        if (err) {
                            ALOGE("could not detach kernel driver: error %d\n", err);
                            break;
                        }
                    }

                    ep->interface_number = i;

                    if (endpoint->bEndpointAddress & LIBUSB_ENDPOINT_IN) {
                        ep->read_endpoint_id = endpoint->bEndpointAddress;
                    } else {
                        ep->write_endpoint_id = endpoint->bEndpointAddress;
                        ep->write_max_pkt_size = endpoint->wMaxPacketSize;
                    }
                }
            }
        }
    }

    libusb_free_config_descriptor(conf_desc);

    if (ep->write_endpoint_id == 0xFF && ep->read_endpoint_id == 0xFF) {
        ALOGE("could not find endpoints\n");
        goto clean;
    }

    ep->usb_handle = handle;
    ep->context = context;

    return err;

clean:
    libusb_close(handle);
err:
    libusb_exit(context);
end:
    return err;
}

static core_res_t endpoint_close(dev_ctx_t *ep)
{
    assert(ep);

    if (ep->usb_handle) {
        libusb_close(ep->usb_handle);
    }
    if (ep->context) {
        libusb_exit(ep->context);
    }

    return CORE_SUCCESS;
}

static core_res_t
endpoint_transfer(const dev_ctx_t *ep, const bool is_write, void *buffer,
        const uint32_t to_transfer, uint32_t *transferred)
{
    core_res_t err = CORE_ERROR_UNKNOWN;
    int32_t inner_err;
    int32_t bytes = 0;
    uint8_t endpoint = is_write ? ep->write_endpoint_id : ep->read_endpoint_id;

    err = libusb_claim_interface(ep->usb_handle, ep->interface_number);
    if (err) {
        ALOGE("could not claim interface %" PRIu8 ": error %d", ep->interface_number, err);
        goto end;
    }

    *transferred = 0;
    inner_err = libusb_bulk_transfer(ep->usb_handle, endpoint, (unsigned char *)buffer, to_transfer, &bytes,
            MAX_ENDPOINT_TRANSFER_TIMEOUT_MS);
    if (inner_err) {
        ALOGE("bulk transfer error %" PRIi32 "\n", inner_err);
        if (inner_err == LIBUSB_ERROR_TIMEOUT) {
            err = CORE_ERROR_TIMEOUT;
        }
    }

    /*ALOGD("transferred %"PRIi32" bytes\n", bytes);*/
    if (bytes) {
        *transferred = (uint32_t)bytes;
    }

    if (is_write && ep->enable_zlp && (to_transfer % ep->write_max_pkt_size) == 0) {
        ALOGD("sending zero-length packet\n");
        inner_err = libusb_bulk_transfer(ep->usb_handle, endpoint, (unsigned char *)buffer, 0, &bytes,
                MAX_ENDPOINT_TRANSFER_TIMEOUT_MS);
        if (inner_err) {
            ALOGE("bulk zlp transfer error %" PRIi32 "\n", inner_err);
            if (inner_err == LIBUSB_ERROR_TIMEOUT) {
                err = CORE_ERROR_TIMEOUT;
            }
        }
    }

    libusb_release_interface(ep->usb_handle, ep->interface_number);

end:
    return err;
}
#endif

