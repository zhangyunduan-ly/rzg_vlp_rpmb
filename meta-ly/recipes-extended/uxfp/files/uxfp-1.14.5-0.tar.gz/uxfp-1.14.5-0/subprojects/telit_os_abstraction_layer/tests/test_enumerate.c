#include "ttest.h"
#include <telit-os-abs.h>

static void test_enumerate_list_of_devices(void);

int main(int argc, char *argv[])
{
    core_res_t err = CORE_ERROR_EINVAL;

    if (argc > 1 && strcmp(argv[1], "debug") == 0) {
        core_log_set_level(LOG_LEVEL_DEBUG);
    } else {
        core_log_set_level(LOG_LEVEL_INFO);
    }

    err = core_init();
    if (err) {
        ALOGE("could not initialize core library\n");
        goto end;
    }

    TTEST_INIT(argc, argv);
    RUN(test_enumerate_list_of_devices);

end:
    return err;
}

/* Given a list of USB IDs pairs, return dev_info_t */
/* of the first device if connected */
void test_enumerate_list_of_devices(void)
{
#define MAX_NUMBER_OF_DEVICES 2
    int32_t err = -1;
    int8_t dev_list_size = MAX_NUMBER_OF_DEVICES;
    dev_info_t dev_list[MAX_NUMBER_OF_DEVICES] = {0};
    /* List of USB IDs to look for */
    usb_id_t usbids[7] = { {0x1bc7, 0x1201},
                           {0x1bc7, 0x1040},
                           {0x1bc7, 0x1041},
                           {0x1bc7, 0x0051},
                           {0x18d1, 0xd00d},
                           {0x1bc7, 0x0036},
                           {0x1bc7, 0x1050} };

    err = core_device_enumerate(usbids, 7, dev_list, &dev_list_size);
    if (err) {
        ALOGD("no device not found\n");
    }
    CHECK_FALSE(err);

    ALOGI("found %" PRIi8 " devices\n", dev_list_size);

    for (int i = 0; i < dev_list_size; ++i) {
        ALOGI("device %s:%s\n", dev_list[i].vendor_id, dev_list[i].product_id);
        ALOGI("\tserial %s\n", dev_list[i].serial);
        ALOGI("\troot path %s\n", dev_list[i].location_path);
        ALOGI("\t#%" PRIu32 " comm_ports'\n",
                dev_list[i].comm_ports_number);

        for (int j = 0; j < dev_list[i].comm_ports_number; j++) {
            ALOGI("\t\tport:%-4s, interface number:%-2s, driver:%s\n",
                    dev_list[i].comm_ports[j], dev_list[i].ifaces[j], dev_list[i].drivers[j]);
        }
    }
#undef MAX_NUMBER_OF_DEVICES
}
