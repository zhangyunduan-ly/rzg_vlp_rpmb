#include <telit-os-abs.h>
#include <ws2tcpip.h>

static core_res_t _core_socket_transfer(const socket_handle_t handle, void *buffer, const uint32_t length,
        const uint32_t msec, bool isWrite, uint32_t *bytes);

core_res_t core_socket_init()
{
    int ret;
    WSADATA wsaData = {0};

    ret = WSAStartup(MAKEWORD(2, 2), &wsaData);

    return (ret ? CORE_ERROR_UNKNOWN : CORE_SUCCESS);
}

core_res_t core_socket_inet_tcp_create(socket_handle_t *handle)
{
    core_res_t ret = CORE_SUCCESS;

    *handle = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (*handle == -1) {
        ERROR_MSG_FMT("error in core_socket_inet_tcp_create", WSAGetLastError());
        ret = CORE_ERROR_UNKNOWN;
    }

    return ret;
}

core_res_t core_socket_inet_tcp_connect(socket_handle_t handle, const char *address, const char *port)
{
    core_res_t ret = CORE_ERROR_EINVAL;
    struct sockaddr_in servaddr;

    if (address && port) {
        memset(&servaddr, 0, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_port = htons(strtol(port, NULL, 10));
        if (inet_pton(AF_INET, address, &(servaddr.sin_addr)) < 1) {
            ALOGE("Invalid address");
            goto end;
        }

        if (connect(handle, (struct sockaddr *)&servaddr, sizeof(servaddr)) == SOCKET_ERROR) {
            ERROR_MSG_FMT("error connecting socket", WSAGetLastError());
            ret = CORE_ERROR_UNKNOWN;
            goto end;
        }

        ret = CORE_SUCCESS;
    }

end:
    return ret;
}

core_res_t core_socket_close(socket_handle_t handle)
{
    int ret;

    ret = closesocket(handle);
    if (ret == SOCKET_ERROR) {
        ERROR_MSG_FMT("error in core_socket_close", WSAGetLastError());
    }

    return (ret ? CORE_ERROR_UNKNOWN : CORE_SUCCESS);
}

core_res_t core_socket_timed_read(const socket_handle_t handle, void *buffer, uint32_t bytes_to_read,
        const uint32_t msec, uint32_t *bytes_read)
{
    return _core_socket_transfer(handle, buffer, bytes_to_read, msec, false, bytes_read);
}

core_res_t core_socket_write(const socket_handle_t handle, const void *buffer, const uint32_t bytes_to_write,
        uint32_t *bytes_written)
{
    return _core_socket_transfer(handle, (void *) buffer, bytes_to_write, WSA_INFINITE, true, bytes_written);
}

core_res_t core_socket_inet_tcp_bind(socket_handle_t handle, const char *address, const char *port)
{
    core_res_t ret = CORE_ERROR_EINVAL;
    struct sockaddr_in servaddr;

    int optVal = 1;
    int optLen = sizeof(optVal);

    if (port) {
        if (setsockopt(handle, SOL_SOCKET, SO_REUSEADDR, (char *)&optVal, optLen) == SOCKET_ERROR) {
            ERROR_MSG_FMT("error in setsockopt", WSAGetLastError());
            ret = CORE_ERROR_UNKNOWN;
            goto end;
        }

        memset(&servaddr, 0, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_port = htons(strtol(port, NULL, 10));
        if (address) {
            servaddr.sin_addr.s_addr = inet_addr(address);
        } else {
            servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
        }

        if (bind(handle, (struct sockaddr *) &servaddr, sizeof(servaddr)) == SOCKET_ERROR) {
            ERROR_MSG_FMT("error in setsockopt", WSAGetLastError());
            ret = CORE_ERROR_UNKNOWN;
            goto end;
        }

        ret = CORE_SUCCESS;
    }

end:
    return ret;
}

core_res_t core_socket_accept(socket_handle_t handle, socket_handle_t *handle_accepted)
{
    core_res_t ret = CORE_SUCCESS;
    socket_handle_t s;

    *handle_accepted = accept(handle, NULL, NULL);
    if (*handle_accepted == INVALID_SOCKET) {
        DWORD err = WSAGetLastError();

        ERROR_MSG_FMT("error in setsockopt", err);
        ret = map_errno_to_core_err(err);
    }

    return ret;
}

core_res_t core_socket_listen(socket_handle_t handle)
{
    core_res_t ret = CORE_SUCCESS;

    if (listen(handle, 0) == SOCKET_ERROR) {
        ERROR_MSG_FMT("error in setsockopt", WSAGetLastError());
        ret = CORE_ERROR_UNKNOWN;
    }

    return ret;
}

core_res_t core_socket_deinit()
{
    int ret;

    ret = WSACleanup();

    return (ret ? CORE_ERROR_UNKNOWN : CORE_SUCCESS);
}

static core_res_t _core_socket_transfer(const socket_handle_t handle, void *buffer, const uint32_t length,
        const uint32_t msec, bool isWrite, uint32_t *bytes)
{
    core_res_t ret = CORE_SUCCESS;
    int ret_socket;
    DWORD err;
    WSABUF dataBuf;
    WSAOVERLAPPED overlapped;
    DWORD flags = 0;

    dataBuf.len = length;
    dataBuf.buf = buffer;

    *bytes = 0;
    SecureZeroMemory((PVOID)&overlapped, sizeof(overlapped));
    overlapped.hEvent = WSACreateEvent();
    if (overlapped.hEvent == NULL) {
        err = WSAGetLastError();

        ERROR_MSG_FMT("error in transferring data", err);
        ret = map_get_last_error_to_core_err(err);
        goto end;
    }

    if (isWrite) {
        ret_socket = WSASend(handle, &dataBuf, 1, bytes, flags, &overlapped, NULL);
    } else {
        ret_socket = WSARecv(handle, &dataBuf, 1, bytes, &flags, &overlapped, NULL);
    }
    if ((ret_socket == SOCKET_ERROR) && (WSA_IO_PENDING != (err = WSAGetLastError()))) {
        ERROR_MSG_FMT("error in transferring data", err);
        ret = map_get_last_error_to_core_err(err);
        goto close_event;
    }

    ret_socket = WSAWaitForMultipleEvents(1, &overlapped.hEvent, TRUE, msec, TRUE);
    if (ret_socket == WSA_WAIT_FAILED) {
        err = WSAGetLastError();
        ERROR_MSG_FMT("error in WSAWaitForMultipleEvents", err);
        ret = map_get_last_error_to_core_err(err);
        goto close_event;
    }

    ret_socket = WSAGetOverlappedResult(handle, &overlapped, bytes, FALSE, &flags);
    if (ret_socket == FALSE) {
        err = WSAGetLastError();
        ERROR_MSG_FMT("error in WSAGetOverlappedResult", err);
        ret = map_get_last_error_to_core_err(err);
    }

close_event:
    WSACloseEvent(overlapped.hEvent);

end:
    return ret;
}

