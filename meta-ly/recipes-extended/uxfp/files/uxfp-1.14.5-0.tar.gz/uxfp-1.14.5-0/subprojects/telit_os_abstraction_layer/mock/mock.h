#ifndef _MOCK_H_
#define _MOCK_H_

#include "telit-os-abs.h"

#define MAX_CORE_RES_QUEUE 20

/**
 * @brief list of core_res_t values
 */
typedef struct {
    int32_t next;
    core_res_t err[MAX_CORE_RES_QUEUE];
} core_res_queue_t;

#endif  /* _MOCK_H_ */
