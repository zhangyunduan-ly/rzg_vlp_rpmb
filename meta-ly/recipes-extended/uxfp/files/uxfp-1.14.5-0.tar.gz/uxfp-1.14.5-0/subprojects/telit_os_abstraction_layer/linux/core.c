#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1
#endif

#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>

#ifndef ANDROID
#include <syslog.h>
#endif

#include <telit-os-abs.h>


sig_atomic_t sigint_detected = 0;
extern bool is_log_native_enabled;

core_res_t map_errno_to_core_err(int err)
{
    core_res_t ret;

    switch (err) {
        case EPERM:
            ret = CORE_ERROR_OPERATION_NOT_PERMITTED;
            break;
        case ENOENT:
            ret = CORE_ERROR_FILE_NOT_FOUND;
            break;
        case EINTR:
            ret = CORE_ERROR_EINTR;
            break;
        case EIO:
            ret = CORE_ERROR_IO_ERROR;
            break;
        case EAGAIN:
            ret = CORE_ERROR_TRY_AGAIN;
            break;
        case EACCES:
            ret = CORE_ERROR_PERMISSION_DENIED;
            break;
        case EBUSY:
            ret = CORE_ERROR_DEVICE_BUSY;
            break;
        case ENODEV:
            ret = CORE_ERROR_NO_SUCH_DEVICE;
            break;
        case EINVAL:
            ret = CORE_ERROR_EINVAL;
            break;
        case ETIMEDOUT:
            ret = CORE_ERROR_TIMEOUT;
            break;
        case ENOSPC:
            ret = CORE_ERROR_ENOSPC;
            break;
        default:
            ret = CORE_ERROR_UNKNOWN;
    }

    return ret;
}

core_res_t core_init(void)
{
    return 0;
}

void core_deinit(void)
{
    core_log_deinit();
}

void core_sleep(const uint32_t timeout_ms)
{
    usleep(timeout_ms * 1000);
}

void core_signal_notify(const int sig)
{
    switch (sig) {
        case SIGINT:
            sigint_detected = 1;
            break;
    }
}

core_res_t core_get_time_of_day(core_timeval_t *tv)
{
    core_res_t ret = CORE_SUCCESS;
    struct timeval t;

    tv->tv_sec = 0;
    tv->tv_usec = 0;

    if (gettimeofday(&t, NULL)) {
        int err = errno;

        ALOGE("error in get time of day %d, %s\n", err, strerror(err));
        ret = map_errno_to_core_err(err);
    } else {
        tv->tv_sec = (uint32_t) t.tv_sec;
        tv->tv_usec = (uint32_t) t.tv_usec;
    }

    return ret;
}

static void _ec_mtoh(void *dest, size_t dest_size, uint64_t src)
{
    if (dest_size == 8) {
        uint64_t src_to_be_converted = src;
        uint64_t *dest_value = dest;

        *dest_value = le64toh(src_to_be_converted);
    } else if (dest_size == 4) {
        uint32_t src_to_be_converted = src;
        uint32_t *dest_value = dest;

        *dest_value = le32toh(src_to_be_converted);
    } else if (dest_size == 2) {
        uint16_t src_to_be_converted = src;
        uint16_t *dest_value = dest;

        *dest_value = le16toh(src_to_be_converted);
    } else if (dest_size == 1) {
        uint8_t *dest_value = dest;

        *dest_value = src;
    } else {
        ALOGW("%s: destination size %zu not supported", __FUNCTION__, dest_size);
    }
}

void core_letoh(void *dest, size_t dest_size, void *src, size_t src_size)
{
    if (dest_size != src_size) {
        ALOGE("dest_size %zu != src_size %zu", dest_size, src_size);
    }

    switch (src_size) {
        case 1: {
            uint8_t *src_value = src;

            _ec_mtoh(dest, dest_size, *src_value);
            break;
        }
        case 2: {
            uint16_t *src_value = src;

            _ec_mtoh(dest, dest_size, *src_value);
            break;
        }
        case 4: {
            uint32_t *src_value = src;

            _ec_mtoh(dest, dest_size, *src_value);
            break;
        }
        case 8: {
            uint64_t *src_value = src;

            _ec_mtoh(dest, dest_size, *src_value);
            break;
        }
        default:
            ALOGW("%s: source size %zu not supported", __FUNCTION__, src_size);
    }
}

static void _ec_htom(void *dest, size_t dest_size, uint64_t src)
{
    if (dest_size == 8) {
        uint64_t src_to_be_converted = src;
        uint64_t *dest_value = dest;

        *dest_value = htole64(src_to_be_converted);
    } else if (dest_size == 4) {
        uint32_t src_to_be_converted = src;
        uint32_t *dest_value = dest;

        *dest_value = htole32(src_to_be_converted);
    } else if (dest_size == 2) {
        uint16_t src_to_be_converted = src;
        uint16_t *dest_value = dest;

        *dest_value = htole16(src_to_be_converted);
    } else if (dest_size == 1) {
        uint8_t *dest_value = dest;

        *dest_value = src;
    } else {
        ALOGW("%s: destination size %zu not supported", __FUNCTION__, dest_size);
    }
}

void core_htole(void *dest, size_t dest_size, void *src, size_t src_size)
{
    if (dest_size != src_size) {
        ALOGE("dest_size %zu != src_size %zu", dest_size, src_size);
    }

    switch (src_size) {
        case 1: {
            uint8_t *src_value = src;

            _ec_htom(dest, dest_size, *src_value);
            break;
        }
        case 2: {
            uint16_t *src_value = src;

            _ec_htom(dest, dest_size, *src_value);
            break;
        }
        case 4: {
            uint32_t *src_value = src;

            _ec_htom(dest, dest_size, *src_value);
            break;
        }
        case 8: {
            uint64_t *src_value = src;

            _ec_htom(dest, dest_size, *src_value);
            break;
        }
        default:
            ALOGW("%s: source size %zu not supported", __FUNCTION__, src_size);
    }
}

core_res_t core_log_set_native(const bool enable)
{
#ifndef ANDROID
    is_log_native_enabled = enable;
    if (enable) {
        core_log_set_print(syslog);
    } else {
        core_log_set_print(stdout_print);
    }

    return CORE_SUCCESS;
#else
    return CORE_ERROR_NOT_IMPLEMENTED;
#endif
}

char *core_str_case_str(const char *haystack, const char *needle)
{
    return strcasestr(haystack, needle);
}

core_res_t core_get_time(struct timespec *ts)
{
    core_res_t ret = CORE_SUCCESS;

    if (-1 == clock_gettime(CLOCK_MONOTONIC, ts)) {
        ret = CORE_ERROR_OPERATION_NOT_PERMITTED;
    }

    return ret;
}
