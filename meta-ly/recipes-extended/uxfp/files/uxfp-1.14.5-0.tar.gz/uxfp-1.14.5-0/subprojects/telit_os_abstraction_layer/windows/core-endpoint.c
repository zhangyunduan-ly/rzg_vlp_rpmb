#include <inttypes.h>
#include <telit-os-abs.h>

static core_res_t core_endpoint_transfer(const dev_ctx_t *ep, const bool is_write, const void *buffer,
        const uint32_t to_transfer, uint32_t *transferred);

core_res_t core_endpoint_open(const dev_info_t *dev_info, dev_ctx_t *ep)
{
    core_res_t err = CORE_ERROR_UNKNOWN;
    bool ok;
    const char *device_path;
    UCHAR endpoint;
    UCHAR iface_number;
    ULONG bytes_written;
    USB_CONFIGURATION_DESCRIPTOR usb_config_descriptor;
    USB_INTERFACE_DESCRIPTOR usb_iface_descriptor;
    USB_DEVICE_DESCRIPTOR usb_device_descriptor;

    device_path = dev_info->comm_ports[0];

    /* Consider 0xFF an invalid endpoint */
    ep->read_endpoint_id = 0xFF;
    ep->write_endpoint_id = 0xFF;
    ep->handle = CreateFile(device_path,
            GENERIC_READ | GENERIC_WRITE,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            NULL,
            OPEN_EXISTING,
            FILE_FLAG_OVERLAPPED,
            0);
    if (ep->handle == INVALID_DEVICE_HANDLE) {
        ALOGE("invalid device handle from device path '%s'\n", device_path);
        goto fail;
    }

    ok = WinUsb_Initialize(ep->handle, &ep->usb_iface_handle);
    if (!ok) {
        ERROR_MSG_FMT("could not initialize winusb", GetLastError());
        goto clean;
    }

    ok = WinUsb_GetCurrentAlternateSetting(ep->usb_iface_handle, &iface_number);
    if (!ok) {
        ERROR_MSG_FMT("could not get alternate settings", GetLastError());
        goto deinitialize;
    }

    ok = WinUsb_GetDescriptor(ep->usb_iface_handle,
            USB_DEVICE_DESCRIPTOR_TYPE,
            0,
            0,
            (UCHAR *)&usb_device_descriptor,
            sizeof(usb_device_descriptor),
            &bytes_written);
    if (!ok) {
        ERROR_MSG_FMT("could not get device descriptor type", GetLastError());
        goto deinitialize;
    }

    ok = WinUsb_GetDescriptor(ep->usb_iface_handle,
            USB_CONFIGURATION_DESCRIPTOR_TYPE,
            0,
            0,
            (UCHAR *)&usb_config_descriptor,
            sizeof(usb_config_descriptor),
            &bytes_written);
    if (!ok) {
        ERROR_MSG_FMT("could not get configuration descriptor type", GetLastError());
        goto deinitialize;
    }

    ok = WinUsb_QueryInterfaceSettings(ep->usb_iface_handle,
            iface_number,
            &usb_iface_descriptor);
    if (!ok) {
        ERROR_MSG_FMT("could not usb interface descriptor", GetLastError());
        goto deinitialize;
    }

    for (endpoint = 0; endpoint < usb_iface_descriptor.bNumEndpoints; endpoint++) {
        WINUSB_PIPE_INFORMATION pipe;

        ok = WinUsb_QueryPipe(ep->usb_iface_handle, iface_number, endpoint, &pipe);
        if (!ok) {
            ERROR_MSG_FMT("could not get pipe info", GetLastError());
            goto deinitialize;
        }

        if (pipe.PipeType != UsbdPipeTypeBulk) {
            continue;
        }

        if (pipe.PipeId & USB_ENDPOINT_DIRECTION_MASK) {
            ep->read_endpoint_id = pipe.PipeId;
            ALOGD("using 0x%02" PRIX8 " as default bulk read endpoint\n",
                    ep->read_endpoint_id);
        } else {
            ep->write_endpoint_id = pipe.PipeId;
            ALOGD("using 0x%02" PRIX8 " as default bulk write endpoint\n",
                    ep->write_endpoint_id);
        }
    }

    if (ep->read_endpoint_id == 0xFF || ep->write_endpoint_id == 0xFF) {
        ALOGE("could not find any endpoint\n");
        err = CORE_ERROR_NO_SUCH_DEVICE;
        goto deinitialize;
    }

    return CORE_SUCCESS;

deinitialize:
    core_endpoint_close(ep);

clean:
    core_device_close(ep->handle);

fail:
    return err;
}

core_res_t core_endpoint_close(dev_ctx_t *ep)
{
    bool ok;

    ok = WinUsb_Free(ep->usb_iface_handle);
    if (!ok) {
        ERROR_MSG_FMT("could not close endpoint interface handle", GetLastError());
    }

    return core_device_close(ep->handle);
}


core_res_t core_endpoint_write(const dev_ctx_t *ep, const void *buffer, const uint32_t bytes_to_write,
        uint32_t *bytes_written)
{
    const bool is_write = true;
    return core_endpoint_transfer(ep, is_write, buffer, bytes_to_write, bytes_written);
}

core_res_t core_endpoint_read(const dev_ctx_t *ep, void *buffer, const uint32_t bytes_to_read,
        uint32_t *bytes_read)
{
    const bool is_write = false;
    return core_endpoint_transfer(ep, is_write, buffer, bytes_to_read, bytes_read);
}

static core_res_t
core_endpoint_transfer(const dev_ctx_t *ep, const bool is_write, const void *buffer,
        const uint32_t to_transfer, uint32_t *transferred)
{
    core_res_t err = CORE_ERROR_UNKNOWN;
    bool ok;
    ULONG timeout = 500 + (to_transfer * 8);
    OVERLAPPED overlapped;

    ZeroMemory(&overlapped, sizeof(overlapped));
    overlapped.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

    ok = WinUsb_SetPipePolicy(ep->usb_iface_handle,
            ep->write_endpoint_id,
            PIPE_TRANSFER_TIMEOUT,
            sizeof(ULONG),
            &timeout);
    if (!ok) {
        ERROR_MSG_FMT("could not set pipe transfer timeout", GetLastError());
        goto clean;
    }

    if (is_write) {
        ok = WinUsb_WritePipe(ep->usb_iface_handle,
                ep->write_endpoint_id,
                (PUCHAR)buffer,
                to_transfer,
                transferred,
                &overlapped);
    } else {
        ok = WinUsb_ReadPipe(ep->usb_iface_handle,
                ep->read_endpoint_id,
                (PUCHAR)buffer,
                to_transfer,
                transferred,
                &overlapped);
    }
    err = GetLastError();
    if (!ok && err != ERROR_IO_PENDING) {
        if (is_write) {
            ERROR_MSG_FMT("could not write to endpoint", err);
        } else {
            ERROR_MSG_FMT("could not read from endpoint", err);
        }
        err = CORE_ERROR_UNKNOWN;
        goto end;
    }

    /*ALOGD("waiting for %s result...\n", is_write? "write" : "read");*/
    ok = WinUsb_GetOverlappedResult(ep->usb_iface_handle,
            &overlapped,
            transferred,
            TRUE);
    if (!ok) {
        if (is_write) {
            ERROR_MSG_FMT("could not get write result", GetLastError());
        } else {
            ERROR_MSG_FMT("could not get read result", GetLastError());
        }
        err = CORE_ERROR_UNKNOWN;
        goto clean;
    }

    /*ALOGD("%s %"PRIu32" bytes\n", is_write? "written" : "read", *transferred);*/
    err = CORE_SUCCESS;

clean:
    if (overlapped.hEvent) {
        CloseHandle(overlapped.hEvent);
    }
end:
    return err;
}

