#include "telit-os-abs.h"
#include <stdio.h>
#include <stdlib.h>

#define SIZE 5897

int main(int c, char **v)
{
    uint8_t buf[SIZE];

    for (int i = 0; i < SIZE; i++) {
        buf[i] = rand() % 70;
    }

    core_log_set_level(LOG_LEVEL_DEBUG);

    core_print_buffer(buf, SIZE, 24);
}

