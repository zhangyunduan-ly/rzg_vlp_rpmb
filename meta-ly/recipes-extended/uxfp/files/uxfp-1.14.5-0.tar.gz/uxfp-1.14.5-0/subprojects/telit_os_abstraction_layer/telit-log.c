#include <assert.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <inttypes.h>
#include <errno.h>
#include <version.h>

#include "telit-os-abs.h"

#define MAX_HEADER_LEN     256
#define MAX_MSG_LEN        1024
#define HEADER_FORMAT      "%" PRId64 ".%.9ld %s %-s:%03d:%s() "
#define MSG_FORMAT         "%s%s"
#define MSG_FORMAT_NEWLINE "%s%s\n"

#define JSON_TYPE_LOG_FMT "{\"timestamp\": \"%" PRIu64 \
        ".%.9ld\", \"type\": \"LOG\", \"severity\":\"%s\", \"file\": \"%s\", \"function\": \"%s\", \"line\": %d, \"msg\": \"%s\"}\n"
#define JSON_TYPE_PROGRESS_FMT "{\"timestamp\": \"%" PRIu64 ".%.9ld\", \"type\": \"PROGRESS\", \"current\": %" \
        PRId64 ", \"max\": %" PRId64 ", \"percent\": %d, \"description\": \"%s\"}\n"
#define JSON_TYPE_CUSTOM_FMT "{\"timestamp\": \"%" PRIu64 ".%.9ld\", \"type\": \"%s\", %s}\n"

static char *level_tag[] = {
    [LOG_LEVEL_EMERG] = "EMR",
    [LOG_LEVEL_ALERT] = "ALR",
    [LOG_LEVEL_CRIT] = "CRT",
    [LOG_LEVEL_ERR] = "ERR",
    [LOG_LEVEL_WARNING] = "WRN",
    [LOG_LEVEL_NOTICE] = "NOT",
    [LOG_LEVEL_INFO] = "INF",
    [LOG_LEVEL_DEBUG] = "DBG",
    [LOG_LEVEL_VERBOSE] = "VRB"
};


typedef void (*pprint_t)(const int level, const char *file, const char *function, const int line, void *data);

static void autonewline_log(const int level, const char *file, const char *function, const int line,
        void *message);
static void raw_log(const int level, const char *file, const char *function, const int line, void *message);

static void core_log_add_header(const int level, const char *file, const char *function, const int line,
        char *header);

static core_log_print_t print = stdout_print;
static pprint_t pprint = raw_log;

static char *json_buffer = NULL;
static uint32_t json_buffer_size = 0;

/* Native (OS dependent) logging defaults to disabled */
bool is_log_native_enabled = false;

/* Logging level defaults to INFO level */
static uint32_t max_log_level = LOG_LEVEL_INFO;


static bool core_log_library_enabled = true;
void core_log_library(const bool enable)
{
    core_log_library_enabled = enable;
}

void core_log_set_pprint(const core_log_pprint_t id)
{
    switch (id) {
        case CORE_LOG_PPRINT_AUTONEWLINE:
            pprint = autonewline_log;
            break;
        case CORE_LOG_PPRINT_JSON:
            errno = 0;
            if (setvbuf(stdout, NULL, _IONBF, 0) != 0) {
                ALOGW("could not disable buffering on stdout: error %d\n", errno);
            }
            errno = 0;
            if (setvbuf(stderr, NULL, _IONBF, 0) != 0) {
                ALOGW("could not disable buffering on stderr: error %d\n", errno);
            }

            pprint = core_log_json;
            break;
        case CORE_LOG_PPRINT_RAW:
        default:
            pprint = raw_log;
            break;
    }
}

void core_log_set_level(const uint32_t level)
{
    max_log_level = level;
}

uint32_t core_log_get_level(void)
{
    return max_log_level;
}

void core_log(const int level, const char *file, const char *function, const int line, const char *fmt, ...)
{
    char message[MAX_MSG_LEN + 1] = {0};

    if (!core_log_library_enabled
            && (file != NULL)
            && strstr(file, "core-") != 0) {
        return;
    }

    if (max_log_level < level) {
        return;
    }

    va_list ap;
    va_start(ap, fmt);
    vsnprintf(message, MAX_MSG_LEN, fmt, ap);
    pprint(level, file, function, line, message);
    va_end(ap);
}

void core_print_tosal_version(void)
{
    ALOGI("\rTosal version %s.%s.%s-%s\n",
            MAJOR, MINOR, PATCH, CUST);
}

static void core_log_add_header(const int level, const char *file, const char *function, const int line,
        char *header)
{
    struct timespec ts = {0};

    if (max_log_level != LOG_LEVEL_INFO && (file && line && function)) {
        if (CORE_SUCCESS != core_get_time(&ts)) {
            print(LOG_LEVEL_ERR, "%s", "could not get time for logs\n");
        }

        snprintf(header, MAX_HEADER_LEN, HEADER_FORMAT, (uint64_t)ts.tv_sec, ts.tv_nsec, level_tag[level],
                file, line, function);
    }
}

static void raw_log(const int level, const char *file, const char *function, const int line, void *data)
{
    char header[MAX_HEADER_LEN + 1] = {0};
    char *message = (char *)data;

    core_log_add_header(level, file, function, line, header);

    print(level, MSG_FORMAT, header, message);
}

static void autonewline_log(const int level, const char *file, const char *function, const int line,
        void *data)
{
    size_t len;
    char *message_format = NULL;
    char header[MAX_HEADER_LEN + 1] = {0};
    char *message = (char *)data;

    core_log_add_header(level, file, function, line, header);

    len = strnlen(message, MAX_MSG_LEN);
    message_format = (len == 0 || (message[len - 1] != '\n' && message[len - 1] != '\r')) ?
            MSG_FORMAT_NEWLINE :
            MSG_FORMAT;

    print(level, message_format, header, message);
}

bool core_json_set_buffer(char *buffer, uint32_t size)
{
    if (!buffer || !size) {
        return false;
    }

    json_buffer = buffer;
    json_buffer_size = size;

    return true;
}

/**
 * @brief remove JSON unsupported characters from message
 *
 * @param[in/out] message the message to be sanitized
 */
static void sanitize_json(char *message)
{
    size_t len = strlen(message);
    if (len > 0 && message[len - 1] == '\n') {
        message[len - 1] = 0;
    }
}
/**
 * @brief compose a string in form of "key=value" out of the given #json_t list
 *
 * @param entries a list of #json_t
 * @param json the output json string
 * @param json_len the len of the output json string
 *
 * @return the len of the generated json string
 */
uint32_t json_compose(json_t *entries, char *json, const uint32_t json_len)
{
#define STRING_VALUE_NOT_LAST_ITEM_FMT     "\"%s\": \"%s\", "
#define STRING_VALUE_LAST_ITEM_FMT         "\"%s\": \"%s\""
#define NOT_STRING_VALUE_NOT_LAST_ITEM_FMT "\"%s\": %s, "
#define NOT_STRING_VALUE_LAST_ITEM_FMT     "\"%s\": %s"
    uint32_t i;
    uint32_t len = 0;
    bool not_enough_space = false;

    memset(json, 0, json_len);
    for (i = 0; entries[i].type != VALUE_TYPE_UNKNOWN; ++i) {
        /* Always use maximum possible length and check for proper value later */
        char value[MAX_JSON_MESSAGE_ARRAY_LEN] = {0};
        char entry[MAX_JSON_ARRAY_ENTRY_LEN] = {0};
        char *fmt;
        int printed;

        switch (entries[i].type) {
            case VALUE_TYPE_BOOLEAN:
                snprintf(value, MAX_JSON_MESSAGE_LEN, "%s",
                        *((bool *)entries[i].value) == true ? "true" : "false");
                break;
            case VALUE_TYPE_INT:
                snprintf(value, MAX_JSON_MESSAGE_LEN, "%d", *(int32_t *)entries[i].value);
                break;
            case VALUE_TYPE_LONG:
                snprintf(value, MAX_JSON_MESSAGE_LEN, "%" PRId64 "", *(int64_t *)entries[i].value);
                break;
            case VALUE_TYPE_ULONG:
                snprintf(value, MAX_JSON_MESSAGE_LEN, "%" PRIu64 "", *(uint64_t *)entries[i].value);
                break;
            case VALUE_TYPE_STRING:
                snprintf(value, MAX_JSON_MESSAGE_LEN, "%s", (char *)entries[i].value);
                break;
            case VALUE_TYPE_ARRAY: {
                uint8_t array_sz, j;
                uint16_t value_array_len = 0;
                uint16_t max_net_len;

                if (entries[i + 1].type != VALUE_TYPE_ARRAY_SIZE) {
                    ALOGE("malformed array entry");
                    continue;
                }
                array_sz = *(uint8_t *)entries[i + 1].value;
                snprintf(value, MAX_JSON_MESSAGE_ARRAY_LEN, "[");
                value_array_len++;
                /* The maximum net len is given as:
                 * MAX_JSON_MESSAGE_ARRAY_LEN: the size of the buffer
                 * -1: [
                 * -1: ]
                 * -1: '\0'
                 * - (3 * array_sz) + 1: { }, for each entries besides the last one for which the , is missing
                 */
                max_net_len = MAX_JSON_MESSAGE_ARRAY_LEN - 1 - 1 - 1 - (3 * array_sz) + 1;
                for (j = 0; j < array_sz; j++) {
                    int32_t message_len;
                    json_t * const *arr_entry = entries[i].value;

                    strcat(value, "{");
                    value_array_len++;
                    message_len = json_compose(arr_entry[j],
                            value + value_array_len,
                            max_net_len - value_array_len);
                    if (max_net_len - value_array_len < message_len) {
                        ALOGE("unable to compose array entry %" PRIu8 "", j);
                        goto end;
                    }
                    value_array_len += message_len;
                    strcat(value, "}");
                    value_array_len++;
                    if (j != array_sz - 1) {
                        strcat(value, ",");
                        value_array_len++;
                    }
                }
                value[value_array_len] = ']';
                value_array_len++;
                break;
            }
            case VALUE_TYPE_ARRAY_SIZE:
                continue;
            case VALUE_TYPE_UNKNOWN:
            default:
                ALOGE("unknown type value %u for entry %u\n", entries[i].type, i);
                return false;
        }

        if (entries[i].type == VALUE_TYPE_ARRAY) {
            fmt = (entries[i + 2].type) == VALUE_TYPE_UNKNOWN ?
                    NOT_STRING_VALUE_LAST_ITEM_FMT :
                    NOT_STRING_VALUE_NOT_LAST_ITEM_FMT;
        } else if (entries[i].type != VALUE_TYPE_STRING ||
                strlen(value) == 0) {
            fmt = (entries[i + 1].type) == VALUE_TYPE_UNKNOWN ?
                    NOT_STRING_VALUE_LAST_ITEM_FMT :
                    NOT_STRING_VALUE_NOT_LAST_ITEM_FMT;
        } else {
            fmt = (entries[i + 1].type) == VALUE_TYPE_UNKNOWN ?
                    STRING_VALUE_LAST_ITEM_FMT :
                    STRING_VALUE_NOT_LAST_ITEM_FMT;
        }

        if (entries[i].type == VALUE_TYPE_ARRAY) {
            printed = snprintf(entry, MAX_JSON_ARRAY_ENTRY_LEN, fmt,
                    entries[i].key,
                    strcmp(value, "[{}]") != 0 ? value : "null");
        } else {
            printed = snprintf(entry, MAX_JSON_ENTRY_LEN, fmt,
                    entries[i].key,
                    strlen(value) > 0 ? value : "null");
        }

        if (printed >=
                (entries[i].type == VALUE_TYPE_ARRAY ? MAX_JSON_ARRAY_ENTRY_LEN : MAX_JSON_ENTRY_LEN)) {
            ALOGE("truncated message\n");
            not_enough_space = true;
        } else {
            /* Codesonar complains that printed can be negative, since snprintf
             * returns -1 in case of truncated output if glibc < 2.1*/
            len += printed;
        }

        if (json_len < len) {
            not_enough_space = true;
        }

        if (!not_enough_space) {
            strcat(json, entry);
        }
    }

end:
#undef STRING_VALUE_NOT_LAST_ITEM_FMT
#undef STRING_VALUE_LAST_ITEM_FMT
#undef NOT_STRING_VALUE_LAST_ITEM_FMT
#undef NOT_STRING_VALUE_NOT_LAST_ITEM_FMT
    return len;
}

void core_log_json(const int level, const char *file, const char *function, const int line, void *data)
{
    struct timespec ts = {0};
    uint32_t json_sz = 0;

    if (!core_log_library_enabled
            && (file != NULL)
            && strstr(file, "core-") != 0) {
        return;
    }

    if (!timespec_get(&ts, TIME_UTC)) {
        ALOGE("could not get time for logs\n");
    }

    if (function != NULL && strcmp(function, JSON_TYPE_PROGRESS) == 0) {
        json_progress_t *progress = (json_progress_t *)data;
        int8_t percent = (progress->max <= 0) ?
                -1 : (100 * progress->current) / progress->max;

        print(level, JSON_TYPE_PROGRESS_FMT, (uint64_t) ts.tv_sec, ts.tv_nsec,
                progress->current, progress->max, percent, progress->description);

    } else if (function != NULL && strcmp(function, JSON_TYPE_CUSTOM) == 0) {
        char *message;
        int32_t entries_num;
        uint32_t message_len;
        json_t *entries = (json_t *)data;

        for (entries_num = 0; entries[entries_num].key != NULL; ++entries_num)
            ;
        switch (entries_num) {
            case 0:
                ALOGE("could not find any JSON data\n");
                return;
            case 1:
                ALOGE("custom JSON data only has the type '%s'\n", (char *)entries[0].value);
                return;
            default:
                /* The first key is the JSON_TYPE and it is ignored */
                entries_num -= 1;
                break;
        }

        /* TODO consider an internal limit to avoid smashing the stack */
        if (json_buffer) {
            /* Use buffer provided by the application */
            message = json_buffer;
            json_sz = json_buffer_size;
        } else {
            /* Using a size_t to allocate size, since the multiplication might
             * overflow an int32 type. Codesonar still complains because it is
             * theoretically possible overflow for some entries_num values */
            size_t size = (size_t)(entries_num) * (size_t)MAX_JSON_MESSAGE_LEN;
            message = (char *)alloca(size + 1);
            json_sz = entries_num * MAX_JSON_MESSAGE_LEN;
        }
        /* Compose the json message skipping the item zero, which is the JSON_TYPE */
        message_len = json_compose(&(entries[1]), message, json_sz);
        if (message_len > json_sz) {
            ALOGE("json string error: not enough space (%" PRIu32 " < %" PRIu32 ")\n",
                    json_sz, message_len);
            return;
        }

        print(level, JSON_TYPE_CUSTOM_FMT, (uint64_t) ts.tv_sec, ts.tv_nsec, entries[0].value, message);
    } else {
        char *message = (char *)data;

        sanitize_json(message);
        print(level, JSON_TYPE_LOG_FMT, (uint64_t) ts.tv_sec, ts.tv_nsec,
                level_tag[level], file, function, line, message);
    }
}


#define LOG_PRINTED_BYTE_SIZE 3

static void internal_print_buffer(uint8_t *buffer, uint32_t len, uint32_t span, const int level)
{
    char *string = NULL;
    uint32_t offset = 0;
    uint64_t size = (uint64_t)span * (uint64_t)LOG_PRINTED_BYTE_SIZE + 1;

    if (!buffer) {
        core_log(LOG_LEVEL_ERR, NULL, NULL, 0, "Passed buffer pointer is null\n");
        return;
    }

    core_log(level, NULL, NULL, 0,
            "Printing buffer %p of %u bytes\n", buffer, len);

    string = (char *)calloc(size, sizeof(char));

    if (string == NULL) {
        core_log(LOG_LEVEL_ERR, NULL, NULL, 0, "String allocation error\n");
        return;
    }

    while (offset < len) {
        uint32_t i;

        for (i = 0; i < span && offset < len; i++, offset++) {
            char tmp[LOG_PRINTED_BYTE_SIZE + 1] = {0};
            snprintf(tmp, LOG_PRINTED_BYTE_SIZE + 1, "%02X ", buffer[offset]);
            memcpy(&string[i * LOG_PRINTED_BYTE_SIZE], tmp, LOG_PRINTED_BYTE_SIZE);
        }

        core_log(level, NULL, NULL, 0, "[%04u] %s\n", offset - i, string);
        memset(string, '\0', size);
    }

    free(string);
}

void core_print_buffer_to_level(uint8_t *buffer, uint32_t len, uint32_t span, const int level)
{
    if (max_log_level < level) {
        return;
    }

    internal_print_buffer(buffer, len, span, level);
}

void core_print_buffer(uint8_t *buffer, uint32_t len, uint32_t span)
{
    core_print_buffer_to_level(buffer, len, span, LOG_LEVEL_DBG);
}

void stdout_print(const int level, const char *fmt, ...)
{
    FILE *stream;
    va_list ap;

    if (level == LOG_LEVEL_EMERG || level == LOG_LEVEL_ALERT ||
            level == LOG_LEVEL_CRIT || level == LOG_LEVEL_ERR) {
        stream = stderr;
    } else {
        stream = stdout;
    }

    va_start(ap, fmt);
    vfprintf(stream, fmt, ap);
    va_end(ap);
}

bool core_log_is_native()
{
    return is_log_native_enabled;
}

bool json_update(json_t *entries, int8_t id, const void *value, vtype_t type)
{
    if (id < 0) {
        ALOGE("could not update JSON: ID is negative\n");
        return false;
    }
    if (!value) {
        ALOGE("could not update JSON ID %d (%s): value address is NULL\n",
                id, entries[id].key);
        return false;
    }

    entries[id].type = type;
    entries[id].value = value;

    return true;
}

static FILE *output_stream = NULL;

void file_print(const int level, const char *fmt, ...)
{
    va_list ap;

    assert(output_stream != NULL);

    va_start(ap, fmt);
    vfprintf(output_stream, fmt, ap);
    va_end(ap);
}

core_res_t core_log_set_output(const char *filename, bool append)
{
    core_res_t err = CORE_SUCCESS;
    char *mode = append ? "a" : "w";
    errno = 0;
    output_stream = fopen(filename, mode);
    if (!output_stream) {
        ALOGE("could not open file %s for logging: error %d, %s\n",
                filename, errno, strerror(errno));
        err = map_errno_to_core_err(errno);
    } else {
        core_log_set_print(file_print);
    }

    return err;
}

void core_log_unset_output()
{
    if (output_stream == NULL) {
        return;
    }
    fflush(output_stream);
    fclose(output_stream);
    output_stream = NULL;
    core_log_set_print(stdout_print);
}

core_res_t core_log_set_print(core_log_print_t new_print)
{
    if (new_print == file_print && output_stream == NULL) {
        ALOGE("No output file path set");
        return CORE_ERROR_OPERATION_NOT_PERMITTED;
    }
    print = new_print;
    return CORE_SUCCESS;
}

void core_log_deinit()
{
    if (output_stream != NULL) {
        fclose(output_stream);
    }
}
