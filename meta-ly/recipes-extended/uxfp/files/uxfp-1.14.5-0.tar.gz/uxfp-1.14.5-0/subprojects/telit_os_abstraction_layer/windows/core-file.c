#include <fcntl.h>
#include <sys\stat.h>
#include <inttypes.h>

#include <telit-os-abs.h>


static int32_t core_file_lseek(file_handle_t handle, int64_t offset, int32_t origin);

core_res_t core_file_exists(const char *file_path)
{
    return (PathFileExists(file_path)) ? CORE_SUCCESS : CORE_ERROR_FILE_NOT_FOUND;
}

core_res_t core_file_open(const char *file_path, file_handle_t *handle)
{
    core_res_t err = CORE_SUCCESS;

    errno = 0;
    *handle = _open(file_path, _O_BINARY | _O_RDWR | _O_CREAT, _S_IREAD | _S_IWRITE);
    if (errno) {
        int error = errno;
        ALOGE("could not open file %s: error %d\n", file_path, error);
        err = map_errno_to_core_err(error);
    }

    return err;
}

core_res_t core_file_close(const file_handle_t handle)
{
    core_res_t err = CORE_SUCCESS;
    int32_t ret;

    errno = 0;
    ret = _close(handle);
    if (ret != 0) {
        int error = errno;
        ALOGE("could not close file: error %d\n", error);
        err = map_errno_to_core_err(error);
    }

    return err;
}

core_res_t core_file_read(const file_handle_t handle, void *buffer, uint32_t bytes_to_read,
        uint32_t *bytes_read)
{
    core_res_t ret = CORE_SUCCESS;
    int32_t bread;

    *bytes_read = 0;
    bread = _read(handle, buffer, bytes_to_read);
    if (bread == -1) {
        int err = errno;

        ALOGE("could not read from file: error %d\n", err);
        ret = map_errno_to_core_err(err);
    } else {
        *bytes_read = bread;
    }

    return ret;
}

core_res_t core_file_write(const file_handle_t handle, const void *buffer, const uint32_t bytes_to_write,
        uint32_t *bytes_written)
{
    core_res_t ret = CORE_SUCCESS;
    int32_t bwritten;

    *bytes_written = 0;
    bwritten = _write(handle, buffer, bytes_to_write);
    if (bwritten == -1) {
        int err = errno;

        ALOGE("could not write to file: error %d\n", err);
        ret = map_errno_to_core_err(err);
    } else {
        *bytes_written = bwritten;
    }

    return ret;
}

core_res_t core_file_lseek_set(file_handle_t handle, int64_t offset)
{
    return (core_file_lseek(handle, offset, SEEK_SET) ?
           CORE_ERROR_UNKNOWN : CORE_SUCCESS);
}

core_res_t core_file_get_size(const file_handle_t handle, uint64_t *size)
{
    core_res_t ret = CORE_SUCCESS;
    struct _stat buf;

    if (!size) {
        ret = CORE_ERROR_EINVAL;
        goto out;
    }
    *size = 0;

    if (_fstat(handle, &buf)) {
        int err = errno;

        ALOGE("could not read from file: error %d\n", err);
        ret = map_errno_to_core_err(err);
    } else {
        *size = buf.st_size;
    }

out:
    return ret;
}

static int32_t
core_file_lseek(file_handle_t handle, int64_t offset, int32_t origin)
{
    int32_t err = -1;
    int64_t off;

    off = _lseek(handle, offset, origin);
    if (off == -1) {
        ALOGE("lseek error: %d\n", errno);
        goto end;
    }

    if (off != offset) {
        ALOGE("lseek returned offset different than expected (%" PRIi64 " != %" PRIi64 ")\n", off, offset);
        goto end;
    }

    err = 0;

end:
    return err;
}

core_res_t core_create_directory(const char *path)
{
    return _mkdir(path);
}

core_res_t core_directory_exists(const char *path)
{
    int ret = CORE_ERROR_EINVAL;

    if (!path) {
        return ret;
    }

    DWORD dwAttrib = GetFileAttributes(path);

    ret = (dwAttrib != INVALID_FILE_ATTRIBUTES &&
            (dwAttrib & FILE_ATTRIBUTE_DIRECTORY));

    return ret ? CORE_SUCCESS : CORE_ERROR_FILE_NOT_FOUND;
}

