#include <stdio.h>
#include "telit-os-abs.h"
#include "ttest.h"

static void test_log_level(void);
static void test_log_json_set_buffer(void);

void test_custom_json()
{
    enum { ID_JSON, ID_STR, ID_BOOL, ID_INT, ID_INT64, ID_UINT64, ID_LAST };
    struct {
        char json_type[MAX_JSON_ENTRY_LEN];
        char str_value[MAX_JSON_ENTRY_LEN];
        char bool_value[MAX_JSON_ENTRY_LEN];
        char int_value[MAX_JSON_ENTRY_LEN];
        char int64_value[MAX_JSON_ENTRY_LEN];
        char uint64_value[MAX_JSON_ENTRY_LEN];
    } values;

    json_t entries [] = {
        [ID_JSON] =          /* the first item defines the json TYPE */
        {"whathever",        /* the key is ignored */
         values.json_type,   /* the value is custom, but all uppercase */
         VALUE_TYPE_STRING}, /* the type is string */
        [ID_STR] = {"key_string", values.str_value, VALUE_TYPE_BOOLEAN},
        [ID_BOOL] = {"key_boolean", values.bool_value, VALUE_TYPE_BOOLEAN},
        [ID_INT] = {"key_int", values.int_value, VALUE_TYPE_INT},
        [ID_INT64] = {"key_long", values.int64_value, VALUE_TYPE_LONG},
        [ID_UINT64] = {"key_ulong", values.uint64_value, VALUE_TYPE_ULONG},
        [ID_LAST] = { NULL, NULL, VALUE_TYPE_UNKNOWN},
    };

    bool ok, bvalue = true;
    int32_t value_i32 = 10;
    int64_t value_i64 = 65536;
    uint64_t value_u64 = 65536;

    ok = json_update(entries, ID_JSON, "CUSTOM_JSON_TYPE", VALUE_TYPE_STRING); CHECK_TRUE(ok);
    ok = json_update(entries, ID_STR, "this is a string", VALUE_TYPE_STRING); CHECK_TRUE(ok);
    ok = json_update(entries, ID_BOOL, &bvalue, VALUE_TYPE_BOOLEAN); CHECK_TRUE(ok);
    ok = json_update(entries, ID_INT, &value_i32, VALUE_TYPE_INT); CHECK_TRUE(ok);
    ok = json_update(entries, ID_INT64, &value_i64, VALUE_TYPE_LONG); CHECK_TRUE(ok);
    ok = json_update(entries, ID_UINT64, &value_u64, VALUE_TYPE_ULONG); CHECK_TRUE(ok);

    core_log_json(LOG_LEVEL_INFO, NULL, JSON_TYPE_CUSTOM, 0, &entries);
}


void test_file_logging()
{
    const char *filename = "test-file-logging.log";
    bool append = true;

    TLOG("About to print on %s file\n", filename);
    core_log_set_output(filename, append);

    ALOGF("fatal (emergency) message");
    ALOGA("alert message");
    ALOGC("critical message");
    ALOGE("error message");
    ALOGW("warning message");
    ALOGI("info message");
    ALOGD("debug message with %u %s", 2, "arguments");
    core_log_unset_output();
    ALOGI("stop logging to the file\n");
}

void negative_test_file_logging()
{
    TLOG("An error message is expected now\n");
    core_res_t err = core_log_set_print(file_print);
    CHECK_NUM(err, ==, CORE_ERROR_OPERATION_NOT_PERMITTED);
}

static void
test_log_level(void)
{
    const uint32_t log_level = LOG_LEVEL_DEBUG;
    core_log_set_level(log_level);

    CHECK_TRUE(core_log_get_level() == log_level);
}

static void
test_log_json_set_buffer(void)
{
#define TEST_BUFFER_DIMENSION 32
    bool ok;
    char buffer[TEST_BUFFER_DIMENSION] = {0};

    /* verify the json set buffer that should fail */
    ok = core_json_set_buffer(NULL, TEST_BUFFER_DIMENSION);
    CHECK_FALSE(ok);

    /* verify the json set buffer that should succeed */
    ok = core_json_set_buffer(buffer, TEST_BUFFER_DIMENSION);
    CHECK_TRUE(ok);
#undef TEST_BUFFER_DIMENSION
}

int main(int c, char **v)
{
    core_res_t err;

    TTEST_INIT(c, v);
    core_log_set_pprint(CORE_LOG_PPRINT_AUTONEWLINE);

    core_init();

    core_log_set_pprint(CORE_LOG_PPRINT_JSON);
    ALOGF("fatal (emergency) message");
    ALOGA("alert message");
    ALOGC("critical message");
    ALOGE("error message");
    ALOGW("warning message");
    ALOGI("info message");
    ALOGD("debug message with %u %s", 2, "arguments");

    json_progress_t progress = {
        .current = 70,
        .max = 100,
        .description = "percent"
    };
    /* defined max */
    core_log_json(LOG_LEVEL_INFO, __FILE__, JSON_TYPE_PROGRESS, __LINE__, &progress);

    /* undefined max */
    progress.max = -1;
    sprintf(progress.description, "undefined progress");
    core_log_json(LOG_LEVEL_INFO, __FILE__, JSON_TYPE_PROGRESS, __LINE__, &progress);

    /* defined max bytes */
    progress.current = 12345; /* e.g. bytes */
    progress.max = 65536;     /* e.g. bytes */
    sprintf(progress.description, "bytes downloaded");
    core_log_json(LOG_LEVEL_INFO, __FILE__, JSON_TYPE_PROGRESS, __LINE__, &progress);

    test_custom_json();

    core_log_set_pprint(CORE_LOG_PPRINT_AUTONEWLINE);
    ALOGI("native logging is enabled: %s\n", core_log_is_native() ? "TRUE" : "FALSE");
    ALOGF("fatal (emergency) message");
    ALOGA("alert message");
    ALOGC("critical message");
    ALOGE("error message");
    ALOGW("warning message");
    ALOGI("info message");
    ALOGD("invisible debug message: log level is defaulted to INFO");

    /* verify the log level set and get */
    RUN(test_log_level);

    ALOGD("debug message\n");
    ALOGD("debug message with %u %s\n", 2, "arguments");

    /* verify the log_json_set_buffer behaviour */
    RUN(test_log_json_set_buffer);

    core_log_set_pprint(CORE_LOG_PPRINT_RAW);
    ALOGD("this message does not have a newline.");
    ALOGD("this message has a newline.\n");

    ALOGI("setting native logging.");
    err = core_log_set_native(false);
    if (err == CORE_ERROR_NOT_IMPLEMENTED) {
        ALOGI("set native logging is not supported");
        return 0;
    }
    if (err) {
        ALOGE("set native error %d", err);
        return -1;
    }

    core_log_set_pprint(CORE_LOG_PPRINT_AUTONEWLINE);
    ALOGI("native logging is enabled: %s", core_log_is_native() ? "TRUE" : "FALSE");
    ALOGF("fatal (emergency) syslog message");
    ALOGA("alert syslog message");
    ALOGC("critical syslog message");
    ALOGE("error syslog message");
    ALOGW("warning syslog message");
    ALOGI("info syslog message");

    ALOGI("info  syslog with %u %s", 2, "args");
    ALOGE("error syslog with %u %s", 2, "args");
    ALOGD("debug syslog with %u %s", 2, "args");

    ALOGI("[newline] info  syslog with %u %s\n", 2, "args");
    ALOGE("[newline] error syslog with %u %s\n", 2, "args");
    ALOGD("[newline] debug syslog with %u %s\n", 2, "args");

    test_file_logging();

    RUN(negative_test_file_logging);

    core_deinit();
    return 0;
}
