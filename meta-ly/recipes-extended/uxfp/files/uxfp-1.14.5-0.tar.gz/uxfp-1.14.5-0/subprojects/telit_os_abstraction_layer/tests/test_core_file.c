#include "telit-os-abs.h"
#include "ttest.h"


void test_core_file_exists_file_found(void);
void test_fail_core_file_exists_file_not_found(void);
void test_fail_core_file_exists_invalid_path(void);
void test_core_file_open(void);


int main(int argc, char *argv[])
{
    TTEST_INIT(argc, argv);
    RUN(test_fail_core_file_exists_file_not_found);
    RUN(test_core_file_exists_file_found);
    RUN(test_fail_core_file_exists_invalid_path);
    RUN(test_core_file_open);
    return 0;
}

void test_core_file_exists_file_found(void)
{
    char *filepath = "test_core_file.c";  /* this file */

    CHECK_NUM(core_file_exists(filepath), ==, CORE_SUCCESS);
}

void test_fail_core_file_exists_file_not_found(void)
{
    core_res_t res;
    char *filepath;

    filepath = "foo.txt";
    res = core_file_exists(filepath);
    CHECK_NUM(res, ==, CORE_ERROR_FILE_NOT_FOUND);
}

void test_fail_core_file_exists_invalid_path(void)
{
    CHECK_NUM(core_file_exists(NULL), !=, CORE_SUCCESS);
}

void test_core_file_open(void)
{
    file_handle_t handle;
    char *filepath = "test_file_remove_after_testing.txt";

    /* file does not exists at start (remove it, if created in previous test) */
    CHECK_NUM(core_file_exists(filepath), ==, CORE_ERROR_FILE_NOT_FOUND);

    /* core_file_open creates a file if it does not exists */
    CHECK_NUM(core_file_open(filepath, &handle), ==, CORE_SUCCESS);
    CHECK_NUM(core_file_close(handle), ==, CORE_SUCCESS);

    /* file now must exists */
    CHECK_NUM(core_file_exists(filepath), ==, CORE_SUCCESS);
}
