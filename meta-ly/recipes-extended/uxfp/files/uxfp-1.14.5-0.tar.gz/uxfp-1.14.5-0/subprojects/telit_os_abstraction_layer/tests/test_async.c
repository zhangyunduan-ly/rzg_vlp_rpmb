#include "telit-os-abs.h"

#include "ttest.h"


void test_thread_create_and_join(void);
void test_mutex(void);
void test_semaphore(void);
void test_semaphore_timedout(void);


int main(int argc, char *argv[])
{
    TTEST_INIT(argc, argv);

    RUN(test_thread_create_and_join);
    RUN(test_mutex);
    RUN(test_semaphore);
    RUN(test_semaphore_timedout);
    return 0;
}


typedef struct {
    int input;
    int output;
} operand_t;

thread_ret_t multiply(void *arg)
{
    operand_t *operand = (operand_t *)arg;
    operand->output = operand->input * 2;
}

void test_thread_create_and_join(void)
{
    core_res_t err;
    thread_handle_t thandleA = {0};
    thread_handle_t thandleB = {0};
    operand_t operandA = {2, 0};
    operand_t operandB = {1, 0};

    err = core_thread_create(&thandleA, multiply, (void *)&operandA);
    CHECK_NUM(err, ==, CORE_SUCCESS);
    err = core_thread_create(&thandleB, multiply, (void *)&operandB);
    CHECK_NUM(err, ==, CORE_SUCCESS);

    err = core_thread_join(&thandleA, NULL);
    CHECK_NUM(err, ==, CORE_SUCCESS);
    CHECK_NUM(operandA.output, ==, operandA.input * 2);

    err = core_thread_join(&thandleB, NULL);
    CHECK_NUM(err, ==, CORE_SUCCESS);
    CHECK_NUM(operandB.output, ==, operandB.input * 2);
}


mutex_handle_t hmutex = {0};
const int main_id = 1;
const int thread_id = 2;
int idx = 0;
int exp_id_in_critical_section[2] = {2, 1};
thread_ret_t code_with_critical_section(void *arg)
{
    core_res_t err;
    int id = *(int *)arg;

    TLOG("in %s:%d\n", __FUNCTION__, id);
    err = core_mutex_lock(&hmutex);
    CHECK_NUM(err, ==, CORE_SUCCESS);

    TLOG("critical section in:%d\n", id);

    /* ID:2 is expected to get into the critical section first */
    CHECK_NUM(exp_id_in_critical_section[idx++], ==, id);

    core_sleep(100);

    TLOG("critical section out:%d\n", id);

    err = core_mutex_unlock(&hmutex);
    CHECK_NUM(err, ==, CORE_SUCCESS);
}

/* Use sleep in order to let id:2 enter in the critical
 * section first, and only then let id:1 enter in the
 * critical section. */
void test_mutex(void)
{
    core_res_t err;
    thread_handle_t handle = {0};

    err = core_mutex_create(&hmutex);
    CHECK_NUM(err, ==, CORE_SUCCESS);

    err = core_thread_create(&handle, code_with_critical_section, (void *)&thread_id);
    CHECK_NUM(err, ==, CORE_SUCCESS);

    core_sleep(100);
    code_with_critical_section((void *)&main_id);

    err = core_thread_join(&handle, NULL);
    CHECK_NUM(err, ==, CORE_SUCCESS);

    err = core_mutex_destroy(&hmutex);
    CHECK_NUM(err, ==, CORE_SUCCESS);
}

mutex_handle_t hmux = {0};
sem_handle_t hsem = {0};
int consume = 3;
thread_ret_t consume_func(void *arg)
{
    core_res_t err;
    int id = *(int *)arg;

    TLOG("%s:%d in\n", __FUNCTION__, id);
    err = core_sem_wait(&hsem);
    CHECK_NUM(err, ==, CORE_SUCCESS);

    core_mutex_lock(&hmux);
    CHECK_NUM(consume, >, 0);
    consume--;
    core_mutex_unlock(&hmux);

    err = core_sem_release(&hsem);
    CHECK_NUM(err, ==, CORE_SUCCESS);

    TLOG("%s:%d out\n", __FUNCTION__, id);
}

void test_semaphore(void)
{
    int i;
    core_res_t err;
    thread_handle_t thandle[3] = {0};
    int idx[3] = {1, 2, 3};

    core_mutex_create(&hmux);

    /* create semaphore with 0 value */
    err = core_sem_create(&hsem, 0);
    CHECK_NUM(err, ==, CORE_SUCCESS);

    /* run 3 consume threads, all shall block on semaphore */
    for (i = 0; i < 3; ++i) {
        core_thread_create(&thandle[i], consume_func, (void *)&idx[i]);
    }

    core_sleep(100);
    /* check that consume is still full (value == 3) and that */
    /* no thread reduce it's value. */
    CHECK_NUM(consume, ==, 3);

    /* release the threads */
    for (i = 0; i < 3; i++) {
        err = core_sem_release(&hsem);
        CHECK_NUM(err, ==, CORE_SUCCESS);
    }

    /* check that consume is empty (value == 0) */
    for (i = 0; i < 3; ++i) {
        core_thread_join(&thandle[i], NULL);
    }
    CHECK_NUM(consume, ==, 0);

    core_mutex_destroy(&hmux);
    core_sem_destroy(&hsem);
}

void test_semaphore_timedout(void)
{
    core_res_t err = core_sem_create(&hsem, 0);
    CHECK_NUM(err, ==, CORE_SUCCESS);

    err = core_sem_timedwait(&hsem, 1000);
    CHECK_NUM(err, ==, CORE_ERROR_TIMEOUT);
    core_sem_destroy(&hsem);
}
