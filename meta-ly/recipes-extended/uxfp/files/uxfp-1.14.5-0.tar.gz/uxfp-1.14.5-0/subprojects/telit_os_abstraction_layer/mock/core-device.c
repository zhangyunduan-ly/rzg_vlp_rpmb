#include <assert.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

#include "telit-os-abs.h"
#include "mock.h"


core_res_queue_t core_device_open_res = {0};
dev_handle_t core_device_open_handle;
core_res_t core_device_open(const char *device_path, dev_handle_t *handle)
{
    assert (core_device_open_res.next < MAX_CORE_RES_QUEUE);
    *handle = core_device_open_handle;
    return core_device_open_res.err[core_device_open_res.next++];
}

core_res_queue_t core_device_close_res = {0};
core_res_t core_device_close(const dev_handle_t handle)
{
    assert (core_device_close_res.next < MAX_CORE_RES_QUEUE);
    return core_device_close_res.err[core_device_close_res.next++];
}

core_res_queue_t core_device_config_res = {0};
core_res_t core_device_config(const dev_handle_t handle)
{
    assert (core_device_config_res.next < MAX_CORE_RES_QUEUE);
    return core_device_config_res.err[core_device_config_res.next++];
}

core_res_queue_t core_get_serial_state_res = {0};
serial_state_t core_get_serial_state_state = {0};
core_res_t core_get_serial_state(const dev_handle_t handle, serial_state_t *state)
{
    *state = core_get_serial_state_state;
    assert (core_get_serial_state_res.next < MAX_CORE_RES_QUEUE);
    return core_get_serial_state_res.err[core_get_serial_state_res.next++];
}
core_res_queue_t core_set_control_signals_res = {0};
core_res_t core_set_control_signals(const dev_handle_t handle, bool dtr, bool rts)
{
    assert (core_set_control_signals_res.next < MAX_CORE_RES_QUEUE);
    return core_set_control_signals_res.err[core_set_control_signals_res.next++];
}

core_res_queue_t core_device_set_baud_rate_res = {0};
core_res_t core_device_set_baud_rate(const dev_handle_t handle, const uint32_t baud_rate)
{
    assert (core_device_set_baud_rate_res.next < MAX_CORE_RES_QUEUE);
    return core_device_set_baud_rate_res.err[core_device_set_baud_rate_res.next++];
}

core_res_queue_t core_device_enumerate_res = {0};
dev_info_t *core_device_enumerate_dev_list = NULL;
int8_t core_device_enumerate_dev_list_size = 0;
core_res_t core_device_enumerate(const usb_id_t *usbid_list,
        const uint8_t usbid_list_size,
        dev_info_t *dev_list,
        int8_t *dev_list_size)
{
    int i;

    *dev_list_size = core_device_enumerate_dev_list_size;
    for (i = 0; i < core_device_enumerate_dev_list_size; i++) {
        memcpy(&dev_list[i], &core_device_enumerate_dev_list[i], sizeof(core_device_enumerate_dev_list[i]));
    }

    if (core_log_get_level() == LOG_LEVEL_DBG) {
        ALOGD("returning device list:\n");
        int i, j;
        for (i = 0; i < *dev_list_size; i++) {
            ALOGD("device[%d].comm_ports_number: %" PRIu32 "\n", i, dev_list[i].comm_ports_number);
            for (j = 0; j < dev_list[i].comm_ports_number; j++) {
                ALOGD("device[%d].comm_ports[%d]: %s\n", i, j, dev_list[i].comm_ports[j]);
            }
        }
    }

    assert (core_device_enumerate_res.next < MAX_CORE_RES_QUEUE);
    ALOGD("returning res %d\n", core_device_enumerate_res.err[core_device_enumerate_res.next]);
    return core_device_enumerate_res.err[core_device_enumerate_res.next++];
}

core_res_queue_t core_device_usb_id_event_listener_res = {0};
usb_id_t core_device_usb_id_event_listener_usb_id = {0};
uint32_t core_device_usb_id_event_listener_wait_ms = 0;
core_res_t core_device_usb_id_event_listener(bool (*condition)(dev_info_t *info, void *data),
        void *data,
        uint32_t timeout_ms,
        usb_id_t *event)
{
    assert(core_device_usb_id_event_listener_res.next < MAX_CORE_RES_QUEUE);
    memcpy(event, &core_device_usb_id_event_listener_usb_id,
            sizeof(core_device_usb_id_event_listener_usb_id));
    return core_device_usb_id_event_listener_res.err[core_device_usb_id_event_listener_res.next];
}

core_res_queue_t core_device_usb_id_event_type_listener_res = {0};
usb_id_t core_device_usb_id_event_type_listener_usb_id = {0};
uint32_t core_device_usb_id_event_type_listener_wait_ms = 0;
core_res_t core_device_usb_id_event_type_listener(bool (*condition)(dev_info_t *info,
        void *data), void *data, uint32_t timeout_ms, usb_id_t *event, usb_event_t *event_type)
{
    assert(core_device_usb_id_event_type_listener_res.next < MAX_CORE_RES_QUEUE);
    memcpy(event, &core_device_usb_id_event_type_listener_usb_id,
            sizeof(core_device_usb_id_event_type_listener_usb_id));
    return core_device_usb_id_event_type_listener_res.err[core_device_usb_id_event_type_listener_res.next];
}

core_res_queue_t core_wait_for_serial_res = {0};
uint32_t core_wait_for_serial_wait_ms = 0;
core_res_t core_wait_for_serial(const char *port)
{
    assert(core_wait_for_serial_res.next < MAX_CORE_RES_QUEUE);
    if (core_wait_for_serial_wait_ms) {
        core_sleep(core_wait_for_serial_wait_ms);
    }
    return core_wait_for_serial_res.err[core_wait_for_serial_res.next];
}
