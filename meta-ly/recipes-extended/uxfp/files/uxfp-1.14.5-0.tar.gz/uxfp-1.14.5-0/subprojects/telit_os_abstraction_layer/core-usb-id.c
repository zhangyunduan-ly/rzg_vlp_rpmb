#include <stdlib.h>
#include <string.h>
#include <telit-os-abs.h>
#include <inttypes.h>

bool core_usb_id_from_str(usb_id_t *usb_id, const char *vid, const char *pid)
{
    bool success = false;
    unsigned long int ret;
    char *end_ptr;

    if (vid && pid) {
        ret = strtoul(vid, &end_ptr, 16);
        if (*end_ptr != '\0') {
            ALOGE("Invalid vid string\n");
            goto exit;
        }
        if ((ret == 0) || (ret > 0xFFFF)) {
            ALOGE("could not convert vendor id %s, value is out of range (1, 0xFFFF)\n",
                    vid);
            goto exit;
        }

        usb_id->vid = ret;

        ret = strtoul(pid, &end_ptr, 16);
        if (*end_ptr != '\0') {
            ALOGE("Invalid pid string\n");
            goto exit;
        }
        if ((ret == 0) || (ret > 0xFFFF)) {
            ALOGE("could not convert product id %s, value is out of range (1, 0xFFFF)\n",
                    pid);
            goto exit;
        }

        usb_id->pid = ret;

        success = true;
    }
exit:
    return success;
}

bool core_usb_id_is_null(usb_id_t *usb_id)
{
    return (!usb_id->vid || !usb_id->pid);

}

bool core_usb_id_equals(const usb_id_t *left, const usb_id_t *right)
{
    return ( (left->vid == right->vid) && (left->pid == right->pid) );
}

/* NOTE: usb_id_list is defined as `void *` so that this function can be passed as "condition"
 * function to core_device_event_listener */
bool core_usb_id_find_match(dev_info_t *devinfo, void *data)
{
    bool ok;
    uint8_t i;
    usb_id_t usb_id;

    usb_id_list_t *list = (usb_id_list_t *)data;

    ok = core_usb_id_from_str(&usb_id, devinfo->vendor_id, devinfo->product_id);
    if (!ok) {
        ALOGE("could not get vid/pid from devinfo\n");
        goto done;
    }

    ok = false;
    for (i = 0; i < list->len && !ok; i++) {
        ok = core_usb_id_equals(&usb_id, &list->items[i]);
    }

done:
    return ok;
}

core_res_t core_usb_id_get_device_if_connected(const usb_id_list_t *usb_ids, dev_info_t *info)
{
    uint8_t i;
    core_res_t err = CORE_ERROR_NO_SUCH_DEVICE;
    int8_t info_size = 1;

    for (i = 0; i < usb_ids->len; i++) {
        ALOGD("looking for device %" PRIu8 "/%" PRIu8 ": 0x%04" PRIX32 ":0x%04" PRIX32 "\n",
                i + 1,
                usb_ids->len,
                usb_ids->items[i].vid,
                usb_ids->items[i].pid);

        memset(info, 0, sizeof(*info));
        err = core_device_enumerate(&usb_ids->items[i], 1, info, &info_size);
        if (err) {
            if (err == CORE_ERROR_NOT_IMPLEMENTED) {
                break;
            }
            ALOGD("device not found\n");
            continue;
        }
        err = CORE_SUCCESS;
        break;
    }

    return err;
}

core_res_t core_usb_id_wait_for_devices(const usb_id_list_t *range, dev_info_t *info,
        const uint32_t timeout_ms)
{
    core_res_t err = CORE_ERROR_UNKNOWN;
    usb_id_t event = {0};
    int8_t info_size = 1;

    err = core_device_enumerate(range->items, range->len, info, &info_size);
    if (!err) {
        return CORE_SUCCESS;
    }

    if (err == CORE_ERROR_NOT_IMPLEMENTED) {
        return err;
    }

    ALOGI("no device connected yet. Waiting for a device to connect...\n");

    err = core_device_usb_id_event_listener(core_usb_id_find_match, (void *)range, timeout_ms, &event);
    if (err) {
        if (err != CORE_ERROR_TIMEOUT) {
            ALOGE("event listener error %d\n", err);
        }
        return err;
    }
    ALOGD("USB attach from device %04" PRIX32 ":%04" PRIX32 "\n", event.vid, event.pid);

    err = core_device_enumerate(&event, 1, info, &info_size);
    if (err) {
        uint8_t i = 3;
        uint16_t waitms = 1000;

        while (i-- > 0 && err) {
            ALOGD("no device found, maybe not ready yet. Retrying after %" PRIu16 "ms...\n", waitms);
            core_sleep(waitms);
            err = core_device_enumerate(&event, 1, info, &info_size);
        }
    }

    return err;
}
