#ifndef _TTEST_H_
#define _TTEST_H_

#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <inttypes.h>

bool test_log_verbose = true;
static bool success = true;
static bool failfast = false;

struct {
    int32_t (*setup)(void);
    int32_t (*teardown)(void);
} ttest_ops = {
    .setup = NULL,
    .teardown = NULL,
};

#define TLOG(format, ...) do { if (test_log_verbose) { printf(format, ## __VA_ARGS__); }} while (0)

#define TTEST_OPS(fsetup, fteardown) {ttest_ops.setup = fsetup; ttest_ops.teardown = fteardown;}

#define SETUP { \
            if (ttest_ops.setup) { \
                if (ttest_ops.setup() != 0) { \
                    TLOG("setup failed\n"); \
                    exit(1); \
                } \
            } \
}
#define TEARDOWN { \
            if (ttest_ops.teardown) { \
                if (ttest_ops.teardown() != 0) { \
                    TLOG("teardown failed\n"); \
                    exit(1); \
                } \
            } \
}

#define TTEST_INIT(argc, argv) do { for (int i = 1; i < argc; i++) { \
                                        if (strcmp(argv[i], "silent") == 0) { test_log_verbose = false; } \
                                        if (strcmp(argv[i], "failfast") == 0) { failfast = true; } \
                                    } \
} while (0)


#define RUN(function) do { \
            SETUP; \
            success = true; \
            printf("[ %s ] START\n", #function); \
            function(); \
            printf("[ %s ] %s\n", #function, success ? "PASSED" : "FAILED"); \
            TEARDOWN; \
            if (!success && failfast) exit (1); \
} while (0)

#define _CHECK(type, left, op, right) do { \
            if (((left) op (right))) { \
                break; \
            } \
            success = false; \
            switch (type) { \
                case 0: /* INT */ { \
                        printf("assertion (%s %s %s) failed because %d %s %d is FALSE @ %s:%d.\n", #left, #op, \
        #right, \
        (int32_t)left, #op, (int32_t)right, __FUNCTION__, __LINE__); \
                        break; \
                } \
                case 1: /* LONG */ { \
                        printf( \
        "assertion (%s %s %s) failed because %" PRId64 "%s %" PRId64 " is FALSE @ %s:%d.\n", \
        #left, #op, #right, (int64_t)left, #op, (int64_t)right, __FUNCTION__, __LINE__); \
                        break; \
                } \
                case 2: /* ULONG */ { \
                        printf( \
        "assertion (%s %s %s) failed because %" PRIu64 "%s %" PRIu64 " is FALSE @ %s:%d.\n", \
        #left, #op, #right, (uint64_t)left, #op, (uint64_t)right, __FUNCTION__, __LINE__); \
                        break; \
                } \
            } \
            if (!success && failfast) exit (1); \
} while (0)

#define _CHECK_WITH_CUSTOM_LOG(type, left, op, right, fmt, ...) do { \
            if (((left) op (right))) { \
                break; \
            } \
            success = false; \
            switch (type) { \
                case 0: /* INT */ { \
                        printf("assertion (%s %s %s) failed because %d %s %d is FALSE @ %s:%d ", #left, #op, \
        #right, \
        (int32_t)left, #op, (int32_t)right, __FUNCTION__, __LINE__); \
                        break; \
                } \
                case 1: /* LONG */ { \
                        printf( \
        "assertion (%s %s %s) failed because %" PRId64 "%s %" PRId64 " is FALSE @ %s:%d.\n", \
        #left, #op, #right, (int64_t)left, #op, (int64_t)right, __FUNCTION__, __LINE__); \
                        break; \
                } \
                case 2: /* ULONG */ { \
                        printf( \
        "assertion (%s %s %s) failed because %" PRIu64 "%s %" PRIu64 " is FALSE @ %s:%d.\n", \
        #left, #op, #right, (uint64_t)left, #op, (uint64_t)right, __FUNCTION__, __LINE__); \
                        break; \
                } \
            } \
            printf(fmt, __VA_ARGS__); \
            if (!success && failfast) exit (1); \
} while (0)

#define _CHECK_WITH_CUSTOM_LOG(type, left, op, right, fmt, ...) do { \
            if (((left) op (right))) { \
                break; \
            } \
            success = false; \
            switch (type) { \
                case 0: /* INT */ { \
                        printf("assertion (%s %s %s) failed because %d %s %d is FALSE @ %s:%d ", #left, #op, \
        #right, \
        (int32_t)left, #op, (int32_t)right, __FUNCTION__, __LINE__); \
                        break; \
                } \
                case 1: /* LONG */ { \
                        printf( \
        "assertion (%s %s %s) failed because %" PRId64 "%s %" PRId64 " is FALSE @ %s:%d.\n", \
        #left, #op, #right, (int64_t)left, #op, (int64_t)right, __FUNCTION__, __LINE__); \
                        break; \
                } \
                case 2: /* ULONG */ { \
                        printf( \
        "assertion (%s %s %s) failed because %" PRIu64 "%s %" PRIu64 " is FALSE @ %s:%d.\n", \
        #left, #op, #right, (uint64_t)left, #op, (uint64_t)right, __FUNCTION__, __LINE__); \
                        break; \
                } \
            } \
            printf(fmt, __VA_ARGS__); \
            if (!success && failfast) exit (1); \
} while (0)

#define CHECK_NUM(left, op, right) _CHECK(0, left, op, right)
#define CHECK_LONG(left, op, right)  _CHECK(1, left, op, right)
#define CHECK_ULONG(left, op, right)  _CHECK(2, left, op, right)

#define CHECK_NUM_MSG(left, op, right, fmt, ...) _CHECK_WITH_CUSTOM_LOG(0, left, op, right, fmt, __VA_ARGS__)
#define CHECK_LONG_MSG(left, op, right, fmt, ...)  _CHECK_WITH_CUSTOM_LOG(1, left, op, right)
#define CHECK_ULONG_MSG(left, op, right, fmt, ...)  _CHECK_WITH_CUSTOM_LOG(2, left, op, right)

#define CHECK_STR(left, op, right) do { \
            if (!left) { printf("%s operand is NULL\n", #left); success = false;} \
            else if (!right) { printf("%s operand is NULL\n", #right); success = false;} \
            else if (strcmp(#op, "==") == 0) { success = (strcmp(left, right) == 0); } \
            else if (strcmp(#op, "!=") == 0) { success = (strcmp(left, right) != 0); } \
            else { printf("ttest error! Unsupported CHECK_STR operand `%s`\n", #op); exit(1); } \
            if (!success) { \
                printf("assertion (%s %s %s) failed because %s %s %s is FALSE @ %s:%d\n\n", #left, #op, \
        #right, \
        left, #op, right, __FUNCTION__, __LINE__); \
                success = false; \
            } \
            if (!success && failfast) exit (1); \
} while (0)

#define CHECK_STR_MSG(left, op, right, fmt, ...) do { \
            if (!left) { printf("%s operand is NULL\n", #left); success = false;} \
            else if (!right) { printf("%s operand is NULL\n", #right); success = false;} \
            else if (strcmp(#op, "==") == 0) { success = (strcmp(left, right) == 0); } \
            else if (strcmp(#op, "!=") == 0) { success = (strcmp(left, right) != 0); } \
            else { printf("ttest error! Unsupported CHECK_STR operand `%s`\n", #op); exit(1); } \
            if (!success) { \
                printf("assertion (%s %s %s) failed because %s %s %s is FALSE @ %s:%d\n ", #left, #op, #right, \
        left, #op, right, __FUNCTION__, __LINE__); \
                printf(fmt, __VA_ARGS__); \
            } \
            if (!success && failfast) exit (1); \
} while (0)

#define CHECK_TRUE(cond) do { \
            if (!(cond) ) { \
                printf("assertion %s == TRUE failed because %s was %d @ %s:%d.\n", #cond, #cond, cond, \
        __FUNCTION__, __LINE__); \
                success = false; \
            } \
            if (!success && failfast) exit (1); \
} while (0)

#define CHECK_TRUE_MSG(cond, fmt, ...) do { \
            if (!(cond) ) { \
                printf("assertion %s == TRUE failed because %s was %d @ %s:%d. ", #cond, #cond, cond, \
        __FUNCTION__, __LINE__); \
                printf(fmt, __VA_ARGS__); \
                success = false; \
            } \
            if (!success && failfast) exit (1); \
} while (0)

#define CHECK_FALSE(cond) do { \
            if ( (cond) ) { \
                printf("assertion %s == FALSE failed because %s was %d @ %s:%d.\n", #cond, #cond, cond, \
        __FUNCTION__, __LINE__); \
                success = false; \
            } \
            if (!success && failfast) exit (1); \
} while (0)

#define CHECK_FALSE_MSG(cond, fmt, ...) do { \
            if ( (cond) ) { \
                printf("assertion %s == FALSE failed because %s was %d @ %s:%d. ", #cond, #cond, cond, \
        __FUNCTION__, __LINE__); \
                printf(fmt, __VA_ARGS__); \
                success = false; \
            } \
            if (!success && failfast) exit (1); \
} while (0)

#endif /* _TTEST_H_ */
