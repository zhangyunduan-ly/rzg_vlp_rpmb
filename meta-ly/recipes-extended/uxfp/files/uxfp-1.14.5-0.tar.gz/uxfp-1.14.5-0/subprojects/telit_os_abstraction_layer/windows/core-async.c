#include "telit-os-abs.h"

static core_res_t inner_close_handle(HANDLE handle)
{
    core_res_t err = CORE_SUCCESS;
    BOOL ok;

    ok = CloseHandle(handle);
    if (!ok) {
        DWORD error = GetLastError();
        ERROR_MSG_FMT("could not close handle", error);
        err = map_get_last_error_to_core_err(error);
    }
    return err;
}

static core_res_t inner_handle_wait(HANDLE handle, DWORD timeout)
{
    core_res_t err = CORE_SUCCESS;
    DWORD ret;

    ret = WaitForSingleObject(handle, timeout);
    switch (ret) {
        case WAIT_OBJECT_0:
            /* nothing to do */
            break;
        case WAIT_TIMEOUT:
            ALOG("wait timeout\n");
            err = CORE_ERROR_TIMEOUT;
            break;
        default: {
            DWORD error = GetLastError();
            ERROR_MSG_FMT("WaitForSingleObject failed", error);
            err = map_get_last_error_to_core_err(error);
        }
    }
    return err;
}

core_res_t core_thread_create(thread_handle_t *handle, thread_ret_t (*callback)(void *), void *callback_arg)
{
    core_res_t err = CORE_SUCCESS;

    *handle = CreateThread(NULL, /* Default security descriptor */
            0,                   /* default stack size */
            (LPTHREAD_START_ROUTINE)callback, callback_arg,
            0,                   /* thread runs immediately after creation */
            NULL /* unnamed thread */);
    if (*handle == INVALID_THREAD_HANDLE) {
        DWORD error = GetLastError();
        ERROR_MSG_FMT("could not create thread", error);
        err = map_get_last_error_to_core_err(error);
    }

    return err;
}

core_res_t core_thread_join(thread_handle_t *handle, void *result)
{
    core_res_t err;
    BOOL ok;

    /* TODO: check result != NULL and return with GetExitCodeThread */
    err = inner_handle_wait(*handle, INFINITE);
    if (err) {
        ALOGE("could not join thread: error %d\n", err);
        return err;
    }

    err = inner_close_handle(*handle);
    if (err) {
        ALOGE("could not destroy thread: error %d\n", err);
    }

    return err;
}

core_res_t core_mutex_create(mutex_handle_t *handle)
{
    core_res_t err = CORE_SUCCESS;

    *handle = CreateMutexA(NULL, /* default security attributes */
            false,               /* the calling thread does not obtain ownership of this mutex */
            NULL /* unnamed mutex */);
    if (*handle == INVALID_MUTEX_HANDLE) {
        DWORD error = GetLastError();
        ERROR_MSG_FMT("could not create mutex", error);
        err = map_get_last_error_to_core_err(error);
    }

    return err;
}

core_res_t core_mutex_lock(mutex_handle_t *handle)
{
    core_res_t err;

    err = inner_handle_wait(*handle, INFINITE);
    if (err) {
        DWORD error = GetLastError();
        ERROR_MSG_FMT("could not lock mutex", error);
        err = map_get_last_error_to_core_err(error);
    }

    return err;
}

core_res_t core_mutex_unlock(mutex_handle_t *handle)
{
    core_res_t err = CORE_SUCCESS;
    BOOL ok;

    ok = ReleaseMutex(*handle);
    if (!ok) {
        DWORD error = GetLastError();
        ERROR_MSG_FMT("could not unlock mutex", error);
        err = map_get_last_error_to_core_err(error);
    }

    return err;
}

core_res_t core_mutex_destroy(mutex_handle_t *handle)
{
    core_res_t err;

    err = inner_close_handle(*handle);
    if (err) {
        ALOGE("could not destroy mutex: error %d\n", err);
    }

    return err;
}

core_res_t core_sem_create(sem_handle_t *handle, int32_t value)
{
    core_res_t err = CORE_SUCCESS;

    *handle = CreateSemaphore(NULL, /* default security attributes */
            value,                  /* initial value */
            SEM_VALUE_MAX,          /* maximum value */
            NULL /* unnamed semaphore */);
    if (*handle == INVALID_SEM_HANDLE) {
        DWORD error = GetLastError();
        ERROR_MSG_FMT("could not create semaphore", error);
        err = map_get_last_error_to_core_err(error);
    }

    return err;
}

core_res_t core_sem_wait(sem_handle_t *handle)
{
    core_res_t err;

    err = inner_handle_wait(*handle, INFINITE);
    if (err) {
        DWORD error = GetLastError();
        ERROR_MSG_FMT("semaphore wait failed", error);
        err = map_get_last_error_to_core_err(error);
    }

    return err;
}
core_res_t core_sem_timedwait(sem_handle_t *handle, uint64_t msec)
{
    core_res_t err;

    err = inner_handle_wait(*handle, (DWORD)msec);
    if (err && err != CORE_ERROR_TIMEOUT) {
        ALOGI("error: %d\n", err);
        DWORD error = GetLastError();
        ERROR_MSG_FMT("semaphore timed wait failed", error);
        err = map_get_last_error_to_core_err(error);
    }

    return err;
}

core_res_t core_sem_release(sem_handle_t *handle)
{
    core_res_t err = CORE_SUCCESS;
    BOOL ok;

    ok = ReleaseSemaphore(*handle,
            1,  /* increase the current semaphore counter by 1 */
            NULL /* ignore semaphore value before release */);
    if (!ok) {
        DWORD error = GetLastError();
        ERROR_MSG_FMT("could not release semaphore", error);
        err = map_get_last_error_to_core_err(error);
    }

    return err;
}

core_res_t core_sem_destroy(sem_handle_t *handle)
{
    core_res_t err;

    err = inner_close_handle(*handle);
    if (err) {
        ALOGE("could not destroy semaphore: error %d\n", err);
    }

    return err;
}
