/**
 * @mainpage Telit OS Abstraction Layer
 * Telit OS Abstraction Layer defines an API used by Telit host tools, in order
 * to make the tools OS independent.
 *
 * Each tool specifies which functions should be implemented in order to allow
 * working in a specific environment.
 *
 * Available sample implementations of the API:
 * - <b>Linux</b>
 * - <b>Windows</b>
 *
 * Copyright (C) 2017, 2018  Telit Communication spa
 *
 */

/**
 * @file telit-os-abs.h
 * @brief Telit OS Abstraction Layer API definition
 *
 * This file shows all the functions available in Telit OS Abstraction Layer and
 * their interfaces.
 */

#ifndef _TELIT_OS_ABS_H_
#define _TELIT_OS_ABS_H_

#include <stdbool.h>
#include <stdint.h>

#ifdef ANDROID
#include <log/log.h>
#endif

#include "telit-os.h"

#define MAX_STR_VALUE         1024
#define MAX_COMM_PORTS_NUM    10
#define MAX_USB_ID_LEN        4
#define TIMEOUT_INFINITE      0xFFFFFFFF

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(array) (sizeof(array) / sizeof(array[0]))
#endif

/**
 * @brief Error interface
 *
 * Some errors are mapped into Linux error codes
 */
typedef enum {
    CORE_SUCCESS                       = 0,
    CORE_ERROR_OPERATION_NOT_PERMITTED = -1,
    CORE_ERROR_FILE_NOT_FOUND          = -2,
    CORE_ERROR_EINTR                   = -4,
    CORE_ERROR_IO_ERROR                = -5,
    CORE_ERROR_TRY_AGAIN               = -11,
    CORE_ERROR_MEM                     = -12,
    CORE_ERROR_PERMISSION_DENIED       = -13,
    CORE_ERROR_DEVICE_BUSY             = -16,
    CORE_ERROR_NO_SUCH_DEVICE          = -19,
    CORE_ERROR_EINVAL                  = -22,
    CORE_ERROR_ENOSPC                  = -28,
    CORE_ERROR_PROTO                   = -71,
    CORE_ERROR_NOT_IMPLEMENTED         = -100,
    CORE_ERROR_TIMEOUT                 = -110,
    CORE_ERROR_UNKNOWN                 = -102,
    CORE_ERROR_OP_CANCELLED            = -125,
} core_res_t;

core_res_t map_errno_to_core_err(int err);
/**
 * @brief USB event type
 *
 */
typedef enum {
    CORE_USB_EVENT_ADD    = 0,
    CORE_USB_EVENT_REMOVE = 1,
} usb_event_type_t;

/**
 * @brief the struct representing an USB event
 */
typedef struct {
    char dev_path[MAX_STR_VALUE]; /**< Unique identifier of the device which generated the event */
    usb_event_type_t type;        /**< type of the USB event, see @usb_event_type_t */
} usb_event_t;

typedef enum {
    VALUE_TYPE_BOOLEAN,
    VALUE_TYPE_INT,
    VALUE_TYPE_LONG,
    VALUE_TYPE_ULONG,
    VALUE_TYPE_STRING,
    VALUE_TYPE_ARRAY,
    VALUE_TYPE_ARRAY_SIZE,
    VALUE_TYPE_UNKNOWN
} vtype_t;


/** \addtogroup logging Logging facility
 * @{
 * @brief Logging functions
 */

#define MAX_JSON_KEY_LEN (32)
#define MAX_JSON_MESSAGE_LEN (512)
#define MAX_JSON_MESSAGE_ARRAY_LEN (MAX_JSON_MESSAGE_LEN * 10)
/* A single composed JSON entry string is "key: value,"
 * the COMMA is present only if there are following entries,
 * but is taken into account as more general case */
#define MAX_JSON_ENTRY_LEN (MAX_JSON_KEY_LEN + MAX_JSON_MESSAGE_LEN + 3)
#define MAX_JSON_ARRAY_ENTRY_LEN (MAX_JSON_KEY_LEN + MAX_JSON_MESSAGE_ARRAY_LEN + 3)

/* JSON log has the same information a log message has, but in JSON format */
#define JSON_TYPE_LOG "JSON_TYPE_LOG"
#define JSON_TYPE_PROGRESS "JSON_TYPE_PROGRESS"
#define JSON_TYPE_CUSTOM "JSON_TYPE_CUSTOM"

/**
 * @brief Enable or disable logging messages from the telit-os-abstraction-layer core functions.
 *
 * @param enable TRUE to enable telit-os-abstraction-layer logging, FALSE otherwise.
 */
void core_log_library(const bool enable);

/**
 * @brief print a log line
 *
 * Not to be used directly, use defines above (e.g. ALOGI, ALOGE, ALOGD, ALOGW, ALOG)
 * @param level logging level
 * @param file name of the file where this is called
 * @param function name of the function where this is called
 * @param line the number of the line inside the file where this is called
 * @param fmt message format
 * @param ... variadic list of arguments to format the message
 */
void core_log(const int level, const char *file, const char *function, const int line, const char *fmt, ...);

/**
 * @brief the struct representing a key:value pair of a JSON string
 */
typedef struct {
    char *key;         /**< key string of the key:value pair */
    const void *value; /**< a pointer to the value of the key:value pair */
    vtype_t type;      /**< the type of the variable pointed by the above value */
} json_t;

/**
 * @brief the struct representing the values of a #JSON_TYPE_PROGRESS log
 */
typedef struct {
    int64_t current;                 /**< number representing the current progress level */
    int64_t max;                     /**< number representing maximum value that current can reach or "<= 0" if unknown */
    char description[MAX_STR_VALUE]; /**< description of the progress values (e.g. percent, bytes, etc.) */
} json_progress_t;

/**
 * @brief set a memory buffer to be used by json print functions
 *
 * @param[in] buffer memory buffer
 * @param[in] size size of the provided memory buffer
 *
 * @return true if the operation is successful, false otherwise
 */
bool core_json_set_buffer(char *buffer, uint32_t size);
/**
 * @brief update the value of the key:value pair at the given ID
 *
 * @param[in] entries a list of #json_t
 * @param[in] id the position in the #json_t list of the item to update
 * @param[in] value the message to store in the #json_t
 * @param[in] type the #vtype_t type of the json value
 *
 * @return true if the message is stored, false otherwise
 */
bool json_update(json_t *entries, int8_t id, const void *value, vtype_t type);
/**
 * @brief print a json formatted message.
 *
 * @param[in] level logging level
 * @param[in] file name of the file where this is called, needed only if #JSON_TYPE_LOG
 * @param[in] function name of the function where this is called, or a #JSON_TYPE string
 * @param[in] line the number of the line inside the file where this is called, needed only if #JSON_TYPE_LOG
 * @param[in] data a string for JSON_TYPE_LOG, a #json_progress_t for #JSON_TYPE_PROGRESS, or a #json_t for #JSON_TYPE_CUSTOM)
 */
void core_log_json(const int level, const char *file, const char *function, const int line, void *data);
/**
 * @brief set the logging verbosity
 *
 * @param level the logging level to set (e.g. LOG_LEVEL_DBG)
 */
void core_log_set_level(const uint32_t level);
/**
 * @brief gets the currently set logging level
 *
 * @return a uint32_t representing the logging level
 */
uint32_t core_log_get_level(void);

/**
 * @brief Basic logging function signature definition
 */
typedef void (*core_log_print_t)(const int level, const char *fmt, ...);

/**
 * @brief Set print function (by default the library prints on stdout)
 *
 * @param print a logging function with core_log_print_t signature
 * @return CORE_SUCCESS in case of succes, CORE_ERROR_OPERATION_NOT_PERMITTED otherwise
 */
core_res_t core_log_set_print(core_log_print_t print);

/**
 * @brief Set the file name to log into
 *
 * @param filename the name of the file to log into
 * @param append TRUE if the file shall be opened in append mode, FALSE otherwise (the file will be overwritten if exists already).
 */
core_res_t core_log_set_output(const char *filename, bool append);

/**
 * @brief Unset the logging to the previously set file (see #core_log_set_output). The logging facility will switch automatically to stdout logging.
 */
void core_log_unset_output();

/**
 * @brief Deinitialize the logging facility.
 *
 */
void core_log_deinit();

/**
 * @brief Basic logging function on stdout/stderr
 *
 * @param level message priority
 * @param fmt message format
 * @param ... parameters of the message
 */

void stdout_print(const int level, const char *fmt, ...);
/**
 * @brief Basic logging function on file (see #core_log_set_output)
 *
 * @param level message priority
 * @param fmt message format
 * @param ... parameters of the message
 */
void file_print(const int level, const char *fmt, ...);

/**
 * @brief Pretty Print function types
 */
typedef enum {
    CORE_LOG_PPRINT_AUTONEWLINE, /**< intelligently add a newline at the end of the message (if not there already) */
    CORE_LOG_PPRINT_RAW,         /**< the log message is printed as it is, no newline is added if missing */
    CORE_LOG_PPRINT_JSON,        /**< the log message is printed as JSON object */
} core_log_pprint_t;

/**
 * @brief Set pretty print function
 *
 * @param id a core_log_pprint_t value
 */
void core_log_set_pprint(const core_log_pprint_t id);

/**
 * @brief enable OS native logging
 *
 * @param enable boolean, enable/disable OS native logging
 * @return core_res_t
 */
core_res_t core_log_set_native(const bool enable);
/**  @} */

/**
 * @brief return current state of native logging
 *
 * @return True if native logging is enabled, false otherwise.
 */
bool core_log_is_native(void);

/**
 * @brief print a generic buffer at debug level
 *
 * @param buffer buffer to be printed
 * @param len actual length of the buffer
 * @param span the size of each log line
 */
void core_print_buffer(uint8_t *buffer, uint32_t len, uint32_t span);

/**
 * @brief print a generic buffer with a specific log level
 *
 * @param buffer buffer to be printed
 * @param len actual length of the buffer
 * @param span the size of each log line
 * @param level the log level to be used
 */
void core_print_buffer_to_level(uint8_t *buffer, uint32_t len, uint32_t span, const int level);

/**
 * @brief Get system time
 *
 * @param ts pointer to an object of type struct timespec
 * @return CORE_SUCCESS in case of succes, CORE_ERROR_OPERATION_NOT_PERMITTED otherwise
 */
core_res_t core_get_time(struct timespec *ts);


/* Logging interface */
#define LOG_LEVEL_EMERG   0           /**< system is unusable */
#define LOG_LEVEL_ALERT   1           /**< action must be taken immediately */
#define LOG_LEVEL_CRIT    2           /**< critical conditions */
#define LOG_LEVEL_ERR     3           /**< error conditions */
#define LOG_LEVEL_WARNING 4           /**< warning conditions */
#define LOG_LEVEL_NOTICE  5           /**< normal but significant condition */
#define LOG_LEVEL_INFO    6           /**< informational */
#define LOG_LEVEL_DEBUG   7           /**< debug-level messages */
#define LOG_LEVEL_VERBOSE 8           /**< verbose debug messages */

#define LOG_LEVEL_DBG LOG_LEVEL_DEBUG /* for backward compatibility */

#if !defined(ANDROID)

/* DEPRECATED, use ALOGI instead */
#define ALOG(format, ...)  core_log(LOG_LEVEL_INFO, NULL, NULL, 0, format, ## __VA_ARGS__)
#define ALOGI(format, ...)  core_log(LOG_LEVEL_INFO, __FILE__, __FUNCTION__, __LINE__, format, ## __VA_ARGS__)
#define ALOGE(format, ...)  core_log(LOG_LEVEL_ERR, __FILE__, __FUNCTION__, __LINE__, format, ## __VA_ARGS__)
#define ALOGD(format, ...)  core_log(LOG_LEVEL_DEBUG, __FILE__, __FUNCTION__, __LINE__, format, \
        ## __VA_ARGS__)
#define ALOGW(format, ...)  core_log(LOG_LEVEL_WARNING, __FILE__, __FUNCTION__, __LINE__, format, \
        ## __VA_ARGS__)
#define ALOGF(format, ...)  core_log(LOG_LEVEL_EMERG, __FILE__, __FUNCTION__, __LINE__, format, \
        ## __VA_ARGS__)
#define ALOGA(format, ...)  core_log(LOG_LEVEL_ALERT, __FILE__, __FUNCTION__, __LINE__, format, \
        ## __VA_ARGS__)
#define ALOGC(format, ...)  core_log(LOG_LEVEL_CRIT, __FILE__, __FUNCTION__, __LINE__, format, ## __VA_ARGS__)
#define ALOGV(format, ...)  core_log(LOG_LEVEL_VERBOSE, __FILE__, __FUNCTION__, __LINE__, format, \
        ## __VA_ARGS__)

#endif

/* Getops interface */
#define MAX_FLAG_VALUE_LEN 256
#define REQ true
#define OPT false

typedef struct {
    char *long_name;
    char *short_name;
    vtype_t type;
    void *value;
    bool required;
    char *description;
} flag_t;

/**
 * \addtogroup getops Command Line Parsing functions
 * @{ */
/**
 * @brief parses command line arguments
 *
 * @param argc the number of command line strings
 * @param argv the array of command line strings
 * @param flags a <b>flag_t</b> instance where store flags' arguments
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                if the CLI has been parsed succesfully <BR>
 * <b>CORE_ERROR_EINVAL</b>           otherwise<BR>
 */
core_res_t get_opts(int argc, char **argv, flag_t *flags);

#define MAX_HELP_MSG_LINE 512

/**
 * @brief Format the help message given usage string and #flag_t
 *
 * @param usage the usage string
 * @param flags_arr a #flag_t array of CLI options
 * @param flags_arr_size the size of the #flag_t
 * @param help_message[][MAX_HELP_MSG_LINE] the output help message
 * @param help_message_size the max number of rows of the help_message
 * @return the number of lines of the help_message <BR>
 */
int compose_help_message(const char *usage,
        const flag_t *flags_arr, const uint8_t flags_arr_size,
        char help_message[][MAX_HELP_MSG_LINE], const uint8_t help_message_size);
/**  @} */

/**
 * \addtogroup string String copying function
 * @{
 * @brief String copying function
 */

/**
 * @brief Size-bounded string copying.
 *
 * The strlcpy() function copy strings. It is designed to be safer, more
 * consistent, and less error prone replacement for strncpy. Unlike that
 * function, strlcpy() take the full size of the buffer (not just the length)
 * and guarantee to NUL-terminate the result (as long as size is larger than 0).
 * Note that a byte for the NUL should be included in size. Also note that
 * strlcpy() only operate on true “C” strings. This means that for strlcpy() src
 * must be NUL-terminated.
 *
 * The strlcpy() function copies up to size - 1 characters from the
 * NUL-terminated string src to dst, NUL-terminating the result.
 *
 * @param dst a buffer where the string is copied
 * @param src a string to be copied
 * @param size the size of the destination buffer
 * @return length of the string to be copied
 */
size_t strlcpy(char *dst, const char *src, size_t size);

/**  @} */

typedef struct core_timeval {
    uint32_t tv_sec;
    uint32_t tv_usec;
} core_timeval_t;

/** \addtogroup core_generic Core generic
 *  @{
 *  @brief Generic functions (e.g. engine init, sleep...)
 */
/**
 * @brief initializes os abstraction layer
 *
 * executes os dependent initializations (if needed) for the abstraction layer
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 when the initialization is successful<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_init(void);
/**
 * @brief deinitializes os abstraction layer
 *
 * executes os dependent deinitializations (if needed) for the abstraction layer
 */
void core_deinit(void);
/**
 * @brief puts the core to sleep
 *
 * sleeps for @p timeout_ms milli-seconds
 * @param timeout_ms milli-seconds to sleep
 */
void core_sleep(const uint32_t timeout_ms);
/**
 * @brief notifies to the core the arrival of a signal
 *
 * notifies to the core the arrival of a signal belonging to the ones defined in
 * @c signal.h, since some implementations of the abstraction layer needs to be informed
 * about this (e.g. @ref core_wait_for_serial for Linux)
 * @param sig signal defined in @c signal.h (e.g. @c SIGINT, @c SIGHUP)
 */
void core_signal_notify(const int sig);
/**
 * @brief returns get times of day
 *
 * gives the number of seconds and microseconds since the Epoch
 * @param tv a core_timeval_t with seconds and microseconds since the Epoch
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if file is closed<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_get_time_of_day(core_timeval_t *tv);
/**
 * @brief copies value from little endian to host
 *
 * copies value from little endian to host with endianess conversion if needed,
 * supported sizes are 1, 2, 4 and 8 bytes.
 * @param dest pointer to the destination variable
 * @param dest_size size in bytes of the destination variable
 * @param src pointer to the source variable
 * @param src_size size in bytes of the source variable
 */
void core_letoh(void *dest, size_t dest_size, void *src, size_t src_size);
/**
 * @brief copies value from host to little endian
 *
 * copies value from host to little endian with endianess conversion if needed,
 * supported sizes are 1, 2, 4 and 8 bytes.
 * @param dest pointer to the destination variable
 * @param dest_size size in bytes of the destination variable
 * @param src pointer to the source variable
 * @param src_size size in bytes of the source variable
 */
void core_htole(void *dest, size_t dest_size, void *src, size_t src_size);
/**
 * @brief finds substring ignoring the case
 *
 * find the first occurrence of the substring needle in the string haystack
 * ignoring the case of both strings.
 * @param haystack pointer to the string to be searched
 * @param needle pointer to the substring
 *
 * @return a pointer to the beginning of the substring, or NULL if the substring is not found
 */
char *core_str_case_str(const char *haystack, const char *needle);

/* Endianess conversion helpers */
#define CORE_COPY_LETOH(DST, SRC) { core_letoh(&(DST), sizeof(DST), &(SRC), sizeof(SRC)); }
#define CORE_COPY_HTOLE(DST, SRC) { core_htole(&(DST), sizeof(DST), &(SRC), sizeof(SRC)); }

/**
 * @brief print Telit OS abstraction layer version
 *
 * print Telit OS Abstraction layer version in the form MAJOR.MINOR.ALPHA.CUSTOM
 */
void core_print_tosal_version(void);
/** @}*/

/* USB ID interface */
/**
 * \addtogroup core Core USB ID interface
 * @{
 * @brief USB ID data and functions
 */
#define MAX_USB_ID_NUM  40

/**
 * @brief USB ID structure with vendor and product id
 */
typedef struct {
    uint32_t vid;  /**< the vendor id as hex number */
    uint32_t pid;  /**< the product id as hex number */
} usb_id_t;

/**
 * @brief List of usb_id_t items
 */
typedef struct {
    uint8_t len;                    /**< the number of usb_id_t in the items list */
    usb_id_t items[MAX_USB_ID_NUM]; /**< the usb_id_t list */
} usb_id_list_t;

/**
 * @brief Fill a usb_id_t structure with vendor id and product id in string format
 *
 * @param usb_id a usb_id_t structure
 * @param vid a vendor id string
 * @param pid a product id string
 *
 * @return true in case of succes, false otherwise
 */
bool core_usb_id_from_str(usb_id_t *usb_id, const char *vid, const char *pid);
/**
 * @brief Check whether the given usb_id_t is null
 *
 * @param usb_id a usb_id_t structure
 *
 * @return true if both vid and pid are zero, false otherwise
 */
bool core_usb_id_is_null(usb_id_t *usb_id);
/**
 * @brief Check if two usb_id_t are equals
 *
 * @param left a usb_id_t item
 * @param right a usb_id_t item
 *
 * @return true if vid and pid of left and right usb_id_t are the same
 */
bool core_usb_id_equals(const usb_id_t *left, const usb_id_t *right);
/** @}*/


/* File interface */
/**
 * \addtogroup core_file Core File interface
 * @{
 * @brief File functions
 */

/**
 * @brief Check for file existence.
 *
 * @param file_path the path of the file to check
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if the file exists<BR>
 * <b>CORE_ERROR_EINVAL</b>            if the file_path is NULL<BR>
 * <b>CORE_ERROR_FILE_NOT_FOUND</b>    if the file does not exists<BR>
 */
core_res_t core_file_exists(const char *file_path);
/**
 * @brief opens a file
 *
 * opens a file at the given @p file_path and returns the related @p handle
 * @param file_path the relative/absolute path of the file to open
 * @param handle the handle of the opened file
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if the file is opened<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_file_open(const char *file_path, file_handle_t *handle);
/**
 * @brief closes a file
 *
 * @param handle file to be closed
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if file is closed<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_file_close(const file_handle_t handle);
/**
 * @brief reads from file
 *
 * attemps to read up to @b bytes_to_read from @p handle
 * @param handle the handle of the file from which to read
 * @param buffer the buffer containing the bytes read
 * @param bytes_to_read the number of bytes to read
 * @param bytes_read the actual bytes read
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if read succeeded<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_file_read(const file_handle_t handle, void *buffer, uint32_t bytes_to_read,
        uint32_t *bytes_read);
/**
 * @brief writes bytes to file
 *
 * attempts to write @p bytes_to_write bytes from @p buffer into @p handle file
 * @param handle the handle of the file
 * @param buffer the buffer containing the bytes to write
 * @param bytes_to_write the number of bytes to write
 * @param bytes_written the number of bytes actually written
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if write succeeded<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_file_write(const file_handle_t handle, const void *buffer, const uint32_t bytes_to_write,
        uint32_t *bytes_written);
/**
 * @brief repositions the offset of the open file
 *
 * attemps to reposition the offset of the file associated with @p handle to @p offset bytes
 * @param handle the handle of the file
 * @param offset the bytes of the offset
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if file is closed<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_file_lseek_set(file_handle_t handle, int64_t offset);
/**
 * @brief gets the file size in bytes
 *
 * @param handle the handle of the file
 * @param size the size in bytes of the file
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if the get file size operation succeeded<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_file_get_size(const file_handle_t handle, uint64_t *size);
/**
 * @brief creates a directory
 *
 * @param path the relative/absolute path of the directory to be created
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                          if the directory was created<BR>
 * <b>CORE_ERROR_OPERATION_NOT_PERMITTED</b>    for implementation specific errors<BR>
 */
core_res_t core_create_directory(const char *path);
/**
 * @brief Check for directory existence.
 *
 * @param path the path of the directory to check
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if the directory exists<BR>
 * <b>CORE_ERROR_EINVAL</b>            if the path is NULL<BR>
 * <b>CORE_ERROR_FILE_NOT_FOUND</b>    if the directory does not exists<BR>
 */
core_res_t core_directory_exists(const char *path);
/**  @} */

/* Device interface */
typedef struct {
    /* On Linux ttyUSBx/ttyACMx
     * On Windows the devicePath and COMx */
    char location_path[MAX_STR_VALUE];
    char serial[MAX_STR_VALUE];
    char vendor_id[MAX_USB_ID_LEN + 1];
    char product_id[MAX_USB_ID_LEN + 1];
    char comm_ports[MAX_COMM_PORTS_NUM][MAX_STR_VALUE];
    char ifaces[MAX_COMM_PORTS_NUM][2 + 1];
    char drivers[MAX_COMM_PORTS_NUM][MAX_STR_VALUE + 1];
    uint32_t comm_ports_number;
    char dev_path[MAX_STR_VALUE];
} dev_info_t;

/**
 * @brief struct representing the serial state
 */
typedef struct {
    bool dsr;  /**< data set ready */
    bool cts;  /**< clear to send */
    bool dcd;  /**< data carrier detect */
    bool ring; /**< ring */
} serial_state_t;

/**
 * @brief Check whether the the usb_id_list contains the dev_info_t's vid & pid
 *
 * @param devinfo a dev_info_t item
 * @param data a usb_id_list_t item
 *
 * @return true if the usb_id_list contains the dev_info_t's vid & pid, false otherwise.
 */
/* NOTE: usb_id_list is defined as `void *` so that this function can be passed as "condition"
 * function to core_device_event_listener */
bool core_usb_id_find_match(dev_info_t *devinfo, void *usb_id_list);

/**
 * \deprecated use core_device_enumerate instead
 * @brief Return dev_info_t of the first device from usb_id_list_t if connected
 *
 * @param usb_ids a usb_id_list_t of the devices to check for
 * @param info the dev_info_t of the connected device
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if the device is connected<BR>
 * <b>CORE_ERROR_NO_SUCH_DEVICE</b>    if the device is not connected<BR>
 */
core_res_t core_usb_id_get_device_if_connected(const usb_id_list_t *usb_ids, dev_info_t *info);

/**
 * @brief Returns a dev_info_t for a connected device with usb_id_t from the given usb_id_list_t, or wait for it for timeout_ms
 *
 * @param usb_ids a usb_id_list_t with the USB id of valid devices.
 * @param info a dev_info_t of the device connected
 * @param timeout_ms the maximum time in milliseconds to wait for a device (use TIMEOUT_INFINITE for wait endlessly)
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if a valid device is connected <BR>
 * <b>CORE_ERROR_TIMEOUT</b>           if the timeout expires<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_usb_id_wait_for_devices(const usb_id_list_t *usb_ids, dev_info_t *info,
        const uint32_t timeout_ms);

/**
 * \addtogroup core_device Core Device interface
 * @{
 * @brief Generic devices functions
 */
/**
 * @brief opens a system device
 *
 * opens a system device at the given @p device_path
 * @param device_path the device path
 * @param handle the handle of the opened device
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if the device is opened <BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_device_open(const char *device_path, dev_handle_t *handle);
/**
 * @brief closes a system device
 *
 * closes a system device represented by @p handle
 * @param handle the handle of the device to close
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if the device is closed<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_device_close(const dev_handle_t handle);
/**
 * @brief configures a system device
 *
 * configures some OS dependent settings of a system device
 * @param handle the handle of the system device to configure
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if configure operation succeeded<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_device_config(const dev_handle_t handle);

/**
 * @brief configure HW flow control on system device.
 *
 * @param handle, the handle of the system device to configure.
 * @param enable, if true enable HW flow control, if false disable HW flow control.
 *
 * @return @c core_res_t <b>CORE_SUCCESS</b> if configure operation succeeded, or the appropriate error code otherwise.
 */
core_res_t core_set_hw_flow_control(const dev_handle_t handle, const bool enable);
/**
 * @brief sets the control signals (DTR, RTS) for a serial device
 *
 * sets the control signals (DTR, RTS) for a serial device
 * @param handle the handle of the system device to configure
 * @param dtr, Data Terminal Ready value
 * @param rts, Request To Send value
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if configure operation succeeded<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_set_control_signals(const dev_handle_t handle, bool dtr, bool rts);
/**
 * @brief gets the state of a serial device
 *
 * gets the state of a serial device
 * @param handle the handle of the serial device
 * @param state, instance of #serial_state_t
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>       if the get operation succeeds<BR>
 * <b>CORE_ERROR_EINVAL</b>  if input is not valid<BR>
 * <b>CORE_ERROR_UNKNOWN</b> for implementation specific errors<BR>
 */
core_res_t core_get_serial_state(const dev_handle_t handle, serial_state_t *state);
/**
 * @brief set system device's baud rate
 *
 * attempts to change system device's baud rate
 * @param handle the handle of the device to configure
 * @param baud_rate the baud rate to be set
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if baud rate is set<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_device_set_baud_rate(const dev_handle_t handle, const uint32_t baud_rate);
/**
 * @brief reads bytes from a system device
 *
 * reads bytes @p bytes_to_read from device @p handle and store them in @p buffer. <BR>
 * @param handle the handle of the device
 * @param buffer buffer to store the read bytes
 * @param bytes_to_read the amount of bytes to read
 * @param bytes_read number of bytes read <b>(could be less than bytes_to_read)</b>
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if read succeeded <BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_device_read(dev_handle_t handle, void *buffer, const uint32_t bytes_to_read,
        uint32_t *bytes_read);
/**
 * @brief writes bytes into a system device
 *
 * attemps to write up to @p bytes_to_write from @p buffer into a system device referenced by @p handle
 * @param handle the handle of the device
 * @param buffer the buffer from where the bytes to write are taken
 * @param bytes_to_write the amount of bytes to write
 * @param bytes_written number of bytes written <b>(could be less than bytes_to_write)</b>
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if write succeeded<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_device_write(const dev_handle_t handle, const void *buffer, const uint32_t bytes_to_write,
        uint32_t *bytes_written);
/**
 * @brief writes bytes into a system device in a recoursive way
 *
 * attemps to write up to @p bytes_to_write from @p buffer into a system device referenced by @p handle
 * and, if written bytes is less than @p bytes_to_write, it reiterates the operation
 * @param handle the handle of the device
 * @param buffer the buffer from where the bytes to write are taken
 * @param bytes_to_write the amount of bytes to write
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if write succeeded<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_device_recoursive_write(const dev_handle_t handle, const void *buffer,
        const size_t bytes_to_write);
/**
 * @brief read bytes from a system device
 *
 * reads bytes @p bytes_to_read from device @p handle and store them in @p buffer. <BR>
 * @param handle the handle of the device
 * @param buffer buffer to store the read bytes
 * @param bytes_to_read the amount of bytes to be read
 * @param msec number of milliseconds that the function should block waiting for the bytes
 * @param bytes_read number of bytes read <b>(could be less than bytes_to_read)</b>
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if socket is connected<BR>
 * <b>CORE_ERROR_TIMEOUT</b>           if timeout occurs<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_device_timed_read(const dev_handle_t handle, void *buffer, uint32_t bytes_to_read,
        const uint32_t msec, uint32_t *bytes_read);
/**
 * @brief gets available bytes to be read
 *
 * gets the number of @p bytes available to be read from device. <BR>
 * @param handle the handle of the device
 * @param bytes the bytes available
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if operetion succeeds<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_device_get_bytes_available(const dev_handle_t handle, uint32_t *bytes);

/**
 * @brief waits for the device to become ready to perform I/O
 *
 * monitors @p handle device for up to @p msec millisecond to become ready to perform I/O. <BR>
 * @param handle the handle of the device
 * @param msec the milliseconds the function will waits for the device to be ready
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if socket is connected<BR>
 * <b>CORE_ERROR_TIMEOUT</b>           if timeout occurs<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_device_poll(const dev_handle_t handle, const int64_t msec);

/**
 * @brief Return a dev_info_t for each connected USB device with ID included in the usb_id_t list
 *
 * @param usbid_list the usb_id_t list used to filter connected USB devices
 * @param usbid_list_size the size of the usb_id_t list
 * @param dev_list a list of dev_info_t for each connected device
 * @param dev_list_size in the size of the given dev_info_t list, out the actual size of the list returned
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if one or more valid devices are connected <BR>
 * <b>CORE_ERROR_NO_SUCH_DEVICE</b>    if no device is connected<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           otherwise<BR>
 */
core_res_t core_device_enumerate(const usb_id_t *usbid_list, const uint8_t usbid_list_size,
        dev_info_t *dev_list, int8_t *dev_list_size);

/**
 * \deprecated use core_device_enumerate instead
 * @brief looks for a device with @p vid (vendor ID) and @p pid (product ID) and, if connected, returns a related dev_info_t @p info. <BR>
 *
 * @param vid the vendor ID of the device
 * @param pid the product ID of the device
 * @param info the dev_info_t of the device
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if a device with VID/PID is connected and dev_info_t is returned <BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_device_get_info(const char *vid, const char *pid, dev_info_t *info);

/**
 * \deprecated use core_device_enumerate instead
 * @brief looks for a device with given @p USB ID and, if connected, returns a related dev_info_t @p info. <BR>
 *
 * @param usbid the usb_id_t structure containing the vendor ID and product ID of the device
 * @param info dev_info_t for the matching device
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if a device with VID/PID is connected and dev_info_t is returned <BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_device_get_usb_id_info(const usb_id_t *usbid, dev_info_t *info);

/**
 * \deprecated use core_device_enumerate instead
 * @brief return a list of #dev_info_t for the given #usb_id_t
 *
 * @param usbid the usb_id_t used to filter connected USB devices
 * @param info a list of dev_info_t for each connected device
 * @param len in the size of the given dev_info_t list, out the actual size of the list returned
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if one or more valid devices are connected <BR>
 * <b>CORE_ERROR_NO_SUCH_DEVICE</b>    if no device is connected<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           otherwise<BR>
 */
core_res_t core_device_get_usb_id_info_list(const usb_id_t *usbid, dev_info_t *info, const int len);

/**
 * @brief listen to USB connection events
 *
 * listen to USB connection events for which the @p condition function with @p data data is TRUE, up to @p timeout_ms milliseconds. <BR>
 * @param condition a function applied to each USB connection event data
 * @param data a data passed to the @p condition function
 * @param timeout_ms the milliseconds the listener will wait for a @p condition matching USB connection event or TIMEOUT_INFINITE (0xFFFFFFFF) to wait without timeout.
 * @param usb_id_t the usb_id_t structure with the vendor and product ID of the occurred event
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if file is closed<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_device_usb_id_event_listener(bool (*condition)(dev_info_t *info,
        void *data), void *data, uint32_t timeout_ms, usb_id_t *event);
/**
 * @brief listen to USB connection events
 *
 * listen to USB connection events for which the @p condition function with @p data data is TRUE, up to @p timeout_ms milliseconds. <BR>
 * @param condition a function applied to each USB connection event data
 * @param data a data passed to the @p condition function
 * @param timeout_ms the milliseconds the listener will wait for a @p condition matching USB connection event or TIMEOUT_INFINITE (0xFFFFFFFF) to wait without timeout.
 * @param event_type type of the occurred event
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if file is closed<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_device_usb_id_event_type_listener(bool (*condition)(dev_info_t *info,
        void *data), void *data, uint32_t timeout_ms, usb_id_t *event, usb_event_t *event_type);
/**
 * \deprecated use core_device_usb_id_event_listener instead
 * @brief listen to USB connection events
 *
 * listen to USB connection events for which the @p condition function with @p data data is TRUE, up to @p timeout_ms milliseconds. <BR>
 * @param condition a function applied to each USB connection event data
 * @param data a data passed to the @p condition function
 * @param timeout_ms the milliseconds the listener will wait for a @p condition matching USB connection event or TIMEOUT_INFINITE (0xFFFFFFFF) to wait without timeout.
 * @param event_vid allocated char array that will contain the Vendor ID of the USB event for witch @p condition function returned TRUE
 * @param event_pid allocated char array that will contain the Product ID of the USB event for witch @p condition function returned TRUE
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if file is closed<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_device_event_listener(bool (*condition)(dev_info_t *info,
        void *data), void *data, uint32_t timeout_ms, char *event_vid, char *event_pid);
/**
 * @brief checks whether the device has specific vid, pid
 *
 * checks whether the device described by the given @p info has @p vid (vendor) and @p pid (product) IDs
 * @param info the <b>dev_info_t<\b> of device
 * @param vid a vendor ID
 * @param pid a product ID
 *
 * @return true if @p info has the given @p vid and @p pid values
 */
bool core_device_has_vid_pid(const dev_info_t *info, const char *vid, const char *pid);
/**
 * @brief discards all characters from the buffer of a specified device
 *
 * @param handle the handle of the device
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if operation succeeds<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_device_flush(const dev_handle_t handle);
/**
 * @brief Return the canonicalized absolute pathname.
 *
 * @param path the path of the device to check
 * @param real_path the real path string pointer
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if operation succeeds<BR>
 * <b>CORE_ERROR_EINVAL</b>            if the path is NULL<BR>
 * <b>CORE_ERROR_NOT_IMPLEMENTED</b>   if not implemented<BR>
 * <b>return a specific core_res_t in case of failure<BR>
 */
core_res_t core_device_realpath(const char *path, char *real_path);
/**  @} */

/** \addtogroup serial_ext Serial extensions for devices
 *  @{
 *  @brief Serial devices specific functions
 */
/**
 * @brief waits for a serial device
 *
 * waits for the serial device @p port (value of port is os dependent) and returns
 * when found, error or @c SIGINT is notified to the core @ref core_signal_notify
 * @param port serial device name <b>(os dependent)</b> (e.g. @c /dev/ttyUSB0 in Linux, @c COM5 in Windows)
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if serial port is found<BR>
 * <b>CORE_ERROR_NO_SUCH_DEVICE</b>    if interrupted before having found the device<BR>
 * <b>CORE_ERROR_NOT_IMPLEMENTED</b>   if not implemented<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_wait_for_serial(const char *port);
/** @}*/

/**
 * \addtogroup core_endpoint Core Endpoint interface
 * @{
 * @brief USB functions
 */
/**
 * @brief opens an USB endpoint device
 *
 * opens the read and write endpoints of a device described by the given dev_info_t @p info
 * @param info the <b>dev_info_t</b> of the device to be opened
 * @param ep the <b>dev_ctx_t</b> structure that describes the opened endpoint
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if endpoint is opened <BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_endpoint_open(const dev_info_t *info, dev_ctx_t *ep);
/**
 * @brief closes an USB endpoint device
 *
 * @param ep the <b>dev_ctx_t</b> instance of the device to be closed
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if the endpoint is closed<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_endpoint_close(dev_ctx_t *ep);
/**
 * @brief writes bytes to endpoint
 *
 * attempts to write up to @p bytes_to_write from @p buffer to an @p ep endpoint
 * @param ep the <b>dev_ctx_t</b> of the endpoint
 * @param buffer the buffer with the bytes to write
 * @param bytes_to_write the number of bytes to write
 * @param bytes_written number of bytes written <b>(could be less than bytes_to_write)</b>
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if file is closed<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_endpoint_write(const dev_ctx_t *ep, const void *buffer, const uint32_t bytes_to_write,
        uint32_t *bytes_written);
/**
 * @brief reads bytes from endpoint
 *
 * reads bytes @p bytes_to_read from endpoint @p ep and store them in @p buffer. <BR>
 * @param ep the <b>dev_ctx_t</b> of the endpoint
 * @param buffer buffer to store the read bytes
 * @param bytes_to_read amount of bytes to be read
 * @param bytes_read number of bytes read <b>(could be less than bytes_to_read)</b>
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if file is closed<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_endpoint_read(const dev_ctx_t *ep, void *buffer, const uint32_t bytes_to_read,
        uint32_t *byte_read);
/**  @} */

/** \addtogroup socket Sockets interface
 *  @{
 *  @brief Sockets functions
 */
/**
 * @brief Initialize sockets engine
 *
 * executes os dependent initializations (if needed) for the socket engine
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if serial port is found<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_socket_init();
/**
 * @brief Creates a tcp socket
 *
 * creates an <c>AF_INET, SOCK_STREAM, IPPROTO_TCP</c> socket and stores handle in @p handle
 * @param handle handle of the created socket if succesfull, otherwise @c INVALID_SOCKET_HANDLE
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if socket is created<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_socket_inet_tcp_create(socket_handle_t *handle);
/**
 * @brief Connects a tcp socket
 *
 * connects socket @p handle to the couple @p address @p port
 * @param handle handle of the socket to be connected
 * @param address string with the numeric address for the connection
 * @param port string with the port for the connection
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if socket is connected<BR>
 * <b>CORE_ERROR_EINVAL</b>            if address or port is not valid<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_socket_inet_tcp_connect(socket_handle_t handle, const char *address, const char *port);
/**
 * @brief Read bytes from a connected socket
 *
 * reads bytes @p bytes_to_read from socket @p handle and store them in @p buffer. <BR>
 * The function waits at most @p msec milliseconds, then returns. The amount of bytes really read are available in @p bytes_read
 * @param handle handle of the socket used for reading
 * @param buffer buffer to store the read bytes
 * @param bytes_to_read amount of bytes to be read
 * @param msec number of milliseconds that the function should block waiting for the bytes
 * @param bytes_read number of bytes read <b>(could be less than bytes_to_read)</b>
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if socket is connected<BR>
 * <b>CORE_ERROR_TIMEOUT</b>           if timeout occurs<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_socket_timed_read(const socket_handle_t handle, void *buffer, uint32_t bytes_to_read,
        const uint32_t msec, uint32_t *bytes_read);
/**
 * @brief Write bytes to a connected socket
 *
 * Write bytes @p bytes_to_write stored in @p buffer to socket @p handle. <BR>
 * The amount of bytes really written are available in @p bytes_written
 * @param handle handle of the socket used for writing
 * @param buffer buffer where the bytes to be written are stored
 * @param bytes_to_write amount of bytes to be written
 * @param bytes_written number of bytes written <b>(could be less than bytes_to_write)</b>
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if socket is connected<BR>
 * <b>CORE_ERROR_TIMEOUT</b>           if timeout occurs (defined at the implementation level)<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_socket_write(const socket_handle_t handle, const void *buffer, const uint32_t bytes_to_write,
        uint32_t *bytes_written);
/**
 * @brief Binds a tcp socket
 *
 * Binds socket @p handle to the couple @p address @p port
 * @param handle handle of the socket to be bound
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if socket is bound<BR>
 * <b>CORE_ERROR_EINVAL</b>            if address or port is not valid<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_socket_inet_tcp_bind(socket_handle_t handle, const char *address, const char *port);
/**
 * @brief Listen from socket for an incoming connection
 *
 * Listens from socket @p handle waiting for an incoming connection
 * @param handle handle of the socket where listening from
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if an incoming connection has arrived<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_socket_listen(socket_handle_t handle);
/**
 * @brief Accepts an incoming connection from socket
 *
 * Accepts an incoming connection from socket @p handle, creates a new socket for operation and stores it in @p handle_accepted
 * @param handle handle of the socket used for accepting the incoming connection
 * @param handle_accepted new socket representing the accepted connection if successful, or @c INVALID_SOCKET_HANDLE
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if the incoming connection is accepted<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_socket_accept(socket_handle_t handle, socket_handle_t *handle_accepted);
/**
 * @brief Closes socket
 *
 * closes socket @p handle
 * @param handle socket to be closed
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if socket is closed<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_socket_close(socket_handle_t handle);
/**
 * @brief deinitializes sockets engine
 *
 * executes os dependent deinitializations (if needed) for the socket engine
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if serial port is found<BR>
 * <b>CORE_ERROR_UNKNOWN</b>           for implementation specific errors<BR>
 */
core_res_t core_socket_deinit();
/** @}*/

/** \addtogroup async operations interface
 *  @{
 *  @brief asynchronous functions
 */
/**
 * @brief creates a new thread and execute it immediately
 *
 * @param handle a @thread_handle_t instance
 * @param callback function executed by the created thread
 * @param callback_arg argument passed to the callback function
 *
 * @return @c core_res_t <br>
 * <b>core_success</b>                 if thread is created, or a specific error otherwise<br>
 */
core_res_t core_thread_create(thread_handle_t *handle, thread_ret_t (*callback)(void *), void *callback_arg);
/**
 * @brief waits for the thread specified by thread to terminate
 *
 * @param handle the handle of the thread to wait for
 * @param result the thread exit code (tbd)
 *
 * @return @c core_res_t <br>
 * <b>core_success</b>                 if thread is joined, or a specific error otherwise<br>
 */
core_res_t core_thread_join(thread_handle_t *handle, void *result);

/**
 * @brief initialize a @mutex_handle_t instance
 *
 * @param handle the @mutex_handle_t instance
 *
 * @return @c core_res_t <br>
 * <b>core_success</b>                 if mutex is created, or a specific error otherwise<br>
 */
core_res_t core_mutex_create(mutex_handle_t *handle);
/**
 * @brief locks the @mutex_handle_t mutex, if it is unlocked, otherwise blocks the caller until
 * the mutex is locked.
 *
 * @param handle the @mutex_handle_t instance
 *
 * @return @c core_res_t <br>
 * <b>core_success</b>                 if has locked the mutex, or a specific error otherwise<br>
 */
core_res_t core_mutex_lock(mutex_handle_t *handle);
/**
 * @brief unlocks the @mutex_handle_t mutex
 *
 * @param handle the @mutex_handle_t instance
 *
 * @return @c core_res_t <br>
 * <b>core_success</b>                 if it has unlocked the mutex, or a specific error otherwise<br>
 */
core_res_t core_mutex_unlock(mutex_handle_t *handle);
/**
 * @brief destroys the @mutex_handle_t mutex
 *
 * @param handle the @mutex_handle_t instance
 *
 * @return @c core_res_t <br>
 * <b>core_success</b>                 if mutex has been destroyed, or a specific error otherwise<br>
 */
core_res_t core_mutex_destroy(mutex_handle_t *handle);

/**
 * @brief creates a @sem_handle_t semaphore
 *
 * @param handle the @sem_handle_t instance
 * @param value the initial semaphore value
 *
 * @return @c core_res_t <br>
 * <b>core_success</b>                 if semaphore is created, or a specific error otherwise<br>
 */
core_res_t core_sem_create(sem_handle_t *handle, int32_t value);
/**
 * @brief If the @sem_handle_t semaphore's value is zero, then the call blocks until
 * it's value is larger than zero, otherwise it locks (decrement value by one) the
 * semaphore and returns immediately.
 *
 * @param handle the @sem_handle_t instance
 *
 * @return @c core_res_t <br>
 * <b>core_success</b>                 if semaphore has been locked, or a specific error otherwise<br>
 */
core_res_t core_sem_wait(sem_handle_t *handle);
/**
 * @brief same as core_sem_wait, but the call blocks at most @msec milliseconds at most, then
 * it either locks the semaphore, if possible, or return with CORE_ERROR_TIMEOUT
 *
 * @param handle the @sem_handle_t instance
 * @param msec the maximum amount of milliseconds the call can block the caller
 *
 * @return @c core_res_t <br>
 * <b>core_success</b>                 if semaphore has been unlocked, or a specific error otherwise<br>
 */
core_res_t core_sem_timedwait(sem_handle_t *handle, uint64_t msec);
/**
 * @brief unlock (increment value by one) the @sem_handle_t semaphore
 *
 * @param handle the @sem_handle_t instance
 *
 * @return @c core_res_t <br>
 * <b>core_success</b>                 if semaphore has been released, or a specific error otherwise<br>
 */
core_res_t core_sem_release(sem_handle_t *handle);
/**
 * @brief destroy the @sem_handle_t semaphore
 *
 * @param handle the @sem_handle_t instance
 *
 * @return @c core_res_t <BR>
 * <b>CORE_SUCCESS</b>                 if semaphore has been destroyed, or a specific error otherwise<BR>
 */
core_res_t core_sem_destroy(sem_handle_t *handle);
/** @}*/

#endif  /* _TELIT_OS_ABS_H_ */
