#ifndef _OS_H_
#define _OS_H_

#include <alloca.h>
#include <fcntl.h>
#include <stdint.h>
#include <sys/select.h>
#include <unistd.h>
#include <endian.h>
#include <limits.h>  /* PATH_MAX */

#define OS_DIR_SEPARATOR "/"

#define INVALID_DEVICE_HANDLE (-1)
#define INVALID_FILE_HANDLE   (-1)
#define INVALID_SOCKET_HANDLE (-1)

#define CORE_PATH_MAX PATH_MAX

typedef int dev_handle_t;
typedef int file_handle_t;
typedef int socket_handle_t;

#if PTHREAD
#include <pthread.h>
#include <semaphore.h>
typedef struct {
    pthread_t thread;
} thread_handle_t;
typedef void *thread_ret_t;
typedef pthread_attr_t thread_attr_t;

typedef struct {
    pthread_mutex_t mutex;
} mutex_handle_t;

typedef struct {
    sem_t semaphore;
} sem_handle_t;
#else

typedef void thread_handle_t;
typedef void mutex_handle_t;
typedef void sem_handle_t;
typedef void thread_ret_t;
typedef void thread_attr_t;
#endif

#if LIBUSB
#include <libusb-1.0/libusb.h>
typedef libusb_context usb_context_t;
typedef libusb_device usb_device_t;
typedef libusb_device_handle usb_handle_t;
#else
typedef void usb_context_t;
typedef void usb_device_t;
typedef int usb_handle_t;
#endif

typedef struct {
    dev_handle_t handle;
    usb_context_t *context;
    usb_handle_t *usb_handle;
    uint8_t interface_number;
    uint8_t read_endpoint_id;
    uint8_t write_endpoint_id;
    uint16_t write_max_pkt_size;
    bool enable_zlp;
} dev_ctx_t;

#endif  /* _OS_H_ */
