#include <assert.h>
#include <stdint.h>
#include <limits.h>
#include <ttest.h>

static void test_fail_num_check(void);
static void test_fail_str_check(void);
static void test_fail_truth_check(void);

int main(void)
{
    RUN(test_fail_num_check);
    RUN(test_fail_str_check);
    RUN(test_fail_truth_check);
    return 0;
}

static void test_fail_num_check(void)
{
    int32_t left32 = 1;
    int32_t right32 = 2;

    CHECK_NUM(left32, ==, right32);        /* expected to fail */
    CHECK_LONG(LONG_MAX, !=, LONG_MAX);    /* expected to fail */
    CHECK_ULONG(ULONG_MAX, !=, ULONG_MAX); /* expected to fail */
}

static void test_fail_str_check(void)
{
    char *leftA = "testA";
    char *rightB = "testB";

    CHECK_STR(leftA, !=, leftA);  /* expected to fail */
    CHECK_STR(leftA, ==, rightB); /* expected to fail */
}


static void test_fail_truth_check(void)
{
    bool value = true;

    CHECK_FALSE(value);
    CHECK_TRUE(!value);
}
