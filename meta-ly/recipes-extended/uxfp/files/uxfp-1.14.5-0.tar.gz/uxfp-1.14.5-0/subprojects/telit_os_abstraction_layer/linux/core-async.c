#include <errno.h>
#include <string.h>
#include "telit-os-abs.h"

core_res_t core_thread_create(thread_handle_t *handle,
        thread_ret_t (*callback)(void *),
        void *callback_arg)
{
#if PTHREAD == 0
    return CORE_ERROR_NOT_IMPLEMENTED;
#else
    core_res_t err;

    err = pthread_create(&handle->thread, NULL, callback, callback_arg);
    if (err) {
        ALOGE("could not create thread: error %d\n", err);
    }

    return err;
#endif
}

core_res_t core_thread_join(thread_handle_t *handle, void *result)
{
#if PTHREAD == 0
    return CORE_ERROR_NOT_IMPLEMENTED;
#else
    core_res_t err;

    /* TODO: get thread exit code (low prio) */
    err = pthread_join(handle->thread, NULL);
    if (err) {
        ALOGE("could not join thread: error %d\n", err);
        err = map_errno_to_core_err(err);
    }

    return err;
#endif
}

core_res_t core_mutex_create(mutex_handle_t *handle)
{
#if PTHREAD == 0
    return CORE_ERROR_NOT_IMPLEMENTED;
#else
    core_res_t err;

    err = pthread_mutex_init(&handle->mutex, NULL);
    if (err) {
        ALOGE("%s failed: error %d\n", __FUNCTION__, err);
    }

    return err;
#endif
}

core_res_t core_mutex_lock(mutex_handle_t *handle)
{
#if PTHREAD == 0
    return CORE_ERROR_NOT_IMPLEMENTED;
#else
    core_res_t err;

    err = pthread_mutex_lock(&handle->mutex);
    if (err) {
        ALOGE("%s failed: error %d\n", __FUNCTION__, err);
    }
    return err;
#endif
}

core_res_t core_mutex_unlock(mutex_handle_t *handle)
{
#if PTHREAD == 0
    return CORE_ERROR_NOT_IMPLEMENTED;
#else
    core_res_t err;

    err = pthread_mutex_unlock(&handle->mutex);
    if (err) {
        ALOGE("%s failed: error %d\n", __FUNCTION__, err);
    }
    return err;
#endif
}

core_res_t core_mutex_destroy(mutex_handle_t *handle)
{
#if PTHREAD == 0
    return CORE_ERROR_NOT_IMPLEMENTED;
#else
    core_res_t err;

    err = pthread_mutex_destroy(&handle->mutex);
    if (err) {
        ALOGE("%s failed: error %d\n", __FUNCTION__, err);
    }
    return err;
#endif
}

core_res_t core_sem_create(sem_handle_t *handle, int32_t value)
{
#if PTHREAD == 0
    return CORE_ERROR_NOT_IMPLEMENTED;
#else
    core_res_t err;

    errno = 0;
    /* non shared between processes by default */
    err = sem_init(&handle->semaphore, false, value);
    if (err) {
        ALOGE("%s failed: error %d: %s\n", __FUNCTION__, errno, strerror(errno));
        err = map_errno_to_core_err(errno);
    }

    return err;
#endif
}

core_res_t core_sem_wait(sem_handle_t *handle)
{
#if PTHREAD == 0
    return CORE_ERROR_NOT_IMPLEMENTED;
#else
    core_res_t err;

    errno = 0;
    err = sem_wait(&handle->semaphore);
    if (err) {
        ALOGE("%s failed: error %d: %s\n", __FUNCTION__, errno, strerror(errno));
        err = map_errno_to_core_err(errno);
    }

    return err;
#endif
}

core_res_t core_sem_timedwait(sem_handle_t *handle, uint64_t msec)
{
#if PTHREAD == 0
    return CORE_ERROR_NOT_IMPLEMENTED;
#else
    core_res_t err;
    struct timespec abs_timeout = {0, 1000 * msec};

    errno = 0;
    err = sem_timedwait(&handle->semaphore, &abs_timeout);
    if (err) {
        ALOGE("%s failed: error %d: %s\n", __FUNCTION__, errno, strerror(errno));
        err = map_errno_to_core_err(errno);
    }

    return err;
#endif
}

core_res_t core_sem_release(sem_handle_t *handle)
{
#if PTHREAD == 0
    return CORE_ERROR_NOT_IMPLEMENTED;
#else
    core_res_t err;

    errno = 0;
    err = sem_post(&handle->semaphore);
    if (err) {
        ALOGE("%s failed: error %d: %s\n", __FUNCTION__, errno, strerror(errno));
        err = map_errno_to_core_err(errno);
    }

    return err;
#endif
}

core_res_t core_sem_destroy(sem_handle_t *handle)
{
#if PTHREAD == 0
    return CORE_ERROR_NOT_IMPLEMENTED;
#else
    core_res_t err;

    errno = 0;
    err = sem_destroy(&handle->semaphore);
    if (err) {
        ALOGE("%s failed: error %d: %s\n", __FUNCTION__, errno, strerror(errno));
        err = map_errno_to_core_err(errno);
    }

    return err;
#endif
}

