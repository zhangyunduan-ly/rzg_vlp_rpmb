REM To be compiled with a VS Native Tools Command Prompt

@echo off

set name=telit-os-abs

if "%1"=="clean"  (
    del %name%.lib
    goto end
)

set CFLAGS=-I. -I..

cl %CFLAGS% -Focore.obj -FS -c core.c

for %%s in (core-*.c) do (
    cl %CFLAGS% -Fo%%~ns.obj -FS -c %%~ns.c
)

cl %CFLAGS% -Fostrlcpy.obj -FS -c ../strlcpy.c
cl %CFLAGS% -Folog.obj -FS -c ../telit-log.c
cl %CFLAGS% -Fousb_id.obj -FS -c ../core-usb-id.c
cl %CFLAGS% -Fogetopts.obj -FS -c ../telit-getopts.c

link -lib -nologo -out:%name%.lib ^
    winusb.lib advapi32.lib setupapi.lib user32.lib shlwapi.lib Winmm.lib ^
    core.obj core-async.obj core-device.obj core-endpoint.obj core-file.obj core-socket.obj usb_id.obj ^
    log.obj getopts.obj strlcpy.obj

del *.obj
:end
