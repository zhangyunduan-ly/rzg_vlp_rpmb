#ifndef _OS_H_
#define _OS_H_

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#ifndef DEFINE_GUID
#define DEFINE_GUID
#include <initguid.h>
#endif

#include <malloc.h>
#include <stdint.h>
#include <stdio.h>
#include <time.h>
#include <windows.h>
#include <timeapi.h>
#include <dbt.h>
#include <winreg.h>
#include <winsock2.h>
#include <usbiodef.h>
#include <setupapi.h>
#include <Winusb.h>
#include <Shlwapi.h>
#include <fileapi.h>
#include <synchapi.h>

#define OS_DIR_SEPARATOR "\\"
#define alloca _alloca

typedef HANDLE dev_handle_t;
#define INVALID_DEVICE_HANDLE INVALID_HANDLE_VALUE

typedef int32_t file_handle_t;
#define INVALID_FILE_HANDLE -1

typedef struct {
    WINUSB_INTERFACE_HANDLE usb_iface_handle;
    dev_handle_t handle;
    UCHAR read_endpoint_id;
    UCHAR write_endpoint_id;
    bool enable_zlp;
} dev_ctx_t;

#define INVALID_SOCKET_HANDLE INVALID_SOCKET
typedef SOCKET socket_handle_t;

#define INVALID_THREAD_HANDLE INVALID_HANDLE_VALUE
typedef HANDLE thread_handle_t;
typedef DWORD thread_ret_t;
typedef void thread_attr_t;

#define INVALID_MUTEX_HANDLE INVALID_HANDLE_VALUE
typedef HANDLE mutex_handle_t;

#define INVALID_SEM_HANDLE INVALID_HANDLE_VALUE
#define SEM_VALUE_MAX 100
typedef HANDLE sem_handle_t;
/* Endiannes */
#define htobe16(x) htons(x)
#define htole16(x) (x)
#define be16toh(x) ntohs(x)
#define le16toh(x) (x)

#define htobe32(x) htonl(x)
#define htole32(x) (x)
#define be32toh(x) ntohl(x)
#define le32toh(x) (x)

#define htobe64(x) htonll(x)
#define htole64(x) (x)
#define be64toh(x) ntohll(x)
#define le64toh(x) (x)

#define ALLOC(dwBytes)          GlobalAlloc(GPTR, (dwBytes))
#define REALLOC(hMem, dwBytes)  GlobalReAlloc((hMem), (dwBytes), (GMEM_MOVEABLE | GMEM_ZEROINIT))
#define FREE(hMem)              GlobalFree((hMem))

#define CORE_PATH_MAX MAX_PATH

/* *INDENT-OFF* */
#define ERROR_MSG_FMT(MSG, ERR)                              \
    {                                                        \
        LPVOID lpMsgBuf;                                     \
                                                             \
        lpMsgBuf = (LPVOID)"Unknown error";                  \
        if (FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER |   \
                FORMAT_MESSAGE_FROM_SYSTEM |                 \
                FORMAT_MESSAGE_IGNORE_INSERTS,               \
                NULL, ERR,                                   \
                MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),   \
                (LPTSTR)&lpMsgBuf, 0, NULL)) {               \
            ALOGE("%s: Error %d: %s\n", MSG, ERR, lpMsgBuf); \
            LocalFree(lpMsgBuf);                             \
        } else {                                             \
            ALOGE("%s: Error %d\n", MSG, ERR);               \
        }                                                    \
    }                                                        \
/* *INDENT-ON* */

#endif  /* _OS_H_ */
