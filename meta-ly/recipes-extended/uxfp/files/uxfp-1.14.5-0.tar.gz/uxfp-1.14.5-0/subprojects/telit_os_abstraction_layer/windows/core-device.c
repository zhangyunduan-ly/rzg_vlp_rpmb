#include <assert.h>
#include <signal.h>
#include <inttypes.h>

#include <telit-os-abs.h>

#define VERBOSE 0

#define RX_BUFFER_SIZE 0x8000
#define TX_BUFFER_SIZE 0x8000

extern sig_atomic_t sigint_detected;

GUID supported_guids[] = {
    /* GUID_DEVINTERFACE_COMPORT */
    {0X86E0D1E0L, 0X8089, 0X11D0, {0X9C, 0XE4, 0X08, 0X00, 0X3E, 0X30, 0X1F, 0X73}},
    /* ANDROID_USB_CLASS_ID */
    {0XF72FE0D4L, 0XCBCB, 0X407D, {0X88, 0X14, 0X9E, 0XD6, 0X73, 0XD0, 0XDD, 0X6B}},
    /* GUID_DEVINTERFACE_USB_DEVICE */
    {0xA5DCBF10L, 0x6530, 0x11D2, {0x90, 0x1F, 0x00, 0xC0, 0x4F, 0xB9, 0x51, 0xED}},
    /* GUID MODEM DEVICE */
    {0x2C7089AA, 0x2E0E, 0x11D1, {0xB1, 0x14, 0x00, 0xC0, 0x4F, 0xC2, 0xAA, 0xE4}},
    /* GUID_DEVINTERFACE_NET */
    {0xCAC88484, 0x7515, 0x4C03, {0x82, 0xE6, 0x71, 0xA8, 0x7A, 0xBA, 0xC3, 0x61}}
};

core_res_t map_get_last_error_to_core_err(DWORD err);

static int32_t get_device_path(HDEVINFO dev_info, SP_DEVICE_INTERFACE_DATA *dev_iface_data, char **path);
static HDEVINFO get_handle_for_guid(CONST GUID *class_guid);
static int32_t get_location_path(HDEVINFO dev_info, SP_DEVINFO_DATA *dev_info_data, char *location_path,
        size_t size);
static int32_t get_port_name(HDEVINFO dev_info, SP_DEVINFO_DATA *dev_info_data, char *port_name, size_t size);
static bool has_vid_pid(const usb_id_t *usbid, const char *path);
static int32_t get_vid_pid_from_port(const char *port, char *vid, char *pid);

const char *strcasestr(const char *arg1, const char *arg2)
{
    const char *a, *b;

    for (; *arg1; *arg1++) {
        a = arg1;
        b = arg2;

        while ((*a++ | 32) == (*b++ | 32))
            if (!*b) {
                return (arg1);
            }
    }

    return(NULL);
}

core_res_t core_device_open(const char *device_path, dev_handle_t *handle)
{
    core_res_t err = CORE_SUCCESS;
    char adjusted_device_path[16] = {0};
    char *actual_path;

    if (strcasestr(device_path, "COM")) {
        snprintf(adjusted_device_path, 16, "\\\\.\\%s", device_path);
        actual_path = adjusted_device_path;
    } else {
        actual_path = (char *)device_path;
    }

    *handle = CreateFile(actual_path,
            GENERIC_READ | GENERIC_WRITE,
            0,
            0,
            OPEN_EXISTING,
            FILE_FLAG_NO_BUFFERING,
            0);
    if (*handle == INVALID_DEVICE_HANDLE) {
        DWORD error = GetLastError();
        ERROR_MSG_FMT("could not open device", error);
        err = map_get_last_error_to_core_err(error);
    }

    return err;
}

core_res_t core_device_close(const dev_handle_t handle)
{
    core_res_t err = CORE_SUCCESS;
    BOOL ret;

    ret = CloseHandle(handle);
    if (!ret) {
        DWORD error = GetLastError();

        ERROR_MSG_FMT("could not close handle", error);
        err = map_get_last_error_to_core_err(error);;
    }

    return err;
}

core_res_t core_device_read(dev_handle_t handle, void *buffer, const uint32_t bytes_to_read,
        uint32_t *bytes_read)
{
    core_res_t ret = CORE_SUCCESS;
    BOOL ok;
    static bool modem_dsr_notice = false;

    *bytes_read = 0;
    ok = ReadFile(handle, buffer, bytes_to_read, bytes_read, NULL);
    if (!ok) {
        DWORD err = GetLastError();

        ERROR_MSG_FMT("could not read file", err);
        ret = map_get_last_error_to_core_err(err);
        goto end;
    }

    if (!*bytes_read) {
        /* with some modems, ReadFile returns with no error even if the device is
         * not present anymore. The only indication is that bytes_read is zero.
         * In this specific case, we check device's DSR flag is still ON. If not
         * the device has been probably disconnected or is not correctly functioning.
         * */
        DWORD modemstat = 0;
        ok = GetCommModemStatus(handle, &modemstat);
        if (!ok) {
            DWORD error = GetLastError();
            ERROR_MSG_FMT("GetCommModemStatus", error);
            ret = map_get_last_error_to_core_err(error);
            goto end;
        }

        if (!(MS_DSR_ON & modemstat)) {
            /* Prevent "DSR is OFF" notification to be appear twice in a row */
            if (!modem_dsr_notice) {
                ALOGD("modem DSR is OFF\n");
                modem_dsr_notice = true;
            }
            ret = CORE_ERROR_NO_SUCH_DEVICE;
        }
    }
    if (ret != CORE_ERROR_NO_SUCH_DEVICE) {
        modem_dsr_notice = false;
    }

end:
    return ret;
}

core_res_t core_device_timed_read(const dev_handle_t handle, void *buffer, uint32_t bytes_to_read,
        const uint32_t msec, uint32_t *bytes_read)
{
    core_res_t ret = CORE_SUCCESS;
    core_timeval_t tv_start;
    DWORD counter = MAXDWORD;

    *bytes_read = 0;
    core_get_time_of_day(&tv_start);

    /* Ugly hack, since there's no way to manage Windows timeouts for having
     * ReadFile act as poll in Linux */
    do {
        core_timeval_t tv_end;
        uint32_t bytes = 0;

        ret = core_device_get_bytes_available(handle, &bytes);
        if (ret) {
            goto end;
        }
        if (bytes) {
            break;
        }

        core_get_time_of_day(&tv_end);
        if ((tv_end.tv_sec * (int)1e6 + tv_end.tv_usec) - (tv_start.tv_sec * (int)1e6 + tv_start.tv_usec) >=
                msec * 1000) {
            ret = CORE_ERROR_TIMEOUT;
            goto end;
        }

        Sleep(0);
    } while (true);

    do {
        ret = core_device_read(handle, buffer, bytes_to_read, bytes_read);
        if (ret != CORE_SUCCESS) {
            ALOGE("Read error");
            goto end;
        }
    } while (*bytes_read == 0 && counter--);

    if (counter <= 0) {
        ret = CORE_ERROR_TIMEOUT;
    }

end:
    return ret;
}

core_res_t core_device_write(const dev_handle_t handle, const void *buffer, const uint32_t bytes_to_write,
        uint32_t *bytes_written)
{
    core_res_t ret = CORE_SUCCESS;
    BOOL ok;

    *bytes_written = 0;
    ok = WriteFile(handle, buffer, bytes_to_write, bytes_written, NULL);
    if (!ok) {
        DWORD err = GetLastError();

        ERROR_MSG_FMT("could not write to the device", err);
        ret = map_get_last_error_to_core_err(err);
    }

    return ret;
}

core_res_t core_device_recoursive_write(dev_handle_t handle, const void *buffer, size_t bytes_to_write)
{
    core_res_t ret = CORE_SUCCESS;
    uint32_t total_written = 0;
    uint32_t written = 0;
    int8_t retry = 10;
    BOOL ok;

    while (total_written < bytes_to_write && retry > 0) {
        ok = WriteFile(handle, buffer, bytes_to_write, &written, NULL);

        if (!ok) {
            DWORD err = GetLastError();

            ERROR_MSG_FMT("could not write to the device", err);
            ret = map_get_last_error_to_core_err(err);
            goto end;
        } else if (written == 0) {
            retry--;
            core_sleep(10);
            continue;
        }

        total_written += written;
        retry = 10;
    }

    if (retry == 0) {
        ALOGE("write returned zero (written %d bytes out of %d)\n", total_written, bytes_to_write);
        ret = CORE_ERROR_IO_ERROR;
    }

end:
    return ret;
}

core_res_t core_device_poll(const dev_handle_t handle, const int64_t msec)
{
    core_res_t ret = CORE_ERROR_TIMEOUT;
    int8_t retry_left = 10;
    int64_t msec_remaining = msec;
    uint32_t bytes = 0;
    uint32_t off = 5;

    /* Simple poll to check if there's something on the device */
    do {
        int64_t sleep;

        ret = core_device_get_bytes_available(handle, &bytes);
        if (ret) {
            if (ret != CORE_ERROR_NO_SUCH_DEVICE) {
                goto out;
            }
            /* This error comes from a DSR check, which may fail.
             * For this we keep checking for bytes availability until
             * the timeout occur, or the retries expiere,
             * then return CORE_ERROR_NO_SUCH_DEVICE
             * if this error persists */
        } else if (bytes) {
            goto out;
        }

        sleep = msec_remaining < off ? msec_remaining : off;
        core_sleep(sleep);
        msec_remaining -= sleep;
        if (msec == INFINITE) {
            retry_left--;
        }
    } while (msec_remaining > 0 && retry_left > 0);

    if (ret == CORE_ERROR_NO_SUCH_DEVICE) {
        return ret;
    }
    ret = CORE_ERROR_TIMEOUT;

out:
    return ret;
}

core_res_t core_get_serial_state(const dev_handle_t handle, serial_state_t *state)
{
    core_res_t err = CORE_SUCCESS;
    DWORD dwModemStatus;

    if (!state) {
        err = CORE_ERROR_EINVAL;
        goto end;
    }
    memset(state, 0, sizeof(*state));

    if (!GetCommModemStatus(handle, &dwModemStatus)) {
        goto end;
    }

    state->cts = MS_CTS_ON & dwModemStatus;
    state->dsr = MS_DSR_ON & dwModemStatus;
    state->ring = MS_RING_ON & dwModemStatus;
    state->dcd = MS_RLSD_ON & dwModemStatus;

end:
    return err;
}

core_res_t core_set_control_signals(const dev_handle_t handle, bool dtr, bool rts)
{
    core_res_t err = CORE_SUCCESS;
    BOOL ok;
    DCB state = {0};

    ok = GetCommState(handle, &state);
    if (!ok) {
        DWORD error = GetLastError();
        ERROR_MSG_FMT("could not get comm state", error);
        err = map_get_last_error_to_core_err(error);
        goto end;
    }

    state.fDtrControl = (dtr ? DTR_CONTROL_ENABLE : DTR_CONTROL_DISABLE);
    state.fRtsControl = (rts ? RTS_CONTROL_ENABLE : RTS_CONTROL_DISABLE);

    ok = SetCommState(handle, &state);
    if (!ok) {
        DWORD error = GetLastError();
        ERROR_MSG_FMT("could not set comm state", error);
        err = map_get_last_error_to_core_err(error);
    }

end:
    return err;
}

/* NOTE: this is the configuration performed by XFP on windows.
 *       Keeping it this way until we can decide what is the
 *       best way to reduce it in minimal functions, eventually
 *       useful on Linux too */
core_res_t core_device_config(const dev_handle_t handle)
{
    core_res_t err = CORE_SUCCESS;
    BOOL ok;
    DCB state = {0};
    COMMTIMEOUTS comm_timeouts = {0};
    COMMPROP comm_props = {0};

    ok = GetCommProperties(handle, &comm_props);
    if (!ok) {
        DWORD error = GetLastError();
        ERROR_MSG_FMT("could not get comm properties", error);
        err = map_get_last_error_to_core_err(error);
        goto end;
    }

    if (comm_props.dwMaxRxQueue == 0 || comm_props.dwMaxRxQueue > RX_BUFFER_SIZE) {
        comm_props.dwMaxRxQueue = RX_BUFFER_SIZE;
    }

    if (comm_props.dwMaxTxQueue == 0 || comm_props.dwMaxTxQueue > TX_BUFFER_SIZE) {
        comm_props.dwMaxTxQueue = TX_BUFFER_SIZE;
    }

    ok = SetupComm(handle, comm_props.dwMaxRxQueue, comm_props.dwMaxTxQueue);
    if (!ok) {
        DWORD error = GetLastError();
        ERROR_MSG_FMT("could not set comm", error);
        err = map_get_last_error_to_core_err(error);
        goto end;
    }

    comm_timeouts.ReadIntervalTimeout = 0xFFFFFFFF;
    comm_timeouts.ReadTotalTimeoutMultiplier = 0x00000000;
    comm_timeouts.ReadTotalTimeoutConstant = 0x00000000;
    comm_timeouts.WriteTotalTimeoutMultiplier = 0x00000000;
    comm_timeouts.WriteTotalTimeoutConstant = 0x00000000;

    ok = SetCommTimeouts(handle, &comm_timeouts);
    if (!ok) {
        DWORD error = GetLastError();
        ERROR_MSG_FMT("could not set timeout", error);
        err = map_get_last_error_to_core_err(error);
        goto end;
    }

    ok = GetCommState(handle, &state);
    if (!ok) {
        DWORD error = GetLastError();
        ERROR_MSG_FMT("could not get comm state", error);
        err = map_get_last_error_to_core_err(error);
        goto end;
    }

    state.fBinary = 1;
    state.fTXContinueOnXoff = 0;
    state.fErrorChar = 0;
    state.fNull = 0;
    state.fAbortOnError = 0;
    state.XonLim = comm_props.dwMaxRxQueue >> 1;
    state.XoffLim = comm_props.dwMaxRxQueue >> 3;

    state.fOutX = 0;
    state.fInX = 0;

    state.XonChar = 0x11;
    state.XoffChar = 0x13;
    state.ErrorChar = 0;
    state.EofChar = 0;
    state.EvtChar = 0;

    /* Disable DTR Control */
    state.fOutxDsrFlow = 0;
    state.fDtrControl = DTR_CONTROL_DISABLE;
    state.fDsrSensitivity = 0;

    state.fOutxCtsFlow = 0;

    ok = SetCommState(handle, &state);
    if (!ok) {
        DWORD error = GetLastError();
        ERROR_MSG_FMT("could not set comm state", error);
        err = map_get_last_error_to_core_err(error);
        goto end;
    }

    /* Disable HW flow control */
    err = core_set_hw_flow_control(handle, false);
    if (err) {
        ALOGE("could not disable hw flow control\n");
        goto end;
    }

    err = core_device_set_baud_rate(handle, 115200);
    if (err) {
        ALOGE("could not set the baud rate\n");
        goto end;
    }

    ok = EscapeCommFunction(handle, SETDTR);
    if (!ok) {
        DWORD error = GetLastError();
        ERROR_MSG_FMT("could not set DTR: error", error);
        err = map_get_last_error_to_core_err(error);
        goto end;
    }

    err = 0;
end:
    return err;
}

core_res_t core_set_hw_flow_control(const dev_handle_t handle, const bool enable)
{
    core_res_t err = CORE_SUCCESS;
    BOOL ok;
    DCB state = {0};
    BOOL lazy_change = false;

    ok = GetCommState(handle, &state);
    if (!ok) {
        DWORD error = GetLastError();
        ERROR_MSG_FMT("could not get comm state", error);
        err = map_get_last_error_to_core_err(error);
        goto end;
    }

    if (enable && state.fRtsControl != RTS_CONTROL_HANDSHAKE) {
        state.fRtsControl = RTS_CONTROL_HANDSHAKE;
        state.fOutxCtsFlow = true;
        lazy_change = true;
    }

    if (!enable && state.fRtsControl != RTS_CONTROL_DISABLE) {
        state.fRtsControl = RTS_CONTROL_DISABLE;
        state.fOutxCtsFlow = false;
        lazy_change = true;
    }

    if (lazy_change) {
        ALOGD("hw flow control: RTScontrol %d, CTSflow %d",
                state.fRtsControl, state.fOutxCtsFlow);
        state.DCBlength = sizeof(DCB);
        ok = SetCommState(handle, &state);
        if (!ok) {
            DWORD error = GetLastError();
            ERROR_MSG_FMT("could not set comm state", error);
            err = map_get_last_error_to_core_err(error);
        }
    }

end:
    return err;
}

core_res_t core_device_set_baud_rate(const dev_handle_t handle, const uint32_t baud_rate)
{
    core_res_t err = CORE_SUCCESS;
    BOOL ok;
    DCB settings;
    COMMPROP comm_props = {0};

    ok = GetCommProperties(handle, &comm_props);
    if (!ok) {
        DWORD error = GetLastError();
        ERROR_MSG_FMT("could not get comm properties", error);
        err = map_get_last_error_to_core_err(error);
        goto end;
    }

    if (!(comm_props.dwSettableParams | SP_BAUD)) {
        ALOGW("SP Baud is not configurable\n");
        goto end;
    }

    ok = GetCommState(handle, &settings);
    if (!ok) {
        DWORD error = GetLastError();
        ERROR_MSG_FMT("could not get COM settings", error);
        err = map_get_last_error_to_core_err(error);
        goto end;
    }

    settings.BaudRate = baud_rate;
    settings.ByteSize = 8;
    settings.Parity = NOPARITY;

    ok = SetCommState(handle, &settings);
    if (!ok) {
        DWORD error = GetLastError();
        ERROR_MSG_FMT("could not set COM settings", error);
        err = map_get_last_error_to_core_err(error);
        goto end;
    }

end:
    return err;
}

core_res_t core_device_get_bytes_available(const dev_handle_t handle, uint32_t *bytes)
{
    core_res_t ret = CORE_SUCCESS;
    BOOL ok;
    DWORD errors;
    COMSTAT stat;
    static bool modem_dsr_notice = false;

    *bytes = 0;

    ok = ClearCommError(handle, &errors, &stat);
    if (!ok) {
        DWORD err = GetLastError();
        ERROR_MSG_FMT("could not get bytes to read", err);
        ret = map_get_last_error_to_core_err(err);
    } else {
        *bytes = stat.cbInQue;
        /*ALOGD("%"PRIu32" bytes in read queue\n", *bytes); */
        if (!*bytes) {
            /* with some modems, stat.cbInQue == 0 even if the device is not present
             * anymore. In this specific case, we check device's DSR flag is still ON.
             * If not the device has been probably disconnected or is not correctly
             * functioning.
             */
            DWORD modemstat = 0;
            ok = GetCommModemStatus(handle, &modemstat);
            if (!ok) {
                DWORD error = GetLastError();
                ERROR_MSG_FMT("GetCommModemStatus", error);
                ret = map_get_last_error_to_core_err(error);
                goto end;
            }

            if (!(MS_DSR_ON & modemstat)) {
                /* Prevent "DSR is OFF" notification to be appear twice in a row */
                if (!modem_dsr_notice) {
                    ALOGD("modem DSR is OFF\n");
                    modem_dsr_notice = true;
                }
                ret = CORE_ERROR_NO_SUCH_DEVICE;
            }
        }
    }
    if (ret != CORE_ERROR_NO_SUCH_DEVICE) {
        modem_dsr_notice = false;
    }

end:
    return ret;
}

bool core_device_has_vid_pid(const dev_info_t *info, const char *vid, const char *pid)
{
    const char *path = NULL;
    char pattern[9] = {0};

    assert(info);
    assert(vid);
    assert(pid);

    if (info->comm_ports_number == 0 ||
            info->comm_ports[0] == NULL) {
        return false;
    }

    if (stricmp(vid, info->vendor_id) != 0) {
        return false;
    }

    if (stricmp(pid, info->product_id) != 0) {
        return false;
    }

    ALOGD("\tmatching device node path '%s'\n", path);
    return true;
}


core_res_t core_device_get_usb_id_info(const usb_id_t *usbid, dev_info_t *info)
{
    int8_t dev_list_size = 1;
    return inner_core_device_get_info(usbid, 1, info, &dev_list_size);
}

static int8_t find_dev_info_with_location_path(dev_info_t *dev_list, int8_t len, const char *location_path)
{
    dev_info_t *info = NULL;

    for (; len >= 0; len--) {
        if (strstr(dev_list[len].location_path, location_path) != NULL) {
            return len;
        }
    }

    return -1;
}

static int32_t
get_pci_location_path(char *location_path, size_t size)
{
    int32_t ret = CORE_ERROR_NO_SUCH_DEVICE;
    char inner_location_path[MAX_STR_VALUE] = {0};
    BOOL ok;
    int i = 0;
    HDEVINFO hDevInfo;
    SP_DEVINFO_DATA DeviceInfoData;

    /* List all connected PCI devices */
    hDevInfo = SetupDiGetClassDevs(NULL, TEXT("PCI"), NULL, DIGCF_PRESENT | DIGCF_ALLCLASSES);

    if (hDevInfo == INVALID_HANDLE_VALUE) {
        goto end;
    }

    for (i = 0;; i++) {
        DeviceInfoData.cbSize = sizeof(DeviceInfoData);

        if (!SetupDiEnumDeviceInfo(hDevInfo, i, &DeviceInfoData)) {
            break;
        }

        ok = SetupDiGetDeviceRegistryProperty(
                hDevInfo, &DeviceInfoData, SPDRP_DEVICEDESC,
                NULL, inner_location_path, MAX_STR_VALUE, NULL);

        ALOGD("SPDRP_DEVICEDESC[%d]: %s\n", i, inner_location_path);

        /* SPDRP_DEVICEDESC string should contain the chipset like "Modem SDX55" */
        if (!ok ||
                ((strstr(inner_location_path, "SDX55") == NULL) &&
                (strstr(inner_location_path, "SDX65") == NULL))) {
            continue;
        }

        ok = SetupDiGetDeviceRegistryProperty(
                hDevInfo, &DeviceInfoData, SPDRP_HARDWAREID,
                NULL, inner_location_path, MAX_STR_VALUE, NULL);

        ALOGD("SPDRP_HARDWAREID[%d]: %s\n", i, inner_location_path);

        if (ok) {
            strlcpy(location_path, inner_location_path, size);
            ret = CORE_SUCCESS;
            break;
        }
    }

end:
    return ret;
}

static core_res_t inner_core_device_get_info(const usb_id_t *usbid_list,
        const uint8_t usbid_list_size,
        dev_info_t *dev_list,
        int8_t *dev_list_size)
{
    core_res_t err = CORE_ERROR_NO_SUCH_DEVICE;

    HDEVINFO handle = INVALID_DEVICE_HANDLE;
    uint8_t supported_guids_n = ARRAY_SIZE(supported_guids);
    uint8_t dev_list_max_size = *dev_list_size;
    int8_t dev_list_idx = 0;
    uint8_t i;

    *dev_list_size = 0;

    for (i = 0; i < supported_guids_n; i++) {
        int32_t inner_err = 0;
        ULONG index = -1;
        BOOL ok;

        handle = get_handle_for_guid(&supported_guids[i]);
        if (handle == INVALID_DEVICE_HANDLE) {
            ERROR_MSG_FMT("could not get handle for the USB device controller", GetLastError());
            err = CORE_ERROR_UNKNOWN;
            goto end;
        }

        while (inner_err != ERROR_NO_MORE_ITEMS) {
            SP_DEVICE_INTERFACE_DATA dev_iface_data = {0};
            SP_DEVINFO_DATA dev_info_data = {0};
            char *dev_path = NULL;
            char location_path[MAX_STR_VALUE] = {0};
            char device_port[MAX_STR_VALUE] = {0};
            char iface_num[2 + 1] = {0};
            dev_info_t *info = &dev_list[dev_list_idx];
            usb_id_t curid = {0};
            uint8_t k;
            char serial[MAX_STR_VALUE] = {0};

            inner_err = 0;
            index++;
            dev_iface_data.cbSize = sizeof(SP_DEVICE_INTERFACE_DATA);

            ok = SetupDiEnumDeviceInterfaces(handle, 0, &supported_guids[i], index, &dev_iface_data);
            if (!ok) {
                inner_err = GetLastError();
                if (inner_err != ERROR_NO_MORE_ITEMS) {
                    ERROR_MSG_FMT("could not get device info data", inner_err);
                    err = CORE_ERROR_UNKNOWN;
                    goto end;
                }
                continue;
            }

            inner_err = get_device_path(handle, &dev_iface_data, &dev_path);
            if (inner_err) {
                ALOGE("could not get device path\n");
                continue;
            }

            for (k = 0; k < usbid_list_size; ++k) {
                if (!has_vid_pid(&usbid_list[k], dev_path)) {
                    continue;
                }
                memcpy(&curid, &usbid_list[k], sizeof(usbid_list[k]));
                goto found;
            }
            ALOGD("path '%s' does not match any vid/pid\n", dev_path);
            continue;
found:

            /* build dev info data for location-path, driver and device name */
            dev_info_data.cbSize = sizeof(SP_DEVINFO_DATA);
            ok = SetupDiEnumDeviceInfo(handle, index, &dev_info_data);
            if (!ok) {
                inner_err = GetLastError();
                if (inner_err != ERROR_NO_MORE_ITEMS) {
                    ERROR_MSG_FMT("could not get device info data", inner_err);
                    err = CORE_ERROR_UNKNOWN;
                    goto end;
                }
                continue;
            }

            inner_err = get_location_path(handle, &dev_info_data, location_path, sizeof(location_path));
            if (inner_err) {
                ALOGD("could not get location path for %s\n", dev_path);

                /* if get location path fails, the device may be a virtual
                 * USB device created by the UDE driver. In this case we
                 * look for the SDX55 or SDX65 modem in the PCI sub-system */
                if ((curid.vid == 0x1bc7 && curid.pid == 0x8000) ||
                        (curid.vid == 0x1bc7 && curid.pid == 0x8900) ||
                        (curid.vid == 0x1bc7 && curid.pid == 0x800A) ||
                        (curid.vid == 0x1bc7 && curid.pid == 0x8905)) {
                    inner_err = get_pci_location_path(location_path, sizeof(location_path));

                    if (inner_err) {
                        ALOGD("could not get pci location path for %s\n", dev_path);
                        continue;
                    }
                } else {
                    continue;
                }
            }

            /* get info instance for the location_path */
            if (strlen(info->location_path) == 0) {
                strlcpy(info->location_path, location_path, sizeof(info->location_path));
            } else if (strcmp(info->location_path, location_path) != 0) {
                /* not the current info instance, find it in dev_list */
                int8_t idx_bak = dev_list_idx;
                dev_list_idx = find_dev_info_with_location_path(dev_list, *dev_list_size, location_path);
                if (dev_list_idx == -1) {
                    ALOGD("new device\n");
                    if ((*dev_list_size) >= dev_list_max_size) {
                        ALOGD("no more dev_info_t free slots, skipping\n");
                        dev_list_idx = idx_bak;
                        continue;
                    }
                    dev_list_idx = (*dev_list_size);
                    strlcpy(dev_list[dev_list_idx].location_path, location_path,
                            sizeof(dev_list[0].location_path));
                }
                info = &dev_list[dev_list_idx];
            }
            ALOGD("dev[%" PRIi8 "].location_path = %s\n", dev_list_idx, info->location_path);

            /* location_path and USB IDs matches, check if there is space to copy this port */
            if (info->comm_ports_number >= MAX_COMM_PORTS_NUM) {
                ALOGD("Max number of ports reached (%u). Could not add this one\n", MAX_COMM_PORTS_NUM);
                continue;
            }

            if (!info->vendor_id[0] && !info->product_id[0]) {
                snprintf(info->vendor_id, MAX_USB_ID_LEN + 1, "%04x", curid.vid);
                snprintf(info->product_id, MAX_USB_ID_LEN + 1, "%04x", curid.pid);
                (*dev_list_size)++;
            }

            inner_err = get_serial_number(dev_path, serial);
            if (!inner_err) {
                strlcpy(info->serial, serial, sizeof(info->serial));
                ALOGD("dev[%" PRIi8 "].serial = %s\n", dev_list_idx, info->serial);
            }

            inner_err = get_iface_number_from_port(dev_path, iface_num);
            if (!inner_err) {
                ALOGD("dev[%" PRIi8 "].iface[%" PRIu32 "] = %s\n", dev_list_idx, info->comm_ports_number,
                        iface_num);
                strlcpy(info->ifaces[info->comm_ports_number], iface_num, sizeof(info->ifaces[0]));
            } else {
                /* for some dump devices the interface numbers is not
                 * available, so we force it to "00" */
                if ((curid.vid == 0x1bc7 && curid.pid == 0x9008) ||
                        (curid.vid == 0x1bc7 && curid.pid == 0x900e) ||
                        (curid.vid == 0x05c6 && curid.pid == 0x9008) ||
                        (curid.vid == 0x05c6 && curid.pid == 0x900e) ||
                        (curid.vid == 0x05c6 && curid.pid == 0x110a) ||
                        (curid.vid == 0x05c6 && curid.pid == 0x110b)) {
                    ALOGD("Setting interface 00 for PID 0x%04" PRIX32 "\n", curid.pid);
                    strlcpy(info->ifaces[info->comm_ports_number], "00", sizeof(info->ifaces[0]));
                }

                /* We want to get the dev_path of the composite device or of the single device
                 * available, so we take the device without MI. In fact this is the same than
                 * the one returned by the remove event */
                if (!strlen(info->dev_path)) {
                    snprintf(info->dev_path, MAX_STR_VALUE, "%s", dev_path);
                    ALOGD("Found dev_path = '%s'\n", info->dev_path);
                }
            }

            ALOGD("dev[%" PRIi8 "].path[%" PRIu32 "] = %s\n", dev_list_idx, info->comm_ports_number,
                    dev_path);
            strlcpy(info->comm_ports[info->comm_ports_number], dev_path, sizeof(info->comm_ports[0]));

            /* try to update path with a COM name */
            inner_err = get_port_name(handle, &dev_info_data, device_port, sizeof(device_port));
            if (!inner_err) {
                int i;
                bool found = false;

                ALOGD("dev[%" PRIi8 "].port[%" PRIu32 "] = %s\n",
                        dev_list_idx, info->comm_ports_number, device_port);

                /* check if the com port is already present, if so, skip */
                for (i = 0; i < info->comm_ports_number && found != true; i++) {
                    if (strcmp(info->comm_ports[i], device_port) == 0) {
                        ALOGD("found same com port already present\n");
                        found = true;
                    }
                }

                if (found) {
                    continue;
                }

                strlcpy(info->comm_ports[info->comm_ports_number], device_port, sizeof(info->comm_ports[0]));
            }

            if (strlen(info->drivers[info->comm_ports_number]) == 0) {
                /* Build a list of driver info items that we will retrieve below */
                if (SetupDiBuildDriverInfoList(handle, &dev_info_data, SPDIT_COMPATDRIVER)) {
                    int j;
                    for (j = 0; ok; j++) {
                        SP_DRVINFO_DATA drv_info;

                        drv_info.cbSize = sizeof(SP_DRVINFO_DATA);
                        ok = SetupDiEnumDriverInfo(handle, &dev_info_data,
                                SPDIT_COMPATDRIVER, j, &drv_info);
                        if (!ok) {
                            break;
                        }

                        if (strstr(drv_info.Description, "Telit") != NULL) {
                            strlcpy(info->drivers[info->comm_ports_number], drv_info.Description,
                                    sizeof(info->drivers[0]));
                            ALOGD("dev[%" PRIi8 "].driver[%" PRIu32 "] = %s\n", dev_list_idx,
                                    info->comm_ports_number, info->drivers[info->comm_ports_number]);
                            break;
                        }
                    }
                }
            }

            /* only increase port number if get_port_name() above didn't return an error */
            if (!inner_err)
                info->comm_ports_number++;
        }

        ok = SetupDiDestroyDeviceInfoList(handle);
        if (!ok) {
            ERROR_MSG_FMT("could not destroy device info list", GetLastError());
        }
    }

end:
    /* "err" here could evaluate to CORE_ERROR_NO_SUCH_DEVICE
     * because the LAST call returned error, not because no
     * device has been found in the whole loop */
    if (err == CORE_ERROR_NO_SUCH_DEVICE &&
            *dev_list_size != 0) {
        err = CORE_SUCCESS;
    }

    return err;
}

core_res_t core_device_enumerate(const usb_id_t *usbid_list,
        const uint8_t usbid_list_size,
        dev_info_t *dev_list,
        int8_t *dev_list_size)
{
    core_res_t err = CORE_ERROR_UNKNOWN;
    uint16_t waitms = 1000;
    uint8_t retries = 5;
    int8_t incoming_size = *dev_list_size;

    err = inner_core_device_get_info(usbid_list, usbid_list_size, dev_list, dev_list_size);

    if (!err && *dev_list_size > 0 && dev_list[0].comm_ports_number == 0) {
        /* Windows enumeration might be slow, resulting in a short delay
         * between the event notification and the availability of the
         * device for enumeration */
        while (retries-- > 0 && dev_list[0].comm_ports_number == 0) {
            ALOGD("device not ready. Retrying in %" PRIu16 "ms...\n", waitms);
            memset(dev_list, 0, sizeof(dev_info_t) * incoming_size);
            *dev_list_size = incoming_size;
            core_sleep(waitms);
            err = inner_core_device_get_info(usbid_list, usbid_list_size, dev_list, dev_list_size);
        }
    }

    return err;
}

core_res_t core_device_get_info(const char *vid, const char *pid, dev_info_t *info)
{
    usb_id_t usbid = {0};
    int8_t len = 1;

    if (!core_usb_id_from_str(&usbid, vid, pid)) {
        ALOGE("could not convert %s:%s into usb_id_t\n", vid, pid);
        return CORE_ERROR_EINVAL;
    }

    return inner_core_device_get_info(&usbid, 1, info, &len);
}

core_res_t core_device_get_usb_id_info_list(const usb_id_t *usbid, dev_info_t *info, const int len)
{
    int8_t dev_list_size = len;
    return inner_core_device_get_info(usbid, len, info, &dev_list_size);
}

/** usb event listener */
dev_info_t usb_evn_info = {0};
usb_event_t usb_event = {0};
MSG msg;

static HWND create_usb_event_handler(const char *);
LRESULT CALLBACK usb_event_handler_cbk(HWND, UINT, WPARAM, LPARAM);
static BOOL register_device_notification(const HWND, HDEVNOTIFY *);

static core_res_t
device_event_listener(bool (*condition)(dev_info_t *info, void *data),
        void *data,
        uint32_t timeout_ms,
        char *event_vid,
        char *event_pid,
        usb_event_t *event)
{
    core_res_t err = CORE_ERROR_UNKNOWN;
    uint32_t time_left = timeout_ms;
    uint32_t interval_ms = 500;
    const char *name = "usb_evn_handler";

    HWND hwnd = create_usb_event_handler(name);
    if (!hwnd) {
        goto end;
    }

    while (time_left >= interval_ms) {
        bool ok;

        memset(&usb_evn_info, 0, sizeof(usb_evn_info));
        PeekMessage(&msg, hwnd, 0, 0, PM_NOREMOVE);
        TranslateMessage(&msg);
        DispatchMessage(&msg);

        /* The second condition is to discard remove event, in order to have
         * backward compatibility with applications waiting only for add */
        if (usb_evn_info.comm_ports_number == 0 ||
                (usb_event.type == CORE_USB_EVENT_REMOVE && event == NULL)) {
            goto next;
        }

        ok = condition(&usb_evn_info, data);
        if (ok) {
            ALOGD("condition met against device %s:%s, exiting...\n",
                    usb_evn_info.vendor_id,
                    usb_evn_info.product_id);
            strlcpy(event_vid, usb_evn_info.vendor_id, 5);
            strlcpy(event_pid, usb_evn_info.product_id, 5);
            if (event) {
                event->type = usb_event.type;
                snprintf(event->dev_path, MAX_STR_VALUE, "%s", usb_evn_info.comm_ports[0]);
            }

            err = CORE_SUCCESS;
            break;
        }

        ALOGD("condition not met\n");

next:
        core_sleep(interval_ms);
        time_left -= interval_ms;
    }

    DestroyWindow(hwnd);
    UnregisterClass(name, GetModuleHandle(0));

    if (time_left < interval_ms) {
        err = CORE_ERROR_TIMEOUT;
        goto end;
    }

    if (usb_evn_info.comm_ports_number > 0) {
        err = CORE_SUCCESS;
    }

end:
    return err;
}

core_res_t core_device_event_listener(bool (*condition)(dev_info_t *info, void *data),
        void *data,
        uint32_t timeout_ms,
        char *event_vid,
        char *event_pid)
{
    return device_event_listener(condition, data, timeout_ms, event_vid, event_pid, NULL);
}

core_res_t core_device_usb_id_event_listener(bool (*condition)(dev_info_t *info, void *data),
        void *data,
        uint32_t timeout_ms,
        usb_id_t *event)
{
    core_res_t err;
    char event_vid[MAX_USB_ID_LEN + 1] = {0};
    char event_pid[MAX_USB_ID_LEN + 1] = {0};

    err = device_event_listener(condition, data, timeout_ms, event_vid, event_pid, NULL);
    if (err) {
        return err;
    }

    return core_usb_id_from_str(event, event_vid, event_pid) ? CORE_SUCCESS : CORE_ERROR_UNKNOWN;
}

core_res_t core_device_usb_id_event_type_listener(bool (*condition)(dev_info_t *info, void *data),
        void *data,
        uint32_t timeout_ms,
        usb_id_t *event,
        usb_event_t *u_event)
{
    core_res_t err;
    char event_vid[MAX_USB_ID_LEN + 1] = {0};
    char event_pid[MAX_USB_ID_LEN + 1] = {0};

    err = device_event_listener(condition, data, timeout_ms, event_vid, event_pid, u_event);
    if (err) {
        return err;
    }

    return core_usb_id_from_str(event, event_vid, event_pid) ? CORE_SUCCESS : CORE_ERROR_UNKNOWN;
}

static HWND
create_usb_event_handler(const char *name)
{
    ATOM hinst;
    HWND handle = NULL;
    WNDCLASSEX wx = {0};

    wx.cbSize = sizeof(WNDCLASSEX);
    wx.lpfnWndProc = usb_event_handler_cbk;
    wx.hInstance = GetModuleHandle(0);
    wx.lpszClassName = name;

    hinst = RegisterClassEx(&wx);
    if (!hinst) {
        ERROR_MSG_FMT("could not register event handler", GetLastError());
        goto end;
    }

    handle = CreateWindowEx(0, name, name, 0, 0, 0, 0, 0, HWND_MESSAGE, NULL, NULL, NULL);
    if (!handle) {
        ERROR_MSG_FMT("could not create usb event handler", GetLastError());
    }

end:
    return handle;
}

LRESULT CALLBACK usb_event_handler_cbk(HWND win_handle, UINT msg, WPARAM wParam, LPARAM lParam)
{
    static HDEVNOTIFY nhandle;

    switch (msg) {
        case WM_CREATE:
            ALOGD("registering event listener\n");
            if (!register_device_notification(win_handle, &nhandle)) {
                return FALSE;
            }
            break;
        case WM_DEVICECHANGE:
            if (wParam == DBT_DEVICEARRIVAL ||
                    wParam == DBT_DEVICEREMOVECOMPLETE) {
                DEV_BROADCAST_HDR *h = (DEV_BROADCAST_HDR *)lParam;
                char *path = NULL;

                switch (h->dbch_devicetype) {
                    case DBT_DEVTYP_PORT: {
                        DEV_BROADCAST_PORT_A *p = (DEV_BROADCAST_PORT_A *)lParam;
                        ALOGI("port device %s %s\n", p->dbcp_name,
                                wParam == DBT_DEVICEARRIVAL ? "added" : "removed");
                        path = p->dbcp_name;
                        break;
                    }
                    case DBT_DEVTYP_DEVICEINTERFACE: {
                        DEV_BROADCAST_DEVICEINTERFACE_A *p = (DEV_BROADCAST_DEVICEINTERFACE_A *)lParam;
                        ALOGD("interface device %s %s\n", p->dbcc_name,
                                wParam == DBT_DEVICEARRIVAL ? "added" : "removed");
                        path = p->dbcc_name;
                        break;
                    }
                    default:
                        ALOGI("device of unmanaged type %d\n", h->dbch_devicetype);
                }

                if (path) {
                    int32_t err;
                    char vid[5] = {0};
                    char pid[5] = {0};

                    err = get_vid_pid_from_port(path, vid, pid);
                    if (!err) {
                        memcpy(usb_evn_info.comm_ports[0], path, MAX_STR_VALUE);
                        strlcpy(usb_evn_info.vendor_id, vid, sizeof(usb_evn_info.vendor_id));
                        strlcpy(usb_evn_info.product_id, pid, sizeof(usb_evn_info.product_id));
                        ALOGD("copied device %s:%s with path '%s'\n",
                                usb_evn_info.vendor_id,
                                usb_evn_info.product_id,
                                usb_evn_info.comm_ports[0]);
                        usb_evn_info.comm_ports_number = 1;
                        usb_event.type =
                                (wParam == DBT_DEVICEARRIVAL ? CORE_USB_EVENT_ADD : CORE_USB_EVENT_REMOVE);
                    }
                }
            }
            break;
        case WM_DESTROY:
            ALOGD("unregistering notification\n");
            if (!UnregisterDeviceNotification(nhandle)) {
                ERROR_MSG_FMT("could not unregister notification\n", GetLastError());
            }
            break;
        default:
            /* unmanaged msg, nothing to do */
            break;
    }

    return TRUE;
}

static BOOL register_device_notification(const HWND hwnd, HDEVNOTIFY *hDevNotify)
{
    BOOL ok;

    DEV_BROADCAST_DEVICEINTERFACE_A notifyFilter = {0};

    notifyFilter.dbcc_size = sizeof(notifyFilter);
    notifyFilter.dbcc_devicetype = DBT_DEVTYP_DEVICEINTERFACE;
    notifyFilter.dbcc_classguid = GUID_DEVINTERFACE_USB_DEVICE;

    *hDevNotify = RegisterDeviceNotification(hwnd, &notifyFilter, DEVICE_NOTIFY_WINDOW_HANDLE);
    return (*hDevNotify != NULL);
}

core_res_t core_wait_for_serial(const char *port)
{
    /* Simple heuristic to check if a serial port is available */
    COMMCONFIG cc;
    DWORD dwSize;
    BOOL found = false;

    if (!strcasestr(port, "COM")) {
        ALOGD("%s not a COM string, skip wait\n", port);
        found = true;
        goto out;
    }

    dwSize = sizeof(cc);

    while (!(found = GetDefaultCommConfig(port, &cc, &dwSize)) && !sigint_detected) {
        core_sleep(250);
    }

out:
    return (found ? CORE_SUCCESS : CORE_ERROR_NO_SUCH_DEVICE);
}

static HDEVINFO
get_handle_for_guid(CONST GUID *class_guid)
{
    HDEVINFO handle = INVALID_DEVICE_HANDLE;

    handle = SetupDiGetClassDevs(class_guid,
            NULL,
            NULL,
            (DIGCF_PRESENT | DIGCF_DEVICEINTERFACE));
    if (handle == INVALID_DEVICE_HANDLE) {
        ALOGE("could not get dev info for GUID %d: error %d\n",
                &class_guid, GetLastError());
    }

    return handle;
}

static bool
has_vid_pid(const usb_id_t *usbid, const char *path)
{
    char pattern[9] = {0};

    snprintf(pattern, 9, "vid_%04x", usbid->vid);
    if (strcasestr(path, pattern) == NULL) {
        return false;
    }

    memset(pattern, 0, 9);
    snprintf(pattern, 9, "pid_%04x", usbid->pid);
    if (strcasestr(path, pattern) == NULL) {
        return false;
    }

    ALOGD("got match path: '%s'\n", path);
    return true;
}

static core_res_t get_serial_number(const char *path, char *serial)
{
    /* port string format is: `vid_vvvv#pid_pppp#ssss...#`
     * where "vvvv" is the vendor id, "pppp" is the product id,
     * and "ssss..." is the serial number.
     */
    char *start, *end;

    if (strstr(path, "mi_") != NULL) {
        ALOGD("composite USB device path format found: no serial number\n");
        return CORE_ERROR_TRY_AGAIN;
    }

    start = strstr(path, "pid_");
    if (!start) {
        ALOGE("no serial number found in path '%s'\n", path);
        return CORE_ERROR_EINVAL;
    }

    /* skip PID value and point to the next item inside the device path */
    start += 9;

    /* find the end of the serial number token */
    end = strstr(start, "#");
    if (!end) {
        ALOGE("could not find end of serial number in path '%s'\n", path);
        return CORE_ERROR_EINVAL;
    }

    strlcpy(serial, start, end - start);
    ALOGD("extracted serial number '%s' from path '%s'\n",
            serial, path);

    return CORE_SUCCESS;
}

static int32_t
get_device_path(HDEVINFO dev_info, SP_DEVICE_INTERFACE_DATA *dev_iface_data, char **path)
{
    BOOL ok;
    SP_DEVICE_INTERFACE_DETAIL_DATA *dev_detail_data = NULL;
    ULONG required_len = 0;
    int32_t err = 0;

    /* Get required len for data first */
    ok = SetupDiGetDeviceInterfaceDetail(dev_info,
            dev_iface_data,
            NULL,
            0,
            &required_len,
            NULL);

    err = GetLastError();
    if (!ok && err != ERROR_INSUFFICIENT_BUFFER) {
        ALOGD("could not get device interface detail: error %" PRIi32 "\n", err);
        err = -1;
        goto end;
    }

    dev_detail_data = ALLOC(required_len);
    dev_detail_data->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);

    ok = SetupDiGetDeviceInterfaceDetail(dev_info,
            dev_iface_data,
            dev_detail_data,
            required_len,
            &required_len,
            NULL);
    if (!ok) {
        err = GetLastError();
        ALOGD("could not get device interface detail: error %" PRIi32 "\n", err);
        err = -1;
        goto clean;
    }

    *path = strdup(dev_detail_data->DevicePath);
    err = 0;

clean:
    FREE(dev_detail_data);

end:
    return err;
}

static int32_t
get_location_path(HDEVINFO dev_info, SP_DEVINFO_DATA *dev_info_data, char *location_path, size_t size)
{
    int32_t ret;
    char inner_location_path[MAX_STR_VALUE] = {0};
    BOOL ok;

    ok = SetupDiGetDeviceRegistryPropertyA(
            dev_info, dev_info_data, SPDRP_LOCATION_PATHS,
            NULL, inner_location_path, MAX_STR_VALUE, NULL);
    if (!ok) {
        ret = CORE_ERROR_UNKNOWN;
        goto end;
    }

    /* remove USBMI part, which refers to interface number */
    if (strstr(inner_location_path, "#USBMI") != NULL) {
        char *usbmi_tok = strstr(inner_location_path, "#USBMI");
        usbmi_tok[0] = '\0';
    }
    strlcpy(location_path, inner_location_path, size);
    ret = CORE_SUCCESS;

end:
    return ret;
}

static int32_t
get_port_name(HDEVINFO dev_info, SP_DEVINFO_DATA *dev_info_data, char *port_name, size_t size)
{
    int32_t err = 0;
    DWORD size_local = size;
    DWORD type;
    HKEY key;

    key = SetupDiOpenDevRegKey(dev_info,
            dev_info_data,
            DICS_FLAG_GLOBAL,
            0,
            DIREG_DEV,
            KEY_QUERY_VALUE);
    if (key == INVALID_HANDLE_VALUE) {
        err = GetLastError();
        ALOGE("key value is invalid: error %" PRIi32 " %s\n", err, strerror(err));
        err = -1;
        goto end;
    }

    type = REG_SZ;

    memset(port_name, 0, MAX_STR_VALUE);

    /* in case of success it returns 0 */
    err = RegQueryValueEx(key, "PortName", NULL, &type, port_name, &size_local);
    if (err) {
        ALOGD("could not get register value: error %" PRIi32 " %s\n", err, strerror(err));
    }

    RegCloseKey(key);

end:
    return err;
}

static int32_t
get_iface_number_from_port(const char *port, char *iface_number)
{
    int32_t ret = -1;
    char *match;

    /*
     * port string is like: \\?\usb#vid_1bc7&pid_0036&mi_04#358148060004335#{86e0d1e0-8089-11d0-9ce4-08003e301f73}
     * where the interface number is the 2 digit number after '&_mi' substring.
     */
    match = strstr(port, "&mi_");
    if (!match) {
        ALOGD("no iface number in port name '%s'\n", port);
        goto end;
    }
    /* we don't want to copy the port name's char after the interface number */
    strlcpy(iface_number, match + 4, 3);

    ret = 0;
end:
    return ret;

}

static int32_t
get_vid_pid_from_port(const char *port, char *vid, char *pid)
{
    int32_t ret = -1;
    char *match;

    /*
     * port string is like: \\?\usb#vid_1bc7&pid_0036&mi_04#358148060004335#{86e0d1e0-8089-11d0-9ce4-08003e301f73}
     * where the VID/PID number is the 4 digit number after 'VID_'/'PID_' substring respectively
     */
    match = strstr(port, "VID_");
    if (!match) {
        ALOGE("could not find VID in port name '%s'\n", port);
        goto end;
    }
    memset(vid, 0, MAX_USB_ID_LEN + 1);
    /* we don't want to copy the port name's char after VID */
    strlcpy(vid, match + 4, MAX_USB_ID_LEN + 1);

    match = strstr(port, "PID_");
    if (!match) {
        ALOGE("could not find PID in port name '%s'\n", port);
        goto end;
    }

    memset(pid, 0, MAX_USB_ID_LEN + 1);
    /* we don't want to copy the port name's char after PID */
    strlcpy(pid, match + 4, MAX_USB_ID_LEN + 1);

    ret = 0;
end:
    return ret;
}

core_res_t core_device_flush(const dev_handle_t handle)
{
    if (PurgeComm(handle, PURGE_RXCLEAR | PURGE_TXCLEAR)) {
        return CORE_SUCCESS;
    }

    return CORE_ERROR_IO_ERROR;
}

core_res_t core_device_realpath(const char *path, char *real_path)
{
    return CORE_ERROR_NOT_IMPLEMENTED;
}

