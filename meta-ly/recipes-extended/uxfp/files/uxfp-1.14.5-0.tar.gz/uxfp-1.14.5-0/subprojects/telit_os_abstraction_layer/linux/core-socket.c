#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>

#include <telit-os-abs.h>

core_res_t core_socket_init()
{
    return CORE_SUCCESS;
}

core_res_t core_socket_inet_tcp_create(socket_handle_t *handle)
{
    core_res_t ret = CORE_SUCCESS;

    *handle = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (*handle == -1) {
        int err = errno;

        ALOGE("error in creating socket %d, %s\n", err, strerror(err));
        ret = map_errno_to_core_err(err);
    }

    return ret;
}

core_res_t core_socket_inet_tcp_connect(socket_handle_t handle, const char *address, const char *port)
{
    int32_t ret = CORE_ERROR_EINVAL;
    struct sockaddr_in servaddr = {0};

    if (address && port) {
        long int sin_port;
        char *end_ptr;

        servaddr.sin_family = AF_INET;
        sin_port = strtol(port, &end_ptr, 10);
        if (*end_ptr != '\0') {
            ALOGE("Invalid port string\n");
            goto end;
        }

        if (sin_port < 0 || sin_port > 0xFFFF) {
            ALOGE("port '%s' exceedes limit (0, %u)", port, 0xFFFF);
            goto end;
        }
        servaddr.sin_port = htons((uint16_t)sin_port);

        if (inet_pton(AF_INET, address, &(servaddr.sin_addr)) < 1) {
            ALOGE("Invalid address\n");
            goto end;
        }

        if (connect(handle, (struct sockaddr *)&servaddr, sizeof(servaddr)) == -1) {
            int err = errno;

            ALOGE("connect: error %d, %s\n", err, strerror(err));
            ret = map_errno_to_core_err(err);
            goto end;
        }

        ret = CORE_SUCCESS;
    }

end:
    return ret;
}

core_res_t core_socket_timed_read(const socket_handle_t handle, void *buffer, uint32_t bytes_to_read,
        const uint32_t msec, uint32_t *bytes_read)
{
    return core_device_timed_read(handle, buffer, bytes_to_read, msec, bytes_read);
}

core_res_t core_socket_write(const socket_handle_t handle, const void *buffer, const uint32_t bytes_to_write,
        uint32_t *bytes_written)
{
    return core_device_write (handle, buffer, bytes_to_write, bytes_written);
}

core_res_t core_socket_inet_tcp_bind(socket_handle_t handle, const char *address, const char *port)
{
    core_res_t ret = CORE_ERROR_EINVAL;
    struct sockaddr_in servaddr = {0};

    if (port) {
        long int sin_port;
        char *endPtr;

        if (setsockopt(handle, SOL_SOCKET, SO_REUSEADDR, &(int){ 1 }, sizeof(int)) < 0) {
            int err = errno;

            ALOGE("setsockopt(SO_REUSEADDR) failed %d, %s\n", err, strerror(err));
            ret = map_errno_to_core_err(err);
            goto end;
        }

        if (setsockopt(handle, SOL_SOCKET, SO_REUSEPORT, &(int){ 1 }, sizeof(int)) < 0) {
            int err = errno;

            ALOGE("setsockopt(SO_REUSEPORT) failed %d, %s\n", err, strerror(err));
            ret = map_errno_to_core_err(err);
            goto end;
        }

        servaddr.sin_family = AF_INET;
        sin_port = strtol(port, &endPtr, 10);
        if (*endPtr != '\0') {
            ALOGE("Invalid port string\n");
            goto end;
        }

        if (sin_port < 0 || sin_port > 0xFFFF) {
            ALOGE("port '%s' exceedes limit (0, %u)", port, 0xFFFF);
            goto end;
        }
        servaddr.sin_port = htons((uint16_t)sin_port);

        if (address) {
            servaddr.sin_addr.s_addr = inet_addr(address);
        } else {
            servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
        }

        if (bind(handle, (struct sockaddr *) &servaddr, sizeof(servaddr)) == -1) {
            int err = errno;

            ALOGE("error in bind %d, %s\n", err, strerror(err));
            ret = map_errno_to_core_err(err);
            goto end;
        }

        ret = CORE_SUCCESS;
    }

end:
    return ret;
}

core_res_t core_socket_listen(socket_handle_t handle)
{
    core_res_t ret = CORE_SUCCESS;

    if (listen(handle, 0) == -1) {
        int err = errno;

        ALOGE("error in listen %d, %s\n", err, strerror(err));
        ret = map_errno_to_core_err(err);
    }

    return ret;
}

core_res_t core_socket_accept(socket_handle_t handle, socket_handle_t *handle_accepted)
{
    core_res_t ret = CORE_SUCCESS;

    *handle_accepted = INVALID_SOCKET_HANDLE;

    ret = core_device_poll(handle, -1);
    if (ret != CORE_SUCCESS) {
        goto end;
    }

    *handle_accepted = accept(handle, NULL, NULL);
    if (*handle_accepted == -1) {
        int err = errno;

        ALOGE("error in accept %d, %s\n", errno, strerror(errno));
        ret = map_errno_to_core_err(err);
    }

end:
    return ret;
}

core_res_t core_socket_close(socket_handle_t handle)
{
    core_res_t ret = CORE_SUCCESS;

    if (close(handle)) {
        int err = errno;

        ALOGE("error in close %d, %s\n", err, strerror(err));
        ret = map_errno_to_core_err(err);
    }

    return ret;
}

core_res_t core_socket_deinit()
{
    return CORE_SUCCESS;
}

