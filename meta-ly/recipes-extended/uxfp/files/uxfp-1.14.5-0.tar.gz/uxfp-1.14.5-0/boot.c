#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <inttypes.h>

#include "protocol.h"
#include "uxfp.h"
#include "boot.h"
#include "devices.h"
#include "diagnostic.h"
#include "driver.h"

#define ONE_SEC_IN_MS             1000
#define MAX_BOOT_MODE_RETRIES     100
#define ENTER_BOOT_MODE_BAUD_RATE 115200
#define NO_DISCOVERY_REBOOT_WAIT_IN_SECONDS 8
#define LISTENING_TIMEOUT_IN_SECONDS 30

/**************************************/
/* BOOT MODE STEPS                    */
/**************************************/
typedef enum {
    BOOT_MODE_STEP_FIRST,
    BOOT_MODE_STEP_ENUMERATE,
    BOOT_MODE_STEP_QUIRKS,
    BOOT_MODE_STEP_LISTENING,
    BOOT_MODE_STEP_OPEN,
    BOOT_MODE_STEP_CONFIG,
    BOOT_MODE_STEP_SEND,
    BOOT_MODE_STEP_READ,
    BOOT_MODE_STEP_COMPARE,
    BOOT_MODE_STEP_ERROR,
    BOOT_MODE_STEP_SUCCESS,
    BOOT_MODE_STEP_UNKNOWN,
} boot_mode_step_t;

static const char *
get_step_string(const boot_mode_step_t step)
{
    const static char *boot_mode_step_str[] = {
        [BOOT_MODE_STEP_FIRST] = "BOOT MODE STEP FIRST",
        [BOOT_MODE_STEP_ENUMERATE] = "BOOT MODE STEP ENUMERATE",
        [BOOT_MODE_STEP_QUIRKS] = "BOOT MODE STEP QUIRKS",
        [BOOT_MODE_STEP_LISTENING] = "BOOT MODE STEP LISTENING",
        [BOOT_MODE_STEP_OPEN] = "BOOT MODE STEP OPEN",
        [BOOT_MODE_STEP_CONFIG] = "BOOT MODE STEP CONFIG",
        [BOOT_MODE_STEP_SEND] = "BOOT MODE STEP SEND",
        [BOOT_MODE_STEP_READ] = "BOOT MODE STEP READ",
        [BOOT_MODE_STEP_COMPARE] = "BOOT MODE STEP COMPARE",
        [BOOT_MODE_STEP_ERROR] = "BOOT MODE STEP ERROR",
        [BOOT_MODE_STEP_SUCCESS] = "BOOT MODE STEP SUCCESS",
        [BOOT_MODE_STEP_UNKNOWN] = "BOOT MODE STEP UNKNOWN",
    };

    if (step >= BOOT_MODE_STEP_UNKNOWN)
        return boot_mode_step_str[BOOT_MODE_STEP_UNKNOWN];

    return boot_mode_step_str[step];
}

/**************************************/
/* Boot operations                    */
/**************************************/
/**
 * @brief Boot handling functions
 */
static struct boot_operations {
    boot_mode_step_t (*boot_open)        (const dev_info_t *, driver_t *);
    boot_mode_step_t (*boot_send)        (driver_t *, boot_context_t *);
    boot_mode_step_t (*boot_ack_read)    (driver_t *, boot_context_t *);
    boot_mode_step_t (*boot_ack_compare) (boot_context_t *);
} boot_fops = {
    .boot_open = NULL,
    .boot_send = NULL,
    .boot_ack_read = NULL,
    .boot_ack_compare = NULL,
};


static boot_mode_step_t
generic_open(const dev_info_t *dev_info, driver_t *driver)
{
    int32_t err = 0;

    err = driver->open(dev_info, driver);
    if (err) {
        ALOGE("could not open device: error %" PRId32 "\n", err);
        return BOOT_MODE_STEP_ERROR;
    }

    return BOOT_MODE_STEP_CONFIG;
}

static boot_mode_step_t
send_no_message(driver_t *driver, boot_context_t *bc)
{
    return BOOT_MODE_STEP_READ;
}

static boot_mode_step_t
generic_send(driver_t *driver, boot_context_t *bc)
{
    int32_t err;
    uint32_t bytes = 0;
    uint32_t offset = (bc->boot_char_len - bc->bytes_left);

    err = driver->send(driver, (bc->boot_char + offset), bc->bytes_left, &bytes);
    if (err) {
        ALOGE("error sending boot char\n");
        return BOOT_MODE_STEP_ERROR;
    }

    bc->bytes_left -= bytes;
    if (bc->bytes_left > 0) {
        ALOGE("write error: written %" PRIu32 "B, missing %" PRIu16 "B. %" PRIi32 " retries left\n",
                bytes,
                bc->bytes_left,
                bc->retries);
        core_sleep(bc->boot_char_send_interval);
        return BOOT_MODE_STEP_SEND;
    }

    bc->bytes_left = bc->exp_ack_boot_str_len;

    return BOOT_MODE_STEP_READ;
}

static boot_mode_step_t
double_boot_char_send(driver_t *driver, boot_context_t *bc)
{
    boot_mode_step_t step;

    step = generic_send(driver, bc);
    if (step == BOOT_MODE_STEP_ERROR || step == BOOT_MODE_STEP_SEND)
        return step;

    bc->bytes_left = bc->boot_char_len;
    return generic_send(driver, bc);
}

static boot_mode_step_t
prepare_for_second_boot_phase(boot_context_t *bc)
{
    char location_path[MAX_STR_VALUE];
    int32_t err;

    if (!has_second_phase_boot(bc->protocol))
        return BOOT_MODE_STEP_SUCCESS;

    /* Change boot context before listening to new attach events, or UXFP might
     * find the old device still connected and attach to that instead. */
    err = get_boot_context(bc->protocol, true, bc);
    if (err) {
        if (err == CORE_ERROR_NO_SUCH_DEVICE) {
            /* If the modem does not have usb_id list for its recovery boot
             * type is not expected to have a second boot phase either. */
            return BOOT_MODE_STEP_SUCCESS;
        }
        return BOOT_MODE_STEP_ERROR;
    }

    ALOGI("[+] enter boot mode phase 2: the device will disconnect and reconnect\n");
    bc->recovery = true;

    if (!bc->modem_discovery)
        return BOOT_MODE_STEP_QUIRKS;

    if (bc->protocol->channel == CHANNEL_SERIAL_PHY)
        return BOOT_MODE_STEP_QUIRKS;

    /* keeping location_path only to permit recognition of the device at next
     * re-attach*/
    strlcpy(location_path, bc->dev_info.location_path, sizeof(location_path));
    memset(&bc->dev_info, 0, sizeof(bc->dev_info));
    strlcpy(bc->dev_info.location_path, location_path, sizeof(bc->dev_info.location_path));

    ALOGD("disconnecting device with location path: '%s'\n", bc->dev_info.location_path);

    return BOOT_MODE_STEP_LISTENING;
}

/** Send boot-char message multiple times with
 * proper interval between each send, and prepare
 * for 2nd boot stage */
static boot_mode_step_t
multiple_boot_message_send_with_reset(driver_t *driver, boot_context_t *bc)
{
    boot_mode_step_t step = BOOT_MODE_STEP_ERROR;
    int32_t times = 10;

    while (times-- > 0) {
        step = generic_send(driver, bc);
        if (step == BOOT_MODE_STEP_ERROR)
            break;
        /* In case of the message is to be sent from the start */
        if (step == BOOT_MODE_STEP_SEND)
            break;
        core_sleep(bc->boot_char_send_interval);
        bc->bytes_left = bc->boot_char_len;
    }

    driver->close(driver);

    return prepare_for_second_boot_phase(bc);
}

/* send boot message and prepare for 2nd boot stage */
static boot_mode_step_t
boot_message_send_with_reset(driver_t *driver, boot_context_t *bc)
{
    boot_mode_step_t step;
    step = generic_send(driver, bc);
    if (step == BOOT_MODE_STEP_ERROR)
        return step;

    driver->close(driver);
    bc->bytes_left = 0;
    return prepare_for_second_boot_phase(bc);
}

static boot_mode_step_t
read_no_ack(driver_t *driver, boot_context_t *bc)
{
    return BOOT_MODE_STEP_COMPARE;
}

static boot_mode_step_t
generic_ack_read(driver_t *driver, boot_context_t *bc)
{
    int32_t err;
    uint32_t bytes;
    uint32_t offset = (bc->exp_ack_boot_str_len - bc->bytes_left);
    uint8_t *rec_ack = &bc->rec_ack.data[0];

    err = driver->wait_reply(driver, bc->boot_char_send_interval);
    if (err) {
        ALOGD("waiting for %" PRIu16 " bytes reply, no reply found\n", bc->exp_ack_boot_str_len);
        bc->bytes_left = bc->boot_char_len;
        return BOOT_MODE_STEP_SEND;
    }

    err = driver->read(driver, (rec_ack + offset), bc->bytes_left, &bytes);
    if (err == CORE_ERROR_TRY_AGAIN) {
        bc->bytes_left = bc->boot_char_len;
        return BOOT_MODE_STEP_SEND;
    }

    if (err) {
        ALOGE("read error %" PRIi32 "\n", err);
        return BOOT_MODE_STEP_READ;
    }

    if (bytes > 0)
        bc->bytes_left -= bytes;

    if (bc->bytes_left > 0) {
        ALOGD("read %" PRIu32 "B, missing %" PRIu16 ". %" PRIi32 " retries left\n",
                bytes, bc->bytes_left, bc->retries);

        return BOOT_MODE_STEP_READ;
    }

    return BOOT_MODE_STEP_COMPARE;
}

/**
 * Compare the received ACK from the modem
 * - bc: the boot context data
 * - bytes_to_check: an index list of the bytes to check in ACK. Last element must be -1 */
static boot_mode_step_t
generic_ack_compare(boot_context_t *bc, const int32_t *bytes_to_check)
{
    uint8_t i = 0;
    boot_mode_step_t next_step = BOOT_MODE_STEP_SUCCESS;
    const uint8_t *rec_ack = bc->rec_ack.data;
    const uint8_t *exp_ack = bc->exp_ack_boot_str;

    while (bytes_to_check[i] >= 0) {
        int32_t pos = bytes_to_check[i];

        if (rec_ack[pos] != exp_ack[i]) {
            if (bc->max_nacks-- > 0) {
                ALOGD(
                        "got a NACK: this modem might emit spurious bytes during boot, nothing to do (%" PRIi8
                        " possible NACK left)\n",
                        bc->max_nacks);
                next_step = BOOT_MODE_STEP_SEND;
            } else {
                ALOGD("wrong ack byte %" PRIi32 ": expected '0x%02" PRIX8 "', read '0x%02" PRIX8 "'\n",
                        pos, exp_ack[i], rec_ack[pos]);
                next_step = BOOT_MODE_STEP_ERROR;
            }
            break;
        }

        i++;
    }

    return next_step;
}

/**
 * Compare the received ACK from the modem and exit at first received nack
 * - bc: the boot context data
 * - bytes_to_check: an index list of the bytes to check in ACK. Last element must be -1 */
static boot_mode_step_t
generic_ack_compare_no_nacks(boot_context_t *bc, const int32_t *bytes_to_check)
{
    uint8_t i = 0;
    boot_mode_step_t next_step = BOOT_MODE_STEP_SUCCESS;
    const uint8_t *rec_ack = bc->rec_ack.data;
    const uint8_t *exp_ack = bc->exp_ack_boot_str;

    while (bytes_to_check[i] >= 0) {
        int32_t pos = bytes_to_check[i];

        if (rec_ack[pos] != exp_ack[i]) {
            ALOGD("wrong ack byte %" PRIi32 ": expected '0x%02" PRIX8 "', read '0x%02" PRIX8 "'\n",
                    pos, exp_ack[i], rec_ack[pos]);
            next_step = BOOT_MODE_STEP_ERROR;
            break;
        }

        i++;
    }

    return next_step;
}

static boot_mode_step_t
compare_no_ack(boot_context_t *bc)
{
    return BOOT_MODE_STEP_SUCCESS;
}

static boot_mode_step_t
boot_mode_1byte_ack_compare(boot_context_t *bc)
{
    const int32_t bytes_to_check[] = {0, -1};
    return generic_ack_compare(bc, bytes_to_check);
}

static boot_mode_step_t
boot_mode_2bytes_ack_compare(boot_context_t *bc)
{
    const int32_t bytes_to_check[] = {0, 1, -1};
    return generic_ack_compare(bc, bytes_to_check);
}

static boot_mode_step_t
boot_mode_3bytes_ack_compare(boot_context_t *bc)
{
    const int32_t bytes_to_check[] = {0, 1, 2, -1};
    return generic_ack_compare(bc, bytes_to_check);
}

static boot_mode_step_t
boot_mode_12bytes_ack_compare(boot_context_t *bc)
{
    const int32_t bytes_to_check[] = {0, 1, 11, -1};
    return generic_ack_compare(bc, bytes_to_check);
}

static boot_mode_step_t
boot_mode_24bytes_ack_compare(boot_context_t *bc)
{
    const int32_t bytes_to_check[] = {0, 1, 22, 23, -1};
    return generic_ack_compare(bc, bytes_to_check);
}

static boot_mode_step_t
boot_mode_28bytes_ack_compare(boot_context_t *bc)
{
    const int32_t bytes_to_check[] = {0, 1, -1};
    return generic_ack_compare(bc, bytes_to_check);
}

static boot_mode_step_t
boot_mode_1byte_ack_compare_with_ignore(boot_context_t *bc)
{
    const int32_t bytes_to_check[] = {0, -1};
    boot_mode_step_t ret;
    static bool ack_received = false;

    ret = generic_ack_compare_no_nacks(bc, bytes_to_check);

    /* received junk and no ack received yet, send boot char again */
    if (ret == BOOT_MODE_STEP_ERROR && !ack_received) {
        return BOOT_MODE_STEP_SEND;
    }

    /* received first ACK, set succes and enable compare for next reads */
    if (ret == BOOT_MODE_STEP_SUCCESS && !ack_received) {
        ack_received = true;
        return BOOT_MODE_STEP_SUCCESS;
    }

    /* already received first ACK, return actual compare result */
    if (ack_received) {
        return ret;
    }

    /* that should neved happen since all cases should have been adressed before */
    return ret;
}

static int32_t
set_boot_operations(const boot_type_t type)
{
    int32_t err = 0;

    boot_fops.boot_open = generic_open;
    boot_fops.boot_send = NULL;
    boot_fops.boot_ack_read = NULL;
    boot_fops.boot_ack_compare = NULL;

    switch (type) {
        case BOOT_TYPE_DO_NOTHING:
            boot_fops.boot_send = send_no_message;
            boot_fops.boot_ack_read = read_no_ack;
            boot_fops.boot_ack_compare = compare_no_ack;
            break;
        case BOOT_TYPE_FASTBOOT:
        case BOOT_TYPE_A_SERIAL:
        case BOOT_TYPE_A_USB:
        case BOOT_TYPE_E:
        case BOOT_TYPE_F_SERIAL:
        case BOOT_TYPE_E_SERIAL:
            boot_fops.boot_send = generic_send;
        /* fallthrough */
        case BOOT_TYPE_B_USB:
        case BOOT_TYPE_D_SERIAL:
            if (!boot_fops.boot_send)
                boot_fops.boot_send = multiple_boot_message_send_with_reset;
            boot_fops.boot_ack_read = generic_ack_read;
            boot_fops.boot_ack_compare = boot_mode_1byte_ack_compare;
            break;
        case BOOT_TYPE_A3_USB:
            boot_fops.boot_send = boot_message_send_with_reset;
            boot_fops.boot_ack_read = generic_ack_read;
            boot_fops.boot_ack_compare = boot_mode_1byte_ack_compare;
            break;
        case BOOT_TYPE_A2:
            boot_fops.boot_send = boot_message_send_with_reset;
            boot_fops.boot_ack_read = generic_ack_read;
            boot_fops.boot_ack_compare = boot_mode_2bytes_ack_compare;
            break;
        case BOOT_TYPE_B_SERIAL:
            boot_fops.boot_send = generic_send;
            boot_fops.boot_ack_read = generic_ack_read;
            boot_fops.boot_ack_compare = boot_mode_3bytes_ack_compare;
            break;
        case BOOT_TYPE_C1_SERIAL:
            boot_fops.boot_ack_compare = boot_mode_24bytes_ack_compare;
        /* fallthrough */
        case BOOT_TYPE_C2_SERIAL:
            if (!boot_fops.boot_ack_compare)
                boot_fops.boot_ack_compare = boot_mode_12bytes_ack_compare;
        /* fallthrough */
        case BOOT_TYPE_C3_SERIAL:
            boot_fops.boot_send = generic_send;
            boot_fops.boot_ack_read = generic_ack_read;
            if (!boot_fops.boot_ack_compare)
                boot_fops.boot_ack_compare = boot_mode_28bytes_ack_compare;
            break;
        case BOOT_TYPE_C1_USB:
            boot_fops.boot_ack_compare = boot_mode_24bytes_ack_compare;
        /* fallthrough */
        case BOOT_TYPE_C2_USB:
            if (!boot_fops.boot_ack_compare)
                boot_fops.boot_ack_compare = boot_mode_12bytes_ack_compare;
        /* fallthrough */
        case BOOT_TYPE_C3_USB:
        case BOOT_TYPE_C4_USB:
            boot_fops.boot_send = double_boot_char_send;
            boot_fops.boot_ack_read = generic_ack_read;
            if (!boot_fops.boot_ack_compare)
                boot_fops.boot_ack_compare = boot_mode_28bytes_ack_compare;
            break;
        case BOOT_TYPE_G_SERIAL:
            boot_fops.boot_send = generic_send;
            boot_fops.boot_ack_read = generic_ack_read;
            boot_fops.boot_ack_compare = boot_mode_1byte_ack_compare_with_ignore;
            break;
        default:
            ALOGE("unsupported boot type %u\n", type);
            err = -1;
    }

    return err;
}

/*********************************************/
/* Enter boot mode section                   */
/*********************************************/
static bool
is_comm_port_available(const dev_info_t *info, const driver_t *driver)
{
    int8_t path_id;

    if (info->comm_ports_number == 0)
        return false;

    path_id = get_flashing_device_or_fallback_position(info);
    if (path_id == CORE_ERROR_NO_SUCH_DEVICE)
        return false;

    if (info->drivers[path_id][0] == '\0')
        ALOGD("No driver identified!\n");
    else
        ALOGD("driver = '%s'\n", info->drivers[path_id]);

    /*
     * Check comm_ports instead of driver because sometimes the comm_ports is
     * available even when the driver name is not available.
     */
    return (info->comm_ports[path_id][0] != '\0');
}

void print_version_info_fn990(const char *prefix, const version_info_fn990_t *info)
{
    if (!info || !prefix) {
        return;
    }

    if (strlen(info->platform) > 0) {
        ALOGD("%s platform: %s\n", prefix, info->platform);
    } else {
        ALOGD("%s platform: %d\n", prefix, info->platform_num);
    }
    ALOGD("%s form_factor: %d\n", prefix, info->form_factor);
    ALOGD("%s major_version: %d\n", prefix, info->major_version);
    ALOGD("%s solution_baseline: %d\n", prefix, info->solution_baseline);
    ALOGD("%s model: %d\n", prefix, info->model);
    ALOGD("%s minor_pkg_version: %d\n", prefix, info->minor_pkg_version);
}

static int32_t fn990_quirks(boot_context_t *ctx, driver_t *driver, stream_t *stream)
{
    uint8_t command[] = {DIAG_EXT_BUILD_ID_F, 0x93, 0x49, 0x7E};
    version_info_fn990_t stream_info = {0};
    version_info_fn990_t modem_info = {0};
    uint8_t buf[MAX_FLAG_VALUE_LEN] = {0};
    core_res_t ret_lseek = CORE_SUCCESS;
    bool modem_image_found = false;
    core_res_t ret = CORE_SUCCESS;
    uint32_t timeout = 500;
    uint32_t size = 0;
    uint32_t written;
    chipset_t chip;

    /* Exit if modem is not FN990 */
    if (ctx->protocol->chipset != CHIPSET_SDX65 && ctx->protocol->chipset != CHIPSET_SDX65_8GB) {
        return CORE_SUCCESS;
    }

    if (!stream) {
        ret = CORE_ERROR_OPERATION_NOT_PERMITTED;
        ALOGE("invalid stream\n");
        goto out;
    }

    if (ctx->recovery || ctx->dev_info.comm_ports_number == 1) {
        ALOGD("Modem is in recovery mode\n");
        return CORE_SUCCESS;
    }

    /* Send diag command to get modem version string */
    core_print_buffer_to_level(command, sizeof(command), 16, LOG_LEVEL_DEBUG);
    ret = driver->send(driver, command, sizeof(command), &written);

    if (ret || written != sizeof(command)) {
        ALOGE("Error writing request\n");
        goto out;
    }

    ret = driver->wait_reply(driver, timeout);

    if (ret != CORE_SUCCESS) {
        ALOGE("Nothing to read\n");
        goto out;
    }

    ret = driver->read(driver, buf, MAX_FLAG_VALUE_LEN, &size);

    if (ret != CORE_SUCCESS) {
        ALOGE("Error in device read\n");
        goto out;
    }

    /* Doing a normal cast here because we are only interested in the string content,
     * Be aware of endianness reading the other numeric fields */
    diag_build_id_rsp *rsp = (diag_build_id_rsp *)buf;

    core_print_buffer_to_level(buf, size, 16, LOG_LEVEL_DEBUG);
    ALOGD("ASCII: \"%s\"\n", rsp->ver_strings);

    /* Get modem chipset from returned version string */
    chip = get_chipset_from_sw_version(rsp->ver_strings);

    /* Exit if modem chipset is different from stream chipset (e.g. single VS double slot) */
    if (chip != ctx->protocol->chipset) {
        ALOGE("Invalid stream for %s\n", get_chipset_name(chip));
        ret = CORE_ERROR_OPERATION_NOT_PERMITTED;
        goto out;
    }

    /* Populate modem info structure with modem version string parsing */
    ret = get_fn990_sw_version_info(rsp->ver_strings, &modem_info);

    if (ret != CORE_SUCCESS) {
        ALOGE("Error %d in get_fn990_sw_version_info (%s)\n", ret, rsp->ver_strings);
        goto out;
    }

    print_version_info_fn990("Modem", &modem_info);

    /* Cycle through stream chunks to get modem images */
    do {
        data_big_block_t chunk = {0};
        uint32_t read_bytes = 0;
        image_info_frame_t img_frame_info = {0};

        ret = stream->read_chunk(stream->handle, &chunk, &read_bytes);

        if (ret) {
            ALOGE("read chunk error %" PRIi32 "\n", ret);
            goto reset;
        }

        if (chunk.len == 0) {
            ALOGD("end of stream reached\n");  /* not an error */
            break;
        }

        /* filter image frames only. Images frame header always starts with 0x00, 0x1B, 0x01 */
        if (chunk.data[0] == 0x00 && chunk.data[1] == 0x1B && chunk.data[2] == 0x01) {
            ret = get_image_info_frame_fn990(&chunk, &img_frame_info);
            if (ret) {
                ALOGE("could not get image info frame from chunk\n");
                break;
            }

            /* Filter modem images only */
            if (img_frame_info.version_type == VERSION_M0_FN990 ||
                    img_frame_info.version_type == VERSION_M1_FN990) {
                /* Get current modem image info from its version string */
                ret = parse_fn990_modem_version(img_frame_info.version, &stream_info);

                if (ret != CORE_SUCCESS) {
                    ALOGE("Error %d in parse_fn990_modem_version (%s)\n", ret, img_frame_info.version);
                    goto reset;
                }

                modem_image_found = true;
                print_version_info_fn990("Stream", &stream_info);

                /* Cross download limit should prevent update between model 0 and 1 (FN990 + PC 1.5 not enabled)
                 * and model 3 and 4 (FN990 + PC 1.5 enabled).
                 * The model 2 is FE990 and it's LGA type module not M.2 module. */
                if (((stream_info.model == 3 || stream_info.model == 4) &&
                        (modem_info.model == 0 || modem_info.model == 1)) ||
                        ((stream_info.model == 0 || stream_info.model == 1) &&
                        (modem_info.model == 3 || modem_info.model == 4))) {
                    ALOGE("Invalid model %d VS %d\n", stream_info.model, modem_info.model);
                    ret = CORE_ERROR_OPERATION_NOT_PERMITTED;
                    goto reset;
                }
            }
        }
    } while (!ret);

    /* Streams can contain CNV images only, in this case flashing is not prevented because there is no risk
     * to corrupt radio  parameters */
    if (!modem_image_found) {
        ALOGW("No modem images in the stream.");
    }

reset:
    ret_lseek = core_file_lseek_set(stream->handle, stream->stream_offset);
    if (ret_lseek)
        ALOGE("could not move to stream payload: error %d\n", ret_lseek);

    /* if previous operations did not return an error, use ret2 to track possible
     * core_file_lseek_set errors, otherwise just forward the previous errors */
    if (ret == CORE_SUCCESS)
        ret = ret_lseek;

out:
    return ret;
}

static int32_t quirks(boot_context_t *ctx)
{
    chipset_t chipsets_list[] = {CHIPSET_ASR1601, CHIPSET_ASR1603, CHIPSET_QCX216, 0};
    const dev_info_t *info = &(ctx->dev_info);
    bool module_found = false;
    usb_id_t loaders[] = {USBID_ASR1601_LOADER, USBID_ASR1603_LOADER,
                          USBID_QCX216_LOADER, {0x0, 0x0}};
    usb_id_t match = {0};

    /* this function is intended to work for a short list of modules (i.e.: such as ASR-based modules or
     * QCX216), so we check it and exit successfully immediately for all other modules */
    for (uint8_t i = 0; chipsets_list[i]; ++i) {
        if (chipsets_list[i] == ctx->protocol->chipset) {
            module_found = true;
            break;
        }
    }
    if (!module_found)
        return CORE_SUCCESS;

    if (ctx->protocol->channel == CHANNEL_SERIAL_PHY
            && ctx->protocol->chipset == CHIPSET_ASR1603) {
        /* ASR1603 takes a lot of time to switch from Arom Usb Boot Port device
         * to the Telit flashing device */
        ALOGD("Wait for ASR1603 to show Telit flashing device\n");
        core_sleep (10 * 1000);
        /* speed change for serial with ASR1603 needs a little delay to be set up */
        ctx->delay_after_speed_change = 500;
        return CORE_SUCCESS;
    }

    if (ctx->modem_discovery == false && ctx->protocol->channel == CHANNEL_SERIAL_USB
            && ctx->dev_info.comm_ports_number == 1) {
        /* Discovery is not available, but USB has a port associated for uxfp; we can proceed */
        ALOGD("specified port:\"%s\" for this device\n", ctx->dev_info.comm_ports[DEFAULT_UART_CHANNEL_ID]);
        return CORE_SUCCESS;
    }

    if (ctx->protocol->channel == CHANNEL_SERIAL_USB && ctx->modem_discovery == true
            && !core_usb_id_from_str(&match, info->vendor_id, info->product_id)) {
        ALOGE("error parsing USB id info (%s:%s)\n", info->vendor_id, info->product_id);
        return CORE_ERROR_OPERATION_NOT_PERMITTED;
    }

    /* modules like LE910S1, LE910R1 and QCX216 take some time before showing the serial devices. */
    for (uint8_t i = 0; loaders[i].vid; ++i) {
        if (core_usb_id_equals(&match, &loaders[i])) {
            /* LE910S1 takes some time before showing the serial devices. */
            ALOGD("Waiting before opening the device\n");
            core_sleep(1000);
        }
    }

    return CORE_SUCCESS;
}

/* check whether the UDE device (PID 0x8900) has all
 * the expected ports. Return to enumeration otherwise */
static int32_t ude_quirks(const boot_context_t *ctx)
{
    usb_id_t match = {0};
    usb_id_t sdx55udeloader = USBID_UDELOADER_FN980;
    usb_id_t sdx65udeloader = USBID_UDELOADER_FN990;
    const dev_info_t *info = &(ctx->dev_info);

    if (ctx->protocol->channel == CHANNEL_SERIAL_PHY) {
        /* nothing to do */
        return CORE_SUCCESS;
    } else if (ctx->modem_discovery == false && ctx->protocol->channel == CHANNEL_SERIAL_USB
            && ctx->dev_info.comm_ports_number == 1) {
        /* nothing to do, as well */
        return CORE_SUCCESS;
    }

    if (!core_usb_id_from_str(&match, info->vendor_id, info->product_id)) {
        ALOGE("error parsing USB id info (%s:%s)\n", info->vendor_id, info->product_id);
        return CORE_ERROR_OPERATION_NOT_PERMITTED;
    }

    if (!core_usb_id_equals(&match, &sdx55udeloader) &&
            !core_usb_id_equals(&match, &sdx65udeloader)) {
        /* no match for this quirk, nothing to do */
        return CORE_SUCCESS;
    }

    if (get_flashing_device_pos(info) == CORE_ERROR_NO_SUCH_DEVICE)
        return CORE_ERROR_TRY_AGAIN;

    return CORE_SUCCESS;
}

static boot_mode_step_t ude_retry()
{
    static uint8_t ude_retry_count = 0;

    if (ude_retry_count++ > 3) {
        ALOGE("no retries left, could not get 0x8900 flashing device\n");
        return BOOT_MODE_STEP_ERROR;
    }
    ALOGD("modem not ready yet, retry enumeration\n");
    core_sleep(1000);
    return BOOT_MODE_STEP_ENUMERATE;
}

static int32_t
bootloader_quirks(boot_context_t *bc, driver_t *driver)
{
    usb_id_t match = {0};
    static usb_id_list_t bootloaders = { 2, {USBID_GOOGLE_FASTBOOT, USBID_TDLOADER} };
    const dev_info_t *info = &(bc->dev_info);

    if (bc->protocol->channel == CHANNEL_SERIAL_PHY) {
        /* nothing to do */
        return CORE_SUCCESS;
    }

    if (!bc->modem_discovery) {
        if (bc->recovery) {
            ALOGI("[+] No modem discovery. Waiting %d seconds to let the modem re-connect.\n",
                    NO_DISCOVERY_REBOOT_WAIT_IN_SECONDS);

            /* wait for modem disconnection, or we might find
             * the old device still connected when listening. */
            core_sleep(NO_DISCOVERY_REBOOT_WAIT_IN_SECONDS * 1000);

            if (bc->no_fastboot_driver) {
                ALOGD("no fastboot system driver expected.\n");
                get_driver(CHANNEL_FASTBOOT, bc->protocol->chipset, driver);

                if (bc->protocol->chipset == CHIPSET_SDX55) {
                    ALOGD("SDX55 bootloader expected, enabling zlp enabled.\n");
                    strlcpy(bc->dev_info.vendor_id, "1bc7", sizeof(bc->dev_info.vendor_id));
                    strlcpy(bc->dev_info.product_id, "9010", sizeof(bc->dev_info.product_id));
                    driver->device.enable_zlp = true;
                } else {
                    strlcpy(bc->dev_info.vendor_id, "18d1", sizeof(bc->dev_info.vendor_id));
                    strlcpy(bc->dev_info.product_id, "d00d", sizeof(bc->dev_info.product_id));
                }
            }
        }

        return CORE_SUCCESS;
    }

    if ((bc->modem_discovery == true) && (!core_usb_id_from_str(&match, info->vendor_id, info->product_id))) {
        ALOGE("cannot parsing USB id info (%s:%s)\n", info->vendor_id, info->product_id);

        return CORE_ERROR_OPERATION_NOT_PERMITTED;
    }

    for (uint8_t i = 0; i < bootloaders.len; i++) {
        if (!core_usb_id_equals(&match, &bootloaders.items[i]))
            continue;

        ALOGD("bootloader device %s:%s found (%" PRIu32 " ports)\n",
                info->vendor_id, info->product_id, info->comm_ports_number);

        get_boot_context(bc->protocol, bc->recovery, bc);

        if (!is_comm_port_available(info, driver)) {
            usb_id_t sdx55_sbl = USBID_TDLOADER;

            ALOGI("no system driver for device %s:%s, using endpoints\n",
                    info->vendor_id, info->product_id);

            get_driver(CHANNEL_FASTBOOT, bc->protocol->chipset, driver);

            if (core_usb_id_equals(&match, &sdx55_sbl)) {
                ALOGD("SDX55 bootloader %s:%s: zlp enabled\n",
                        info->vendor_id, info->product_id);
                driver->device.enable_zlp = true;
            }
        }
        break;
    }

    return CORE_SUCCESS;
}

/**
 * @brief update #boot_context_t with a complete #dev_info_t that has the required port name
 *
 * Used to find an actual connected device with the user requested port name.
 */
static bool find_device_by_port(boot_context_t *c, dev_info_t *dev_list, const uint8_t dev_list_size)
{
    bool ret = false;

    for (int i = 0; i < dev_list_size; ++i) {
        for (int j = 0; j < dev_list[i].comm_ports_number; ++j) {
            if (strcmp(c->dev_info.comm_ports[0], dev_list[i].comm_ports[j]) == 0) {
                memcpy(&c->dev_info, &dev_list[i], sizeof(dev_list[i]));
                ret = true;
                break;
            }
        }
    }

    return ret;
}

/**
 * @brief update #boot_context_t with a complete #dev_info_t that has the required location path
 */
static bool
find_device_by_location_path(boot_context_t *c, dev_info_t *dev_list, const uint8_t dev_list_size)
{
    bool ret = false;

    for (int i = 0; i < dev_list_size; ++i) {
        if (strcmp(c->dev_info.location_path, dev_list[i].location_path) == 0) {
            memcpy(&c->dev_info, &dev_list[i], sizeof(dev_list[i]));
            ret = true;
            break;
        }
    }

    return ret;
}

/**
 * @brief update #boot_context_t with a complete #dev_info_t that has the appropriate port
 * The appropriate port could be:
 * - the user provided one using --port
 * - the one belonging to a device with a given location_path
 * If no port is found and there are more than 1 valid connected device, exit with error
 */
static core_res_t
search_flashing_device(boot_context_t *c, dev_info_t *dev_list, const uint8_t dev_list_size)
{
    if (c->dev_info.comm_ports_number) {
        if (find_device_by_port(c, dev_list, dev_list_size)) {
            ALOGD("using device: {%s:%s location_path:%s, port:%s}\n",
                    c->dev_info.vendor_id,
                    c->dev_info.product_id,
                    c->dev_info.location_path,
                    c->dev_info.comm_ports[0]);
            return CORE_SUCCESS;
        }

        return CORE_ERROR_NO_SUCH_DEVICE;
    }

    if (strlen(c->dev_info.location_path) > 0) {
        if (find_device_by_location_path(c, dev_list, dev_list_size)) {
            ALOGD("using device: {%s:%s, location_path:%s}\n",
                    c->dev_info.vendor_id,
                    c->dev_info.product_id,
                    c->dev_info.location_path);
            return CORE_SUCCESS;
        }

        return CORE_ERROR_NO_SUCH_DEVICE;

    }

    if (dev_list_size > 1) {
        ALOGI("found too many devices connected (%" PRIu8 "). Please use --port flag.\n", dev_list_size);
        ALOGI("to get the correct port name, call UXFP with --show-diag-ports first.\n");

        return CORE_ERROR_OPERATION_NOT_PERMITTED;
    }

    /* only one device found */
    memcpy(&c->dev_info, &dev_list[0], sizeof(dev_list[0]));

    return CORE_SUCCESS;
}

static int
boot_mode_step_enumerate(driver_t *driver, boot_context_t *c, dev_info_t *dev_list, core_res_t *err,
        boot_mode_step_t *step)
{
    int8_t dev_list_size = MAX_DEVICE_LIST_SIZE;

    ALOGI("[+] checking connected devices...\n");
    *err = core_device_enumerate(c->usb_ids->items, c->usb_ids->len, dev_list, &dev_list_size);
    switch (*err) {
        case CORE_SUCCESS:
            break;
        case CORE_ERROR_NOT_IMPLEMENTED:
            c->modem_discovery = false;
            /* since discovery is not available, switch to usb profile without discovery management */
            if (c->protocol->channel == CHANNEL_SERIAL_USB)
                get_driver(CHANNEL_SERIAL_USB_NO_DISCOVERY, c->protocol->chipset, driver);
            break;
        case CORE_ERROR_NO_SUCH_DEVICE:
            ALOGI("[+] no device found\n");
            ALOGI("[+] please connect a USB device...\n");
            *step = BOOT_MODE_STEP_LISTENING;
            break;
        default:
            ALOGE("USB enumeration error %d\n", err);
            *step = BOOT_MODE_STEP_ERROR;
            break;
    }

    if (*err) {
        if (!c->modem_discovery) {
            /* If modem_discovery is not available, we continue only if:
             * - user defined device path (--port)
             * - modem in recovery and no fastboot driver */
            if ((c->recovery && c->no_fastboot_driver) ||
                    c->dev_info.comm_ports_number) {
                *err = CORE_SUCCESS;
                *step = BOOT_MODE_STEP_QUIRKS;
            }
        }
        return 1;
    }

    *err = search_flashing_device(c, dev_list, dev_list_size);
    if (*err) {
        *step = BOOT_MODE_STEP_ERROR;
        return 1;
    }

    if (c->protocol->channel != CHANNEL_SERIAL_PCI &&
            is_pci_device(&c->dev_info)) {
        /* SDX55 might appear either as USB or PCI device.
         * Adjust the channel and driver instances if necessary */
        ALOGD("%s:%s is a PCIe device, adjusting configuration\n",
                c->dev_info.vendor_id, c->dev_info.product_id);
        c->protocol->channel = CHANNEL_SERIAL_PCI;
        get_driver(CHANNEL_SERIAL_PCI, c->protocol->chipset, driver);
    }

    *step = BOOT_MODE_STEP_QUIRKS;
    return 0;
}

/**
 * @brief state machine to handle the steps of a boot phase
 */
static boot_mode_step_t
enter_boot_mode_step(driver_t *driver, boot_context_t *c, boot_mode_step_t step, stream_t *stream)
{
    static dev_info_t dev_list[MAX_DEVICE_LIST_SIZE] = {0};
    core_res_t err = CORE_ERROR_UNKNOWN;

    ALOGD("step %u %s\n", step, get_step_string(step));

    switch (step) {
        case BOOT_MODE_STEP_FIRST:
            c->bytes_left = c->boot_char_len;

            if (c->protocol->channel == CHANNEL_SERIAL_PHY)
                step = BOOT_MODE_STEP_OPEN;
            else
                step = BOOT_MODE_STEP_ENUMERATE;

            break;
        case BOOT_MODE_STEP_ENUMERATE:
            memset(dev_list, 0, sizeof(dev_list));
            if (boot_mode_step_enumerate(driver, c, dev_list, &err, &step))
                break;
        /* fall through */
        case BOOT_MODE_STEP_QUIRKS:
            err = bootloader_quirks(c, driver);
            if (err) {
                step = BOOT_MODE_STEP_ERROR;
                break;
            }

            err = ude_quirks(c);
            if (err) {
                if (err == CORE_ERROR_TRY_AGAIN) {
                    step = ude_retry();
                    break;
                }
            }

            err = quirks(c);
            if (err) {
                step = BOOT_MODE_STEP_ERROR;
                break;
            }

            step = BOOT_MODE_STEP_OPEN;
            break;

        case BOOT_MODE_STEP_LISTENING: {
            usb_id_t event = {0};
            int8_t dev_list_size = MAX_DEVICE_LIST_SIZE;
            memset(dev_list, 0, sizeof(dev_list));

            err = core_device_usb_id_event_listener(core_usb_id_find_match,
                    c->usb_ids,
                    c->timeout, &event);
            if (err) {
                if (err == CORE_ERROR_TIMEOUT) {
                    ALOGI("[!] listening timed out; trying to look for the module directly\n");

                    /* a last enumeration is performed to search for the expected device, if it is already
                     * active but the presentation of the module has been lost; this way we avoid declaring
                     * that the module is not present unless the last module lookup fails */
                    err = core_device_enumerate(c->usb_ids->items, 1, dev_list, &dev_list_size);
                    ALOGI("[!] module %sfound", !err ? "" : "not ");
                    if (err == CORE_SUCCESS)
                        goto found;
                }
                step = BOOT_MODE_STEP_ERROR;
                break;
            }

            ALOGD("USB attach event from %04" PRIX32 ":%04" PRIX32 "\n", event.vid, event.pid);

            /* enumerate after listening is needed to fill the proper data structures to go on */
            err = core_device_enumerate(&event, 1, dev_list, &dev_list_size);
            if (err) {
                /* Windows enumeration might be slow, resulting in a short delay
                 * between the event notification and the availability of the
                 * device for enumeration */
                uint8_t retries = 3;
                uint16_t waitms = 1000;

                while (retries-- > 0 && err) {
                    ALOGD("no device ready yet. Retrying in %" PRIu16 "ms...\n", waitms);
                    core_sleep(waitms);
                    err = core_device_enumerate(&event, 1, dev_list, &dev_list_size);
                }
            }
            if (err)
                break;
found:
            err = search_flashing_device(c, dev_list, dev_list_size);
            if (err) {
                if (err == CORE_ERROR_NO_SUCH_DEVICE) {
                    step = BOOT_MODE_STEP_LISTENING;
                    break;
                }

                ALOGE("no device info for %04" PRIX32 ":%04" PRIX32 ": error %d\n", event.vid, event.pid,
                        err);
                step = BOOT_MODE_STEP_ERROR;
                break;
            }

            step = BOOT_MODE_STEP_QUIRKS;
            break;
        }
        case BOOT_MODE_STEP_OPEN: {
            dev_info_t dev_list_tmp = {0};
            usb_id_t items = {0};

            /* This check is intended to find if USB devices discovery in bus is available, and in case of not
             * to disable the discovery check from now on */
            if (core_device_get_usb_id_info(&items, &dev_list_tmp) == CORE_ERROR_NOT_IMPLEMENTED) {
                c->modem_discovery = false;
                ALOGD("USB devices discovery not available\n");
            }

            ALOGI("[+] enter boot mode\n");
            step = boot_fops.boot_open(&c->dev_info, driver);
            break;
        }
        case BOOT_MODE_STEP_CONFIG:
            err = driver->configure(driver, false);
            if (err) {
                ALOGE("could not configure the device\n");
                step = BOOT_MODE_STEP_ERROR;
                break;
            }

            /* Enter boot mode always requires baud rate to be 115200 */
            err = driver->set_baud_rate(driver, ENTER_BOOT_MODE_BAUD_RATE);
            if (err) {
                ALOGE("set baud rate %" PRIu32 " error %d\n", c->baud_rate, err);
                step = BOOT_MODE_STEP_ERROR;
                break;
            }

            err = fn990_quirks(c, driver, stream);
            if (err) {
                step = BOOT_MODE_STEP_ERROR;
                break;
            }

            step++;
            break;
        case BOOT_MODE_STEP_SEND:
            step = boot_fops.boot_send(driver, c);
            if (step != BOOT_MODE_STEP_READ)
                break;
        /* fall through */
        case BOOT_MODE_STEP_READ:
            step = boot_fops.boot_ack_read(driver, c);
            break;
        case BOOT_MODE_STEP_COMPARE:
            step = boot_fops.boot_ack_compare(c);
            /* Do not exit at first compare error */
            if (step == BOOT_MODE_STEP_ERROR) {
                step = BOOT_MODE_STEP_SEND;
                break;
            }
            /* If not already in recovery, verify whether the modem has a
             * second boot phase and prepare it if that so */
            if (step == BOOT_MODE_STEP_SUCCESS && !c->recovery)
                step = prepare_for_second_boot_phase(c);
            break;
        default:
            ALOGE("unexpected step %u\n", step);
            err = CORE_ERROR_UNKNOWN;
            step = BOOT_MODE_STEP_ERROR;
    }

    if (c->retries-- <= 0) {
        ALOGE("Run out of retries\n");
        step = BOOT_MODE_STEP_ERROR;
    }

    if (err == CORE_ERROR_NOT_IMPLEMENTED) {
        ALOGI("[!] Modem discovery is not supported in this build\n");
        step = BOOT_MODE_STEP_ERROR;
    }

    if (c->report_entries)
        json_update(c->report_entries, REPORT_KEY_BOOT_STEP,
                get_step_string(step), VALUE_TYPE_STRING);
    return step;
}

/**
 * @brief configure the expected boot, ack and timings to set a modem in boot mode
 */
static int32_t
get_boot_messages(boot_type_t type, boot_context_t *ctx)
{
    int32_t err = 0;

    /* Boot buffers */
    static uint8_t boot_mode_1byte_boot_string[1] = { 0x55 };
    static uint8_t boot_mode_2bytes_boot_string[2] = { 0x41, 0x54 };
    /* AT+TCOMWRT=1;#REBOOT */
    static uint8_t boot_mode_asr_qcx216_bytes_boot_string[] = {
        0x41, 0x54, 0x2B, 0x54, 0x43, 0x4F, 0x4D, 0x57, 0x52, 0x54,
        0x3D, 0x31, 0x3B, 0x23, 0x52, 0x45, 0x42, 0x4F, 0x4F, 0x54,
        0x0D
    };


    /* Ack buffers */
    static uint8_t boot_mode_1byte_ack_string[1] = { 0xA0 };
    static uint8_t boot_mode_1byte_ack_string_a1[1] = { 0xA1 };
    static uint8_t boot_mode_asr_byte_ack_string[2] = { 0x4F, 0x4B };            /* "OK" reply to AT command. Currently this ack is not verified in compare boot step. */
    static uint8_t boot_mode_3bytes_ack_string[3] = { 0x92, 0x00, 0x00 };
    static uint8_t boot_mode_12bytes_ack_string[3] = { 0xF0, 0x0A, 0xFF };       /* actual ACK is 12 bytes long, only first, second and last shall be checked */
    static uint8_t boot_mode_24bytes_ack_string[4] = { 0xF0, 0x16, 0xFF, 0xFF }; /* actual ACK is 24 bytes long, only first, second, last and before last shall be checked */
    static uint8_t boot_mode_28bytes_ack_string_var_a[2] = { 0xF1, 0x1C };       /* actual ACK is 28 bytes long, only first two bytes shall be checked */
    static uint8_t boot_mode_28bytes_ack_string_var_b[2] = { 0xF1, 0x1A };       /* actual ACK is 28 bytes long, only first two bytes shall be checked */

    ALOGD("getting messages for boot type %s\n", get_boot_type_name(type));

    ctx->max_nacks = 0;

    switch (type) {
        case BOOT_TYPE_DO_NOTHING:
            /* no message exchange is expected for this type */
            break;
        case BOOT_TYPE_FASTBOOT:
        case BOOT_TYPE_A_SERIAL:
        case BOOT_TYPE_A_USB:
        case BOOT_TYPE_B_USB:
        case BOOT_TYPE_D_SERIAL:
        case BOOT_TYPE_E_SERIAL:
        case BOOT_TYPE_F_SERIAL:
            ctx->boot_char_send_interval =
                    (type == BOOT_TYPE_F_SERIAL || type == BOOT_TYPE_E_SERIAL) ? 60 : 120;
            ctx->boot_char_len = 1;
            ctx->boot_char = boot_mode_1byte_boot_string;
            ctx->exp_ack_boot_str_len = 1;
            ctx->exp_ack_boot_str = boot_mode_1byte_ack_string;
            if (type == BOOT_TYPE_E_SERIAL)
                ctx->max_nacks = 10;
            break;
        case BOOT_TYPE_A2:
            ctx->boot_char_send_interval = 120;
            ctx->boot_char_len =
                    sizeof(boot_mode_asr_qcx216_bytes_boot_string)
                    / sizeof(boot_mode_asr_qcx216_bytes_boot_string[0]);
            ctx->boot_char = boot_mode_asr_qcx216_bytes_boot_string;
            ctx->exp_ack_boot_str_len = 2;
            ctx->exp_ack_boot_str = boot_mode_asr_byte_ack_string;
            break;
        case BOOT_TYPE_A3_USB:
            ctx->boot_char_send_interval = 70;
            ctx->boot_char_len = 1;
            ctx->boot_char = boot_mode_1byte_boot_string;
            ctx->exp_ack_boot_str_len = 1;
            ctx->exp_ack_boot_str = boot_mode_1byte_ack_string_a1;
            break;
        case BOOT_TYPE_B_SERIAL:
            ctx->boot_char_send_interval = 120;
            ctx->boot_char_len = 1;
            ctx->boot_char = boot_mode_1byte_boot_string;
            ctx->exp_ack_boot_str_len = 3;
            ctx->exp_ack_boot_str = boot_mode_3bytes_ack_string;
            break;
        case BOOT_TYPE_G_SERIAL:
            ctx->boot_char_send_interval = 30;
            /* ALT1350 has a boot delay to allow flashing with Altair tool, the high retries number
             * is needed to wait for this delay to finish and for xfp engine to start in the module */
            ctx->retries = 20000;
            ctx->boot_char_len = 1;
            ctx->boot_char = boot_mode_1byte_boot_string;
            ctx->exp_ack_boot_str_len = 1;
            ctx->exp_ack_boot_str = boot_mode_1byte_ack_string;
            break;
        case BOOT_TYPE_C1_SERIAL:
        case BOOT_TYPE_C2_SERIAL:
        case BOOT_TYPE_C3_SERIAL:
        case BOOT_TYPE_C1_USB:
        case BOOT_TYPE_C2_USB:
        case BOOT_TYPE_C3_USB:
        case BOOT_TYPE_C4_USB:
            ctx->boot_char_send_interval = 60;
            ctx->boot_char_len = 2;
            ctx->boot_char = boot_mode_2bytes_boot_string;

            if (type == BOOT_TYPE_C1_SERIAL || type == BOOT_TYPE_C1_USB) {
                ctx->exp_ack_boot_str_len = 24;
                ctx->exp_ack_boot_str = boot_mode_24bytes_ack_string;
            }

            if (type == BOOT_TYPE_C2_SERIAL || type == BOOT_TYPE_C2_USB) {
                ctx->exp_ack_boot_str_len = 12;
                ctx->exp_ack_boot_str = boot_mode_12bytes_ack_string;
            }

            if (type == BOOT_TYPE_C3_SERIAL || type == BOOT_TYPE_C3_USB) {
                ctx->exp_ack_boot_str_len = 28;
                ctx->exp_ack_boot_str = boot_mode_28bytes_ack_string_var_a;
            }

            if (type == BOOT_TYPE_C4_USB) {
                ctx->exp_ack_boot_str_len = 28;
                ctx->exp_ack_boot_str = boot_mode_28bytes_ack_string_var_b;
            }
            break;
        case BOOT_TYPE_UNKNOWN:
            err = CORE_ERROR_OPERATION_NOT_PERMITTED;
            break;
        default:
            ALOGE("unknown boot type %u\n", type);
            err = CORE_ERROR_UNKNOWN;
            break;
    }

    return err;
}

int32_t enter_boot_mode(driver_t *driver, boot_context_t *ctx, bool stop_after_restart, stream_t *stream)
{
    int32_t err;
    boot_mode_step_t step = BOOT_MODE_STEP_FIRST;
    ctx->modem_discovery = true;
    bool retry = true;

    while (true) {
        step = enter_boot_mode_step(driver, ctx, step, stream);

        if (step == BOOT_MODE_STEP_ERROR && retry) {
            ALOGD("boot mode failed, retrying to address possible temporary enumeration issues\n");
            core_sleep(4000);
            retry = false;
            step = BOOT_MODE_STEP_FIRST;
            continue;
        }

        if (step == BOOT_MODE_STEP_SUCCESS || step == BOOT_MODE_STEP_ERROR ||
                (step == BOOT_MODE_STEP_LISTENING && stop_after_restart))
            break;
    }

    err = (step == BOOT_MODE_STEP_ERROR) ? -1 : 0;
    if (!err && !stop_after_restart)
        ALOGI("[+] enter boot mode OK\n");

    return err;
}

int32_t get_boot_context(protocol_t *protocol, bool is_recovery, boot_context_t *ctx)
{
    int32_t err;
    boot_type_t type;

    ctx->protocol = protocol;
    ctx->recovery = is_recovery;
    ctx->timeout = LISTENING_TIMEOUT_IN_SECONDS * ONE_SEC_IN_MS;
    /* retries variable may be overwritten in get_boot_messages() depending on the boot type */
    ctx->retries = MAX_BOOT_MODE_RETRIES;

    /* module identifiers contains USB and PCI values, so this check should be performed for both
     * USB and PCI */
    if (protocol->channel == CHANNEL_SERIAL_USB || protocol->channel == CHANNEL_SERIAL_PCI) {
        err = get_usb_ids_from_chipset(protocol->chipset, is_recovery, &ctx->usb_ids);
        if (err) {
            if (err != CORE_ERROR_NO_SUCH_DEVICE)
                ALOGE("get usb ids error\n");
            return err;
        }
    }

    type = is_recovery ? protocol->boot_type_recovery : protocol->boot_type;
    err = get_boot_messages(type, ctx);
    if (err) {
        if (err != CORE_ERROR_OPERATION_NOT_PERMITTED)
            ALOGE("could not get boot context for boot type %u\n", type);
        goto end;
    }

    err = set_boot_operations(type);
    if (err) {
        ALOGE("set boot operations error\n");
        return err;
    }

end:
    return err;
}
