#!/bin/sh

echo "First argument is the firmware bin file"
echo "Second argument (optional, default 1) is the number of firmware update operations to be performed"

# exit when any command fails
set -e

if [ -z "$2" ]; then
    RETRIES=1
else
    RETRIES=$2
fi

I=0
while [ $I -lt "$RETRIES" ]; do
    I=$((I + 1))
    echo ##############################
    echo Attempt $I out of "$RETRIES"
    echo ##############################

    echo "Disabling mhi pcie device runtime power management"
    pci_mhi_path=$(lspci -D | grep "Qualcomm Device" | awk '{print $1}')
    echo on > "/sys/bus/pci/devices/$pci_mhi_path/power/control"

    echo "Setting the driver in firmware update mode"
    echo 1 > /sys/bus/mhi/devices/mhi0/fw_update

    echo "Calling ufxp"
    ../builddir/uxfp -f "$1"

    echo "Resetting the MHI stack"
    echo 0 > /sys/bus/mhi/devices/mhi0/fw_update
    echo "Waiting for the diagnostic device to be ready"
    sleep 60
done

echo "Successfully performed $I out of $RETRIES firmware update operations"
