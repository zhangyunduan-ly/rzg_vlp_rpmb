@echo OFF
if "%~1"=="" (
echo stream file was not passed
echo USAGE: pcie_fw_update.bat stream_file [uxfp option 1 [uxfp option 2]]
echo uxfp options:
echo          -d or --debug            : enable debug logging
echo          -l or --lossrecovery     : device in recovery mode
echo          -w or --show-diag-ports  : only show connected diagnostic ports and exit
goto end
)

start /wait /b /d %~dp0 uxfp.exe -f %~f1 %2 %3

echo Flashing end
echo Please wait. The device is restarting
timeout /t 10 /nobreak > nul 2>&1

SET _cmd=pnputil /enum-devices /connected /class system
FOR /f "tokens=3 delims= " %%G IN ('%_cmd% ^|find "PCI\VEN_17CB"') DO set hwid="%%G"

pnputil /restart-device %hwid%

:end
echo bye
