#!/usr/bin/env bash

set -euo pipefail

UXFP=uxfp

if [ "$#" -lt 1 ]; then
    echo "This is a wrapper script for uxfp. You have to use the uxfp's options"
    echo "usage: $0 <options>"
    echo "example: $0 --file <path/to/stream/file>"
    $UXFP --help
    exit
fi

echo "Disabling mhi pcie device runtime power management"
pci_mhi_path=$(lspci -D | grep "Qualcomm Device" | awk '{print $1}')
echo on > "/sys/bus/pci/devices/$pci_mhi_path/power/control"

echo "Setting the driver in firmware update mode"
echo 1 > /sys/bus/mhi/devices/mhi0/fw_update

echo "Calling ufxp"
$UXFP "${@}"

echo "Resetting the MHI stack"
echo 0 > /sys/bus/mhi/devices/mhi0/fw_update
echo "Waiting for the diagnostic device to be ready"
sleep 60

echo "Successfully performed a firmware update operation"
