#ifndef _DIAGNOSTIC_H_
#define _DIAGNOSTIC_H_

#include <telit-os-abs.h>
#include "driver.h"

#define MAX_DEVICE_LIST_SIZE (10)

typedef struct {
    usb_id_t usb_id;
    char serial_number[MAX_STR_VALUE];
    char diagnostic_port_name[MAX_STR_VALUE];
} diagnostic_t;

/**
 * @brief Mapping between modems USB id list and Diagnostic ports
 *
 * @param[in] driver the #driver_t instance driving the modem
 * @param[in] usb_ids a list of #usb_ids_t for the modems to look for
 * @param[in] usb_ids_size the size of the usb_ids list in input
 * @param[out] diagnostic a list of #diagnostic_t, one for each matching modem
 * @param[out] diagnostic_size the size of the diagnostic list returned
 */
core_res_t show_connected_diag_ports(const driver_t *driver, const usb_id_t *usb_ids, int32_t usb_ids_size,
        diagnostic_t *diagnostic, int8_t *diagnostic_size);

#endif  /* _DIAGNOSTIC_H_ */
