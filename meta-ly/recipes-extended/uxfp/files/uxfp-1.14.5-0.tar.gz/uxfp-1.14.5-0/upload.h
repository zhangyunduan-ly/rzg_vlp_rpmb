/**
 * @file upload.h
 * @brief Handling of modem upload phase
 *
 * Copyright (C) 2018  Telit Communication spa
 */
#ifndef _UPLOAD_H_
#define _UPLOAD_H_

#include <telit-os-abs.h>

#include "driver.h"
#include "stream.h"
#include "uxfp.h"
#include "boot.h"

#define MAX_BUFFER_SIZE 256
#define MAX_DATA_SIZE 256

typedef enum {
    UPLOAD_SUCCESS,
    UPLOAD_ERR_READ_CHUNK,
    UPLOAD_ERR_GOT_NACK,
    UPLOAD_ERR_UNKNOWN_STEP,
} upload_error_t;

/**
 * @brief baud rate/speed values
 */
typedef enum {
    SPEED_OPT_UNKNOWN  = 0,
    SPEED_OPT_115200   = 115200,
    SPEED_OPT_230400   = 230400,
    SPEED_OPT_460800   = 460800,
    SPEED_OPT_921600   = 921600,
    SPEED_OPT_2000000  = 2000000,
    SPEED_OPT_3000000  = 3000000,
    SPEED_OPT_3200000  = 3200000,
    SPEED_OPT_3750000  = 3750000,
    SPEED_OPT_NOCHANGE = 9,
} speed_opt_t;

/**
 * @brief speed change handling states
 */
typedef enum {
    SPEED_CHANGE_CHANGE_IN_MODEM,
    SPEED_CHANGE_CHANGE_IN_HOST,
    SPEED_CHANGE_DONE,
} speed_change_state_t;

/**
 * @brief structure to handle a data buffer
 */
typedef struct {
    uint8_t data[MAX_BUFFER_SIZE]; /**< data array */
    uint32_t len;                  /**< length of the data array */
} buffer_t;

/**
 * @brief data and function to handle acknowledge byte from the modem
 */
typedef struct _acknowledge_t {
    uint8_t data[MAX_DATA_SIZE];                                      /**< the buffer containing the modem reply */
    int32_t data_len;                                                 /**< length of the buffer data */
    int32_t ack_len;                                                  /**< expected ack len */
    bool (*compare)(const struct _acknowledge_t *, const buffer_t *); /**< ack buffer comparing function */
} acknowledge_t;

typedef enum {
    ACK_IS_EXPECTED,
    ACK_SKIP_UNTIL_OFFSET,
    ACK_READ_AND_IGNORE_UNTIL_OFFSET,
} ack_offset_handling_t;

/**
 * @brief context data exchanged during upload steps according to the selected upload protocol
 */
typedef struct {
    stream_t stream;                                            /**< #stream_t instance with firmware info */
    bool is_ack_exp;                                            /**< true if the modem is expected to reply with ACK messages */
    ack_offset_handling_t ack_expected;                         /**< the #ack_offset_handling_t selector for handling ack boot offset */
    const uint32_t ack_boot_offset;                             /**< offset in firmware stream after which the modem is expected to return ACK messages */
    const acknowledge_t *exp_ack;                               /**< the expected ACK message */
    const acknowledge_t *exp_first_ack;                         /**< the expected first ACK message */
    uint32_t ack_timeout_ms;                                    /**< the ACK message timeout */
    speed_opt_t wanted_speed;                                   /**< the desired baud rate */
    speed_change_state_t speed_change_state;                    /**< the #speed_change_state_t state */
    bool enable_hw_flow_control_after_speed_change;             /**< the hardware flow control enabling status */
    uint8_t max_nacks;                                          /**< Max number of NACK received before error out from upload */
    void (*progress)(const int64_t current, const int64_t max); /**< logging progress function (can be NULL) */
    json_t *report_entries;
} upload_context_t;

/**
 * @brief upload the firmware stream on the modem
 *
 * @param[in] driver the modem #driver_t instance
 * @param[in] ctx the #upload_context_t
 *
 * @return 0 in case of success, or telit_os_abstraction_layer::core_res_t otherwise
 */
int32_t upload_firmware(driver_t *driver, upload_context_t *ctx, boot_context_t *boot_ctx);


/**
 * @brief configure #upload_context_t structure for the given #upload_type_t and #channel_t
 *
 * @param[in] protocol the #protocol_t
 * @param[out] ctx the #upload_context_t
 *
 * @return 0 in case of success, or telit_os_abstraction_layer::core_res_t otherwise
 */
int32_t get_upload_context(protocol_t *protocol, upload_context_t *ctx);

#endif  /* _UPLOAD_H_ */
