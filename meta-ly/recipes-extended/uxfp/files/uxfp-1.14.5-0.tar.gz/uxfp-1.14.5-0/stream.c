#include <assert.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <inttypes.h>

#include <telit-os-abs.h>
#include "stream.h"

#define STREAM_VER_WITH_ACK_BOOT_OFFSET 0x0005
#define ACK_BOOT_OFFSET_POSITION        0xBE
#define HW_FLOW_CTRL_POSITION           0xE2
#define STREAM_OFFSET_POSITION          0x102

#define STREAM_VERSION_FOR_HW_FLOW_CTRL_DISABLE 8
#define STREAM_NO_HW_FLOW_CTRL_STR "NO HW FLOW CONTROL"

/* According to 80000NT10058A_r20 */
#pragma pack( push, 1 )
/**
 * @brief Firmware stream's header fields
 */
typedef struct {
    uint16_t header_size;
    char sw_version[32];
    char product_name[32];
    uint16_t memory_type;
    uint16_t stream_version;
    uint32_t speed_offset;
} stream_header_t;
#pragma pack( pop )

int32_t get_image_info_frame_fn990(const data_big_block_t *chunk, image_info_frame_t *info)
{
    /* Frame format
     * Bytes, Offset, Description
     * 1,     0,      command type
     * 2,     1,      command length (0x1b 0x01))
     * 16,    3,      image name
     * 4,     19,     image binary's size (little endian)
     * 4,     23,     number of frames to be written (little endian)
     * 1,     27,     version type {HOST, MODEM, CNV, OEMAPPS, CUSTAPPS}
     * 2,     28,     reserved
     * 256,   30,     version of the image
     * 2,     286,    the CRC value for all field (little endian)
     */
    uint32_t frame_number;
    uint32_t image_size;
    uint16_t cmd_len;
    int32_t err = 0;

    if (!info || !chunk) {
        err = CORE_ERROR_EINVAL;
        goto end;
    }

    info->cmd_type = chunk->data[0];
    memcpy(&cmd_len, chunk->data + 1, 2);
    info->cmd_len = le16toh(cmd_len);

    memcpy(info->image_name, chunk->data + 3, 16);

    memcpy(&image_size, chunk->data + 19, 4);
    info->image_size = le32toh(image_size);

    memcpy(&frame_number, chunk->data + 23, 4);
    info->frame_number = le32toh(frame_number);

    switch (chunk->data[27]) {
        case VERSION_HOST_FN990:
            info->index = 0;
            info->version_type = VERSION_HOST_FN990;
            break;
        case VERSION_M0_FN990:
            info->index = 1;
            info->version_type = VERSION_M0_FN990;
            break;
        case VERSION_M1_FN990:
            info->index = 2;
            info->version_type = VERSION_M1_FN990;
            break;
        case VERSION_CNV0_FN990:
            info->index = 1;
            info->version_type = VERSION_CNV0_FN990;
            break;
        case VERSION_CNV1_FN990:
            info->index = 2;
            info->version_type = VERSION_CNV1_FN990;
            break;
        case VERSION_OEMAPPS_FN990:
            info->index = 3;
            info->version_type = VERSION_OEMAPPS_FN990;
            break;
        case VERSION_CUSTAPPS_FN990:
            info->index = 4;
            info->version_type = VERSION_CUSTAPPS_FN990;
            break;
        default:
            ALOGE("unsupported version type %d\n", chunk->data[27]);
            err = CORE_ERROR_EINVAL;
            break;
    }

    strlcpy(info->version, (const char *)chunk->data + 30, sizeof(info->version));

end:
    return err;
}

#pragma weak read_chunk_from_stream
int32_t
read_chunk_from_stream(const file_handle_t file,
        data_big_block_t *chunk,
        uint32_t *bytes)
{
    core_res_t err = 0;
    uint16_t len = 0;

    err = core_file_read(file, &len, CHUNK_HEADER_LEN, bytes);
    if (err) {
        ALOGE("stream chunk header read error %d\n", err);
        goto end;
    }

    chunk->len = le16toh(len);

    /* According to 80000NT10058A_r20, reading LEN + 1 bytes from stream */
    err = core_file_read(file, chunk->data, chunk->len + 1, bytes);
    if (err) {
        ALOGE("stream chunk payload read error %d\n", err);
        goto end;
    }

end:
    return err;
}

static int32_t
stream_get_base_sw_version(const char *sw_version, char *base_sw_version, size_t size)
{
    char *last_dot = NULL;

    /* TODO: review this logic */
    last_dot = strrchr(sw_version, '.');
    if (last_dot) {
        memset(base_sw_version, 0, size);
        memcpy(base_sw_version, sw_version, (last_dot - sw_version));
        return CORE_SUCCESS;
    }
    /* OEMPRI standalone stream binaries have sw_version like "FLEX_<OEMPRI version>" */
    if (strstr(sw_version, "FLEX_") != NULL) {
        memset(base_sw_version, 0, size);
        strlcpy(base_sw_version, sw_version, size);
        return CORE_SUCCESS;
    }
    /* OEMPRI standalone stream binaries for LM940 have sw_version like "FLEX" */
    if (strstr(sw_version, "FLEX") != NULL) {
        memset(base_sw_version, 0, size);
        strlcpy(base_sw_version, sw_version, size);
        return CORE_SUCCESS;
    }

    return CORE_ERROR_EINVAL;
}

static core_res_t
get_ack_boot_offset(const file_handle_t handle, stream_t *stream)
{
    core_res_t err;
    uint32_t bytes_read;
    uint32_t ack_boot_offset;

    if (!stream_has_ack_boot_offset(stream))
        return CORE_SUCCESS;

    err = core_file_lseek_set(handle, ACK_BOOT_OFFSET_POSITION);
    if (err) {
        ALOGE("could not seek ack boot offset: ret %d\n", err);
        return err;
    }

    err = core_file_read(handle, &(ack_boot_offset), sizeof(ack_boot_offset), &bytes_read);
    if (err || bytes_read != sizeof(ack_boot_offset)) {
        ALOGE("could not read ACK boot offset\n");
        return err ? err : -1;
    }

    stream->ack_boot_offset = le32toh(ack_boot_offset);

    ALOGD(" ack boot offset : %08" PRIx32 "\n", stream->ack_boot_offset);
    return err;
}

static core_res_t
get_hw_flow_ctrl_offset(const file_handle_t handle, stream_t *stream)
{
    core_res_t err;
    uint32_t bytes_read;
    char hw_flow_ctrl[32] = {0};

    err = core_file_lseek_set(handle, HW_FLOW_CTRL_POSITION);
    if (err) {
        ALOGE("could not seek hw flow control offset: err %d\n", err);
        goto end;
    }

    err = core_file_read(handle, &(hw_flow_ctrl), 32, &bytes_read);
    if (err) {
        ALOGE("could not read hw flow ctrl offset\n");
        return err;
    }

    if (strncmp(hw_flow_ctrl, STREAM_NO_HW_FLOW_CTRL_STR, MAX_STREAM_STRING))
        stream->hw_flow_ctrl = true;
    ALOGD("hw flow ctrl setting: %s\n", stream->hw_flow_ctrl ? "true" : "false");
end:
    return err;
}

static core_res_t
get_stream_offset(const file_handle_t handle, stream_t *stream)
{
    core_res_t err;
    uint32_t bytes_read;
    uint32_t offset;

    if (stream->stream_version < 8)
        return CORE_SUCCESS;

    err = core_file_lseek_set(handle, STREAM_OFFSET_POSITION);
    if (err) {
        ALOGE("could not seek ack boot offset: ret %d\n", err);
        return err;
    }

    err = core_file_read(handle, &(offset), sizeof(offset), &bytes_read);
    if (err || bytes_read != sizeof(offset)) {
        ALOGE("could not read stream boot offset\n");
        return err ? err : -1;
    }

    stream->stream_offset = le32toh(offset);

    ALOGD("     stream offset : %08" PRIx32 "\n", stream->stream_offset);
    return err;
}

static core_res_t
point_to_payload(const channel_t channel, stream_t *stream)
{
    core_res_t err;
    uint32_t payload_offset;

    /* stream_offset is set to always point to where the payload is:
     * - in version<8 is right after the header
     * - in version>=8
     *   - channel Serial/PCIe: is right after the header
     *   - channel USB: is at stream_offset value taken from the header. */
    if (channel == CHANNEL_SERIAL_USB)
        payload_offset = (stream->stream_version >= 8 && stream->stream_offset != 0) ?
                stream->stream_offset :
                stream->header_size;
    else
        payload_offset = stream->header_size;
    stream->stream_offset = payload_offset;
    ALOGD("pointing to stream payload at offset 0x%" PRIX32 " (%" PRIu32 ")\n",
            stream->stream_offset, stream->stream_offset);

    err = core_file_lseek_set(stream->handle, stream->stream_offset);
    if (err)
        ALOGE("could not move to stream payload: error %d\n", err);
    return err;
}

int32_t stream_get_from_file(const file_handle_t handle, const channel_t channel, stream_t *stream)
{
    core_res_t err = 0;
    uint32_t bytes_read = 0;
    stream_header_t sh = {0};

    err = core_file_read(handle, &(sh), sizeof(sh), &bytes_read);
    if (err) {
        ALOGE("could not read stream header: error %d\n", err);
        goto end;
    }

    ALOGD("stream header:\n");
    ALOGD("  header size   : %d\n", le16toh(sh.header_size));
    ALOGD("  sw version    : %s\n", sh.sw_version);
    ALOGD("  product name  : %s\n", sh.product_name);
    ALOGD("  memory type   : %04" PRIx16 "\n", le16toh(sh.memory_type));
    ALOGD("  stream version: %" PRIu16 "\n", le16toh(sh.stream_version));
    ALOGD("  speed offset  : %08" PRIx32 "\n", le32toh(sh.speed_offset));

    memset(stream, 0, sizeof(*stream));

    stream->handle = handle;
    stream->header_size = le16toh(sh.header_size);
    stream->speed_offset = le32toh(sh.speed_offset);
    stream->stream_version = le16toh(sh.stream_version);

    memcpy(stream->product_name, sh.product_name, MAX_STREAM_STRING);
    memcpy(stream->sw_version, sh.sw_version, MAX_STREAM_STRING);

    err = core_file_get_size(handle, &stream->filesize);
    if (err)
        ALOGE("could not get file size\n");

    err = stream_get_base_sw_version(sh.sw_version, stream->base_sw_version, sizeof(stream->base_sw_version));
    if (err < 0) {
        ALOGW("could not get base sw version\n");
        err = 0;
    }

    err = get_ack_boot_offset(handle, stream);
    if (err)
        goto end;

    err = get_stream_offset(handle, stream);
    if (err)
        goto end;

    if (stream->stream_version == STREAM_VERSION_FOR_HW_FLOW_CTRL_DISABLE) {
        err = get_hw_flow_ctrl_offset(handle, stream);
        if (err)
            goto end;
    }

    err = point_to_payload(channel, stream);
    if (err) {
        ALOGE("could point to payload: error %d\n", err);
        goto end;
    }

    stream->read_chunk = read_chunk_from_stream;

end:
    return err;
}

void stream_print_content(const stream_t *stream)
{
    assert(stream != NULL);

    ALOGI("- stream header:\n");
    ALOGI("  product name   : %s\n", stream->product_name);
    ALOGI("  header size    : %" PRIu16 "\n", stream->header_size);
    ALOGI("  version        : %s\n", stream->sw_version);
    ALOGI("  base version   : %s\n", stream->base_sw_version);
    ALOGI("  file size      : %" PRIu64 " B\n", stream->filesize);
    ALOGI("  ack boot offset: 0x%" PRIx32 "\n", stream->ack_boot_offset);
    ALOGI("  speed offset   : 0x%" PRIx32 "\n", stream->speed_offset);
    ALOGI("  stream offset  : 0x%" PRIx32 "\n", stream->stream_offset);
}


bool stream_has_ack_boot_offset(const stream_t *stream)
{
    return (stream->stream_version >= STREAM_VER_WITH_ACK_BOOT_OFFSET);
}
