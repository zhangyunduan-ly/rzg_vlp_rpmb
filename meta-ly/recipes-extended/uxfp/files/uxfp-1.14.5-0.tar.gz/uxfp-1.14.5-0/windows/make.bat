@echo off

echo "********************************************************************"
echo "WARNING: make.bat is deprecated it will be removed! Please use Meson"
echo "********************************************************************"

set NAME=uxfp
set ROOT=..

if "%1"=="clean"  (
    del %NAME%.exe
    del %NAME%.res
    del *.ilk
    del *.pdb
    del %ROOT%\tests\test_*.exe
    goto end
)

set DBG=
if "%1" == "debug" (
    set DBG="-DEBUG"
)

REM Modify the following paths if needed for pointing to telit-os-abs.lib and includes
if exist %ROOT%\subprojects\telit_os_abstraction_layer\ (
    set LIBS=%ROOT%\subprojects\telit_os_abstraction_layer\windows\telit-os-abs.lib
    set CFLAGS=-I%ROOT% -I%ROOT%\subprojects\telit_os_abstraction_layer -I%ROOT%\subprojects\telit_os_abstraction_layer\windows
) else (
    set LIBS=%ROOT%\..\telit_os_abstraction_layer\windows\telit-os-abs.lib
    set CFLAGS=-I%ROOT% -I%ROOT%\..\telit_os_abstraction_layer -I%ROOT%\..\telit_os_abstraction_layer\windows
)

rc /r uxfp.rc

for %%s in (%ROOT%\*.c) do (
    cl %CFLAGS% -Fo%%~ns.obj -FS -c %ROOT%\%%~ns.c
)

if "%1" == "tests" (
    cd %ROOT%\tests
    for %%s in (test_*.c) do (

        echo "--- making test: %%~ns ---"

        cl %CFLAGS% -Fo%%~ns.obj^ -FS -c %%~ns.c

        link %DBG% -nologo -out:%%~ns.exe ^
            %%~ns.obj ^
             %ROOT%\windows\boot.obj ^
             %ROOT%\windows\driver.obj ^
             %ROOT%\windows\stream.obj ^
             %ROOT%\windows\protocol.obj ^
             %ROOT%\windows\upload.obj ^
             %ROOT%\windows\devices.obj ^
             %LIBS%
    )
    del *.obj
    del %ROOT%\windows\*.obj

    cd %ROOT%\windows
    goto end
)

link %DBG% *.obj %LIBS% uxfp.res -out:%NAME%.exe

del *.obj

:end
