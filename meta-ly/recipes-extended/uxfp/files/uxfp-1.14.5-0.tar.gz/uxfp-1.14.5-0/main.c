/**
 * @mainpage uxfp
 * UXFP is the Telit modems firmware updating tool.
 *
 * It is composed of
 *
 * - The libuxfp library: a static library that provides the firmware updater APIs
 * - The uxfp application binary: runnable UXFP updater application that uses libuxfp library.
 *
 * UXFP library interface can be used to compose a different firmware stream uploader than
 * the one provided in main.c
 *
 * Copyright (C) 2018  Telit Communication spa
 */

#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <telit-os-abs.h>
#include <inttypes.h>

#include "protocol.h"
#include "boot.h"
#include "diagnostic.h"
#include "stream.h"
#include "upload.h"

#include "uxfp.h"
#include "version.h"

#define USAGE \
        "usage:\n\
        uxfp --help\n\
        uxfp --file <path/to/stream/file> --show-diag-ports\n\
        uxfp --file <path/to/stream/file>\n\
        uxfp --file <path/to/stream/file> --port <path/to/device> [--debug] [--lossrecovery] [--noprogress]\n\
        uxfp --file <path/to/stream/file> --port <path/to/device> --serial [--debug] [--lossrecovery] [--noprogress]\n\
        uxfp --file <path/to/stream/file> --port <path/to/device> --serial --speed <baudrate> [--debug] [--lossrecovery] [--noprogress]\n"

struct {
    char port[MAX_FLAG_VALUE_LEN];
    char file[MAX_FLAG_VALUE_LEN];
    bool serial;
    uint64_t speed;
    bool debug;
    bool boot_mode;
    bool recovery;
    bool noprogress;
    bool show_connected_diag_ports;
    bool json;
    bool report;
    bool no_fastboot_driver;
    bool pci;
} options = {0};

flag_t flags [] = {
    {"--file", "-f", VALUE_TYPE_STRING, &options.file, REQ, "path to stream file"},
    {"--port", "-p", VALUE_TYPE_STRING, &options.port, OPT, "flashing port path (case sensitive)"},
    {"--serial", NULL, VALUE_TYPE_BOOLEAN, &options.serial, OPT,
     "the given port is a physical serial one (ignored if --port is not provided)"},
    {"--speed", "-s", VALUE_TYPE_ULONG, &options.speed, OPT,
     "serial speed [valid values 115200, 230400, 460800, 921600, 2000000, 3000000 ]"},
    {"--debug", "-d", VALUE_TYPE_BOOLEAN, &options.debug, OPT, "enable debug logging"},
    {"--boot-mode", "-b", VALUE_TYPE_BOOLEAN, &options.boot_mode, OPT, "put the device in boot mode"},
    {"--lossrecovery", "-l", VALUE_TYPE_BOOLEAN, &options.recovery, OPT, "device in recovery mode"},
    {"--no-fastboot-driver", NULL, VALUE_TYPE_BOOLEAN, &options.no_fastboot_driver, OPT,
     "No system driver takes care of the modem fastboot device (only if NO modem discovery)."},
    {"--noprogress", "-n", VALUE_TYPE_BOOLEAN, &options.noprogress, OPT,
     "do not show progress percent in non-debug mode (to use inside scripts)"},
    {"--show-diag-ports", "-w", VALUE_TYPE_BOOLEAN, &options.show_connected_diag_ports, OPT,
     "only show connected diagnostic ports and exit"},
    {"--json", "-j", VALUE_TYPE_BOOLEAN, &options.json, OPT,
     "log in JSON format (automatically enable --report)"},
    {"--report", NULL, VALUE_TYPE_BOOLEAN, &options.report, OPT,
     "final JSON report (do not enable --json automatically)"},
    {"--pci", NULL, VALUE_TYPE_BOOLEAN, &options.pci, OPT,
     "option to be used in case of PCIe-connected modem and automatic modem detection not available"},
    {NULL, NULL, VALUE_TYPE_UNKNOWN, NULL, OPT, NULL},
};


/* Final JSON report values */
struct {
    char json_type[MAX_JSON_MESSAGE_LEN];
    char stream_file[MAX_JSON_MESSAGE_LEN];
    char port[MAX_JSON_MESSAGE_LEN];
    int32_t channel;
    int32_t speed;
    char last_boot_step[MAX_JSON_MESSAGE_LEN];
    uint64_t upload_stream_off;
    int32_t upload_chunk;
    int32_t upload_perc;
    int32_t upload_return;
} report_values = {0};

json_t report_entries [] = {
    [REPORT_JSON_TYPE] = {"type", report_values.json_type, VALUE_TYPE_STRING },
    [REPORT_KEY_STREAM_FILE] = {"stream", report_values.stream_file, VALUE_TYPE_STRING },
    [REPORT_KEY_PORT] = {"port", &report_values.port, VALUE_TYPE_STRING },
    [REPORT_KEY_CHANNEL] = {"channel", &report_values.channel, VALUE_TYPE_INT },
    [REPORT_KEY_SPEED] = {"speed", &report_values.speed, VALUE_TYPE_INT },
    [REPORT_KEY_BOOT_STEP] = {"last_boot_step", &report_values.last_boot_step, VALUE_TYPE_STRING },
    [REPORT_KEY_UPLOAD_STREAM_OFF] = {"stream_offset", &report_values.upload_stream_off, VALUE_TYPE_ULONG },
    [REPORT_KEY_UPLOAD_CHUNK] = {"chunks", &report_values.upload_chunk, VALUE_TYPE_INT },
    [REPORT_KEY_UPLOAD_PERC] = {"percent", &report_values.upload_perc, VALUE_TYPE_INT },
    [REPORT_KEY_UPLOAD_RETURN] = {"upload_return", &report_values.upload_return, VALUE_TYPE_INT },
    [REPORT_KEY_LAST] = {NULL, NULL, VALUE_TYPE_UNKNOWN},
};

#define REPORT_STRING(key, value) if (options.report) { json_update(report_entries, key, value, \
        VALUE_TYPE_STRING); }
#define REPORT_INT(key, value) if (options.report) { json_update(report_entries, key, value, VALUE_TYPE_INT); \
}

static void print_help(flag_t *flags_arr);
static int32_t get_stream(const char *path_to_stream, const channel_t channel, stream_t *stream);
static int32_t get_contexts(protocol_t *protocol, const bool recovery, const bool report,
        boot_context_t *boot, upload_context_t *upload);
static void progress(const int64_t current, const int64_t max);
static void progress_json(const int64_t current, const int64_t max);
static int32_t diagnostic(chipset_t chipset, driver_t *driver, bool recovery);

static void print_version_string()
{
    ALOGI("UXFP version %s.%s.%s-%s\n", MAJOR, MINOR, PATCH, CUST);
    core_print_tosal_version();
}

int32_t check_options()
{
    if (options.boot_mode && options.recovery) {
        ALOGE("The --boot_mode option is incompatible with --lossrecovery option!\n");
        return 1;
    }

    return 0;
}

int main(int argc, char *argv[])
{
    int32_t err;
    chipset_t chipset = CHIPSET_UNKNOWN;
    channel_t channel = CHANNEL_SERIAL_USB;
    driver_t driver = {0};
    boot_context_t boot = {0};
    upload_context_t upload = {0};
    protocol_t protocol = {0};

    err = core_init();
    assert(!err);

    core_log_set_native(false);
    core_log_set_pprint(CORE_LOG_PPRINT_AUTONEWLINE);

    err = get_opts(argc, argv, flags);
    if (err) {
        print_help(flags);
        goto end;
    }

    if (options.debug)
        core_log_set_level(LOG_LEVEL_DBG);

    if (options.json) {
        options.report = true;
        core_log_set_pprint(CORE_LOG_PPRINT_JSON);
    }

    err = check_options();
    if (err)
        goto end;

    if (options.pci)
        channel = CHANNEL_SERIAL_PCI;

    print_version_string();
    ALOGI("options:\n");
    ALOGI("- stream file    : %s\n", options.file);

    REPORT_STRING(REPORT_JSON_TYPE, "REPORT");
    REPORT_STRING(REPORT_KEY_STREAM_FILE, options.file);

    if (strlen(options.port)) {
        ALOGI("- %s port    : %s\n", options.serial ? "serial" : "device", options.port);
        strlcpy(boot.dev_info.comm_ports[0], options.port, sizeof(boot.dev_info.comm_ports[0]));
        boot.dev_info.comm_ports_number = 1;
        REPORT_STRING(REPORT_KEY_PORT, options.port);
    }

    if (options.serial) {
        if (boot.dev_info.comm_ports_number == 0) {
            print_help(flags);
            ALOGE("serial flag requires flashing port\n");
            goto end;
        }

        channel = CHANNEL_SERIAL_PHY;
    }

    REPORT_STRING(REPORT_KEY_CHANNEL, (char *)get_channel_name(channel));

    if (options.speed) {
        switch (options.speed) {
            case SPEED_OPT_115200:
            case SPEED_OPT_230400:
            case SPEED_OPT_460800:
            case SPEED_OPT_921600:
            case SPEED_OPT_2000000:
            case SPEED_OPT_3000000:
            case SPEED_OPT_3200000:
            case SPEED_OPT_3750000:
                ALOGI("- speed          : %" PRIu64 "\n", options.speed);
                upload.wanted_speed = options.speed;
                break;
            default:
                print_help(flags);
                ALOGE("invalid serial speed %" PRIu64 "\n", options.speed);
                goto end;
        }
        REPORT_INT(REPORT_KEY_SPEED, &options.speed);
    }

    err = get_stream(options.file, channel, &upload.stream);
    if (err) {
        ALOGE("could not get stream from file %s: error %" PRIi32 "\n",
                options.file, err);
        goto end;
    }

    stream_print_content(&upload.stream);

    chipset = get_chipset_from_sw_version(upload.stream.base_sw_version);
    if (chipset == CHIPSET_UNKNOWN) {
        ALOGE("could not get chipset from sw version '%s'\n", upload.stream.base_sw_version);
        goto close_file;
    }

    err = get_driver(channel, chipset, &driver);
    if (err) {
        ALOGE("could not get driver for channel %u\n", channel);
        goto end;
    }

    if (options.show_connected_diag_ports) {
        diagnostic(chipset, &driver, options.recovery);
        goto close_file;
    }

    err = get_protocol_from_chipset(chipset, channel, &protocol);
    if (err)
        goto close_file;

    err = get_contexts(&protocol, options.recovery, options.report, &boot, &upload);
    if (err)
        goto close_file;

    boot.no_fastboot_driver = options.no_fastboot_driver;

    err = enter_boot_mode(&driver, &boot, options.boot_mode, &(upload.stream));
    if (err) {
        ALOGI("[+] could not complete boot mode\n");
        goto close_device;
    }

    if (options.boot_mode) {
        ALOGI("exiting without flashing [--boot-mode option]\n");
        goto close_device;
    }

    if (!options.noprogress)
        upload.progress = options.json ? progress_json : progress;

    if (boot.protocol->chipset == CHIPSET_ASR1601
            || boot.protocol->chipset == CHIPSET_ASR1603) {
        /* ASR requires a small delay in between ACK from boot mode and first upload chunk */
        core_sleep(100);
    }

    err = upload_firmware(&driver, &upload, &boot);
    if (err)
        ALOGI("[+] could not complete firmware upload\n");

close_device:
    driver.close(&driver);

close_file:
    core_file_close(upload.stream.handle);

    if (options.report)
        core_log_json(LOG_LEVEL_INFO, NULL, JSON_TYPE_CUSTOM, 0, &report_entries);

end:
    core_deinit();

    return err;
}

#define MAX_HELP_MSG_LINES 20
static void print_help(flag_t *flags_arr)
{
    uint8_t len;
    char help_message[MAX_HELP_MSG_LINES][MAX_HELP_MSG_LINE] = {0};
    uint8_t flags_size;

    for (flags_size = 0;
            flags_arr[flags_size].type != VALUE_TYPE_UNKNOWN;
            ++flags_size)
        ;

    len = compose_help_message(USAGE, flags_arr, flags_size, help_message, MAX_HELP_MSG_LINES);

    print_version_string();
    for (uint8_t i = 0; i < len; ++i) {
        ALOGI("%s\n", help_message[i]);
    }
}

static int32_t
get_stream(const char *path_to_stream, const channel_t channel, stream_t *stream)
{
    int32_t err;
    file_handle_t file;

    err = core_file_exists(path_to_stream);
    if (err) {
        ALOGE("could not open stream file '%s'\n", path_to_stream);
        goto end;
    }

    err = core_file_open(path_to_stream, &file);
    if (err) {
        ALOGE("could not open stream file '%s'\n", path_to_stream);
        goto end;
    }

    err = stream_get_from_file(file, channel, stream);
    if (err) {
        ALOGE("could not get stream header from handle\n");
        core_file_close(file);
    }

end:
    return err;
}

static int32_t
get_contexts(protocol_t *protocol, const bool recovery, const bool report, boot_context_t *boot,
        upload_context_t *upload)
{
    int32_t err = -1;
    chipset_t chipset = protocol->chipset;

    err = get_boot_context(protocol, recovery, boot);
    if (err) {
        ALOGE("could not get boot context for chipset %u (%s)\n",
                chipset, get_chipset_name(chipset));
        goto end;
    }

    err = get_upload_context(protocol, upload);
    if (err) {
        ALOGE("could not get upload context for chipset %u (%s)\n",
                chipset, get_chipset_name(chipset));
        goto end;
    }

    if (report) {
        boot->report_entries = report_entries;
        upload->report_entries = report_entries;
    }
end:
    return err;
}

#define BAR_LENGTH 20
#define BAR_STEP 5
static void progress(const int64_t current, const int64_t max)
{
    /* show an initial "-" to indicate trasfer has started even if
     * the first step has not reached yet */
    static char progressbar[BAR_LENGTH + 1] = "-                   ";
    int32_t cur_percent;

    if (core_log_get_level() == LOG_LEVEL_DBG)
        return;

    if (core_log_is_native())
        return;

    cur_percent = (100 * current) / max;
    if (cur_percent > BAR_STEP) {
        uint8_t arrow_idx = (cur_percent / BAR_STEP) % BAR_LENGTH;
        uint8_t bar_idx = (cur_percent / BAR_STEP) - 1;
        progressbar[bar_idx] = '=';
        if (arrow_idx > 0)
            progressbar[arrow_idx] = '-';
    }
    ALOGI("[+] flashing [%s] %3" PRIi32 "%%, transferred %6" PRIi64 "/%-6" PRIi64 " B\r",
            progressbar, cur_percent, current, max);
}

static void progress_json(const int64_t current, const int64_t max)
{
    static json_progress_t progress = {
        .current = 0,
        .max = 0,
        .description = "transferred bytes"
    };
    static int32_t percent = 0;
    int32_t cur_percent;

    cur_percent = (100 * current) / max;

    if (percent != cur_percent) {
        percent = cur_percent;
        progress.current = current;
        progress.max = max;
        core_log_json(LOG_LEVEL_INFO, __FILE__, JSON_TYPE_PROGRESS, __LINE__, (void *)&progress);
    }
}

static int32_t diagnostic(chipset_t chipset, driver_t *driver, bool is_recovery)
{
    int32_t err = CORE_SUCCESS;
    diagnostic_t diagnostic_devs[MAX_DEVICE_LIST_SIZE] = {0};
    int8_t diagnostic_devs_size = MAX_DEVICE_LIST_SIZE;
    usb_id_list_t *usb_ids;

    err = get_usb_ids_from_chipset(chipset, is_recovery, &usb_ids);
    if (!err)
        err = show_connected_diag_ports(driver, usb_ids->items,
                usb_ids->len, diagnostic_devs, &diagnostic_devs_size);

    switch (err) {
        case CORE_ERROR_NOT_IMPLEMENTED:
            ALOGI("[!] Modem diagnostic is not supported in this build\n");
            break;
        case CORE_ERROR_NO_SUCH_DEVICE:
            ALOGI("no device with compatible VID/PID has been found.\n");
            ALOGI("please connect a USB device and run this command again.\n");
            break;
        case CORE_SUCCESS:
            ALOGI("found %" PRIi8 " compatible modems\n", diagnostic_devs_size);

            for (int i = 0; i < diagnostic_devs_size; ++i) {
                ALOGI("%04" PRIX32 ":%04" PRIX32 " - serial number: %s - diag port: %s\n",
                        diagnostic_devs[i].usb_id.vid, diagnostic_devs[i].usb_id.pid,
                        diagnostic_devs[i].serial_number, diagnostic_devs[i].diagnostic_port_name);

            }
            break;
        default:
            break;
    }

    return err;
}
