#include <assert.h>
#include <stdbool.h>

#include "devices.h"

const char *get_diag_interface_number(const uint32_t pid)
{
    switch (pid) {
        case 0x0041:  /* INFINEON */
            return IFACE_NUMBER_01;
        case 0x1203:  /* MDM9x15 */
        case 0x1042:  /* LM9x0 */
        case 0x1052:  /* SDX55 */
        case 0x1056:  /* SDX55 */
        case 0x1062:  /* SDX12 */
        case 0x1072:  /* FN990A28 */
        case 0x7020:  /* QCX216 */
        case 0x7021:  /* QCX216 */
            return IFACE_NUMBER_02;
        case 0x7010:  /* ASR1601 */
        case 0x7011:  /* ASR1601 */
        case 0x701A:  /* ASR1603 */
        case 0x701B:  /* ASR1603 */
            return IFACE_NUMBER_03;
        default:
            return IFACE_NUMBER_00;
    }
}

bool is_pci_device(const dev_info_t *device)
{
    usb_id_t usbid;
    usb_id_list_t pci_devices = {2, {USBID_PCIE_FN980, USBID_PCIE_FN990}};

    if (!core_usb_id_from_str(&usbid, device->vendor_id, device->product_id)) {
        ALOGE("could not convert USB ids {vid:%s, pid:%s}\n", device->vendor_id, device->product_id);
        return false;
    }

    for (int i = 0; i < pci_devices.len; ++i) {
        if (core_usb_id_equals(&usbid, &pci_devices.items[i]))
            return true;
    }

    return false;
}
